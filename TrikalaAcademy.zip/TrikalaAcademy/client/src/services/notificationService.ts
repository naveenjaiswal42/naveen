import { showNotification, requestNotificationPermission } from '@/firebase';

// Function to check if notifications are supported by the browser
export const isNotificationSupported = (): boolean => {
  return 'Notification' in window;
};

// Function to check if notification permission has been granted
export const hasNotificationPermission = (): boolean => {
  return Notification.permission === 'granted';
};

export interface NotificationPreferences {
  enabled: boolean;
  morningTime: string;
  eveningTime: string;
  morningReminder: boolean;
  eveningReminder: boolean;
  meditationReminder: boolean;
  silentHours: {
    enabled: boolean;
    start: string;
    end: string;
  };
  types: {
    rituals: boolean;
    meditation: boolean;
    courses: boolean;
    achievements: boolean;
  }
}

// Get notification preferences from local storage
export const getNotificationPreferences = (): NotificationPreferences => {
  const defaultPreferences: NotificationPreferences = {
    enabled: false,
    morningTime: '08:00',
    eveningTime: '20:00',
    morningReminder: true,
    eveningReminder: true,
    meditationReminder: true,
    silentHours: {
      enabled: false,
      start: '22:00',
      end: '07:00'
    },
    types: {
      rituals: true,
      meditation: true,
      courses: true,
      achievements: true
    }
  };

  try {
    const savedPrefs = localStorage.getItem('notificationPreferences');
    if (savedPrefs) {
      return JSON.parse(savedPrefs);
    }
  } catch (error) {
    console.error('Error reading notification preferences from localStorage:', error);
  }

  return defaultPreferences;
};

// Save notification preferences to local storage
export const saveNotificationPreferences = (preferences: NotificationPreferences): boolean => {
  try {
    localStorage.setItem('notificationPreferences', JSON.stringify(preferences));
    return true;
  } catch (error) {
    console.error('Error saving notification preferences to localStorage:', error);
    return false;
  }
};

// Request permission and enable notifications
export const enableNotifications = async (): Promise<boolean> => {
  const permissionGranted = await requestNotificationPermission();
  
  if (permissionGranted) {
    const prefs = getNotificationPreferences();
    prefs.enabled = true;
    saveNotificationPreferences(prefs);
    
    // Send notification preferences to server
    try {
      const userId = localStorage.getItem('userId');
      if (userId) {
        await fetch(`/api/users/${userId}/notification-preferences`, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify(prefs),
        });
      }
    } catch (error) {
      console.error('Error updating notification preferences on server:', error);
    }
    
    return true;
  }
  
  return false;
};

// Disable notifications
export const disableNotifications = async (): Promise<boolean> => {
  try {
    const prefs = getNotificationPreferences();
    prefs.enabled = false;
    saveNotificationPreferences(prefs);
    
    // Send updated preferences to server
    const userId = localStorage.getItem('userId');
    if (userId) {
      await fetch(`/api/users/${userId}/notification-preferences`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(prefs),
      });
    }
    
    return true;
  } catch (error) {
    console.error('Error disabling notifications:', error);
    return false;
  }
};

// Update notification timing preferences
export const updateNotificationTiming = async (
  morningTime: string, 
  eveningTime: string
): Promise<boolean> => {
  try {
    const prefs = getNotificationPreferences();
    prefs.morningTime = morningTime;
    prefs.eveningTime = eveningTime;
    saveNotificationPreferences(prefs);
    
    // Send updated preferences to server
    const userId = localStorage.getItem('userId');
    if (userId) {
      await fetch(`/api/users/${userId}/notification-preferences`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(prefs),
      });
    }
    
    return true;
  } catch (error) {
    console.error('Error updating notification timing:', error);
    return false;
  }
};

// Update notification types
export const updateNotificationTypes = async (types: {
  rituals: boolean;
  meditation: boolean;
  courses: boolean;
  achievements: boolean;
}): Promise<boolean> => {
  try {
    const prefs = getNotificationPreferences();
    prefs.types = types;
    saveNotificationPreferences(prefs);
    
    // Send updated preferences to server
    const userId = localStorage.getItem('userId');
    if (userId) {
      await fetch(`/api/users/${userId}/notification-preferences`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(prefs),
      });
    }
    
    return true;
  } catch (error) {
    console.error('Error updating notification types:', error);
    return false;
  }
};

// Show a notification with the given title and message
export const sendNotification = (title: string, message: string): boolean => {
  const prefs = getNotificationPreferences();
  
  if (!prefs.enabled) {
    console.log('Notifications are disabled');
    return false;
  }
  
  return showNotification(title, message);
};

// Show a ritual reminder notification
export const sendRitualReminder = (isEvening: boolean = false): boolean => {
  const prefs = getNotificationPreferences();
  
  if (!prefs.enabled || !prefs.types.rituals) {
    return false;
  }
  
  const title = isEvening 
    ? "Evening Spiritual Practice" 
    : "Morning Spiritual Practice";
  
  const message = isEvening
    ? "Take time for your evening ritual to reflect and find inner peace."
    : "Begin your day with mindfulness and intention. Your morning ritual awaits.";
  
  return showNotification(title, message);
};

// Show a meditation reminder notification
export const sendMeditationReminder = (): boolean => {
  const prefs = getNotificationPreferences();
  
  if (!prefs.enabled || !prefs.types.meditation) {
    return false;
  }
  
  return showNotification(
    "Time to Meditate",
    "Take a few moments to center yourself and cultivate inner peace."
  );
};

// Show a course progress notification
export const sendCourseReminder = (courseName: string): boolean => {
  const prefs = getNotificationPreferences();
  
  if (!prefs.enabled || !prefs.types.courses) {
    return false;
  }
  
  return showNotification(
    "Continue Your Learning",
    `Your spiritual journey with "${courseName}" awaits. Continue where you left off.`
  );
};

// Show an achievement notification
export const sendAchievementNotification = (achievementTitle: string): boolean => {
  const prefs = getNotificationPreferences();
  
  if (!prefs.enabled || !prefs.types.achievements) {
    return false;
  }
  
  return showNotification(
    "New Achievement!",
    `Congratulations! You've earned "${achievementTitle}".`
  );
};