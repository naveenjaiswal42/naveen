/**
 * Streak Service for tracking user meditation and ritual streaks
 */

import { apiRequest } from '@/lib/queryClient';
import { format } from 'date-fns';

/**
 * Update user's daily meditation streak
 * @param {number} userId - User ID
 * @returns {Promise<number>} - Current streak count
 */
export const updateDailyStreak = async (userId) => {
  try {
    const today = format(new Date(), 'yyyy-MM-dd');
    
    // Call streak update endpoint
    const response = await apiRequest(`/api/users/${userId}/streak`, {
      method: 'POST',
      body: JSON.stringify({ date: today })
    });
    
    return response.streak || 0;
  } catch (error) {
    console.error('Error updating daily streak:', error);
    return 0;
  }
};

/**
 * Get user's current meditation streak
 * @param {number} userId - User ID
 * @returns {Promise<number>} - Current streak count
 */
export const getDailyStreak = async (userId) => {
  try {
    const response = await apiRequest(`/api/users/${userId}/streak`);
    return response.streak || 0;
  } catch (error) {
    console.error('Error getting streak:', error);
    return 0;
  }
};

// Add alias for getCurrentStreak to maintain compatibility with existing code
export const getCurrentStreak = getDailyStreak;

/**
 * Gets the user's current daily ritual streak
 * @param {number} userId The user's ID
 * @returns {Promise<number>} The current daily ritual streak count
 */
export const getDailyRitualStreak = async (userId) => {
  if (!userId) return 0;
  
  try {
    const response = await apiRequest(`/api/users/${userId}/ritual-streak`);
    return response.streak || 0;
  } catch (error) {
    console.error("Error getting daily ritual streak:", error);
    return 0;
  }
};

/**
 * Updates the user's daily ritual streak
 * @param {number} userId The user's ID
 * @returns {Promise<number>} The updated daily ritual streak count
 */
export const updateDailyRitualStreak = async (userId) => {
  if (!userId) return 0;
  
  try {
    const today = format(new Date(), 'yyyy-MM-dd');
    const response = await apiRequest(`/api/users/${userId}/ritual-streak`, {
      method: 'POST',
      body: JSON.stringify({ date: today })
    });
    
    return response.streak || 0;
  } catch (error) {
    console.error("Error updating daily ritual streak:", error);
    return 0;
  }
};