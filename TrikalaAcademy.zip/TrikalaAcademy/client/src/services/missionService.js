/**
 * Mission Service for handling daily missions and XP rewards
 * Provides functions for completing missions and tracking meditation streaks
 */

import { apiRequest } from '@/lib/queryClient';
import { useToast } from '@/hooks/use-toast';
import { useAuth } from '@/contexts/AuthContext';
import { format } from 'date-fns';

/**
 * Complete daily mission for user and award XP
 * Uses API endpoint instead of direct Firebase calls
 */
export const completeDailyMission = async (userId, xpAmount = 100) => {
  try {
    const today = format(new Date(), 'yyyy-MM-dd');
    
    const response = await apiRequest(`/api/users/${userId}/missions/daily`, {
      method: 'POST',
      body: JSON.stringify({
        date: today,
        xpAmount
      })
    });
    
    return response;
  } catch (error) {
    console.error('Error completing daily mission:', error);
    throw error;
  }
};

/**
 * Get user's meditation streak and badge information
 */
export const getUserStreak = async (userId) => {
  try {
    const response = await apiRequest(`/api/users/${userId}/streak`);
    return {
      streak: response.streak || 0,
      weeklyStreakAchieved: response.weeklyStreakAchieved || false,
      badges: response.badges || []
    };
  } catch (error) {
    console.error('Error getting user streak:', error);
    return {
      streak: 0,
      weeklyStreakAchieved: false,
      badges: []
    };
  }
};

/**
 * Check if user has earned weekly streak bonus
 */
export const checkWeeklyStreakBonus = async (userId) => {
  try {
    const streakInfo = await getUserStreak(userId);
    return streakInfo.weeklyStreakAchieved;
  } catch (error) {
    console.error('Error checking weekly streak bonus:', error);
    return false;
  }
};

/**
 * Complete meditation and update streak
 */
export const completeMeditation = async (userId, chakraType) => {
  try {
    // Award XP for meditation completion
    const missionResult = await completeDailyMission(userId);
    
    // Check if weekly streak bonus was achieved
    const streakInfo = await getUserStreak(userId);
    const weeklyStreakAchieved = streakInfo.weeklyStreakAchieved;
    
    // Return combined result
    return {
      success: true,
      xpAwarded: missionResult.awarded ? missionResult.xpAmount : 0,
      message: missionResult.message,
      chakraType,
      weeklyStreakAchieved,
      badges: streakInfo.badges || []
    };
  } catch (error) {
    console.error('Error completing meditation:', error);
    return {
      success: false,
      message: 'Failed to complete meditation',
      error: error.message,
      weeklyStreakAchieved: false,
      badges: []
    };
  }
};

/**
 * Hook to use mission functionality with integrated auth and toast
 */
export const useMissions = () => {
  const { user } = useAuth();
  const { toast } = useToast();
  
  const completeUserMeditation = async (chakraType) => {
    if (!user) {
      toast({
        title: "Not logged in",
        description: "Please log in to track your progress",
        variant: "destructive"
      });
      return { success: false };
    }
    
    try {
      const result = await completeMeditation(user.id, chakraType);
      
      if (result.success) {
        if (result.xpAwarded > 0) {
          toast({
            title: "Daily Mission Complete!",
            description: `You earned ${result.xpAwarded} XP for meditating today!`,
            variant: "success"
          });
        } else {
          toast({
            title: "Meditation Completed",
            description: result.message || "Your meditation has been recorded.",
          });
        }
        
        // Check if weekly streak bonus was achieved
        if (result.weeklyStreakAchieved) {
          toast({
            title: "🏆 Weekly Streak Achievement!",
            description: "You've completed 7 consecutive days of meditation! +500 XP + '7-Day Meditation Warrior' Badge Unlocked!",
            variant: "success",
            duration: 6000
          });
        }
      }
      
      return result;
    } catch (error) {
      console.error('Error in completeUserMeditation:', error);
      toast({
        title: "Error",
        description: "Failed to complete meditation tracking",
        variant: "destructive"
      });
      return { success: false, error: error.message };
    }
  };
  
  const getStreakInfo = async () => {
    if (!user) return { streak: 0, weeklyStreakAchieved: false, badges: [] };
    return getUserStreak(user.id);
  };
  
  return {
    completeUserMeditation,
    getUserStreak: user ? () => getUserStreak(user.id) : () => Promise.resolve({ streak: 0, badges: [] }),
    getStreakInfo,
    checkWeeklyStreakBonus: user ? () => checkWeeklyStreakBonus(user.id) : () => Promise.resolve(false)
  };
};