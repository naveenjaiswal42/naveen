import { apiRequest } from "@/lib/queryClient";

/**
 * Updates the user's daily meditation streak
 * @param userId The user's ID
 * @returns The updated streak count
 */
export const updateDailyStreak = async (userId: number): Promise<number> => {
  if (!userId) return 0;
  
  try {
    const response = await apiRequest<{ streak: number }>({
      url: `/api/users/${userId}/streak`,
      method: 'POST',
      body: {
        date: new Date().toISOString().split('T')[0] // YYYY-MM-DD
      }
    });
    
    return response.streak;
  } catch (error) {
    console.error("Error updating meditation streak:", error);
    return 0;
  }
};

/**
 * Gets the user's current meditation streak
 * @param userId The user's ID
 * @returns The current streak count
 */
export const getCurrentStreak = async (userId: number): Promise<number> => {
  if (!userId) return 0;
  
  try {
    const response = await apiRequest<{ streak: number }>({
      url: `/api/users/${userId}/streak`,
      method: 'GET'
    });
    
    return response.streak;
  } catch (error) {
    console.error("Error getting meditation streak:", error);
    return 0;
  }
};

/**
 * Gets the user's current daily ritual streak
 * @param userId The user's ID
 * @returns The current daily ritual streak count
 */
export const getDailyRitualStreak = async (userId: number): Promise<number> => {
  if (!userId) return 0;
  
  try {
    const response = await apiRequest<{ streak: number }>({
      url: `/api/users/${userId}/ritual-streak`,
      method: 'GET'
    });
    
    return response.streak;
  } catch (error) {
    console.error("Error getting daily ritual streak:", error);
    return 0;
  }
};

/**
 * Updates the user's daily ritual streak
 * @param userId The user's ID
 * @returns The updated daily ritual streak count
 */
export const updateDailyRitualStreak = async (userId: number): Promise<number> => {
  if (!userId) return 0;
  
  try {
    const response = await apiRequest<{ streak: number }>({
      url: `/api/users/${userId}/ritual-streak`,
      method: 'POST',
      body: {
        date: new Date().toISOString().split('T')[0] // YYYY-MM-DD
      }
    });
    
    return response.streak;
  } catch (error) {
    console.error("Error updating daily ritual streak:", error);
    return 0;
  }
};