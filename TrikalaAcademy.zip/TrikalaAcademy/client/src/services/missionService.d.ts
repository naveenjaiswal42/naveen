/**
 * Type definitions for the mission service
 */

interface MissionResult {
  success: boolean;
  xpAwarded?: number;
  message?: string;
  chakraType?: string;
  weeklyStreakAchieved?: boolean;
  badges?: string[];
  error?: string;
}

interface StreakInfo {
  streak: number;
  weeklyStreakAchieved: boolean;
  badges: string[];
}

declare module '@/services/missionService' {
  export function completeDailyMission(userId: number, xpAmount?: number): Promise<any>;
  export function getUserStreak(userId: number): Promise<StreakInfo>;
  export function checkWeeklyStreakBonus(userId: number): Promise<boolean>;
  export function completeMeditation(userId: number, chakraType: string): Promise<MissionResult>;
  export function useMissions(): {
    completeUserMeditation: (chakraType: string) => Promise<MissionResult>;
    getUserStreak: () => Promise<StreakInfo>;
    getStreakInfo: () => Promise<StreakInfo>;
    checkWeeklyStreakBonus: () => Promise<boolean>;
  };
}