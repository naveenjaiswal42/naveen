// This is a re-export to maintain compatibility with the components
// that still use @/hooks/use-auth instead of @/contexts/AuthContext

import { useAuth as _useAuth } from "../contexts/AuthContext";

export const useAuth = _useAuth;