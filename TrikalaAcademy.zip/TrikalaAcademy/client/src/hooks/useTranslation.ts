import { useState } from 'react';
import { SupportedLanguages, translate, englishTranslations } from '../lib/translations';

// Custom hook for translations
// NOTE: Temporarily forced to English only as per user request
export function useTranslation() {
  // Always use English language (language system is temporarily disabled)
  const [language] = useState<SupportedLanguages>('en');
  
  // Mock setLanguage function that doesn't do anything
  const setLanguage = (newLanguage: SupportedLanguages) => {
    console.log('Language switching temporarily disabled, staying in English');
    // Do nothing - always stay in English
  };

  // Translation function - always use English translations
  const t = (key: keyof typeof englishTranslations, params?: Record<string, string>) => {
    return translate(key, 'en', params);
  };

  return {
    language: 'en' as SupportedLanguages,
    setLanguage,
    t
  };
}