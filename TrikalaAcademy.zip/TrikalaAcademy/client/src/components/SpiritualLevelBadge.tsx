import { Star, Award } from "lucide-react";

export interface SpiritualLevelBadgeProps {
  xp: number;
  size?: 'sm' | 'md' | 'lg';
  showXp?: boolean;
  showTooltip?: boolean;
  className?: string;
}

// XP levels and corresponding titles
export const SPIRITUAL_LEVELS = [
  { minXp: 0, maxXp: 499, name: "Beginner", color: "bg-gray-400 dark:bg-gray-600", textColor: "text-white", description: "Taking first steps on your spiritual path", icon: "🌱" },
  { minXp: 500, maxXp: 1999, name: "Seeker", color: "bg-indigo-400 dark:bg-indigo-600", textColor: "text-white", description: "Actively seeking spiritual knowledge and growth", icon: "🔍" },
  { minXp: 2000, maxXp: 4999, name: "Awakened", color: "bg-purple-500 dark:bg-purple-700", textColor: "text-white", description: "Experiencing heightened spiritual awareness", icon: "✨" },
  { minXp: 5000, maxXp: 9999, name: "Ascended", color: "bg-pink-500 dark:bg-pink-700", textColor: "text-white", description: "Elevated consciousness and deeper spiritual connection", icon: "🌟" },
  { minXp: 10000, maxXp: Infinity, name: "Master", color: "bg-amber-400 dark:bg-amber-600", textColor: "text-white", description: "Achieved mastery of spiritual practices and wisdom", icon: "⭐" },
];

// Helper function to get the current level based on XP
export const getCurrentLevel = (xp: number) => {
  return SPIRITUAL_LEVELS.find(level => xp >= level.minXp && xp <= level.maxXp) || SPIRITUAL_LEVELS[0];
};

// Helper function to get the next level based on XP
export const getNextLevel = (xp: number) => {
  const currentLevelIndex = SPIRITUAL_LEVELS.findIndex(level => xp >= level.minXp && xp <= level.maxXp);
  if (currentLevelIndex < SPIRITUAL_LEVELS.length - 1) {
    return SPIRITUAL_LEVELS[currentLevelIndex + 1];
  }
  return null; // No next level (reached max)
};

export default function SpiritualLevelBadge({ 
  xp, 
  size = 'md', 
  showXp = false, 
  showTooltip = true,
  className = ""
}: SpiritualLevelBadgeProps) {
  const currentLevel = getCurrentLevel(xp);
  
  // Size classes
  const sizeClasses = {
    sm: "px-2 py-1 text-xs",
    md: "px-3 py-1.5 text-sm",
    lg: "px-4 py-2 text-base"
  };
  
  // Simple badge without tooltip
  return (
    <div className={`inline-flex items-center gap-1.5 rounded-full ${currentLevel.color} ${currentLevel.textColor} font-medium shadow-sm ${sizeClasses[size]} ${className}`}>
      <span className="mr-1">{currentLevel.icon}</span>
      {currentLevel.name}
      {showXp && (
        <span className="ml-1 opacity-80 text-xs">
          {xp.toLocaleString()} XP
        </span>
      )}
    </div>
  );
}