import { useState, useEffect } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import PhoneNumberInput from "./PhoneNumberInput";
import OtpInput from "./OtpInput";
import { setupRecaptcha, sendOtp, verifyOtp } from "@/lib/firebase";
import { useToast } from "@/hooks/use-toast";
import Logo from "@/components/ui/logo";

// Feature cards for welcome screen
const features = [
  { icon: "fas fa-om", label: "Chakra Meditation" },
  { icon: "fas fa-book", label: "Spiritual Courses" },
  { icon: "fas fa-star", label: "Daily Rituals" },
  { icon: "fas fa-spa", label: "Healing Practices" },
  { icon: "fas fa-moon", label: "Astrology Guidance" },
  { icon: "fas fa-hands", label: "Energy Healing" },
];

const AuthContainer = () => {
  const [phoneNumber, setPhoneNumber] = useState("");
  const [showOtpInput, setShowOtpInput] = useState(false);
  const [loading, setLoading] = useState(false);
  const { toast } = useToast();

  useEffect(() => {
    // Initialize recaptcha when component mounts
    const recaptchaContainer = document.createElement("div");
    recaptchaContainer.id = "recaptcha-container";
    document.body.appendChild(recaptchaContainer);
    
    setupRecaptcha("recaptcha-container");
    
    return () => {
      // Clean up recaptcha container on unmount
      if (document.getElementById("recaptcha-container")) {
        document.getElementById("recaptcha-container")?.remove();
      }
    };
  }, []);

  const handleGetOtp = async () => {
    if (phoneNumber.length !== 10) {
      toast({
        title: "Invalid Phone Number",
        description: "Please enter a valid 10-digit phone number",
        variant: "destructive",
      });
      return;
    }

    setLoading(true);
    
    try {
      const formattedPhoneNumber = `+91${phoneNumber}`;
      const result = await sendOtp(formattedPhoneNumber);
      
      if (result.success) {
        setShowOtpInput(true);
        toast({
          title: "OTP Sent",
          description: "A verification code has been sent to your phone",
        });
      } else {
        toast({
          title: "Failed to send OTP",
          description: "Please try again later",
          variant: "destructive",
        });
      }
    } catch (error) {
      console.error("Error sending OTP:", error);
      toast({
        title: "Error",
        description: "Something went wrong. Please try again.",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  const handleVerifyOtp = async (otp: string) => {
    setLoading(true);
    
    try {
      const result = await verifyOtp(otp);
      
      if (result.success) {
        toast({
          title: "Authentication Successful",
          description: "Welcome to Trikala Academy",
        });
        // Auth state change will automatically redirect user
      } else {
        toast({
          title: "Invalid OTP",
          description: "Please enter the correct verification code",
          variant: "destructive",
        });
      }
    } catch (error) {
      console.error("Error verifying OTP:", error);
      toast({
        title: "Error",
        description: "Something went wrong. Please try again.",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  const handleResendOtp = async () => {
    setLoading(true);
    
    try {
      // Reset recaptcha
      setupRecaptcha("recaptcha-container");
      
      // Resend OTP
      const formattedPhoneNumber = `+91${phoneNumber}`;
      const result = await sendOtp(formattedPhoneNumber);
      
      if (result.success) {
        toast({
          title: "OTP Resent",
          description: "A new verification code has been sent to your phone",
        });
      } else {
        toast({
          title: "Failed to resend OTP",
          description: "Please try again later",
          variant: "destructive",
        });
      }
    } catch (error) {
      console.error("Error resending OTP:", error);
      toast({
        title: "Error",
        description: "Something went wrong. Please try again.",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex flex-col">
      <div className="flex-1 flex items-center justify-center p-4 md:p-8">
        <div className="w-full max-w-md">
          {/* Logo and Branding */}
          <div className="text-center mb-8">
            <Logo className="w-32 h-32 mx-auto" />
            <h1 className="font-heading font-bold text-3xl mt-4 text-primary dark:text-primary">
              Trikala Academy
            </h1>
            <p className="text-gray-600 dark:text-gray-300 mt-2">
              Spiritual Learning & Growth Platform
            </p>
          </div>

          {/* Authentication Card */}
          <Card className="mb-6">
            <CardContent className="pt-6 p-8">
              <div className="space-y-6">
                <h2 className="text-2xl font-heading font-semibold text-gray-800 dark:text-white text-center">
                  Welcome Back
                </h2>

                {/* Phone Input */}
                <PhoneNumberInput 
                  value={phoneNumber} 
                  onChange={setPhoneNumber} 
                />

                {/* OTP Input (Conditionally shown) */}
                {showOtpInput && (
                  <div>
                    <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                      Enter OTP
                    </label>
                    <OtpInput 
                      onComplete={handleVerifyOtp} 
                    />
                    <p className="text-sm text-gray-500 dark:text-gray-400 mt-2 text-center">
                      Didn't receive code?{" "}
                      <button 
                        className="text-primary dark:text-primary-400 font-medium"
                        onClick={handleResendOtp}
                        disabled={loading}
                      >
                        Resend OTP
                      </button>
                    </p>
                  </div>
                )}

                {/* Action Button */}
                <Button 
                  className="w-full py-6" 
                  onClick={showOtpInput ? undefined : handleGetOtp}
                  disabled={loading || (!showOtpInput && phoneNumber.length !== 10)}
                >
                  {loading ? "Please Wait..." : showOtpInput ? "Verify OTP" : "Get OTP"}
                </Button>
              </div>
            </CardContent>
          </Card>

          {/* App Features Preview */}
          <div className="grid grid-cols-3 gap-3 mb-8">
            {features.map((feature, index) => (
              <div key={index} className="bg-white dark:bg-gray-800 rounded-lg p-3 text-center shadow-sm">
                <div className="w-10 h-10 bg-primary-100 dark:bg-primary-900 rounded-full flex items-center justify-center mx-auto mb-2">
                  <i className={`${feature.icon} text-primary dark:text-primary-400`}></i>
                </div>
                <p className="text-xs font-medium text-gray-700 dark:text-gray-300">
                  {feature.label}
                </p>
              </div>
            ))}
          </div>

          {/* Privacy Policy */}
          <p className="text-xs text-center text-gray-500 dark:text-gray-400">
            By continuing, you agree to our{" "}
            <a href="#" className="text-primary dark:text-primary-400">
              Terms of Service
            </a>{" "}
            and{" "}
            <a href="#" className="text-primary dark:text-primary-400">
              Privacy Policy
            </a>
          </p>
        </div>
      </div>
    </div>
  );
};

export default AuthContainer;
