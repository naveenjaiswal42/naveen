import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { ChangeEvent, useState } from "react";

interface PhoneNumberInputProps {
  onChange: (phoneNumber: string) => void;
  value: string;
}

const PhoneNumberInput = ({ onChange, value }: PhoneNumberInputProps) => {
  // Format phone number as user types
  const handlePhoneChange = (e: ChangeEvent<HTMLInputElement>) => {
    const input = e.target.value;
    
    // Only allow digits
    const digits = input.replace(/\D/g, "");
    
    // Format as Indian phone number (max 10 digits)
    let formattedPhone = digits.slice(0, 10);
    
    onChange(formattedPhone);
  };

  return (
    <div>
      <Label htmlFor="phone" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
        Phone Number
      </Label>
      <div className="relative">
        <div className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none">
          <span className="text-gray-500 dark:text-gray-400">+91</span>
        </div>
        <Input
          type="tel"
          id="phone"
          value={value}
          onChange={handlePhoneChange}
          className="pl-12"
          placeholder="Enter your phone number"
        />
      </div>
    </div>
  );
};

export default PhoneNumberInput;
