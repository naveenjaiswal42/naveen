import { useState } from "react";
import html2canvas from "html2canvas";
import { Button } from "@/components/ui/button";
import { Share2, Download } from "lucide-react";

interface BadgeShareCardProps {
  badgeTitle: string;
  badgeDescription: string;
  earnedDate?: string;
  badgeIcon?: string;
  badgeColor?: string;
}

export default function BadgeShareCard({
  badgeTitle,
  badgeDescription,
  earnedDate,
  badgeIcon = "🏆",
  badgeColor = "indigo"
}: BadgeShareCardProps) {
  const [isDownloading, setIsDownloading] = useState(false);

  const downloadBadge = async () => {
    try {
      setIsDownloading(true);
      const card = document.getElementById("badge-card");
      if (!card) return;
      
      const canvas = await html2canvas(card, {
        backgroundColor: null,
        scale: 2,
        logging: false,
        allowTaint: true,
        useCORS: true
      });
      
      const link = document.createElement("a");
      link.download = `${badgeTitle.replace(/\s+/g, '-').toLowerCase()}-badge.png`;
      link.href = canvas.toDataURL("image/png");
      link.click();
    } catch (error) {
      console.error("Error downloading badge:", error);
    } finally {
      setIsDownloading(false);
    }
  };

  const shareBadge = async () => {
    try {
      setIsDownloading(true);
      const card = document.getElementById("badge-card");
      if (!card) return;
      
      const canvas = await html2canvas(card, {
        backgroundColor: null,
        scale: 2,
        logging: false,
        allowTaint: true,
        useCORS: true
      });
      
      const blob = await new Promise<Blob>((resolve) => {
        canvas.toBlob((blob) => {
          resolve(blob as Blob);
        }, "image/png");
      });
      
      if (navigator.share) {
        await navigator.share({
          title: `My ${badgeTitle} Badge from Trikala Academy`,
          text: `I earned the ${badgeTitle} badge at Trikala Academy! ${badgeDescription}`,
          files: [new File([blob], `${badgeTitle.replace(/\s+/g, '-').toLowerCase()}-badge.png`, { type: "image/png" })]
        });
      } else {
        // Fallback for browsers that don't support Web Share API
        downloadBadge();
      }
    } catch (error) {
      console.error("Error sharing badge:", error);
      // Fallback to download if sharing fails
      downloadBadge();
    } finally {
      setIsDownloading(false);
    }
  };

  // Dynamically determine badge background color
  const getBadgeColorClass = () => {
    const colors: Record<string, string> = {
      indigo: "bg-indigo-100 border-indigo-300 text-indigo-800",
      purple: "bg-purple-100 border-purple-300 text-purple-800",
      blue: "bg-blue-100 border-blue-300 text-blue-800",
      green: "bg-green-100 border-green-300 text-green-800",
      red: "bg-red-100 border-red-300 text-red-800",
      orange: "bg-orange-100 border-orange-300 text-orange-800",
      yellow: "bg-yellow-100 border-yellow-300 text-yellow-800"
    };
    
    return colors[badgeColor] || colors.indigo;
  };

  return (
    <div className="flex flex-col items-center my-6">
      <div
        id="badge-card"
        className={`p-8 rounded-xl text-center shadow-lg w-80 border-2 ${getBadgeColorClass()}`}
      >
        <div className="text-4xl mb-3">{badgeIcon}</div>
        <h2 className="text-2xl font-bold mb-4">{badgeTitle}</h2>
        <p className="text-gray-700 mb-6">{badgeDescription}</p>
        {earnedDate && (
          <p className="text-sm text-gray-600 mb-3">Earned on {earnedDate}</p>
        )}
        <div className="border-t pt-4 mt-2 border-gray-200">
          <p className="text-sm flex items-center justify-center gap-2">
            <span className="text-lg">⚛️</span> Trikala Academy
          </p>
        </div>
      </div>

      <div className="flex gap-3 mt-6">
        <Button
          onClick={downloadBadge}
          disabled={isDownloading}
          className="flex items-center gap-2"
        >
          <Download size={18} />
          Download Badge
        </Button>
        
        <Button
          onClick={shareBadge}
          disabled={isDownloading}
          variant="outline"
          className="flex items-center gap-2"
        >
          <Share2 size={18} />
          Share Badge
        </Button>
      </div>
    </div>
  );
}