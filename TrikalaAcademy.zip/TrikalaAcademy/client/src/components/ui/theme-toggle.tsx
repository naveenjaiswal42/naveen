import { Moon, Sun } from "lucide-react";
import { useTheme } from "../ui/theme-provider";
import { Button } from "@/components/ui/button";
import { useEffect, useState } from "react";

interface ThemeToggleProps {
  mode?: "light" | "dark" | "auto";
}

export function ThemeToggle({ mode = "auto" }: ThemeToggleProps) {
  const { theme, setTheme } = useTheme();
  const [mounted, setMounted] = useState(false);

  // Avoid hydration mismatch by only rendering after mount
  useEffect(() => {
    setMounted(true);
  }, []);

  const toggleTheme = () => {
    setTheme(theme === "dark" ? "light" : "dark");
  };

  if (!mounted) {
    return <Button variant="ghost" size="icon" className="w-9 h-9" />;
  }
  
  // Determine button style based on mode
  const buttonStyle = mode === "dark" 
    ? "w-9 h-9 text-white/80 hover:text-white transition-all duration-300 transform hover:scale-105 hover:bg-white/10 rounded-full" 
    : "w-9 h-9 text-gray-600 dark:text-gray-300 transition-all duration-300 transform hover:scale-105 hover:bg-gray-100 dark:hover:bg-gray-800 rounded-full";

  return (
    <Button 
      variant="ghost" 
      size="icon" 
      onClick={toggleTheme}
      className={buttonStyle}
    >
      {theme === "dark" ? (
        <Sun className="h-[1.2rem] w-[1.2rem] transition-transform duration-300" />
      ) : (
        <Moon className="h-[1.2rem] w-[1.2rem] transition-transform duration-300 hover:rotate-12" />
      )}
      <span className="sr-only">Toggle theme</span>
    </Button>
  );
}