import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Select, SelectContent, SelectGroup, SelectItem, SelectLabel, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import { getChakraRecommendations } from "@/lib/openai";
import { Loader2, FlameKindling } from "lucide-react";
import { type ChakraType, chakras } from "@/lib/chakras";

export default function ChakraRecommendations() {
  const [selectedChakra, setSelectedChakra] = useState<ChakraType | "">("");
  const [experience, setExperience] = useState<"beginner" | "intermediate" | "advanced">("beginner");
  const [recommendations, setRecommendations] = useState<{
    affirmations: string[];
    practices: string[];
    dietRecommendations: string[];
  } | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const { toast } = useToast();

  const handleGetRecommendations = async () => {
    if (!selectedChakra) {
      toast({
        title: "Selection Required",
        description: "Please select a chakra to receive recommendations.",
        variant: "destructive",
      });
      return;
    }

    setIsLoading(true);
    try {
      const result = await getChakraRecommendations(selectedChakra, experience);
      setRecommendations(result);
    } catch (error) {
      console.error("Error getting chakra recommendations:", error);
      toast({
        title: "Connection Error",
        description: "Unable to retrieve recommendations. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  // Find the selected chakra info
  const chakraInfo = chakras.find(c => c.id === selectedChakra);

  return (
    <Card className="w-full max-w-3xl mx-auto">
      <CardHeader className={`bg-primary/5 border-b`}>
        <div className="flex items-center gap-2">
          <FlameKindling className="h-5 w-5 text-primary" />
          <CardTitle>Personalized Chakra Recommendations</CardTitle>
        </div>
        <CardDescription>
          Receive personalized affirmations, practices, and nutrition recommendations for balancing your chakras
        </CardDescription>
      </CardHeader>
      <CardContent className="pt-6">
        <div className="flex flex-col sm:flex-row gap-4 mb-6">
          <div className="flex-1">
            <label className="text-sm font-medium mb-2 block">Select Chakra</label>
            <Select value={selectedChakra} onValueChange={(value) => setSelectedChakra(value as ChakraType)}>
              <SelectTrigger>
                <SelectValue placeholder="Choose a chakra" />
              </SelectTrigger>
              <SelectContent>
                <SelectGroup>
                  <SelectLabel>Chakras</SelectLabel>
                  {chakras.map((chakra) => (
                    <SelectItem key={chakra.id} value={chakra.id}>
                      <span className="flex items-center gap-2">
                        <span className={`h-3 w-3 rounded-full`} style={{ backgroundColor: chakra.color }}></span>
                        {chakra.name}
                      </span>
                    </SelectItem>
                  ))}
                </SelectGroup>
              </SelectContent>
            </Select>
          </div>
          
          <div className="flex-1">
            <label className="text-sm font-medium mb-2 block">Experience Level</label>
            <Select value={experience} onValueChange={(value) => setExperience(value as "beginner" | "intermediate" | "advanced")}>
              <SelectTrigger>
                <SelectValue placeholder="Choose your level" />
              </SelectTrigger>
              <SelectContent>
                <SelectGroup>
                  <SelectLabel>Experience Level</SelectLabel>
                  <SelectItem value="beginner">Beginner</SelectItem>
                  <SelectItem value="intermediate">Intermediate</SelectItem>
                  <SelectItem value="advanced">Advanced</SelectItem>
                </SelectGroup>
              </SelectContent>
            </Select>
          </div>
        </div>
        
        <div className="flex justify-center">
          <Button onClick={handleGetRecommendations} disabled={isLoading || !selectedChakra}>
            {isLoading ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                Generating recommendations...
              </>
            ) : (
              'Get Personalized Recommendations'
            )}
          </Button>
        </div>

        {recommendations && chakraInfo && (
          <div className="mt-8 grid gap-6">
            <div 
              className="p-4 rounded-lg" 
              style={{ backgroundColor: `${chakraInfo.color}15` /* 15% opacity */ }}
            >
              <h3 className="text-lg font-semibold mb-3" style={{ color: chakraInfo.color }}>
                {chakraInfo.name} Chakra ({chakraInfo.frequency})
              </h3>
              <p className="text-sm mb-3">{chakraInfo.description}</p>
              <p className="text-sm mb-1"><strong>Element:</strong> {chakraInfo.element}</p>
              <p className="text-sm"><strong>Affirmation:</strong> {chakraInfo.affirmation}</p>
            </div>
            
            <div className="grid sm:grid-cols-3 gap-4">
              <div className="bg-muted/50 rounded-lg p-4">
                <h4 className="font-medium mb-2">Affirmations</h4>
                <ul className="space-y-1 text-sm">
                  {recommendations.affirmations.map((affirmation, i) => (
                    <li key={i} className="list-disc ml-4">{affirmation}</li>
                  ))}
                </ul>
              </div>
              
              <div className="bg-muted/50 rounded-lg p-4">
                <h4 className="font-medium mb-2">Practices</h4>
                <ul className="space-y-1 text-sm">
                  {recommendations.practices.map((practice, i) => (
                    <li key={i} className="list-disc ml-4">{practice}</li>
                  ))}
                </ul>
              </div>
              
              <div className="bg-muted/50 rounded-lg p-4">
                <h4 className="font-medium mb-2">Nutrition</h4>
                <ul className="space-y-1 text-sm">
                  {recommendations.dietRecommendations.map((diet, i) => (
                    <li key={i} className="list-disc ml-4">{diet}</li>
                  ))}
                </ul>
              </div>
            </div>
          </div>
        )}
      </CardContent>
      <CardFooter className="text-xs text-muted-foreground border-t pt-4">
        <div className="flex items-center gap-1">
          <FlameKindling className="h-3 w-3" />
          <span>Personalized recommendations based on ancient chakra wisdom</span>
        </div>
      </CardFooter>
    </Card>
  );
}