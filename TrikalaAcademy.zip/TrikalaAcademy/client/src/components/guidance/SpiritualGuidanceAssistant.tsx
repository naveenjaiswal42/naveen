import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { useToast } from "@/hooks/use-toast";
import { getSpiritualGuidance } from "@/lib/openai";
import { Loader2, Send, Sparkles } from "lucide-react";

export default function SpiritualGuidanceAssistant() {
  const [query, setQuery] = useState("");
  const [response, setResponse] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const { toast } = useToast();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!query.trim()) {
      toast({
        title: "Empty Question",
        description: "Please enter your spiritual question.",
        variant: "destructive",
      });
      return;
    }

    setIsLoading(true);
    try {
      const guidance = await getSpiritualGuidance(query);
      setResponse(guidance);
    } catch (error) {
      console.error("Error getting spiritual guidance:", error);
      toast({
        title: "Connection Error",
        description: "Unable to connect to the wisdom source. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <Card className="w-full max-w-3xl mx-auto">
      <CardHeader className="bg-primary/5 border-b">
        <div className="flex items-center gap-2">
          <Sparkles className="h-5 w-5 text-primary" />
          <CardTitle>Spiritual Guidance Assistant</CardTitle>
        </div>
        <CardDescription>
          Ask questions about meditation, chakras, spiritual practices, or seek guidance on your spiritual journey
        </CardDescription>
      </CardHeader>
      <CardContent className="pt-6">
        <form onSubmit={handleSubmit} className="space-y-4">
          <Textarea
            placeholder="What spiritual guidance do you seek today?"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            className="min-h-[100px] resize-none"
          />
          
          <div className="flex justify-end">
            <Button type="submit" disabled={isLoading}>
              {isLoading ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Connecting to wisdom...
                </>
              ) : (
                <>
                  <Send className="mr-2 h-4 w-4" />
                  Ask for Guidance
                </>
              )}
            </Button>
          </div>
        </form>

        {response && (
          <div className="mt-6 p-4 bg-muted/50 rounded-lg">
            <h3 className="text-sm font-semibold text-muted-foreground mb-2">Divine Guidance:</h3>
            <div className="prose prose-sm">
              {response.split('\n').map((paragraph, i) => (
                <p key={i} className="mb-2">{paragraph}</p>
              ))}
            </div>
          </div>
        )}
      </CardContent>
      <CardFooter className="text-xs text-muted-foreground border-t pt-4">
        <div className="flex items-center gap-1">
          <Sparkles className="h-3 w-3" />
          <span>Powered by spiritual wisdom and modern AI technology</span>
        </div>
      </CardFooter>
    </Card>
  );
}