import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import { generateSpiritualGrowthPlan } from "@/lib/openai";
import { Loader2, TreePine, CalendarCheck, BookOpenText } from "lucide-react";
import { useAuth } from "@/contexts/AuthContext";

export default function SpiritualGrowthPlanner() {
  const { user } = useAuth();
  const [formData, setFormData] = useState({
    currentPractice: "",
    goal: "",
    timeAvailable: "15-30 minutes"
  });
  const [growthPlan, setGrowthPlan] = useState<{
    dailyPractices: string[];
    weeklyPractices: string[];
    monthlyMilestones: string[];
    resources: string[];
  } | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const { toast } = useToast();

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleSelectChange = (name: string, value: string) => {
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!formData.goal.trim()) {
      toast({
        title: "Missing Information",
        description: "Please share your spiritual growth goal.",
        variant: "destructive",
      });
      return;
    }

    setIsLoading(true);
    try {
      const plan = await generateSpiritualGrowthPlan({
        name: user?.name || "Spiritual Seeker",
        currentPractice: formData.currentPractice,
        goal: formData.goal,
        timeAvailable: formData.timeAvailable
      });
      setGrowthPlan(plan);
    } catch (error) {
      console.error("Error generating growth plan:", error);
      toast({
        title: "Connection Error",
        description: "Unable to generate your growth plan. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <Card className="w-full max-w-3xl mx-auto">
      <CardHeader className="bg-primary/5 border-b">
        <div className="flex items-center gap-2">
          <TreePine className="h-5 w-5 text-primary" />
          <CardTitle>Spiritual Growth Planner</CardTitle>
        </div>
        <CardDescription>
          Generate a personalized spiritual practice plan based on your goals and available time
        </CardDescription>
      </CardHeader>
      <CardContent className="pt-6">
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-2">
            <label htmlFor="currentPractice" className="text-sm font-medium">
              Current Spiritual Practice (if any)
            </label>
            <Input
              id="currentPractice"
              name="currentPractice"
              placeholder="E.g., occasional meditation, yoga, prayer"
              value={formData.currentPractice}
              onChange={handleChange}
            />
          </div>
          
          <div className="space-y-2">
            <label htmlFor="goal" className="text-sm font-medium">
              Your Spiritual Growth Goal <span className="text-red-500">*</span>
            </label>
            <Textarea
              id="goal"
              name="goal"
              placeholder="E.g., deepen meditation practice, find inner peace, connect with higher self"
              value={formData.goal}
              onChange={handleChange}
              required
              className="min-h-[100px]"
            />
          </div>
          
          <div className="space-y-2">
            <label htmlFor="timeAvailable" className="text-sm font-medium">
              Daily Time Available for Practice <span className="text-red-500">*</span>
            </label>
            <Select 
              value={formData.timeAvailable} 
              onValueChange={(value) => handleSelectChange('timeAvailable', value)}
            >
              <SelectTrigger>
                <SelectValue placeholder="Select available time" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="5-10 minutes">5-10 minutes</SelectItem>
                <SelectItem value="15-30 minutes">15-30 minutes</SelectItem>
                <SelectItem value="30-60 minutes">30-60 minutes</SelectItem>
                <SelectItem value="1-2 hours">1-2 hours</SelectItem>
                <SelectItem value="2+ hours">2+ hours</SelectItem>
              </SelectContent>
            </Select>
          </div>
          
          <div className="flex justify-center pt-2">
            <Button type="submit" disabled={isLoading}>
              {isLoading ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Creating your plan...
                </>
              ) : (
                <>Generate My Spiritual Plan</>
              )}
            </Button>
          </div>
        </form>

        {growthPlan && (
          <div className="mt-8 space-y-6">
            <h3 className="text-xl font-medium text-center text-primary">Your Spiritual Growth Plan</h3>
            
            <div className="grid gap-4 sm:grid-cols-2">
              <Card>
                <CardHeader className="py-3">
                  <div className="flex items-center gap-2">
                    <CalendarCheck className="h-4 w-4 text-primary" />
                    <CardTitle className="text-base">Daily Practices</CardTitle>
                  </div>
                </CardHeader>
                <CardContent>
                  <ul className="space-y-1">
                    {growthPlan.dailyPractices.map((practice, i) => (
                      <li key={i} className="list-disc ml-4 text-sm">{practice}</li>
                    ))}
                  </ul>
                </CardContent>
              </Card>
              
              <Card>
                <CardHeader className="py-3">
                  <div className="flex items-center gap-2">
                    <CalendarCheck className="h-4 w-4 text-primary" />
                    <CardTitle className="text-base">Weekly Practices</CardTitle>
                  </div>
                </CardHeader>
                <CardContent>
                  <ul className="space-y-1">
                    {growthPlan.weeklyPractices.map((practice, i) => (
                      <li key={i} className="list-disc ml-4 text-sm">{practice}</li>
                    ))}
                  </ul>
                </CardContent>
              </Card>
            </div>
            
            <Card>
              <CardHeader className="py-3">
                <div className="flex items-center gap-2">
                  <CalendarCheck className="h-4 w-4 text-primary" />
                  <CardTitle className="text-base">Monthly Milestones</CardTitle>
                </div>
              </CardHeader>
              <CardContent>
                <ul className="space-y-1">
                  {growthPlan.monthlyMilestones.map((milestone, i) => (
                    <li key={i} className="list-disc ml-4 text-sm">{milestone}</li>
                  ))}
                </ul>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader className="py-3">
                <div className="flex items-center gap-2">
                  <BookOpenText className="h-4 w-4 text-primary" />
                  <CardTitle className="text-base">Recommended Resources</CardTitle>
                </div>
              </CardHeader>
              <CardContent>
                <ul className="space-y-1">
                  {growthPlan.resources.map((resource, i) => (
                    <li key={i} className="list-disc ml-4 text-sm">{resource}</li>
                  ))}
                </ul>
              </CardContent>
            </Card>
          </div>
        )}
      </CardContent>
      <CardFooter className="text-xs text-muted-foreground border-t pt-4">
        <div className="flex items-center gap-1">
          <TreePine className="h-3 w-3" />
          <span>Your personalized plan adapts to your spiritual path and grows with you</span>
        </div>
      </CardFooter>
    </Card>
  );
}