import { useState, useRef, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Slider } from "@/components/ui/slider";
import { Card, CardContent } from "@/components/ui/card";
import { ChakraType, getChakraFrequency } from "@/lib/chakras";
import { useToast } from "@/hooks/use-toast";
import { Play, Pause, Volume2, Volume1, VolumeX } from "lucide-react";
import { apiRequest } from "@/lib/queryClient";
import { MeditationTrack } from "@shared/schema";

interface MeditationPlayerProps {
  selectedChakra: ChakraType;
}

const MeditationPlayer = ({ selectedChakra }: MeditationPlayerProps) => {
  const [tracks, setTracks] = useState<MeditationTrack[]>([]);
  const [currentTrack, setCurrentTrack] = useState<MeditationTrack | null>(null);
  const [isPlaying, setIsPlaying] = useState(false);
  const [currentTime, setCurrentTime] = useState(0);
  const [duration, setDuration] = useState(0);
  const [volume, setVolume] = useState(0.7);
  const [loading, setLoading] = useState(true);
  
  const audioRef = useRef<HTMLAudioElement | null>(null);
  const { toast } = useToast();

  // Fetch tracks for the selected chakra
  useEffect(() => {
    const fetchTracks = async () => {
      setLoading(true);
      try {
        // Use our API to get meditation tracks by chakra type
        const tracksData = await apiRequest<MeditationTrack[]>({
          url: `/api/meditation-tracks?chakraType=${selectedChakra}`,
          method: 'GET'
        });
        
        setTracks(tracksData);
        
        // Set default track if available
        if (tracksData.length > 0) {
          setCurrentTrack(tracksData[0]);
        }
      } catch (error) {
        console.error("Error fetching meditation tracks:", error);
        toast({
          title: "Error",
          description: "Failed to load meditation tracks",
          variant: "destructive",
        });
      } finally {
        setLoading(false);
      }
    };
    
    fetchTracks();
  }, [selectedChakra]);

  // Handle track change
  useEffect(() => {
    if (currentTrack && audioRef.current) {
      // Get the audio URL
      const getAudio = async () => {
        try {
          // Set audio source directly
          audioRef.current!.src = currentTrack.audioUrl;
          audioRef.current!.volume = volume;
          
          if (isPlaying) {
            audioRef.current!.play();
          }
        } catch (error) {
          console.error("Error loading audio:", error);
          toast({
            title: "Audio Error",
            description: "Could not load the meditation audio",
            variant: "destructive",
          });
        }
      };
      
      getAudio();
    }
  }, [currentTrack]);

  // Handle play/pause
  useEffect(() => {
    if (audioRef.current) {
      if (isPlaying) {
        audioRef.current.play().catch(error => {
          console.error("Playback error:", error);
          setIsPlaying(false);
          toast({
            title: "Playback Error",
            description: "Could not play the meditation audio",
            variant: "destructive",
          });
        });
      } else {
        audioRef.current.pause();
      }
    }
  }, [isPlaying]);

  // Update volume
  useEffect(() => {
    if (audioRef.current) {
      audioRef.current.volume = volume;
    }
  }, [volume]);

  const handlePlayPause = () => {
    setIsPlaying(!isPlaying);
  };

  const handleTimeUpdate = () => {
    if (audioRef.current) {
      setCurrentTime(audioRef.current.currentTime);
      setDuration(audioRef.current.duration);
    }
  };

  const handleEnded = () => {
    setIsPlaying(false);
    setCurrentTime(0);
    
    // Auto-play next track if available
    if (tracks.length > 1) {
      const currentIndex = tracks.findIndex(track => track.id === currentTrack?.id);
      const nextIndex = (currentIndex + 1) % tracks.length;
      setCurrentTrack(tracks[nextIndex]);
      setIsPlaying(true);
    }
  };

  const handleVolumeChange = (newValue: number[]) => {
    const volumeValue = newValue[0];
    setVolume(volumeValue);
  };

  const formatTime = (timeInSeconds: number): string => {
    const minutes = Math.floor(timeInSeconds / 60);
    const seconds = Math.floor(timeInSeconds % 60);
    return `${minutes}:${seconds < 10 ? '0' : ''}${seconds}`;
  };

  const handleSeek = (newValue: number[]) => {
    const seekTime = newValue[0];
    setCurrentTime(seekTime);
    if (audioRef.current) {
      audioRef.current.currentTime = seekTime;
    }
  };

  const getVolumeIcon = () => {
    if (volume === 0) {
      return <VolumeX className="h-4 w-4" />;
    } else if (volume < 0.5) {
      return <Volume1 className="h-4 w-4" />;
    } else {
      return <Volume2 className="h-4 w-4" />;
    }
  };

  if (loading) {
    return (
      <Card>
        <CardContent className="pt-6 text-center">
          <p className="text-gray-500 dark:text-gray-400">
            Loading meditation tracks...
          </p>
        </CardContent>
      </Card>
    );
  }

  if (tracks.length === 0) {
    return (
      <Card>
        <CardContent className="pt-6 text-center">
          <p className="text-gray-500 dark:text-gray-400">
            No meditation tracks available for this chakra
          </p>
        </CardContent>
      </Card>
    );
  }

  return (
    <div>
      <audio
        ref={audioRef}
        onTimeUpdate={handleTimeUpdate}
        onLoadedMetadata={handleTimeUpdate}
        onEnded={handleEnded}
      />
      
      <Card className="overflow-hidden">
        <div className="relative h-48 bg-gradient-to-b from-primary/30 to-primary/10 flex items-center justify-center">
          {currentTrack?.imageUrl ? (
            <img 
              src={currentTrack.imageUrl} 
              alt={currentTrack.title} 
              className="w-full h-full object-cover opacity-80"
            />
          ) : (
            <div className="w-24 h-24 rounded-full bg-primary/30 flex items-center justify-center text-primary">
              <i className="fas fa-om text-4xl"></i>
            </div>
          )}
          <div className="absolute inset-0 flex items-center justify-center">
            <div className="w-16 h-16 rounded-full bg-primary flex items-center justify-center cursor-pointer" onClick={handlePlayPause}>
              {isPlaying ? (
                <Pause className="h-8 w-8 text-white" />
              ) : (
                <Play className="h-8 w-8 text-white ml-1" />
              )}
            </div>
          </div>
        </div>
        
        <CardContent className="pt-4">
          <div className="text-center mb-4">
            <h3 className="text-lg font-medium text-gray-800 dark:text-white">
              {currentTrack?.title || "Meditation Track"}
            </h3>
            <p className="text-sm text-gray-500 dark:text-gray-400">
              {getChakraFrequency(selectedChakra)} frequency
            </p>
          </div>
          
          {/* Time slider */}
          <div className="mb-4">
            <Slider
              value={[currentTime]}
              max={duration || 100}
              step={1}
              onValueChange={handleSeek}
              className="mb-2"
            />
            <div className="flex justify-between text-xs text-gray-500 dark:text-gray-400">
              <span>{formatTime(currentTime)}</span>
              <span>{formatTime(duration)}</span>
            </div>
          </div>
          
          {/* Volume control */}
          <div className="flex items-center mt-4">
            <Button 
              variant="ghost" 
              size="icon" 
              className="text-gray-500"
              onClick={() => setVolume(volume === 0 ? 0.7 : 0)}
            >
              {getVolumeIcon()}
            </Button>
            <Slider
              value={[volume]}
              max={1}
              step={0.01}
              onValueChange={handleVolumeChange}
              className="ml-2"
            />
          </div>
          
          {/* Track selection */}
          {tracks.length > 1 && (
            <div className="mt-6">
              <h4 className="text-sm font-medium mb-2 text-gray-700 dark:text-gray-300">
                Other Tracks:
              </h4>
              <div className="space-y-2">
                {tracks.map(track => (
                  <Button
                    key={track.id}
                    variant={track.id === currentTrack?.id ? "default" : "outline"}
                    size="sm"
                    className="w-full justify-start text-left"
                    onClick={() => {
                      setCurrentTrack(track);
                      setIsPlaying(true);
                    }}
                  >
                    <i className={`fas fa-${track.id === currentTrack?.id ? 'play' : 'music'} mr-2`}></i>
                    {track.title}
                  </Button>
                ))}
              </div>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
};

export default MeditationPlayer;
