import { useRef, useEffect, useState } from 'react';

interface AudioGeneratorProps {
  frequency: number;
  isPlaying: boolean;
  onEnded: () => void;
  duration?: number;
  gain?: number;
}

export function AudioGenerator({ 
  frequency, 
  isPlaying, 
  onEnded, 
  duration = 10, 
  gain = 0.3 
}: AudioGeneratorProps) {
  const audioContextRef = useRef<AudioContext | null>(null);
  const oscillatorRef = useRef<OscillatorNode | null>(null);
  const gainNodeRef = useRef<GainNode | null>(null);
  const timerRef = useRef<NodeJS.Timeout | null>(null);
  const [secondsLeft, setSecondsLeft] = useState(duration);

  // Create and configure audio context
  useEffect(() => {
    // Initialize only once
    if (!audioContextRef.current) {
      audioContextRef.current = new (window.AudioContext || (window as any).webkitAudioContext)();
    }
    
    return () => {
      // Clean up oscillator
      if (oscillatorRef.current) {
        oscillatorRef.current.stop();
        oscillatorRef.current.disconnect();
        oscillatorRef.current = null;
      }
      
      // Clear timer
      if (timerRef.current) {
        clearTimeout(timerRef.current);
      }
    };
  }, []);

  // Handle play/pause
  useEffect(() => {
    const audioContext = audioContextRef.current;
    if (!audioContext) return;
    
    // Resume audio context if it's suspended (browser policy requires user interaction)
    if (audioContext.state === 'suspended') {
      audioContext.resume();
    }
    
    if (isPlaying) {
      // Create oscillator and gain node
      const oscillator = audioContext.createOscillator();
      const gainNode = audioContext.createGain();
      
      // Configure oscillator
      oscillator.type = 'sine';
      oscillator.frequency.value = frequency;
      
      // Configure gain (volume)
      gainNode.gain.value = gain;
      
      // Connect nodes
      oscillator.connect(gainNode);
      gainNode.connect(audioContext.destination);
      
      // Start oscillator
      oscillator.start();
      
      // Save references
      oscillatorRef.current = oscillator;
      gainNodeRef.current = gainNode;
      
      // Set up timer for duration
      setSecondsLeft(duration);
      const updateTimer = () => {
        setSecondsLeft((prev) => {
          if (prev <= 1) {
            // Stop audio and call onEnded when time is up
            if (oscillatorRef.current) {
              oscillatorRef.current.stop();
              oscillatorRef.current.disconnect();
              oscillatorRef.current = null;
            }
            onEnded();
            return 0;
          }
          // Continue countdown
          timerRef.current = setTimeout(updateTimer, 1000);
          return prev - 1;
        });
      };
      
      // Start timer
      timerRef.current = setTimeout(updateTimer, 1000);
    } else {
      // Stop oscillator on pause
      if (oscillatorRef.current) {
        oscillatorRef.current.stop();
        oscillatorRef.current.disconnect();
        oscillatorRef.current = null;
      }
      
      // Clear timer
      if (timerRef.current) {
        clearTimeout(timerRef.current);
      }
    }
    
    return () => {
      // Clean up oscillator
      if (oscillatorRef.current) {
        oscillatorRef.current.stop();
        oscillatorRef.current.disconnect();
        oscillatorRef.current = null;
      }
      
      // Clear timer
      if (timerRef.current) {
        clearTimeout(timerRef.current);
      }
    };
  }, [isPlaying, frequency, duration, gain, onEnded]);

  return null; // This component doesn't render anything
}