import { useState } from "react";
import { useChakras } from "@/contexts/ChakraContext";
import { chakras as chakraData, ChakraType } from "@/lib/chakras";
import { Button } from "@/components/ui/button";
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "@/components/ui/tooltip";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { useToast } from "@/hooks/use-toast";

const ChakraVisualization = () => {
  const { chakras, activateChakra } = useChakras();
  const [selectedChakra, setSelectedChakra] = useState<ChakraType>("root");
  const { toast } = useToast();

  const handleChakraClick = (chakraId: ChakraType) => {
    setSelectedChakra(chakraId);
  };

  const handleActivateChakra = async () => {
    if (chakras[selectedChakra]) {
      toast({
        title: "Already Activated",
        description: `Your ${selectedChakra} chakra is already activated.`,
      });
      return;
    }

    try {
      await activateChakra(selectedChakra);
      toast({
        title: "Chakra Activated",
        description: `You have successfully activated your ${selectedChakra} chakra!`,
      });
    } catch (error) {
      console.error("Error activating chakra:", error);
      toast({
        title: "Activation Failed",
        description: "Unable to activate chakra. Please try again.",
        variant: "destructive",
      });
    }
  };

  const chakraInfo = chakraData.find((c) => c.id === selectedChakra);

  return (
    <div className="grid md:grid-cols-2 gap-6">
      {/* Chakra Visualization */}
      <div className="relative">
        <div className="aspect-square w-full max-w-md mx-auto relative">
          {/* SVG Chakra visualization */}
          <svg viewBox="0 0 500 500" className="w-full h-full">
            {/* Background circular pattern */}
            <circle cx="250" cy="250" r="240" fill="none" stroke="hsl(var(--primary) / 0.1)" strokeWidth="2" />
            <circle cx="250" cy="250" r="200" fill="none" stroke="hsl(var(--primary) / 0.15)" strokeWidth="2" />
            <circle cx="250" cy="250" r="160" fill="none" stroke="hsl(var(--primary) / 0.2)" strokeWidth="2" />
            
            {/* Radiating lines */}
            {Array.from({ length: 24 }).map((_, i) => {
              const angle = (i * 15) * Math.PI / 180;
              const x1 = 250 + 120 * Math.cos(angle);
              const y1 = 250 + 120 * Math.sin(angle);
              const x2 = 250 + 240 * Math.cos(angle);
              const y2 = 250 + 240 * Math.sin(angle);
              
              return (
                <line 
                  key={i} 
                  x1={x1} 
                  y1={y1} 
                  x2={x2} 
                  y2={y2} 
                  stroke="hsl(var(--primary) / 0.1)" 
                  strokeWidth="1" 
                />
              );
            })}
            
            {/* Chakra circles */}
            {chakraData.map((chakra, index) => {
              const angle = ((index * 360) / chakraData.length) * Math.PI / 180;
              const distance = 150; // Distance from center
              const x = 250 + distance * Math.cos(angle - Math.PI/2); // Start from top (- Math.PI/2)
              const y = 250 + distance * Math.sin(angle - Math.PI/2);
              
              return (
                <g 
                  key={chakra.id} 
                  className="cursor-pointer transform transition-transform duration-300 hover:scale-110"
                  onClick={() => handleChakraClick(chakra.id)}
                >
                  <circle 
                    cx={x} 
                    cy={y} 
                    r="25" 
                    className={chakra.color.replace('bg-', 'fill-')}
                    opacity={chakras[chakra.id] ? 1 : 0.5} 
                  />
                  <text 
                    x={x} 
                    y={y} 
                    textAnchor="middle" 
                    dominantBaseline="middle" 
                    fill="white" 
                    fontSize="12"
                  >
                    <tspan x={x} y={y} dominantBaseline="middle" textAnchor="middle">
                      {chakra.id.charAt(0).toUpperCase()}
                    </tspan>
                  </text>
                </g>
              );
            })}
            
            {/* Center - Aura */}
            <circle 
              cx="250" 
              cy="250" 
              r="50" 
              fill="url(#auraGradient)" 
              filter="blur(5px)"
            />
            
            {/* Definition for aura gradient */}
            <defs>
              <radialGradient id="auraGradient" cx="50%" cy="50%" r="50%" fx="50%" fy="50%">
                <stop offset="0%" stopColor="hsl(var(--primary) / 0.8)" />
                <stop offset="100%" stopColor="hsl(var(--primary) / 0)" />
              </radialGradient>
            </defs>
          </svg>
          
          {/* Om symbol overlay in center */}
          <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
            <div className="w-24 h-24 flex items-center justify-center text-white">
              <i className="fas fa-om text-4xl opacity-70"></i>
            </div>
          </div>
        </div>
      </div>
      
      {/* Chakra Information Panel */}
      <Card className="overflow-hidden">
        <CardHeader className={`${chakraInfo?.color.replace('bg-', 'bg-')} text-white`}>
          <CardTitle className="flex items-center gap-2">
            <i className={`${chakraInfo?.icon} mr-2`}></i>
            {chakraInfo?.name} Chakra
          </CardTitle>
          <CardDescription className="text-white/80">
            {chakraInfo?.frequency} • {chakraInfo?.element} Element
          </CardDescription>
        </CardHeader>
        <CardContent className="pt-6">
          <div className="mb-4">
            <p className="text-gray-800 dark:text-gray-200">
              {chakraInfo?.description}
            </p>
            
            <div className="mt-4">
              <h4 className="font-medium text-gray-800 dark:text-gray-200 mb-1">Affirmation:</h4>
              <p className="italic text-gray-600 dark:text-gray-400">
                "{chakraInfo?.affirmation}"
              </p>
            </div>
          </div>
          
          <div className="mt-6">
            <Button 
              className="w-full" 
              onClick={handleActivateChakra}
              disabled={chakras[selectedChakra]}
              variant={chakras[selectedChakra] ? "outline" : "default"}
            >
              {chakras[selectedChakra] ? (
                <>
                  <i className="fas fa-check mr-2"></i>
                  Activated
                </>
              ) : (
                <>
                  <i className="fas fa-om mr-2"></i>
                  Activate this Chakra
                </>
              )}
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default ChakraVisualization;
