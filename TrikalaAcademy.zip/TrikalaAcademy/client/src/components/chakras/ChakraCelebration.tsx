import { useEffect, useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { ChakraType } from '@/lib/chakras';

interface ChakraCelebrationProps {
  chakraName: string;
  chakraType: ChakraType;
  onClose: () => void;
}

export default function ChakraCelebration({ chakraName, chakraType, onClose }: ChakraCelebrationProps) {
  const [particles, setParticles] = useState<{ id: number; x: number; y: number; size: number; color: string }[]>([]);
  
  // Generate celebration particles
  useEffect(() => {
    // Create particles for celebration effect
    const newParticles = Array.from({ length: 50 }, (_, i) => ({
      id: i,
      x: Math.random() * 100,
      y: Math.random() * 100,
      size: Math.random() * 10 + 5,
      color: getChakraColor(chakraType)
    }));
    
    setParticles(newParticles);
    
    // Auto close after 3 seconds
    const timer = setTimeout(() => {
      onClose();
    }, 3000);
    
    return () => clearTimeout(timer);
  }, [chakraType, onClose]);
  
  // Get chakra color for particles
  const getChakraColor = (type: ChakraType): string => {
    switch (type) {
      case "root": return "#e53e3e";
      case "sacral": return "#ed8936";
      case "solar": return "#ecc94b";
      case "heart": return "#48bb78";
      case "throat": return "#4299e1";
      case "thirdEye": return "#667eea";
      case "crown": return "#9f7aea";
      default: return "#a0aec0";
    }
  };
  
  // Get background gradient based on chakra
  const getGradient = (type: ChakraType): string => {
    switch (type) {
      case "root": return "from-red-50 via-white to-red-50";
      case "sacral": return "from-orange-50 via-white to-orange-50";
      case "solar": return "from-yellow-50 via-white to-yellow-50";
      case "heart": return "from-green-50 via-white to-green-50";
      case "throat": return "from-blue-50 via-white to-blue-50";
      case "thirdEye": return "from-indigo-50 via-white to-indigo-50";
      case "crown": return "from-purple-50 via-white to-purple-50";
      default: return "from-gray-50 via-white to-gray-50";
    }
  };
  
  // Get text color based on chakra
  const getTextColor = (type: ChakraType): string => {
    switch (type) {
      case "root": return "text-red-600";
      case "sacral": return "text-orange-600";
      case "solar": return "text-yellow-600";
      case "heart": return "text-green-600";
      case "throat": return "text-blue-600";
      case "thirdEye": return "text-indigo-600";
      case "crown": return "text-purple-600";
      default: return "text-gray-600";
    }
  };

  return (
    <AnimatePresence>
      <motion.div 
        className={`fixed inset-0 flex items-center justify-center z-50 bg-gradient-radial ${getGradient(chakraType)} bg-opacity-95 backdrop-blur-sm`}
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
      >
        {/* Particles */}
        {particles.map((particle) => (
          <motion.div
            key={particle.id}
            className="absolute rounded-full"
            style={{
              width: particle.size,
              height: particle.size,
              backgroundColor: particle.color,
              left: `${particle.x}%`,
              top: `${particle.y}%`,
              opacity: 0.7,
            }}
            initial={{ scale: 0, opacity: 0 }}
            animate={{
              scale: [0, 1.5, 1],
              opacity: [0, 0.8, 0],
              x: Math.random() * 200 - 100,
              y: Math.random() * 200 - 100,
              transition: { 
                duration: 2 + Math.random(),
                repeat: Infinity,
                repeatType: "loop"
              }
            }}
          />
        ))}
        
        {/* Center celebration content */}
        <motion.div 
          className="text-center p-12 rounded-xl bg-white bg-opacity-70 backdrop-blur-lg shadow-2xl z-10"
          initial={{ scale: 0.8, y: 20 }}
          animate={{ scale: 1, y: 0 }}
          transition={{ type: "spring", damping: 10, stiffness: 100 }}
        >
          <motion.div
            initial={{ rotate: -5, scale: 0.9 }}
            animate={{ rotate: 5, scale: 1.1 }}
            transition={{ duration: 0.5, repeat: Infinity, repeatType: "reverse" }}
            className="mb-6 text-6xl"
          >
            ✨
          </motion.div>
          
          <motion.h1 
            className={`text-4xl font-bold mb-6 ${getTextColor(chakraType)}`}
            initial={{ y: -20 }}
            animate={{ y: 0 }}
            transition={{ type: "spring", damping: 10 }}
          >
            {chakraName} चक्र सक्रिय हुआ!
          </motion.h1>
          
          <motion.div
            style={{ backgroundColor: getChakraColor(chakraType) }}
            className={`w-16 h-16 rounded-full mx-auto mb-6 flex items-center justify-center`}
            initial={{ rotate: 0 }}
            animate={{ rotate: 360 }}
            transition={{ duration: 3, repeat: 1 }}
          >
            <div className="w-10 h-10 rounded-full bg-white opacity-30"></div>
          </motion.div>
          
          <motion.p 
            className="text-lg text-gray-700"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.3 }}
          >
            बधाई हो! आपने नई आध्यात्मिक ऊर्जा को जगा दिया है!
          </motion.p>
          
          <motion.p 
            className={`mt-2 text-md ${getTextColor(chakraType)}`}
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.5 }}
          >
            +500 XP अर्जित किए
          </motion.p>
        </motion.div>
      </motion.div>
    </AnimatePresence>
  );
}