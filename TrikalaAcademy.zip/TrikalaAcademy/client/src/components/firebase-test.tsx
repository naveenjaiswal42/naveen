import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Label } from '@/components/ui/label';
import { Input } from '@/components/ui/input';

// Fake user storage - in a real app, this would be a proper auth solution
const LOCAL_STORAGE_KEY = 'trikala_auth_user';

// Development-only simple auth system
export default function LocalAuthTest() {
  const [phoneNumber, setPhoneNumber] = useState('');
  const [otp, setOtp] = useState('');
  const [step, setStep] = useState<'phone' | 'otp' | 'success'>('phone');
  const [status, setStatus] = useState<string>('Development Mode: Login with any phone number and OTP 123456');
  const [user, setUser] = useState<any>(null);

  // Load user from localStorage on component mount
  useEffect(() => {
    const savedUser = localStorage.getItem(LOCAL_STORAGE_KEY);
    if (savedUser) {
      try {
        const parsedUser = JSON.parse(savedUser);
        setUser(parsedUser);
        setStep('success');
      } catch (e) {
        localStorage.removeItem(LOCAL_STORAGE_KEY);
      }
    }
  }, []);

  const handleSendOtp = () => {
    if (phoneNumber.length < 10) {
      setStatus('Please enter a valid phone number');
      return;
    }

    // In dev mode, always move to OTP step
    setStep('otp');
    setStatus('⚠️ DEVELOPMENT MODE: Use code 123456');
  };

  const handleVerifyOtp = () => {
    if (otp.length < 6) {
      setStatus('Please enter a 6 digit OTP');
      return;
    }

    // In development mode, accept 123456 as valid OTP
    if (otp === '123456') {
      const mockUser = {
        uid: 'dev-user-123',
        phoneNumber: phoneNumber,
        displayName: 'Dev User',
        metadata: {
          creationTime: new Date().toISOString(),
          lastSignInTime: new Date().toISOString()
        }
      };
      
      setUser(mockUser);
      setStep('success');
      setStatus('Successfully authenticated');
      
      // Save to localStorage for persistence
      localStorage.setItem(LOCAL_STORAGE_KEY, JSON.stringify(mockUser));
      
      // Trigger an event that the AuthContext can listen for
      window.dispatchEvent(new CustomEvent('localAuthStateChanged', { detail: { user: mockUser } }));
    } else {
      setStatus('⚠️ Invalid OTP. In development mode, use 123456');
    }
  };

  const handleLogout = () => {
    setUser(null);
    setStep('phone');
    setPhoneNumber('');
    setOtp('');
    setStatus('Development Mode: Logged out successfully');
    
    // Clear localStorage
    localStorage.removeItem(LOCAL_STORAGE_KEY);
    
    // Trigger logout event
    window.dispatchEvent(new CustomEvent('localAuthStateChanged', { detail: { user: null } }));
  };

  return (
    <div className="container max-w-md mx-auto p-4">
      <Card className="w-full">
        <CardHeader>
          <CardTitle className="text-center">Trikala Academy</CardTitle>
        </CardHeader>
        <CardContent>
          {status && (
            <div className={`mb-4 p-2 rounded text-sm ${status.includes('Invalid') ? 'bg-red-100 text-red-700' : 'bg-amber-100 text-amber-700'}`}>
              {status}
            </div>
          )}
          
          {step === 'phone' && (
            <div className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="phone">Phone Number</Label>
                <Input
                  id="phone"
                  type="tel"
                  placeholder="Enter phone number (e.g. 9123456789)"
                  value={phoneNumber}
                  onChange={(e) => setPhoneNumber(e.target.value)}
                />
              </div>
              <Button className="w-full" onClick={handleSendOtp}>
                Send OTP
              </Button>
            </div>
          )}
          
          {step === 'otp' && (
            <div className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="otp">One-Time Password</Label>
                <Input
                  id="otp"
                  type="text"
                  placeholder="Enter 6-digit OTP (use 123456)"
                  value={otp}
                  onChange={(e) => setOtp(e.target.value)}
                />
              </div>
              <Button className="w-full" onClick={handleVerifyOtp}>
                Verify OTP
              </Button>
              <Button 
                variant="outline" 
                className="w-full"
                onClick={() => setStep('phone')}
              >
                Back
              </Button>
            </div>
          )}
          
          {step === 'success' && user && (
            <div className="space-y-4">
              <div className="p-4 bg-green-50 rounded-md">
                <h3 className="font-medium text-green-800">Authentication Successful!</h3>
                <div className="mt-2 text-sm text-green-700">
                  <p>User ID: {user.uid}</p>
                  <p>Phone: {user.phoneNumber}</p>
                </div>
              </div>
              <Button variant="destructive" className="w-full" onClick={handleLogout}>
                Logout
              </Button>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}