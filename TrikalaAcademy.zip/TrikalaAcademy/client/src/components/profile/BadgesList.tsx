import { useAuth } from "@/contexts/AuthContext";

interface User {
  id: number;
  phone: string;
  name?: string;
  profile_image?: string;
  level: number;
  xp: number;
  badges?: string[];
}
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Award, Medal } from "lucide-react";

interface BadgesListProps {
  user: User | null;
}

const badgeDescriptions: Record<string, { description: string, color: string }> = {
  "7-Day Meditation Warrior": {
    description: "Completed 7 consecutive days of meditation practice",
    color: "text-yellow-500"
  },
  "Spiritual Titan": {
    description: "Completed 30 consecutive days of meditation practice",
    color: "text-purple-500"
  },
  // Add more badges as they're created
};

export function BadgesList({ user }: BadgesListProps) {
  if (!user || !user.badges || user.badges.length === 0) {
    return (
      <Card className="mb-6">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Award className="h-5 w-5 text-indigo-500" />
            Spiritual Achievements
          </CardTitle>
          <CardDescription>
            You haven't earned any badges yet. Complete your spiritual practices regularly to unlock achievements.
          </CardDescription>
        </CardHeader>
      </Card>
    );
  }

  return (
    <Card className="mb-6">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Award className="h-5 w-5 text-indigo-500" />
          Spiritual Achievements
        </CardTitle>
        <CardDescription>
          Your journey has been rewarded with these spiritual badges
        </CardDescription>
      </CardHeader>
      <CardContent>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {user.badges.map((badge: string, index: number) => {
            const badgeInfo = badgeDescriptions[badge] || {
              description: "A special achievement on your spiritual journey",
              color: "text-indigo-500"
            };
            
            return (
              <div 
                key={index} 
                className="flex items-center gap-3 p-3 bg-gradient-to-r from-gray-50 to-white dark:from-gray-800 dark:to-gray-900 rounded-lg border border-gray-100 dark:border-gray-800"
              >
                <div className={`${badgeInfo.color} bg-gray-100 dark:bg-gray-800 p-2 rounded-full`}>
                  <Medal className="h-6 w-6" />
                </div>
                <div>
                  <h3 className="text-sm font-semibold">{badge}</h3>
                  <p className="text-xs text-gray-500 dark:text-gray-400">{badgeInfo.description}</p>
                </div>
              </div>
            );
          })}
        </div>
      </CardContent>
    </Card>
  );
}