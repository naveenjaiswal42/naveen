import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardFooter } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Trash } from 'lucide-react';

/**
 * This component is for debugging enrollment state issues.
 * It displays the current localStorage data and lets you clear it.
 */
export function EnrollmentDebugger() {
  const [enrolledCourses, setEnrolledCourses] = useState<number[]>([]);
  const [refreshKey, setRefreshKey] = useState(0);

  useEffect(() => {
    try {
      const stored = localStorage.getItem('enrolledCourses');
      if (stored) {
        const parsed = JSON.parse(stored);
        console.log("LocalStorage content:", parsed);
        setEnrolledCourses(parsed);
      } else {
        console.log("No enrolled courses in localStorage");
        setEnrolledCourses([]);
      }
    } catch (e) {
      console.error("Failed to parse localStorage:", e);
      setEnrolledCourses([]);
    }
  }, [refreshKey]);

  const clearEnrollments = () => {
    localStorage.removeItem('enrolledCourses');
    setRefreshKey(prev => prev + 1);
  };

  const forceEnroll = (courseId: number) => {
    const newEnrolled = [...enrolledCourses];
    if (!newEnrolled.includes(courseId)) {
      newEnrolled.push(courseId);
      localStorage.setItem('enrolledCourses', JSON.stringify(newEnrolled));
      setRefreshKey(prev => prev + 1);
    }
  };

  const forceUnenroll = (courseId: number) => {
    const newEnrolled = enrolledCourses.filter(id => id !== courseId);
    localStorage.setItem('enrolledCourses', JSON.stringify(newEnrolled));
    setRefreshKey(prev => prev + 1);
  };

  return (
    <Card className="mb-8 border-red-300 dark:border-red-800">
      <CardHeader className="bg-red-50 dark:bg-red-900/20">
        <CardTitle className="text-lg text-red-700 dark:text-red-400 flex items-center justify-between">
          <span>Enrollment Debugger</span>
          <Button variant="destructive" size="sm" onClick={clearEnrollments}>
            <Trash className="h-4 w-4 mr-2" />
            Clear All Enrollments
          </Button>
        </CardTitle>
      </CardHeader>
      <CardContent className="pt-4">
        <div className="mb-4">
          <h3 className="font-medium mb-2">LocalStorage Enrolled Courses:</h3>
          {enrolledCourses.length > 0 ? (
            <div className="flex gap-2 flex-wrap">
              {enrolledCourses.map(courseId => (
                <Badge key={courseId} variant="secondary" className="flex items-center gap-1">
                  Course #{courseId}
                  <button 
                    className="ml-1 bg-red-100 dark:bg-red-900/30 rounded-full h-4 w-4 flex items-center justify-center text-red-700 dark:text-red-400 text-xs"
                    onClick={() => forceUnenroll(courseId)}
                  >
                    ×
                  </button>
                </Badge>
              ))}
            </div>
          ) : (
            <p className="text-sm text-gray-500 dark:text-gray-400">No enrolled courses found in localStorage</p>
          )}
        </div>
        
        <div className="grid grid-cols-4 gap-2 mt-4">
          <Button 
            size="sm" 
            variant="outline" 
            onClick={() => forceEnroll(1)}
            className="border-blue-300 dark:border-blue-800 hover:bg-blue-50 dark:hover:bg-blue-900/30"
          >
            Force Enroll #1
          </Button>
          <Button 
            size="sm" 
            variant="outline" 
            onClick={() => forceEnroll(2)}
            className="border-green-300 dark:border-green-800 hover:bg-green-50 dark:hover:bg-green-900/30"
          >
            Force Enroll #2
          </Button>
          <Button 
            size="sm" 
            variant="outline" 
            onClick={() => forceEnroll(3)}
            className="border-purple-300 dark:border-purple-800 hover:bg-purple-50 dark:hover:bg-purple-900/30"
          >
            Force Enroll #3
          </Button>
          <Button 
            size="sm" 
            variant="outline" 
            onClick={() => forceEnroll(4)}
            className="border-amber-300 dark:border-amber-800 hover:bg-amber-50 dark:hover:bg-amber-900/30"
          >
            Force Enroll #4
          </Button>
        </div>
      </CardContent>
      <CardFooter className="bg-red-50 dark:bg-red-900/10 text-xs text-red-600 dark:text-red-400">
        This debugger is for development purposes only.
      </CardFooter>
    </Card>
  );
}