import React, { useState, useEffect } from 'react';
import { useLocation } from 'wouter';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Bell, Calendar, Clock, X } from 'lucide-react';

interface RitualReminderPopupProps {
  title: string;
  description?: string;
  ritualId?: number;
  ritualName?: string;
  time?: string;
  onClose: () => void;
}

export function RitualReminderPopup({
  title,
  description = "Don't miss your daily spiritual practice!",
  ritualId,
  ritualName,
  time,
  onClose
}: RitualReminderPopupProps) {
  const [isVisible, setIsVisible] = useState(false);
  const [, setLocation] = useLocation();
  
  // Animation effect
  useEffect(() => {
    // Small delay for animation
    const timer = setTimeout(() => {
      setIsVisible(true);
    }, 100);
    
    return () => clearTimeout(timer);
  }, []);
  
  // Handle going to ritual page
  const handleGoToRitual = () => {
    onClose();
    if (ritualId) {
      setLocation(`/rituals/${ritualId}`);
    } else {
      setLocation('/rituals');
    }
  };
  
  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center">
      {/* Backdrop */}
      <div 
        className={`absolute inset-0 bg-black/40 backdrop-blur-sm transition-opacity duration-300 ${
          isVisible ? 'opacity-100' : 'opacity-0'
        }`}
        onClick={onClose}
      />
      
      {/* Popup */}
      <Card 
        className={`relative w-full max-w-md mx-4 sm:mx-auto mb-4 sm:mb-0 transition-all duration-300 ${
          isVisible 
            ? 'opacity-100 transform translate-y-0' 
            : 'opacity-0 transform translate-y-8'
        }`}
      >
        <Button 
          variant="ghost" 
          size="icon" 
          className="absolute right-2 top-2" 
          onClick={onClose}
        >
          <X className="h-4 w-4" />
        </Button>
        
        <CardHeader className="pb-2">
          <div className="flex items-center gap-3">
            <div className="bg-amber-100 dark:bg-amber-900/40 text-amber-600 dark:text-amber-400 p-2 rounded-full">
              <Bell className="h-5 w-5" />
            </div>
            <div>
              <CardTitle>{title}</CardTitle>
              <CardDescription>{description}</CardDescription>
            </div>
          </div>
        </CardHeader>
        
        <CardContent>
          {ritualName && (
            <div className="flex items-center gap-3 bg-purple-50 dark:bg-purple-900/20 p-3 rounded-md mb-3">
              <Calendar className="h-5 w-5 text-purple-600 dark:text-purple-400" />
              <div>
                <p className="font-medium">{ritualName}</p>
                {time && (
                  <div className="flex items-center text-sm text-gray-500 dark:text-gray-400 mt-1">
                    <Clock className="h-3.5 w-3.5 mr-1" />
                    <span>{time}</span>
                  </div>
                )}
              </div>
            </div>
          )}
          
          <p className="text-sm text-gray-600 dark:text-gray-300">
            Regular practice is key to spiritual growth and chakra activation. Don't break your streak!
          </p>
        </CardContent>
        
        <CardFooter className="flex justify-between border-t border-gray-100 dark:border-gray-800 pt-4">
          <Button variant="outline" onClick={onClose}>
            Dismiss
          </Button>
          <Button onClick={handleGoToRitual}>
            Go to Ritual
          </Button>
        </CardFooter>
      </Card>
    </div>
  );
}