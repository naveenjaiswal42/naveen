import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Separator } from '@/components/ui/separator';
import { Switch } from '@/components/ui/switch';
import { Label } from '@/components/ui/label';
import { Bell, Sun, Moon, Clock, X, AlertTriangle } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { NotificationPreferences as Preferences, getNotificationPreferences, saveNotificationPreferences, isNotificationSupported, hasNotificationPermission } from '@/services/notificationService';
import { useNotifications } from '@/contexts/NotificationContext';
import { useToast } from '@/hooks/use-toast';

export function NotificationPreferences() {
  // Get notification context and toast
  const { isPermissionGranted, requestPermission } = useNotifications();
  const { toast } = useToast();
  
  // Get stored preferences
  const [preferences, setPreferences] = useState<Preferences>(getNotificationPreferences());
  const [isNotificationsSupported, setIsNotificationsSupported] = useState(false);

  // Check if browser supports notifications
  useEffect(() => {
    setIsNotificationsSupported(isNotificationSupported());
  }, []);

  // Handle main notifications toggle
  const handleToggleNotifications = async (enabled: boolean) => {
    if (enabled && !isPermissionGranted) {
      // If enabling notifications and don't have permission, request it
      const granted = await requestPermission();
      
      if (!granted) {
        toast({
          title: 'Permission Denied',
          description: 'Please allow notifications in your browser settings.',
          variant: 'destructive',
        });
        return;
      }
    }
    
    const newPreferences: Preferences = {
      ...preferences,
      enabled,
    };
    
    setPreferences(newPreferences);
    saveNotificationPreferences(newPreferences);
  };

  // Handle morning reminders toggle
  const handleToggleMorningReminders = (enabled: boolean) => {
    const newPreferences: Preferences = {
      ...preferences,
      morningReminder: enabled,
    };
    
    setPreferences(newPreferences);
    saveNotificationPreferences(newPreferences);
  };

  // Handle evening reminders toggle
  const handleToggleEveningReminders = (enabled: boolean) => {
    const newPreferences: Preferences = {
      ...preferences,
      eveningReminder: enabled,
    };
    
    setPreferences(newPreferences);
    saveNotificationPreferences(newPreferences);
  };

  // Handle meditation reminders toggle
  const handleToggleMeditationReminders = (enabled: boolean) => {
    const newPreferences: Preferences = {
      ...preferences,
      meditationReminder: enabled,
    };
    
    setPreferences(newPreferences);
    saveNotificationPreferences(newPreferences);
  };
  
  // Handle morning time change
  const handleMorningTimeChange = (time: string) => {
    const newPreferences: Preferences = {
      ...preferences,
      morningTime: time,
    };
    
    setPreferences(newPreferences);
    saveNotificationPreferences(newPreferences);
  };
  
  // Handle evening time change
  const handleEveningTimeChange = (time: string) => {
    const newPreferences: Preferences = {
      ...preferences,
      eveningTime: time,
    };
    
    setPreferences(newPreferences);
    saveNotificationPreferences(newPreferences);
  };

  // Handle silent hours toggle
  const handleToggleSilentHours = (enabled: boolean) => {
    const newPreferences: Preferences = {
      ...preferences,
      silentHours: {
        ...preferences.silentHours,
        enabled,
      },
    };
    
    setPreferences(newPreferences);
    saveNotificationPreferences(newPreferences);
  };

  // Handle silent hours start time change
  const handleSilentHoursStartChange = (value: string) => {
    const newPreferences: Preferences = {
      ...preferences,
      silentHours: {
        ...preferences.silentHours,
        start: value,
      },
    };
    
    setPreferences(newPreferences);
    saveNotificationPreferences(newPreferences);
  };

  // Handle silent hours end time change
  const handleSilentHoursEndChange = (value: string) => {
    const newPreferences: Preferences = {
      ...preferences,
      silentHours: {
        ...preferences.silentHours,
        end: value,
      },
    };
    
    setPreferences(newPreferences);
    saveNotificationPreferences(newPreferences);
  };

  // If notifications aren't supported, show warning
  if (!isNotificationsSupported) {
    return (
      <Card className="w-full">
        <CardHeader className="pb-3">
          <div className="flex items-center gap-2">
            <AlertTriangle className="h-5 w-5 text-amber-500" />
            <CardTitle>Notifications Not Supported</CardTitle>
          </div>
          <CardDescription>
            Your browser doesn't support notifications.
          </CardDescription>
        </CardHeader>
        <CardContent>
          <p className="text-sm text-gray-600 dark:text-gray-400">
            Daily ritual reminders are not available on this browser. Please use a modern browser like Chrome, Firefox, or Safari for the best experience.
          </p>
        </CardContent>
      </Card>
    );
  }

  // Generate time options for select fields
  const generateTimeOptions = () => {
    const options = [];
    for (let hour = 0; hour < 24; hour++) {
      const hourText = hour.toString().padStart(2, '0');
      options.push({ value: `${hourText}:00`, label: `${hourText}:00` });
      options.push({ value: `${hourText}:30`, label: `${hourText}:30` });
    }
    return options;
  };

  return (
    <Card className="w-full">
      <CardHeader className="pb-3">
        <div className="flex items-center gap-2">
          <Bell className="h-5 w-5 text-indigo-500" />
          <CardTitle>Notification Settings</CardTitle>
        </div>
        <CardDescription>
          Configure when and how you receive ritual reminders.
        </CardDescription>
      </CardHeader>
      
      <CardContent className="space-y-6">
        {/* Main notification toggle */}
        <div className="flex items-center justify-between">
          <div className="space-y-0.5">
            <Label className="text-base">Enable Notifications</Label>
            <p className="text-sm text-gray-500 dark:text-gray-400">
              Receive reminders for daily rituals and meditation
            </p>
          </div>
          <Switch 
            checked={preferences.enabled}
            onCheckedChange={handleToggleNotifications}
          />
        </div>
        
        <Separator />
        
        {/* Morning reminder toggle with time selector */}
        <div className="space-y-2">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <div className="bg-amber-100 dark:bg-amber-900/20 p-1.5 rounded-full">
                <Sun className="h-4 w-4 text-amber-600 dark:text-amber-400" />
              </div>
              <Label>Morning Ritual Reminders</Label>
            </div>
            <Switch 
              checked={preferences.morningReminder}
              onCheckedChange={handleToggleMorningReminders}
              disabled={!preferences.enabled}
            />
          </div>
          {preferences.morningReminder && preferences.enabled && (
            <div className="ml-8 grid grid-cols-1 md:grid-cols-2 gap-2 mt-2">
              <div className="text-sm text-gray-500 dark:text-gray-400 flex items-center">
                <Clock className="h-3 w-3 mr-1" />
                <span>Choose your morning reminder time:</span>
              </div>
              <div>
                <Select 
                  value={preferences.morningTime}
                  onValueChange={handleMorningTimeChange}
                  disabled={!preferences.enabled}
                >
                  <SelectTrigger className="h-8 text-sm">
                    <SelectValue placeholder="Time" />
                  </SelectTrigger>
                  <SelectContent>
                    {[...Array(12)].map((_, hour) => {
                      const h = hour + 4; // Start from 4 AM
                      const formattedHour = h % 12 || 12;
                      const period = h < 12 ? 'AM' : 'PM';
                      const value = `${h.toString().padStart(2, '0')}:00`;
                      return (
                        <SelectItem key={`morning-${value}`} value={value}>
                          {`${formattedHour}:00 ${period}`}
                        </SelectItem>
                      );
                    })}
                  </SelectContent>
                </Select>
              </div>
            </div>
          )}
        </div>
        
        {/* Evening reminder toggle with time selector */}
        <div className="space-y-2">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <div className="bg-indigo-100 dark:bg-indigo-900/20 p-1.5 rounded-full">
                <Moon className="h-4 w-4 text-indigo-600 dark:text-indigo-400" />
              </div>
              <Label>Evening Ritual Reminders</Label>
            </div>
            <Switch 
              checked={preferences.eveningReminder}
              onCheckedChange={handleToggleEveningReminders}
              disabled={!preferences.enabled}
            />
          </div>
          {preferences.eveningReminder && preferences.enabled && (
            <div className="ml-8 grid grid-cols-1 md:grid-cols-2 gap-2 mt-2">
              <div className="text-sm text-gray-500 dark:text-gray-400 flex items-center">
                <Clock className="h-3 w-3 mr-1" />
                <span>Choose your evening reminder time:</span>
              </div>
              <div>
                <Select 
                  value={preferences.eveningTime}
                  onValueChange={handleEveningTimeChange}
                  disabled={!preferences.enabled}
                >
                  <SelectTrigger className="h-8 text-sm">
                    <SelectValue placeholder="Time" />
                  </SelectTrigger>
                  <SelectContent>
                    {[...Array(9)].map((_, hour) => {
                      const h = hour + 15; // Start from 3 PM (15:00)
                      const formattedHour = h % 12 || 12;
                      const period = h < 12 ? 'AM' : 'PM';
                      const value = `${h.toString().padStart(2, '0')}:00`;
                      return (
                        <SelectItem key={`evening-${value}`} value={value}>
                          {`${formattedHour}:00 ${period}`}
                        </SelectItem>
                      );
                    })}
                  </SelectContent>
                </Select>
              </div>
            </div>
          )}
        </div>
        
        {/* Meditation reminder toggle */}
        <div className="space-y-2">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <div className="bg-purple-100 dark:bg-purple-900/20 p-1.5 rounded-full">
                <div className="h-4 w-4 text-purple-600 dark:text-purple-400 flex items-center justify-center">
                  🧘
                </div>
              </div>
              <Label>Meditation Reminders</Label>
            </div>
            <Switch 
              checked={preferences.meditationReminder}
              onCheckedChange={handleToggleMeditationReminders}
              disabled={!preferences.enabled}
            />
          </div>
          {preferences.meditationReminder && preferences.enabled && (
            <div className="ml-8 text-sm text-gray-500 dark:text-gray-400 flex items-center">
              <Clock className="h-3 w-3 mr-1" />
              <span>Reminders for missed meditation sessions and streaks</span>
            </div>
          )}
        </div>
        
        <Separator />
        
        {/* Silent hours toggle */}
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <div className="space-y-0.5">
              <div className="flex items-center gap-2">
                <Clock className="h-4 w-4 text-gray-500" />
                <Label className="text-base">Silent Hours</Label>
              </div>
              <p className="text-sm text-gray-500 dark:text-gray-400">
                Don't receive notifications during these hours
              </p>
            </div>
            <Switch 
              checked={preferences.silentHours.enabled}
              onCheckedChange={handleToggleSilentHours}
              disabled={!preferences.enabled}
            />
          </div>
          
          {/* Silent hours time range */}
          {preferences.silentHours.enabled && (
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="silent-start">From</Label>
                <Select 
                  value={preferences.silentHours.start}
                  onValueChange={handleSilentHoursStartChange}
                  disabled={!preferences.enabled}
                >
                  <SelectTrigger id="silent-start">
                    <SelectValue placeholder="Start time" />
                  </SelectTrigger>
                  <SelectContent>
                    {generateTimeOptions().map(option => (
                      <SelectItem key={option.value} value={option.value}>
                        {option.label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label htmlFor="silent-end">To</Label>
                <Select 
                  value={preferences.silentHours.end}
                  onValueChange={handleSilentHoursEndChange}
                  disabled={!preferences.enabled}
                >
                  <SelectTrigger id="silent-end">
                    <SelectValue placeholder="End time" />
                  </SelectTrigger>
                  <SelectContent>
                    {generateTimeOptions().map(option => (
                      <SelectItem key={option.value} value={option.value}>
                        {option.label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>
          )}
        </div>
      </CardContent>
      
      <CardFooter className="flex justify-between border-t pt-4">
        <div className="text-xs text-gray-500 dark:text-gray-400">
          <p>Changes are automatically saved</p>
        </div>
        <Button 
          size="sm" 
          variant="outline"
          onClick={() => {
            const defaultPrefs = {
              enabled: isPermissionGranted, 
              morningReminder: true,
              eveningReminder: true,
              meditationReminder: true,
              morningTime: "05:00",
              eveningTime: "17:00",
              silentHours: {
                enabled: false,
                start: "22:00",
                end: "06:00",
              },
              types: {
                rituals: true,
                meditation: true,
                courses: true,
                achievements: true
              }
            };
            setPreferences(defaultPrefs);
            saveNotificationPreferences(defaultPrefs);
          }}
        >
          Reset to Default
        </Button>
      </CardFooter>
    </Card>
  );
}