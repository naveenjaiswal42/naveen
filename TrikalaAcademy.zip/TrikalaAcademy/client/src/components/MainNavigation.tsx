import { Link, useLocation } from "wouter";
import { Home, BookOpen, Flower, Sun, LightbulbIcon } from "lucide-react";

export default function MainNavigation() {
  const [location] = useLocation();

  // Define the main navigation items
  const navItems = [
    {
      path: "/dashboard",
      label: "Home",
      icon: <Home className="h-5 w-5" />
    },
    {
      path: "/courses",
      label: "Courses",
      icon: <BookOpen className="h-5 w-5" />
    },
    {
      path: "/chakras",
      label: "Chakras",
      icon: <Flower className="h-5 w-5" />
    },
    {
      path: "/rituals",
      label: "Rituals",
      icon: <Sun className="h-5 w-5" />
    },
    {
      path: "/guidance",
      label: "Guidance",
      icon: <LightbulbIcon className="h-5 w-5" />
    }
  ];

  return (
    <div className="bg-white dark:bg-gray-800 border-b border-gray-200 dark:border-gray-700 shadow-sm">
      <div className="max-w-screen-xl mx-auto px-4">
        <div className="flex justify-center md:justify-start space-x-2 md:space-x-8">
          {navItems.map((item) => {
            const isActive = location === item.path || 
                          (item.path === "/dashboard" && location === "/");
            
            return (
              <Link key={item.path} href={item.path}>
                <div className={`flex items-center py-3 px-1 md:px-2 border-b-2 transition-colors ${
                  isActive
                    ? "border-primary text-primary dark:border-primary dark:text-primary"
                    : "border-transparent text-gray-600 dark:text-gray-300 hover:text-gray-900 dark:hover:text-white"
                }`}>
                  <span className="mr-1.5">{item.icon}</span>
                  <span className="text-sm font-medium">{item.label}</span>
                </div>
              </Link>
            );
          })}
        </div>
      </div>
    </div>
  );
}