import { useState, useEffect } from "react";
import { Link } from "wouter";
import { useAuth } from "@/contexts/AuthContext";
import { Course, UserCourse } from "@shared/schema";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { BookOpen, Star, PlayCircle, Award } from "lucide-react";

// Define a type that maps camelCase property names to snake_case database field names
type CourseWithMappedFields = {
  id: number;
  title: string;
  description: string | null;
  image_url: string | null;
  level: number | null;
  total_lessons: number | null;
  xp_reward: number | null;
  progress: number;
  lessons_completed: number;
}

const CoursesList = () => {
  const { user } = useAuth();
  const { toast } = useToast();
  const [courses, setCourses] = useState<CourseWithMappedFields[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchCourses = async () => {
      if (!user) return;
      
      try {
        setLoading(true);
        
        // Get all available courses
        const allCourses = await apiRequest<Course[]>({
          url: '/api/courses',
          method: 'GET'
        });
        
        // Get user's enrolled courses
        const userCourses = await apiRequest<UserCourse[]>({
          url: `/api/users/${user.id}/courses`,
          method: 'GET'
        }).catch((error) => {
          console.error("Failed to fetch user courses:", error);
          // If this fails (due to auth), return an empty array
          return [] as UserCourse[];
        });
        
        // Map user courses with course details
        const enrolledCourses: CourseWithMappedFields[] = [];
        
        // If we have user courses, process them
        if (userCourses && userCourses.length > 0) {
          for (const userCourse of userCourses) {
            const courseData = allCourses.find(c => c.id === userCourse.courseId);
            
            if (courseData) {
              const lessonsCompleted = userCourse.lessonsCompleted ?? 0;
              const progress = courseData.totalLessons 
                ? Math.round((lessonsCompleted / courseData.totalLessons) * 100) 
                : 0;
              
              enrolledCourses.push({
                id: courseData.id,
                title: courseData.title,
                description: courseData.description,
                image_url: courseData.imageUrl,
                level: courseData.level,
                total_lessons: courseData.totalLessons,
                xp_reward: courseData.xpReward,
                progress,
                lessons_completed: lessonsCompleted
              });
            }
          }
        }
        
        setCourses(enrolledCourses);
      } catch (error) {
        console.error("Error fetching courses:", error);
        toast({
          title: "Error",
          description: "Failed to load your courses",
          variant: "destructive",
        });
      } finally {
        setLoading(false);
      }
    };
    
    fetchCourses();
  }, [user, toast]);

  // No need for a loading state section, we'll handle it in the main return

  return (
    <section className="mb-6">
      <div className="flex justify-between items-center mb-3">
        <h2 className="font-heading font-semibold text-lg text-gray-800 dark:text-white">
          My Courses
        </h2>
        <Link href="/my-courses" className="text-primary dark:text-primary-400 text-sm">
          View all my courses
        </Link>
      </div>
      
      <div className="space-y-4">
        {loading ? (
          <div className="bg-white dark:bg-gray-800 rounded-xl shadow-md p-6 text-center">
            <div className="flex items-center justify-center gap-2">
              <div className="h-5 w-5 animate-spin rounded-full border-2 border-primary border-r-transparent"></div>
              <span className="text-gray-500 dark:text-gray-400">Loading courses...</span>
            </div>
          </div>
        ) : courses.length === 0 ? (
          <div className="bg-white dark:bg-gray-800 rounded-xl shadow-md p-6 text-center">
            <p className="text-gray-500 dark:text-gray-400 mb-4">
              You haven't enrolled in any courses yet
            </p>
            <Link href="/courses" className="text-primary dark:text-primary-400 font-medium">
              Browse Available Courses
            </Link>
          </div>
        ) : (
          courses.slice(0, 2).map((course) => (
            <div key={course.id} className="bg-white dark:bg-gray-800 rounded-xl shadow-md overflow-hidden">
              <div className="relative h-32">
                <div className="absolute inset-0 bg-gray-200 dark:bg-gray-700 flex items-center justify-center">
                  {course.image_url ? (
                    <img
                      src={course.image_url}
                      alt={course.title}
                      className="w-full h-full object-cover"
                    />
                  ) : (
                    <BookOpen className="h-10 w-10 text-gray-400 dark:text-gray-500" />
                  )}
                </div>
                <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent"></div>
                <div className="absolute bottom-3 left-3 right-3 flex justify-between items-center">
                  <h3 className="text-white font-medium">{course.title}</h3>
                  <div className="bg-primary text-white text-xs px-2 py-1 rounded-full">
                    Level {course.level}
                  </div>
                </div>
              </div>
              <div className="p-3">
                <div className="flex justify-between items-center mb-2">
                  <div className="flex items-center">
                    <div className="w-6 h-6 rounded-full bg-primary-100 dark:bg-primary-900 flex items-center justify-center">
                      <PlayCircle className="h-3 w-3 text-primary dark:text-primary-400" />
                    </div>
                    <span className="text-xs text-gray-600 dark:text-gray-400 ml-1.5">
                      {course.lessons_completed}/{course.total_lessons} Lessons
                    </span>
                  </div>
                  <div className="flex items-center">
                    <Star className="h-3 w-3 text-amber-400" />
                    <span className="text-xs ml-1 text-gray-600 dark:text-gray-400">
                      {course.xp_reward} XP
                    </span>
                  </div>
                </div>
                
                <div className="w-full bg-gray-200 dark:bg-gray-700 rounded-full h-1.5">
                  <div 
                    className="bg-primary dark:bg-primary-500 h-1.5 rounded-full" 
                    style={{ width: `${course.progress}%` }}
                  ></div>
                </div>
              </div>
            </div>
          ))
        )}
        
        {courses.length > 2 && (
          <Link href="/my-courses" className="block text-center text-sm text-primary dark:text-primary-400 mt-2">
            View {courses.length - 2} more courses
          </Link>
        )}
      </div>
    </section>
  );
};

export default CoursesList;
