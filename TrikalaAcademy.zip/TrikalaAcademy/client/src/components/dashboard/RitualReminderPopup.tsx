import { useState, useEffect } from "react";
import { Bell, X, Clock } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Ritual } from "@shared/schema";

interface RitualReminderPopupProps {
  ritual: Ritual;
  onClose: () => void;
  onJoin: (ritualId: number) => void;
}

const RitualReminderPopup = ({ ritual, onClose, onJoin }: RitualReminderPopupProps) => {
  const [countdown, setCountdown] = useState<number>(5 * 60); // 5 minutes in seconds
  const [visible, setVisible] = useState<boolean>(true);

  // Format seconds to MM:SS
  const formatTime = (seconds: number): string => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  useEffect(() => {
    // Countdown timer
    const timer = setInterval(() => {
      setCountdown((prev) => {
        if (prev <= 1) {
          clearInterval(timer);
          return 0;
        }
        return prev - 1;
      });
    }, 1000);

    // Cleanup
    return () => {
      clearInterval(timer);
    };
  }, []);

  // Animation to slide out
  const handleClose = () => {
    setVisible(false);
    // Give time for animation to complete
    setTimeout(onClose, 500);
  };

  return (
    <div className={`fixed bottom-4 right-4 z-50 transition-transform duration-500 ease-in-out ${
      visible ? 'translate-x-0' : 'translate-x-[calc(100%+1rem)]'
    }`}>
      <Card className="w-80 bg-gradient-to-r from-indigo-600 to-indigo-500 text-white shadow-lg p-0 overflow-hidden rounded-lg border-none">
        <div className="bg-indigo-700/20 p-3 flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <Bell className="h-5 w-5 text-indigo-200 animate-pulse" />
            <span className="font-medium">Ritual Reminder</span>
          </div>
          <button 
            onClick={handleClose}
            className="text-indigo-200 hover:text-white transition-colors"
          >
            <X className="h-5 w-5" />
          </button>
        </div>
        
        <div className="p-4">
          <div className="mb-3">
            <h3 className="text-lg font-semibold">{ritual.title}</h3>
            <p className="text-indigo-100 text-sm">
              Starting in <span className="font-mono bg-indigo-500/30 px-2 py-0.5 rounded">
                {formatTime(countdown)}
              </span>
            </p>
          </div>
          
          <div className="bg-indigo-700/20 rounded p-3 mb-4 flex items-center space-x-3">
            <Clock className="h-4 w-4 text-indigo-200 flex-shrink-0" />
            <p className="text-sm">
              {ritual.durationMinutes} minutes • {ritual.timeOfDay || "Any time"}
            </p>
          </div>
          
          <div className="flex space-x-2">
            <Button 
              onClick={handleClose}
              variant="ghost" 
              className="flex-1 text-indigo-100 hover:text-white hover:bg-indigo-700/30"
            >
              Remind Later
            </Button>
            <Button 
              onClick={() => {
                onJoin(ritual.id);
                handleClose();
              }}
              variant="default" 
              className="flex-1 bg-white text-indigo-700 hover:bg-indigo-50"
            >
              Join Now
            </Button>
          </div>
        </div>
        
        {/* Progress indicator */}
        <div className="h-1 bg-indigo-700/30 w-full relative">
          <div 
            className="absolute left-0 top-0 h-full bg-white transition-all duration-1000 ease-linear"
            style={{ width: `${(countdown / (5 * 60)) * 100}%` }}
          ></div>
        </div>
      </Card>
    </div>
  );
};

export default RitualReminderPopup;