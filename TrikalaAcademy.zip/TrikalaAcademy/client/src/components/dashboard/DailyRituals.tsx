import { useState, useEffect } from "react";
import { Link } from "wouter";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { useAuth } from "@/contexts/AuthContext";
import { Ritual, UserRitual } from "@shared/schema";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { Sun, Check, Plus, Moon, Sunrise } from "lucide-react";
import RitualReminderPopup from "./RitualReminderPopup";

// Helper function to get today's date in YYYY-MM-DD format
const getTodayDate = () => {
  const today = new Date();
  return today.toISOString().split('T')[0];
};

const DailyRituals = () => {
  const { user } = useAuth();
  const { toast } = useToast();
  const [rituals, setRituals] = useState<Array<Ritual & { completed: boolean }>>([]);
  const [loading, setLoading] = useState(true);
  const [showReminder, setShowReminder] = useState<boolean>(false);
  const [activeRitual, setActiveRitual] = useState<Ritual | null>(null);

  useEffect(() => {
    const fetchRituals = async () => {
      if (!user) return;
      
      try {
        setLoading(true);
        
        // Get all rituals from our API
        const allRituals = await apiRequest<Ritual[]>({
          url: '/api/rituals',
          method: 'GET'
        });
        
        // Get today's completed rituals for user
        const todayStr = getTodayDate();
        const userRituals = await apiRequest<UserRitual[]>({
          url: `/api/users/1/rituals?date=${todayStr}`, // Use '1' as the ID
          method: 'GET'
        }).catch((error) => {
          console.error("Failed to fetch user rituals:", error);
          // If this fails, return an empty array
          return [] as UserRitual[];
        });
        
        // Extract ritual IDs from user rituals
        const completedRitualIds = userRituals.map(ritual => ritual.ritualId);
        
        // Combine data
        const ritualsWithCompletionStatus = allRituals.map(ritual => ({
          ...ritual,
          completed: completedRitualIds.includes(ritual.id)
        }));
        
        setRituals(ritualsWithCompletionStatus);
        
        // DEMONSTRATION: Always show a reminder popup for an upcoming ritual
        // In a production app, this would check for actual upcoming rituals
        if (ritualsWithCompletionStatus.length > 0) {
          // Find first uncompleted ritual, or use the first ritual as demo
          const demoRitual = ritualsWithCompletionStatus.find(r => !r.completed) || 
                            ritualsWithCompletionStatus[0];
          
          // Show reminder immediately for demo purposes
          setTimeout(() => {
            console.log("SHOWING RITUAL REMINDER POPUP FOR:", demoRitual.title);
            setActiveRitual(demoRitual);
            setShowReminder(true);
          }, 1000);
        }
      } catch (error) {
        console.error("Error fetching rituals:", error);
        toast({
          title: "Error",
          description: "Failed to load daily rituals",
          variant: "destructive",
        });
      } finally {
        setLoading(false);
      }
    };
    
    fetchRituals();
  }, [user]);

  const completeRitual = async (ritualId: number) => {
    if (!user) return;
    
    try {
      // Use our API to complete a ritual
      await apiRequest({
        url: `/api/users/1/rituals`, // Use '1' as the ID
        method: 'POST',
        body: {
          ritualId: ritualId,
          date: getTodayDate()
        }
      });
      
      // Update local state
      setRituals(prev => prev.map(ritual => 
        ritual.id === ritualId 
          ? { ...ritual, completed: true } 
          : ritual
      ));
      
      // Add XP for completing ritual (handled by the server)
      const completedRitual = rituals.find(r => r.id === ritualId);
      if (completedRitual && completedRitual.xpReward) {
        toast({
          title: "Ritual Completed",
          description: `You earned ${completedRitual.xpReward} XP!`,
        });
      }
    } catch (error) {
      console.error("Error completing ritual:", error);
      toast({
        title: "Error",
        description: "Failed to mark ritual as completed",
        variant: "destructive",
      });
    }
  };

  // Calculate completed count
  const completedCount = rituals.filter(r => r.completed).length;

  if (loading) {
    return (
      <section className="mb-6">
        <div className="flex justify-between items-center mb-3">
          <h2 className="font-heading font-semibold text-lg text-gray-800 dark:text-white">
            Daily Rituals
          </h2>
          <Button variant="link" size="sm" className="text-primary dark:text-primary-400 p-0 h-auto" asChild>
            <Link href="/rituals">View all</Link>
          </Button>
        </div>
        <Card>
          <CardContent className="pt-6">
            <p className="text-center text-gray-500 dark:text-gray-400">
              Loading daily rituals...
            </p>
          </CardContent>
        </Card>
      </section>
    );
  }

  return (
    <section className="mb-6">
      <div className="flex justify-between items-center mb-3">
        <h2 className="font-heading font-semibold text-lg text-gray-800 dark:text-white">
          Daily Rituals
        </h2>
        <Button variant="link" size="sm" className="text-primary dark:text-primary-400 p-0 h-auto" asChild>
          <Link href="/rituals">View all</Link>
        </Button>
      </div>
      
      <div className="bg-indigo-50 dark:bg-indigo-900/20 rounded-xl shadow-md p-4">
        <div className="flex items-center justify-between mb-4">
          <span className="text-sm text-indigo-700 dark:text-indigo-300">🕉️ Today's Sacred Practices</span>
          <span className="text-sm font-medium text-indigo-600 dark:text-indigo-400">
            {completedCount}/{rituals.length} Completed
          </span>
        </div>
        
        <div className="space-y-4">
          {rituals.length === 0 ? (
            <p className="text-center text-indigo-500 dark:text-indigo-400 py-4">
              No rituals available today
            </p>
          ) : (
            rituals.slice(0, 3).map((ritual) => (
              <div 
                key={ritual.id} 
                className="flex items-center justify-between p-4 bg-white dark:bg-indigo-950/30 rounded-lg shadow-sm"
              >
                <div className="flex items-center">
                  <div className="w-12 h-12 rounded-full bg-indigo-100 dark:bg-indigo-800/50 flex items-center justify-center mr-4">
                    {ritual.timeOfDay?.includes("Morning") ? (
                      <Sunrise className="h-6 w-6 text-indigo-600 dark:text-indigo-300" />
                    ) : ritual.timeOfDay?.includes("Night") ? (
                      <Moon className="h-6 w-6 text-indigo-600 dark:text-indigo-300" />
                    ) : (
                      <Sun className="h-6 w-6 text-indigo-600 dark:text-indigo-300" />
                    )}
                  </div>
                  <div>
                    <h3 className="text-base font-medium text-indigo-800 dark:text-indigo-200">
                      {ritual.title}
                    </h3>
                    <p className="text-sm text-indigo-500 dark:text-indigo-400">
                      {ritual.durationMinutes} min • {ritual.timeOfDay || "Any time"}
                    </p>
                  </div>
                </div>
                <div className="flex items-center">
                  {ritual.completed ? (
                    <div className="w-10 h-10 rounded-full border-2 border-green-500 flex items-center justify-center text-green-500 bg-green-50 dark:bg-green-900/20">
                      <Check className="h-5 w-5" />
                    </div>
                  ) : (
                    <button 
                      className="px-3 py-2 rounded-lg bg-indigo-600 hover:bg-indigo-700 text-white text-sm font-medium transition-colors"
                      onClick={() => completeRitual(ritual.id)}
                    >
                      Join Now
                    </button>
                  )}
                </div>
              </div>
            ))
          )}
          
          {rituals.length > 3 && (
            <Button variant="outline" size="sm" className="w-full text-indigo-600 dark:text-indigo-400 border-indigo-200 dark:border-indigo-800/50 mt-2 hover:bg-indigo-50 dark:hover:bg-indigo-900/30" asChild>
              <Link href="/rituals">
                View {rituals.length - 3} more rituals
              </Link>
            </Button>
          )}
        </div>
      </div>
      
      {/* Ritual Reminder Popup */}
      {showReminder && activeRitual && (
        <RitualReminderPopup 
          ritual={activeRitual}
          onClose={() => setShowReminder(false)}
          onJoin={(ritualId) => {
            completeRitual(ritualId);
            setShowReminder(false);
          }}
        />
      )}
    </section>
  );
};

export default DailyRituals;
