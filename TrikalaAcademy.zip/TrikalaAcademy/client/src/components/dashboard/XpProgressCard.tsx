import { useAuth } from "@/contexts/AuthContext";
import XpProgressCircle from "@/components/XpProgressCircle";
import SpiritualLevelBadge, { getCurrentLevel, getNextLevel } from "@/components/SpiritualLevelBadge";
import { Card } from "@/components/ui/card";
import { useTranslation } from "@/hooks/useTranslation";
import { Star, TrendingUp, Award } from "lucide-react";

// XP required for each level
const XP_LEVELS = [
  { level: 1, xp: 0 },
  { level: 2, xp: 1000 },
  { level: 3, xp: 2500 },
  { level: 4, xp: 5000 },
  { level: 5, xp: 10000 },
  { level: 6, xp: 15000 },
  { level: 7, xp: 25000 },
];

// Get XP required for next level
const getNextLevelXp = (currentLevel: number) => {
  const nextLevel = XP_LEVELS.find(l => l.level > currentLevel);
  return nextLevel ? nextLevel.xp : XP_LEVELS[XP_LEVELS.length - 1].xp;
};

// Get XP for current level
const getCurrentLevelXp = (currentLevel: number) => {
  const current = XP_LEVELS.find(l => l.level === currentLevel);
  return current ? current.xp : 0;
};

export default function XpProgressCard() {
  const { user } = useAuth();
  const { t } = useTranslation();
  
  const userXp = user?.xp || 0;
  
  // Get the current and next spiritual levels
  const currentLevel = getCurrentLevel(userXp);
  const nextLevel = getNextLevel(userXp);
  
  // Calculate progress to next level
  const currentLevelXp = currentLevel.minXp;
  const nextLevelXp = nextLevel ? nextLevel.minXp : currentLevel.maxXp;
  const xpForNextLevel = nextLevelXp - currentLevelXp;
  const progress = userXp - currentLevelXp;
  
  // Legacy level system (can be removed once fully migrated to new system)
  const userLevel = user?.level || 1;
  
  return (
    <Card className="p-6 bg-white dark:bg-gray-800 border-none shadow-md">
      <div className="flex items-center justify-between mb-4">
        <h3 className="text-lg font-semibold flex items-center">
          <Star className="h-5 w-5 mr-2 text-amber-500" />
          Spiritual Progress
        </h3>
      </div>
      
      <div className="flex flex-col md:flex-row items-center justify-between">
        <div className="mb-6 md:mb-0">
          <XpProgressCircle 
            xp={progress} 
            goalXp={xpForNextLevel}
            size="lg"
          />
        </div>
        
        <div className="flex-1 md:ml-8">
          <div className="flex items-center gap-3 mb-3">
            <Award className="h-5 w-5 text-indigo-500" />
            <SpiritualLevelBadge xp={userXp} size="md" showXp={false} />
          </div>
          
          <div className="space-y-4">
            <div>
              <div className="flex items-center justify-between mb-1 text-sm">
                <span className="text-gray-600 dark:text-gray-400">
                  Current XP
                </span>
                <span className="font-medium">{userXp.toLocaleString()} XP</span>
              </div>
              <div className="w-full bg-gray-200 dark:bg-gray-700 rounded-full h-1.5">
                <div 
                  className="bg-indigo-500 h-1.5 rounded-full" 
                  style={{ width: `${Math.min(100, (progress / xpForNextLevel) * 100)}%` }}
                ></div>
              </div>
            </div>
            
            {/* Next level information */}
            {nextLevel && (
              <>
                <div className="flex items-center justify-between text-sm">
                  <div className="flex items-center">
                    <TrendingUp className="h-4 w-4 mr-1 text-green-500" />
                    <span className="text-gray-600 dark:text-gray-400">
                      XP needed for {nextLevel?.name}
                    </span>
                  </div>
                  <span className="font-medium">
                    {(nextLevel?.minXp ? nextLevel.minXp - userXp : 0).toLocaleString()} XP
                  </span>
                </div>
                
                <div className="flex flex-wrap gap-2 pt-2">
                  <div className="text-xs text-gray-600 dark:text-gray-400">
                    Next level: <span className="font-medium text-indigo-600 dark:text-indigo-400">
                      {nextLevel?.name || ""}
                    </span>
                    {nextLevel?.icon && <span className="ml-1">{nextLevel.icon}</span>}
                  </div>
                </div>
              </>
            )}
            
            {/* Max level reached message */}
            {!nextLevel && (
              <div className="text-sm text-center py-2 px-4 bg-amber-50 dark:bg-amber-900/20 border border-amber-200 dark:border-amber-800/30 rounded-md">
                <span className="font-medium text-amber-600 dark:text-amber-400">
                  ✨ You've reached the highest spiritual level! ✨
                </span>
              </div>
            )}
          </div>
        </div>
      </div>
    </Card>
  );
}