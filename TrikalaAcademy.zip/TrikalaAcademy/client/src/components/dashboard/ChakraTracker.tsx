import { Button } from "@/components/ui/button";
import { useChakras } from "@/contexts/ChakraContext";
import { chakras as chakraData } from "@/lib/chakras";
import { Link } from "wouter";
import { Play, Flower } from "lucide-react";
import { useState, useEffect } from "react";

const ChakraTracker = () => {
  const { chakras, activeCount } = useChakras();
  const [isMobile, setIsMobile] = useState(false);
  
  useEffect(() => {
    // Check initial screen size
    const checkScreenSize = () => {
      setIsMobile(window.innerWidth < 380);
    };
    
    // Set on initial load
    checkScreenSize();
    
    // Update on resize
    window.addEventListener('resize', checkScreenSize);
    
    // Clean up
    return () => window.removeEventListener('resize', checkScreenSize);
  }, []);

  return (
    <section className="mb-6">
      <div className="flex justify-between items-center mb-3">
        <h2 className="font-heading font-semibold text-lg text-gray-800 dark:text-white">
          Chakra Energy
        </h2>
        <Button variant="link" size="sm" className="text-primary dark:text-primary-400 p-0 h-auto" asChild>
          <Link href="/chakras">View all</Link>
        </Button>
      </div>
      
      <div className="bg-white dark:bg-gray-800 rounded-xl shadow-md p-4">
        <div className="flex items-center justify-between mb-4">
          <span className="text-sm text-gray-500 dark:text-gray-400">Your energy centers</span>
          <span className="text-sm font-medium text-primary dark:text-primary-400">
            {activeCount}/7 Activated
          </span>
        </div>
        
        <div className="grid grid-cols-7 gap-1 md:flex md:justify-around md:items-center">
          {chakraData.map((chakra) => {
            const isActive = chakras[chakra.id];
            
            return (
              <div className="flex flex-col items-center" key={chakra.id}>
                <div className={`w-8 h-8 md:w-10 md:h-10 rounded-full ${chakra.color} ${isActive ? '' : 'opacity-50'} mb-1 md:mb-2 flex items-center justify-center shadow-sm`}>
                  <Flower className="h-3 w-3 md:h-4 md:w-4 text-white" />
                </div>
                <span className={`text-[10px] md:text-xs text-center ${isActive 
                  ? 'text-gray-800 font-medium dark:text-gray-200' 
                  : 'text-gray-600 dark:text-gray-400'}`}>
                  {isMobile ? chakra.name.substring(0, 1) : chakra.name}
                </span>
              </div>
            );
          })}
        </div>
        
        <div className="mt-4">
          <Button className="w-full py-6" asChild>
            <Link href="/chakra-meditation">
              <Play className="h-4 w-4 mr-2" />
              <span>Start Meditation</span>
            </Link>
          </Button>
        </div>
      </div>
    </section>
  );
};

export default ChakraTracker;
