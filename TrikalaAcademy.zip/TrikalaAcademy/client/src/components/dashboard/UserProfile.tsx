import { useAuth } from "@/contexts/AuthContext";
import { useChakras } from "@/contexts/ChakraContext";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import XpProgressCircle from "@/components/XpProgressCircle";

const UserProfile = () => {
  const { user } = useAuth();
  const { progressPercentage } = useChakras();

  // Default values if user is not loaded yet
  const userName = user?.name || "Trikala Academy";
  const userLevel = user?.level || 1;
  const userXp = user?.xp || 0;

  return (
    <section className="bg-white dark:bg-gray-800 rounded-xl shadow-lg p-5 mb-6 border border-gray-100 dark:border-gray-700">
      <div className="flex items-center">
        <div className="relative mr-5">
          <Avatar className="w-18 h-18 border-2 border-primary dark:border-primary-600 shadow-md">
            <AvatarImage src={user?.profile_image} />
            <AvatarFallback className="bg-gradient-to-br from-primary-400 to-primary-700 text-white text-xl font-bold">
              {userName.charAt(0).toUpperCase()}
            </AvatarFallback>
          </Avatar>

        </div>
        
        <div className="flex-1 ml-1">
          <h2 className="font-heading font-semibold text-xl text-gray-800 dark:text-white">
            {userName}
          </h2>
          {/* XP and milestones section removed */}
        </div>
        
        <div className="flex flex-col items-center bg-gray-50 dark:bg-gray-700/50 p-2 rounded-lg shadow-inner">
          {/* Today's Chakra Progress */}
          <div className="flex flex-col items-center">
            <XpProgressCircle 
              xp={progressPercentage}
              goalXp={100}
              size="sm"
              showText={true}
            />
            <span className="text-xs mt-1 font-medium text-primary dark:text-primary-400">Today's Progress</span>
          </div>
        </div>
      </div>
    </section>
  );
};

export default UserProfile;
