import { useEffect, useState } from "react";
import Confetti from "react-confetti";

interface ChallengeCompletionPopupProps {
  show: boolean;
  onClose: () => void;
  challengeTitle: string;
}

export default function ChallengeCompletionPopup({ show, onClose, challengeTitle }: ChallengeCompletionPopupProps) {
  const [windowSize, setWindowSize] = useState({ width: 0, height: 0 });

  useEffect(() => {
    // Set initial window size
    setWindowSize({ width: window.innerWidth, height: window.innerHeight });
    
    // Update window size on resize
    const handleResize = () => {
      setWindowSize({ width: window.innerWidth, height: window.innerHeight });
    };
    
    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, []);

  if (!show) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-60 flex items-center justify-center z-50">
      <Confetti 
        width={windowSize.width} 
        height={windowSize.height}
        recycle={false}
        numberOfPieces={300}
        colors={['#C084FC', '#8B5CF6', '#6366F1', '#A855F7', '#EC4899']}
      />
      <div className="bg-white dark:bg-gray-800 p-10 rounded-lg text-center shadow-xl animate-bounce-slow">
        <h1 className="text-4xl font-bold text-indigo-700 dark:text-indigo-400 mb-6">🏅 Challenge Completed!</h1>
        <p className="text-xl text-gray-700 dark:text-gray-300 mb-4">You successfully completed:</p>
        <p className="text-2xl font-semibold text-indigo-600 dark:text-indigo-300">{challengeTitle}</p>

        <div className="mt-6 mb-8">
          <div className="text-amber-600 dark:text-amber-400 font-medium text-lg mb-2">Rewards Earned:</div>
          <div className="flex items-center justify-center space-x-4">
            <div className="flex flex-col items-center">
              <div className="text-3xl mb-2">✨</div>
              <div className="text-sm text-gray-600 dark:text-gray-400">XP Boost</div>
            </div>
            <div className="flex flex-col items-center">
              <div className="text-3xl mb-2">🏆</div>
              <div className="text-sm text-gray-600 dark:text-gray-400">Achievement</div>
            </div>
            <div className="flex flex-col items-center">
              <div className="text-3xl mb-2">🌟</div>
              <div className="text-sm text-gray-600 dark:text-gray-400">Spiritual Level</div>
            </div>
          </div>
        </div>

        <button
          onClick={onClose}
          className="mt-4 bg-indigo-600 text-white px-8 py-3 rounded-lg hover:bg-indigo-700 transition"
        >
          Continue Journey
        </button>
      </div>
    </div>
  );
}