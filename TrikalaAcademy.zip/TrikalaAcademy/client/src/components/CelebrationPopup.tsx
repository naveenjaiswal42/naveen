import { useState, useEffect } from "react";
import Confetti from "react-confetti";

interface CelebrationPopupProps {
  show: boolean;
  onClose: () => void;
  message?: string;
}

export default function CelebrationPopup({ show, onClose, message = "You completed your meditation today!" }: CelebrationPopupProps) {
  const [windowSize, setWindowSize] = useState({ width: 0, height: 0 });

  useEffect(() => {
    // Set initial window size
    setWindowSize({ width: window.innerWidth, height: window.innerHeight });
    
    // Update window size on resize
    const handleResize = () => {
      setWindowSize({ width: window.innerWidth, height: window.innerHeight });
    };
    
    window.addEventListener("resize", handleResize);
    
    // Cleanup event listener
    return () => {
      window.removeEventListener("resize", handleResize);
    };
  }, []);

  if (!show) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
      <Confetti 
        width={windowSize.width} 
        height={windowSize.height} 
        recycle={false}
        numberOfPieces={200}
        gravity={0.1}
      />

      <div className="bg-white dark:bg-gray-800 p-8 rounded-lg text-center shadow-lg transform transition-all animate-scale-up max-w-md mx-4">
        <div className="w-20 h-20 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-4">
          <span className="text-4xl">🎉</span>
        </div>
        <h1 className="text-3xl font-bold text-primary mb-4">Congratulations!</h1>
        <p className="text-gray-700 dark:text-gray-300 text-lg mb-6">{message}</p>
        <div className="flex flex-wrap gap-4 justify-center">
          <button
            onClick={onClose}
            className="bg-primary hover:bg-primary/90 text-white px-6 py-3 rounded-lg transition-colors"
          >
            Continue My Journey
          </button>
        </div>
      </div>
    </div>
  );
}