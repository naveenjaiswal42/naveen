import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { X, Award, Download } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import CertificateDownload from "./CertificateDownload";

interface CertificateCongratulationsProps {
  courseTitle: string;
  userName: string;
  onClose: () => void;
  showFullCertificate?: boolean;
  isCourseCompleted?: boolean;
}

export default function CertificateCongratulations({ courseTitle, userName, onClose, showFullCertificate = false, isCourseCompleted = true }: CertificateCongratulationsProps) {
  const [showConfetti, setShowConfetti] = useState(true);
  const [viewMode, setViewMode] = useState<'celebration' | 'certificate'>(showFullCertificate ? 'certificate' : 'celebration');
  
  // Automatically hide confetti after 5 seconds to avoid performance issues
  useEffect(() => {
    const timer = setTimeout(() => {
      setShowConfetti(false);
    }, 5000);
    
    return () => clearTimeout(timer);
  }, []);

  return (
    <AnimatePresence>
      <motion.div 
        className="fixed inset-0 flex items-center justify-center bg-black/50 backdrop-blur-sm z-50"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
      >
        {showConfetti && viewMode === 'celebration' && <Confetti />}
        
        <motion.div
          initial={{ scale: 0.8, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          exit={{ scale: 0.8, opacity: 0 }}
          transition={{ type: "spring", damping: 15 }}
          className="relative overflow-y-auto max-h-[90vh]"
        >
          {viewMode === 'celebration' ? (
            <Card className="w-[90vw] max-w-lg p-6 bg-gradient-to-br from-violet-50 to-indigo-50 dark:from-violet-950/50 dark:to-indigo-950/50 border-purple-200 dark:border-purple-800 shadow-lg">
              <Button 
                variant="ghost" 
                size="icon" 
                className="absolute right-2 top-2" 
                onClick={onClose}
              >
                <X className="h-4 w-4" />
              </Button>

              <div className="text-center">
                <motion.div 
                  initial={{ y: -20 }} 
                  animate={{ y: [0, -10, 0] }} 
                  transition={{ repeat: 3, duration: 1 }}
                  className="mx-auto mb-6 bg-purple-100 dark:bg-purple-900/30 p-4 rounded-full w-24 h-24 flex items-center justify-center"
                >
                  <Award className="h-12 w-12 text-primary" />
                </motion.div>
                
                <motion.h1 
                  className="text-3xl font-bold text-primary mb-6"
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.3 }}
                >
                  Congratulations
                </motion.h1>
                
                <motion.p 
                  className="text-lg text-gray-700 dark:text-gray-300 mb-4"
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  transition={{ delay: 0.5 }}
                >
                  You have successfully completed:
                </motion.p>
                
                <motion.h2 
                  className="text-2xl font-semibold text-primary mb-8"
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  transition={{ delay: 0.7 }}
                >
                  {courseTitle}
                </motion.h2>
                
                <motion.div
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.9 }}
                >
                  <Button 
                    className="mb-4 w-full"
                    onClick={() => setViewMode('certificate')}
                  >
                    <Download className="mr-2 h-4 w-4" />
                    View Certificate
                  </Button>
                  
                  <p className="text-sm text-gray-600 dark:text-gray-400">
                    You've earned 100 XP and a beautiful certificate
                  </p>
                </motion.div>
              </div>
            </Card>
          ) : (
            <Card className="w-[90vw] max-w-4xl p-6 bg-white dark:bg-gray-800 border-purple-200 dark:border-purple-800 shadow-lg">
              <Button 
                variant="ghost" 
                size="icon" 
                className="absolute right-2 top-2" 
                onClick={onClose}
              >
                <X className="h-4 w-4" />
              </Button>
              
              <div className="flex flex-col items-center">
                <CertificateDownload 
                  courseTitle={courseTitle} 
                  userName={userName} 
                  isCourseCompleted={isCourseCompleted}
                />
                
                <Button 
                  variant="outline" 
                  onClick={() => setViewMode('celebration')}
                  className="mt-4"
                >
                  Back to Celebration
                </Button>
              </div>
            </Card>
          )}
        </motion.div>
      </motion.div>
    </AnimatePresence>
  );
}

// Simple confetti component using framer-motion
function Confetti() {
  const colors = ["#f44336", "#e91e63", "#9c27b0", "#673ab7", "#3f51b5", "#2196f3", "#03a9f4", "#00bcd4"];
  
  return (
    <div className="fixed inset-0 pointer-events-none">
      {Array.from({ length: 100 }).map((_, i) => (
        <motion.div
          key={i}
          className="absolute h-2 w-2 rounded-full"
          style={{
            backgroundColor: colors[Math.floor(Math.random() * colors.length)],
            top: Math.random() * -10 + "%",
            left: Math.random() * 100 + "%",
          }}
          animate={{
            y: window.innerHeight,
            x: Math.random() * 100 - 50,
            rotate: Math.random() * 360,
          }}
          transition={{
            duration: Math.random() * 2 + 4,
            repeat: 0,
            ease: "linear",
            delay: Math.random() * 1.5,
          }}
        />
      ))}
    </div>
  );
}