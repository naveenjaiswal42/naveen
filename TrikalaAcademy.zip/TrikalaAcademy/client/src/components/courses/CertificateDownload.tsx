import { useState } from "react";
import jsPDF from "jspdf";
import html2canvas from "html2canvas";
import { Trophy, Download, Eye } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";

interface CertificateDownloadProps {
  courseTitle: string;
  userName: string;
  completionDate?: string;
  isCourseCompleted?: boolean;
}

export default function CertificateDownload({ 
  courseTitle, 
  userName, 
  completionDate = new Date().toLocaleDateString(),
  isCourseCompleted = false
}: CertificateDownloadProps) {
  console.log("CertificateDownload rendered with isCourseCompleted:", isCourseCompleted);
  const [showPreview, setShowPreview] = useState(false);

  const downloadCertificate = async () => {
    const certificate = document.getElementById('certificate');

    try {
      if (certificate) {
        const canvas = await html2canvas(certificate);
        const imgData = canvas.toDataURL('image/png');
        const pdf = new jsPDF('landscape', 'mm', 'a4');
        pdf.addImage(imgData, 'PNG', 10, 10, 277, 190);
        pdf.save(`${courseTitle}_certificate.pdf`);
      }
    } catch (error) {
      console.error("Error generating PDF:", error);
    }
  };

  return (
    <div className="flex flex-col items-center mt-8 w-full max-w-4xl mx-auto">
      {/* Control Panel */}
      <div className="w-full flex flex-col sm:flex-row items-center justify-between mb-6 p-4 bg-gray-50 dark:bg-gray-800 rounded-lg">
        <div className="flex items-center space-x-4 mb-4 sm:mb-0">
          <div className="flex items-center space-x-2">
            <Switch 
              id="certificate-toggle"
              checked={showPreview} 
              onCheckedChange={setShowPreview} 
            />
            <Label htmlFor="certificate-toggle" className="cursor-pointer">
              {showPreview ? "View Certificate" : "View Celebration"}
            </Label>
          </div>
        </div>
        
        <div className="flex space-x-3">
          <Button
            variant="outline"
            size="sm"
            onClick={() => setShowPreview(true)}
            disabled={showPreview}
            className="flex items-center gap-2"
          >
            <Eye className="h-4 w-4" />
            Preview
          </Button>
          
          {isCourseCompleted ? (
            <Button
              variant="default"
              size="sm"
              onClick={downloadCertificate}
              className="flex items-center gap-2"
            >
              <Download className="h-4 w-4" />
              Download
            </Button>
          ) : (
            <Button
              variant="default"
              size="sm"
              disabled
              className="flex items-center gap-2 cursor-not-allowed"
              title="Complete the course to download certificate"
            >
              <Download className="h-4 w-4" />
              Download
            </Button>
          )}
        </div>
      </div>

      {/* Certificate */}
      {showPreview ? (
        <div
          id="certificate"
          className="relative border-8 border-indigo-600 dark:border-indigo-500 p-8 rounded-lg w-full max-w-[700px] aspect-[1.414/1] flex flex-col justify-center items-center bg-gradient-to-r from-indigo-50 to-white text-indigo-800 shadow-xl"
        >
          {/* Background pattern */}
          <div className="absolute inset-0 opacity-5 pointer-events-none" style={{ background: 'url("data:image/svg+xml,%3Csvg width=\'20\' height=\'20\' viewBox=\'0 0 20 20\' xmlns=\'http://www.w3.org/2000/svg\'%3E%3Cg fill=\'%239C92AC\' fill-opacity=\'0.4\' fill-rule=\'evenodd\'%3E%3Ccircle cx=\'3\' cy=\'3\' r=\'3\'/%3E%3Ccircle cx=\'13\' cy=\'13\' r=\'3\'/%3E%3C/g%3E%3C/svg%3E")' }}></div>
          
          {/* Logo & header */}
          <div className="absolute top-6 left-6 flex items-center space-x-2">
            <div className="w-12 h-12 text-indigo-700">
              <svg viewBox="0 0 100 100" fill="currentColor" xmlns="http://www.w3.org/2000/svg">
                <path d="M50,5C25.1,5,5,25.1,5,50s20.1,45,45,45s45-20.1,45-45S74.9,5,50,5z M50,15c19.3,0,35,15.7,35,35S69.3,85,50,85
                  S15,69.3,15,50S30.7,15,50,15z"/>
                <path d="M64.7,45.2c-2.4,0.8-4.8,1.9-7,3.4c-4.7,3.3-8,8.4-9.3,14.3c-0.2,0.8-0.3,1.7-0.4,2.6c-0.1,0.8-0.9,1.4-1.7,1.4
                  c-0.1,0-0.1,0-0.2,0c-0.9-0.1-1.6-0.9-1.5-1.8c0.1-1.1,0.3-2.1,0.5-3.2c1.5-7,5.5-13,11.2-17c2.5-1.8,5.3-3.1,8.3-4
                  c0.9-0.3,1.8,0.2,2.1,1.1C67.1,43.9,66.6,44.8,64.7,45.2z"/>
                <path d="M50,40c5.5,0,10-4.5,10-10s-4.5-10-10-10s-10,4.5-10,10S44.5,40,50,40z M50,26c2.2,0,4,1.8,4,4s-1.8,4-4,4s-4-1.8-4-4
                  S47.8,26,50,26z"/>
                <path d="M37.5,66.2c-0.4-0.8-0.1-1.8,0.7-2.2c2.2-1.1,4.3-2.3,6.1-3.8c4-3.2,6.6-7.5,7.7-12.9c0.1-0.8,0.2-1.7,0.2-2.5
                  c0-0.9,0.7-1.7,1.6-1.7c0,0,0.1,0,0.1,0c0.9,0,1.7,0.8,1.7,1.7c0,1-0.1,2-0.3,3c-1.3,6.3-4.4,11.5-9.2,15.4c-2.1,1.7-4.5,3.1-7,4.4
                  c-0.2,0.1-0.5,0.2-0.7,0.2C38.1,67.8,37.7,67.1,37.5,66.2z"/>
                <path d="M53.5,55.2c-0.1-0.6-0.3-1.1-0.4-1.7c-0.3-0.9,0.2-1.8,1.1-2.1c0.9-0.3,1.8,0.2,2.1,1.1c0.2,0.8,0.4,1.5,0.5,2.3
                  c0.1,0.9-0.5,1.7-1.4,1.8c-0.1,0-0.1,0-0.2,0C54.3,56.6,53.6,56,53.5,55.2z"/>
                <path d="M44.4,48.8c-0.9,0.2-1.8-0.4-2-1.3c-0.1-0.4-0.2-0.9-0.2-1.3c-0.1-0.9,0.6-1.7,1.5-1.8c0.9-0.1,1.7,0.6,1.8,1.5
                  c0,0.3,0.1,0.6,0.1,0.9C45.9,47.7,45.3,48.6,44.4,48.8z"/>
              </svg>
            </div>
            <span className="text-xl font-bold text-indigo-700">त्रिकाला अकादमी</span>
          </div>
          
          {/* Trophy icon */}
          <div className="w-24 h-24 mb-4 text-indigo-700">
            <Trophy className="w-full h-full drop-shadow-lg" />
          </div>
          
          {/* Main content */}
          <h1 className="text-4xl font-bold mb-6 text-indigo-800 tracking-wide">Certificate of Achievement</h1>
          <div className="w-3/4 h-px bg-indigo-200 mb-6"></div>
          <p className="text-xl mb-2">This is to certify that</p>
          <h2 className="text-3xl font-bold mb-4 text-indigo-900">{userName}</h2>
          <p className="text-lg mb-2">has successfully completed</p>
          <h3 className="text-2xl font-semibold mb-4 text-indigo-900 px-6 py-2 border border-indigo-200 rounded-lg">{courseTitle}</h3>
          <p className="text-md my-4">With excellence and devotion to spiritual growth</p>
          <p className="text-md mb-2">Completed on: <span className="font-semibold">{completionDate}</span></p>
          
          {/* Footer with seal and signature */}
          <div className="mt-8 w-full">
            <div className="flex justify-between items-end">
              <div>
                <div className="text-sm font-medium mb-1 text-indigo-900">Certificate ID:</div>
                <div className="text-xs text-indigo-600">{Math.random().toString(36).substring(2, 12).toUpperCase()}</div>
              </div>
              
              <div className="flex flex-col items-center">
                <div className="w-16 h-16 mb-1">
                  <svg viewBox="0 0 100 100" xmlns="http://www.w3.org/2000/svg" fill="currentColor" className="text-indigo-700 opacity-80">
                    <path d="M50,4.5C24.9,4.5,4.5,24.9,4.5,50S24.9,95.5,50,95.5S95.5,75.1,95.5,50S75.1,4.5,50,4.5z M50,9.5
                      c22.3,0,40.5,18.2,40.5,40.5S72.3,90.5,50,90.5S9.5,72.3,9.5,50S27.7,9.5,50,9.5z M50,14.5c-19.6,0-35.5,15.9-35.5,35.5
                      S30.4,85.5,50,85.5S85.5,69.6,85.5,50S69.6,14.5,50,14.5z M50,19.5c16.8,0,30.5,13.7,30.5,30.5S66.8,80.5,50,80.5S19.5,66.8,19.5,50
                      S33.2,19.5,50,19.5z M50,24.5c-14.1,0-25.5,11.4-25.5,25.5S35.9,75.5,50,75.5S75.5,64.1,75.5,50S64.1,24.5,50,24.5z M50,29.5
                      c11.3,0,20.5,9.2,20.5,20.5S61.3,70.5,50,70.5S29.5,61.3,29.5,50S38.7,29.5,50,29.5z M50,34.5c-8.5,0-15.5,7-15.5,15.5
                      S41.5,65.5,50,65.5S65.5,58.5,65.5,50S58.5,34.5,50,34.5z M50,39.5c5.8,0,10.5,4.7,10.5,10.5S55.8,60.5,50,60.5S39.5,55.8,39.5,50
                      S44.2,39.5,50,39.5z M50,44.5c-3,0-5.5,2.5-5.5,5.5s2.5,5.5,5.5,5.5s5.5-2.5,5.5-5.5S53,44.5,50,44.5z"/>
                  </svg>
                </div>
                <div className="text-xs text-indigo-800 font-medium">OFFICIAL SEAL</div>
              </div>
              
              <div className="flex flex-col items-end">
                <div className="h-10 mb-1 text-indigo-900 italic text-right">Trikala Academy</div>
                <div className="text-xs text-indigo-600">Spiritual Growth & Enlightenment</div>
              </div>
            </div>
          </div>
          
          {/* Border design elements */}
          <div className="absolute top-3 right-3 w-16 h-16 border-t-4 border-r-4 border-indigo-500 opacity-50"></div>
          <div className="absolute bottom-3 left-3 w-16 h-16 border-b-4 border-l-4 border-indigo-500 opacity-50"></div>
          
          {/* Corner decorative elements */}
          <div className="absolute top-5 right-20 w-12 h-12 opacity-10">
            <svg viewBox="0 0 100 100" fill="currentColor" xmlns="http://www.w3.org/2000/svg">
              <path d="M50,5C25.1,5,5,25.1,5,50s20.1,45,45,45s45-20.1,45-45S74.9,5,50,5z M50,15c19.3,0,35,15.7,35,35S69.3,85,50,85
                S15,69.3,15,50S30.7,15,50,15z"/>
              <path d="M64.7,45.2c-2.4,0.8-4.8,1.9-7,3.4c-4.7,3.3-8,8.4-9.3,14.3c-0.2,0.8-0.3,1.7-0.4,2.6c-0.1,0.8-0.9,1.4-1.7,1.4
                c-0.1,0-0.1,0-0.2,0c-0.9-0.1-1.6-0.9-1.5-1.8c0.1-1.1,0.3-2.1,0.5-3.2c1.5-7,5.5-13,11.2-17c2.5-1.8,5.3-3.1,8.3-4
                c0.9-0.3,1.8,0.2,2.1,1.1C67.1,43.9,66.6,44.8,64.7,45.2z"/>
              <path d="M50,40c5.5,0,10-4.5,10-10s-4.5-10-10-10s-10,4.5-10,10S44.5,40,50,40z M50,26c2.2,0,4,1.8,4,4s-1.8,4-4,4s-4-1.8-4-4
                S47.8,26,50,26z"/>
              <path d="M37.5,66.2c-0.4-0.8-0.1-1.8,0.7-2.2c2.2-1.1,4.3-2.3,6.1-3.8c4-3.2,6.6-7.5,7.7-12.9c0.1-0.8,0.2-1.7,0.2-2.5
                c0-0.9,0.7-1.7,1.6-1.7c0,0,0.1,0,0.1,0c0.9,0,1.7,0.8,1.7,1.7c0,1-0.1,2-0.3,3c-1.3,6.3-4.4,11.5-9.2,15.4c-2.1,1.7-4.5,3.1-7,4.4
                c-0.2,0.1-0.5,0.2-0.7,0.2C38.1,67.8,37.7,67.1,37.5,66.2z"/>
            </svg>
          </div>
          <div className="absolute bottom-5 left-20 w-12 h-12 opacity-10">
            <svg viewBox="0 0 100 100" fill="currentColor" xmlns="http://www.w3.org/2000/svg">
              <path d="M50,5C25.1,5,5,25.1,5,50s20.1,45,45,45s45-20.1,45-45S74.9,5,50,5z M50,15c19.3,0,35,15.7,35,35S69.3,85,50,85
                S15,69.3,15,50S30.7,15,50,15z"/>
              <path d="M64.7,45.2c-2.4,0.8-4.8,1.9-7,3.4c-4.7,3.3-8,8.4-9.3,14.3c-0.2,0.8-0.3,1.7-0.4,2.6c-0.1,0.8-0.9,1.4-1.7,1.4
                c-0.1,0-0.1,0-0.2,0c-0.9-0.1-1.6-0.9-1.5-1.8c0.1-1.1,0.3-2.1,0.5-3.2c1.5-7,5.5-13,11.2-17c2.5-1.8,5.3-3.1,8.3-4
                c0.9-0.3,1.8,0.2,2.1,1.1C67.1,43.9,66.6,44.8,64.7,45.2z"/>
              <path d="M50,40c5.5,0,10-4.5,10-10s-4.5-10-10-10s-10,4.5-10,10S44.5,40,50,40z M50,26c2.2,0,4,1.8,4,4s-1.8,4-4,4s-4-1.8-4-4
                S47.8,26,50,26z"/>
              <path d="M37.5,66.2c-0.4-0.8-0.1-1.8,0.7-2.2c2.2-1.1,4.3-2.3,6.1-3.8c4-3.2,6.6-7.5,7.7-12.9c0.1-0.8,0.2-1.7,0.2-2.5
                c0-0.9,0.7-1.7,1.6-1.7c0,0,0.1,0,0.1,0c0.9,0,1.7,0.8,1.7,1.7c0,1-0.1,2-0.3,3c-1.3,6.3-4.4,11.5-9.2,15.4c-2.1,1.7-4.5,3.1-7,4.4
                c-0.2,0.1-0.5,0.2-0.7,0.2C38.1,67.8,37.7,67.1,37.5,66.2z"/>
            </svg>
          </div>
        </div>
      ) : (
        <div className="relative flex flex-col items-center justify-center p-8 rounded-lg w-full max-w-[700px] aspect-[1.414/1] bg-gradient-to-r from-indigo-600 to-purple-700 text-white overflow-hidden">
          {/* Decorative elements */}
          <div className="absolute inset-0 flex justify-center">
            <div className="w-full h-full opacity-20">
              <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100" fill="currentColor">
                <circle cx="50" cy="50" r="45" fill="none" stroke="currentColor" strokeWidth="1"/>
                <circle cx="50" cy="50" r="35" fill="none" stroke="currentColor" strokeWidth="1"/>
                <circle cx="50" cy="50" r="25" fill="none" stroke="currentColor" strokeWidth="1"/>
                <circle cx="50" cy="50" r="15" fill="none" stroke="currentColor" strokeWidth="1"/>
              </svg>
            </div>
          </div>
          
          {/* Top ornament */}
          <div className="absolute top-0 left-0 w-full">
            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1440 320" fill="currentColor" className="text-white opacity-10">
              <path d="M0,288L48,272C96,256,192,224,288,197.3C384,171,480,149,576,165.3C672,181,768,235,864,250.7C960,267,1056,245,1152,208C1248,171,1344,117,1392,90.7L1440,64L1440,0L1392,0C1344,0,1248,0,1152,0C1056,0,960,0,864,0C768,0,672,0,576,0C480,0,384,0,288,0C192,0,96,0,48,0L0,0Z"></path>
            </svg>
          </div>
          
          {/* Logo in corner */}
          <div className="absolute top-4 left-4 flex items-center space-x-1">
            <div className="w-10 h-10 text-white opacity-80">
              <svg viewBox="0 0 100 100" fill="currentColor" xmlns="http://www.w3.org/2000/svg">
                <path d="M50,5C25.1,5,5,25.1,5,50s20.1,45,45,45s45-20.1,45-45S74.9,5,50,5z M50,15c19.3,0,35,15.7,35,35S69.3,85,50,85
                  S15,69.3,15,50S30.7,15,50,15z"/>
                <path d="M64.7,45.2c-2.4,0.8-4.8,1.9-7,3.4c-4.7,3.3-8,8.4-9.3,14.3c-0.2,0.8-0.3,1.7-0.4,2.6c-0.1,0.8-0.9,1.4-1.7,1.4
                  c-0.1,0-0.1,0-0.2,0c-0.9-0.1-1.6-0.9-1.5-1.8c0.1-1.1,0.3-2.1,0.5-3.2c1.5-7,5.5-13,11.2-17c2.5-1.8,5.3-3.1,8.3-4
                  c0.9-0.3,1.8,0.2,2.1,1.1C67.1,43.9,66.6,44.8,64.7,45.2z"/>
                <path d="M50,40c5.5,0,10-4.5,10-10s-4.5-10-10-10s-10,4.5-10,10S44.5,40,50,40z M50,26c2.2,0,4,1.8,4,4s-1.8,4-4,4s-4-1.8-4-4
                  S47.8,26,50,26z"/>
                <path d="M37.5,66.2c-0.4-0.8-0.1-1.8,0.7-2.2c2.2-1.1,4.3-2.3,6.1-3.8c4-3.2,6.6-7.5,7.7-12.9c0.1-0.8,0.2-1.7,0.2-2.5
                  c0-0.9,0.7-1.7,1.6-1.7c0,0,0.1,0,0.1,0c0.9,0,1.7,0.8,1.7,1.7c0,1-0.1,2-0.3,3c-1.3,6.3-4.4,11.5-9.2,15.4c-2.1,1.7-4.5,3.1-7,4.4
                  c-0.2,0.1-0.5,0.2-0.7,0.2C38.1,67.8,37.7,67.1,37.5,66.2z"/>
              </svg>
            </div>
            <span className="text-sm font-semibold text-white opacity-80">त्रिकाला अकादमी</span>
          </div>
          
          {/* Main content */}
          <div className="relative z-10">
            <div className="mb-2 text-white/60 text-sm font-light">TRIKALA ACADEMY PRESENTS</div>
            
            <div className="w-32 h-32 mx-auto mb-6 animate-bounce">
              <Trophy className="w-full h-full drop-shadow-lg" />
            </div>
            
            <h1 className="text-5xl font-bold mb-4 text-center text-white drop-shadow-md bg-clip-text bg-gradient-to-r from-white to-indigo-200">Congratulations!</h1>
            <h2 className="text-2xl font-medium mb-6 text-center">{userName}</h2>
            
            <div className="w-32 h-px bg-white/30 mx-auto mb-6"></div>
            
            <p className="text-xl mb-4 text-center">
              You have successfully completed
            </p>
            <h3 className="text-3xl font-bold mb-8 text-center px-6 py-2 border border-white/20 rounded-lg backdrop-blur-sm">
              {courseTitle}
            </h3>
            
            <div className="flex items-center justify-center">
              <div className="px-4 py-1 bg-white/10 backdrop-blur-sm rounded-full text-sm animate-pulse">
                Click "View Certificate" to see and download your achievement
              </div>
            </div>
          </div>
          
          {/* Animated particles */}
          <div className="absolute top-10 left-10 w-3 h-3 rounded-full bg-white/30 animate-ping" style={{ animationDuration: '3s', animationDelay: '0.5s' }}></div>
          <div className="absolute top-30 right-20 w-4 h-4 rounded-full bg-white/20 animate-ping" style={{ animationDuration: '4s', animationDelay: '1s' }}></div>
          <div className="absolute bottom-20 left-30 w-2 h-2 rounded-full bg-white/40 animate-ping" style={{ animationDuration: '2.5s', animationDelay: '0.2s' }}></div>
          <div className="absolute bottom-40 right-40 w-3 h-3 rounded-full bg-white/30 animate-ping" style={{ animationDuration: '3.5s', animationDelay: '1.5s' }}></div>
        </div>
      )}
    </div>
  );
}