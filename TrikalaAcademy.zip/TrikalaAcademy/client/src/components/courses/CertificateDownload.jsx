import { useState } from "react";
import jsPDF from "jspdf";
import html2canvas from "html2canvas";
import { Trophy, Download, Eye } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";

export default function CertificateDownload({ courseTitle, userName, completionDate = new Date().toLocaleDateString() }) {
  const [showPreview, setShowPreview] = useState(false);

  const downloadCertificate = async () => {
    const certificate = document.getElementById('certificate');

    try {
      const canvas = await html2canvas(certificate);
      const imgData = canvas.toDataURL('image/png');
      const pdf = new jsPDF('landscape', 'mm', 'a4');
      pdf.addImage(imgData, 'PNG', 10, 10, 277, 190);
      pdf.save(`${courseTitle}_certificate.pdf`);
    } catch (error) {
      console.error("Error generating PDF:", error);
    }
  };

  return (
    <div className="flex flex-col items-center mt-8 w-full max-w-4xl mx-auto">
      {/* Control Panel */}
      <div className="w-full flex flex-col sm:flex-row items-center justify-between mb-6 p-4 bg-gray-50 dark:bg-gray-800 rounded-lg">
        <div className="flex items-center space-x-4 mb-4 sm:mb-0">
          <div className="flex items-center space-x-2">
            <Switch 
              id="certificate-toggle"
              checked={showPreview} 
              onCheckedChange={setShowPreview} 
            />
            <Label htmlFor="certificate-toggle" className="cursor-pointer">
              {showPreview ? "View Certificate" : "View Celebration"}
            </Label>
          </div>
        </div>
        
        <div className="flex space-x-3">
          <Button
            variant="outline"
            size="sm"
            onClick={() => setShowPreview(true)}
            disabled={showPreview}
            className="flex items-center gap-2"
          >
            <Eye className="h-4 w-4" />
            Preview
          </Button>
          
          <Button
            variant="default"
            size="sm"
            onClick={downloadCertificate}
            className="flex items-center gap-2"
          >
            <Download className="h-4 w-4" />
            Download
          </Button>
        </div>
      </div>

      {/* Certificate */}
      {showPreview ? (
        <div
          id="certificate"
          className="border-4 border-indigo-600 dark:border-indigo-500 p-8 rounded-lg w-full max-w-[700px] aspect-[1.414/1] flex flex-col justify-center items-center bg-white text-indigo-600 shadow-lg"
        >
          <div className="w-24 h-24 mb-4 text-indigo-600">
            <Trophy className="w-full h-full" />
          </div>
          <h1 className="text-4xl font-bold mb-6">Certificate of Completion</h1>
          <p className="text-xl mb-2">This is to certify that</p>
          <h2 className="text-2xl font-bold mb-4">{userName}</h2>
          <p className="text-lg mb-2">has successfully completed the course</p>
          <h3 className="text-xl font-semibold mb-6">{courseTitle}</h3>
          <p className="text-md mb-2">Completed on: {completionDate}</p>
          <div className="mt-8 w-full flex justify-between items-center">
            <div className="text-sm text-gray-400">Certificate ID: {Math.random().toString(36).substring(2, 12).toUpperCase()}</div>
            <div className="text-sm text-gray-400">Trikala Academy</div>
          </div>
        </div>
      ) : (
        <div className="flex flex-col items-center justify-center p-8 rounded-lg w-full max-w-[700px] aspect-[1.414/1] bg-gradient-to-r from-indigo-500 to-purple-500 text-white">
          <div className="w-32 h-32 mb-6 animate-bounce">
            <Trophy className="w-full h-full" />
          </div>
          <h1 className="text-4xl font-bold mb-4 text-center">Congratulations!</h1>
          <h2 className="text-2xl font-medium mb-8 text-center">{userName}</h2>
          <p className="text-xl mb-6 text-center">
            You have successfully completed the course
          </p>
          <h3 className="text-3xl font-bold mb-10 text-center">{courseTitle}</h3>
          <p className="text-lg text-center opacity-80">
            Click "View Certificate" to see your achievement or download it directly.
          </p>
        </div>
      )}
    </div>
  );
}