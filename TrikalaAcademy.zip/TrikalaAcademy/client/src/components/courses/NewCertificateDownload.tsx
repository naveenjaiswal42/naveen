import { useState } from "react";
import jsPDF from "jspdf";
import html2canvas from "html2canvas";
import { Download, Eye, Printer } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import logoPath from "@assets/logo.png";
import { QRCodeSVG } from "qrcode.react";
import { useAuth } from "@/contexts/AuthContext";
import { useToast } from "@/hooks/use-toast";

interface CertificateDownloadProps {
  courseTitle: string;
  userName: string;
  completionDate?: string;
  isCourseCompleted?: boolean;
  userId?: number;
  courseId?: number;
}

export default function NewCertificateDownload({ 
  courseTitle, 
  userName, 
  completionDate = new Date().toLocaleDateString(),
  isCourseCompleted = false,
  userId = 1,
  courseId = 1
}: CertificateDownloadProps) {
  console.log("NewCertificateDownload rendered with isCourseCompleted:", isCourseCompleted);
  const [showPreview, setShowPreview] = useState(true);
  const { user, updateUserProfile } = useAuth();
  const { toast } = useToast();
  
  // Generate a consistent certificate ID for this user and course
  const certificateId = `CERT-${new Date().toISOString().slice(0,10).replace(/-/g,'')}-${Math.random().toString(36).substring(2, 6).toUpperCase()}`;
  const verificationUrl = `https://trikalaacademy.com/verify-certificate/${certificateId}?u=${userId}&c=${courseId}`;

  // Award XP bonus for certificate download
  const awardXpBonus = async () => {
    if (!user) return;
    
    try {
      // Add 200 XP to user's profile
      const response = await fetch(`/api/users/${user.id}/xp`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ xpAmount: 200 }),
      });
      
      if (response.ok) {
        const updatedUser = await response.json();
        
        // Update user context with new XP
        updateUserProfile({ xp: updatedUser.xp });
        
        // Show success toast
        toast({
          title: "🎉 XP Bonus Awarded!",
          description: "You earned +200 XP for downloading your certificate!",
          variant: "default",
        });
      }
    } catch (error) {
      console.error('Error awarding XP bonus:', error);
      toast({
        title: "Error",
        description: "Failed to award XP bonus. Please try again.",
        variant: "destructive",
      });
    }
  };
  
  const downloadCertificate = async () => {
    const certificate = document.getElementById('certificate');

    try {
      if (certificate) {
        const canvas = await html2canvas(certificate, { scale: 2 }); // Higher resolution
        const imgData = canvas.toDataURL('image/png');
        const pdf = new jsPDF('landscape', 'mm', 'a4');
        pdf.addImage(imgData, 'PNG', 10, 10, 277, 190);
        
        // Format the file name with student name for better organization
        const sanitizedName = userName.replace(/[^a-z0-9]/gi, '_').toLowerCase();
        pdf.save(`Trikala-Certificate-${sanitizedName}-${courseTitle}.pdf`);
        
        // Award XP bonus after successful download
        await awardXpBonus();
      }
    } catch (error) {
      console.error("Error generating PDF:", error);
    }
  };
  
  // Handle direct printing
  const printCertificate = () => {
    const certificate = document.getElementById('certificate');
    if (certificate) {
      html2canvas(certificate, { scale: 2 }).then(canvas => {
        const imgData = canvas.toDataURL('image/png');
        
        // Create a temporary hidden iframe for printing
        const printFrame = document.createElement('iframe');
        printFrame.style.position = 'fixed';
        printFrame.style.right = '0';
        printFrame.style.bottom = '0';
        printFrame.style.width = '0';
        printFrame.style.height = '0';
        printFrame.style.border = '0';
        
        document.body.appendChild(printFrame);
        
        printFrame.onload = () => {
          const frameDoc = printFrame.contentDocument;
          if (frameDoc) {
            frameDoc.open();
            frameDoc.write(`
              <html>
                <head>
                  <title>Print Certificate - ${courseTitle}</title>
                  <style>
                    body { margin: 0; padding: 0; display: flex; justify-content: center; }
                    img { max-width: 100%; height: auto; }
                    @media print {
                      @page { size: landscape; margin: 0; }
                    }
                  </style>
                </head>
                <body>
                  <img src="${imgData}" />
                  <script>
                    setTimeout(() => {
                      window.print();
                      window.parent.document.body.removeChild(window.frameElement);
                    }, 200);
                  </script>
                </body>
              </html>
            `);
            frameDoc.close();
          }
        };
      }).catch(err => {
        console.error("Error preparing certificate for print:", err);
      });
    }
  };

  return (
    <div className="flex flex-col items-center mt-8 w-full max-w-4xl mx-auto px-4">
      {/* Control Panel */}
      <div className="w-full flex flex-col sm:flex-row items-center justify-between mb-6 p-4 bg-gray-50 dark:bg-gray-800 rounded-lg">
        <div className="flex items-center space-x-4 mb-4 sm:mb-0 w-full sm:w-auto justify-center">
          <div className="flex items-center space-x-2">
            <Switch 
              id="certificate-toggle"
              checked={showPreview} 
              onCheckedChange={setShowPreview} 
            />
            <Label htmlFor="certificate-toggle" className="cursor-pointer">
              {showPreview ? "View Certificate" : "View Celebration"}
            </Label>
          </div>
        </div>
        
        <div className="flex space-x-2 sm:space-x-3 w-full sm:w-auto justify-center">
          <Button
            variant="outline"
            size="sm"
            onClick={() => setShowPreview(true)}
            disabled={showPreview}
            className="flex items-center gap-1 sm:gap-2 text-xs sm:text-sm"
          >
            <Eye className="h-3 w-3 sm:h-4 sm:w-4" />
            <span className="sm:inline">Preview</span>
          </Button>
          
          {isCourseCompleted ? (
            <>
              <Button
                variant="default"
                size="sm"
                onClick={downloadCertificate}
                className="flex items-center gap-1 sm:gap-2 text-xs sm:text-sm"
              >
                <Download className="h-3 w-3 sm:h-4 sm:w-4" />
                <span className="sm:inline">Download</span>
              </Button>
              <Button
                variant="outline"
                size="sm"
                onClick={printCertificate}
                className="flex items-center gap-1 sm:gap-2 text-xs sm:text-sm"
              >
                <Printer className="h-3 w-3 sm:h-4 sm:w-4" />
                <span className="sm:inline">Print</span>
              </Button>
            </>
          ) : (
            <>
              <Button
                variant="default"
                size="sm"
                disabled
                className="flex items-center gap-1 sm:gap-2 text-xs sm:text-sm cursor-not-allowed"
                title="Complete the course to download certificate"
              >
                <Download className="h-3 w-3 sm:h-4 sm:w-4" />
                <span className="sm:inline">Download</span>
              </Button>
              <Button
                variant="outline"
                size="sm"
                disabled
                className="flex items-center gap-1 sm:gap-2 text-xs sm:text-sm cursor-not-allowed"
                title="Complete the course to print certificate"
              >
                <Printer className="h-3 w-3 sm:h-4 sm:w-4" />
                <span className="sm:inline">Print</span>
              </Button>
            </>
          )}
        </div>
      </div>

      {/* Certificate */}
      {showPreview ? (
        <div
          id="certificate"
          className="relative w-full max-w-[850px] mx-auto aspect-[1.414/1] flex flex-col justify-center items-center overflow-hidden rounded-lg shadow-xl border-[3px] sm:border-[6px] border-indigo-600/80 scale-[0.85] sm:scale-100 origin-top"
          style={{ 
            background: 'linear-gradient(135deg, #f5f7fa 0%, #f8f9fa 100%)' 
          }}
        >
          {/* Background elegant pattern */}
          <div className="absolute inset-0 opacity-10"
            style={{ 
              backgroundImage: `url("data:image/svg+xml,%3Csvg width='100' height='100' viewBox='0 0 100 100' xmlns='http://www.w3.org/2000/svg'%3E%3Cpath d='M11 18c3.866 0 7-3.134 7-7s-3.134-7-7-7-7 3.134-7 7 3.134 7 7 7zm48 25c3.866 0 7-3.134 7-7s-3.134-7-7-7-7 3.134-7 7 3.134 7 7 7zm-43-7c1.657 0 3-1.343 3-3s-1.343-3-3-3-3 1.343-3 3 1.343 3 3 3zm63 31c1.657 0 3-1.343 3-3s-1.343-3-3-3-3 1.343-3 3 1.343 3 3 3zM34 90c1.657 0 3-1.343 3-3s-1.343-3-3-3-3 1.343-3 3 1.343 3 3 3zm56-76c1.657 0 3-1.343 3-3s-1.343-3-3-3-3 1.343-3 3 1.343 3 3 3zM12 86c2.21 0 4-1.79 4-4s-1.79-4-4-4-4 1.79-4 4 1.79 4 4 4zm28-65c2.21 0 4-1.79 4-4s-1.79-4-4-4-4 1.79-4 4 1.79 4 4 4zm23-11c2.76 0 5-2.24 5-5s-2.24-5-5-5-5 2.24-5 5 2.24 5 5 5zm-6 60c2.21 0 4-1.79 4-4s-1.79-4-4-4-4 1.79-4 4 1.79 4 4 4zm29 22c2.76 0 5-2.24 5-5s-2.24-5-5-5-5 2.24-5 5 2.24 5 5 5zM32 63c2.76 0 5-2.24 5-5s-2.24-5-5-5-5 2.24-5 5 2.24 5 5 5zm57-13c2.76 0 5-2.24 5-5s-2.24-5-5-5-5 2.24-5 5 2.24 5 5 5zm-9-21c1.105 0 2-.895 2-2s-.895-2-2-2-2 .895-2 2 .895 2 2 2zM60 91c1.105 0 2-.895 2-2s-.895-2-2-2-2 .895-2 2 .895 2 2 2zM35 41c1.105 0 2-.895 2-2s-.895-2-2-2-2 .895-2 2 .895 2 2 2zM12 60c1.105 0 2-.895 2-2s-.895-2-2-2-2 .895-2 2 .895 2 2 2z' fill='%236366f1' fill-opacity='0.25' fill-rule='evenodd'/%3E%3C/svg%3E")`
            }}
          ></div>
          
          {/* Colorful gradient border */}
          <div className="absolute inset-0 rounded-lg opacity-10 pointer-events-none bg-gradient-to-br from-indigo-500 via-purple-500 to-pink-500"></div>
          
          {/* Ornamental frame */}
          <div className="absolute inset-8 border-[10px] rounded-lg opacity-8 pointer-events-none" 
            style={{ 
              borderImage: 'url("data:image/svg+xml,%3Csvg xmlns=\'http://www.w3.org/2000/svg\' width=\'75\' height=\'75\' viewBox=\'0 0 75 75\'%3E%3Cg fill=\'none\' fill-rule=\'evenodd\'%3E%3Cpath stroke=\'%234F46E5\' stroke-width=\'2\' d=\'M38 38c0-12.7-10.3-23-23-23S-8 25.3-8 38s10.3 23 23 23 23-10.3 23-23M38 38c0 12.7 10.3 23 23 23s23-10.3 23-23-10.3-23-23-23-23 10.3-23 23\'/%3E%3C/g%3E%3C/svg%3E") 40',
              borderImageRepeat: 'round'
            }}
          ></div>
          
          {/* Lotus motif background elements */}
          <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[120%] h-[120%] opacity-[0.03] pointer-events-none" 
            style={{ 
              backgroundImage: `url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='200' height='200' viewBox='0 0 200 200'%3E%3Cg fill='%236d28d9' fill-opacity='0.9'%3E%3Cpath d='M100 0C90 10 80 20 70 30C60 20 50 10 40 0C30 10 20 20 10 30C20 40 30 50 40 60C30 70 20 80 10 90C20 100 30 110 40 120C30 130 20 140 10 150C20 160 30 170 40 180C50 170 60 160 70 150C80 160 90 170 100 180C110 170 120 160 130 150C140 160 150 170 160 180C170 170 180 160 190 150C180 140 170 130 160 120C170 110 180 100 190 90C180 80 170 70 160 60C170 50 180 40 190 30C180 20 170 10 160 0C150 10 140 20 130 30C120 20 110 10 100 0Z'/%3E%3C/g%3E%3C/svg%3E")`,
              backgroundSize: 'contain',
              backgroundPosition: 'center',
              backgroundRepeat: 'no-repeat',
              transform: 'rotate(45deg)'
            }}
          ></div>
          
          {/* Logo at top center */}
          <div className="absolute top-4 sm:top-6 inset-x-0 flex justify-center items-center">
            <div className="relative w-20 h-20 sm:w-28 sm:h-28">
              <img src={logoPath} alt="Trikala Academy Logo" className="w-full h-full object-contain" />
            </div>
          </div>
          
          {/* Logo in corner */}
          <div className="absolute top-6 sm:top-10 left-4 sm:left-8 flex flex-col items-center">
            <div className="w-12 h-12 sm:w-16 sm:h-16">
              <img src={logoPath} alt="Trikala Academy Logo" className="w-full h-full object-contain" />
            </div>
            <span className="text-xs sm:text-sm font-semibold text-indigo-800 mt-1">Trikala Academy</span>
          </div>
          
          {/* Main content */}
          <div className="w-full px-6 sm:px-12 mt-12 sm:mt-16 flex flex-col items-center">
            <h1 className="text-3xl sm:text-4xl font-bold mb-2 bg-gradient-to-r from-indigo-700 via-purple-700 to-indigo-700 text-transparent bg-clip-text text-center" style={{ fontFamily: 'Playfair Display, serif' }}>Certificate of Completion</h1>
            <div className="w-3/4 h-px bg-gradient-to-r from-indigo-300 via-purple-300 to-indigo-300 mb-4 sm:mb-6"></div>
            
            <p className="text-sm sm:text-base text-gray-600 mb-1 text-center font-medium">This is to certify that</p>
            <h2 className="text-2xl sm:text-3xl font-bold mb-3 text-indigo-900 text-center border-b-2 border-indigo-200 pb-1 px-4">{userName}</h2>
            
            <p className="text-sm sm:text-base text-gray-600 mb-1 text-center font-medium">has successfully completed the course</p>
            <h3 className="text-xl sm:text-2xl italic font-medium mb-4 text-indigo-800 text-center max-w-[90%] sm:max-w-md">{courseTitle}</h3>
            
            <p className="text-xs sm:text-sm text-gray-600 mb-1 text-center">
              Demonstrating dedication to spiritual growth and self-transformation
            </p>
            
            <div className="mt-2 w-3/4 sm:w-96 h-px bg-gradient-to-r from-transparent via-indigo-200 to-transparent"></div>
            <p className="text-xs sm:text-sm italic text-indigo-600/80 mt-3 text-center max-w-[90%] sm:max-w-md">
              "The journey of a thousand miles begins with a single step"
            </p>
          </div>
          
          {/* Certificate ID at top right */}
          <div className="absolute top-4 sm:top-6 right-4 sm:right-12">
            <p className="text-[10px] sm:text-xs text-indigo-700 font-medium text-center">CERTIFICATE ID</p>
            <p className="text-xs sm:text-sm text-indigo-900 font-semibold">{certificateId}</p>
          </div>

          {/* Footer with signatures */}
          <div className="absolute bottom-6 sm:bottom-10 w-full px-4 sm:px-12">
            <div className="flex justify-between items-end">
              {/* Instructor Signature */}
              <div className="flex flex-col items-center">
                <div className="flex items-end h-8 sm:h-10 mb-1 border-b border-gray-400 w-24 sm:w-40">
                  <div className="text-gray-500 italic text-xs sm:text-sm">Director's Signature</div>
                </div>
                <p className="text-[10px] sm:text-xs text-gray-600 font-medium">Director, Trikala Academy</p>
              </div>
              
              {/* Issue Date in center */}
              <div className="flex flex-col items-center">
                <div className="h-8 sm:h-10 mb-1 border-b border-gray-400 w-24 sm:w-32 flex justify-center items-end pb-1">
                  <p className="text-xs sm:text-sm text-gray-600">{new Date().toLocaleDateString('en-GB')}</p>
                </div>
                <p className="text-[10px] sm:text-xs text-gray-600 font-medium">Issue Date</p>
              </div>
              
              {/* QR Code on right */}
              <div className="flex flex-col items-center">
                <div className="w-16 h-16 sm:w-20 sm:h-20 border border-gray-300 bg-white p-1">
                  <QRCodeSVG 
                    value={verificationUrl}
                    size={60}
                    bgColor={"#ffffff"}
                    fgColor={"#000000"}
                    level={"H"}
                    includeMargin={false}
                  />
                </div>
                <p className="text-[10px] sm:text-xs text-gray-600 font-medium">Verify</p>
              </div>
            </div>
          </div>
          
          {/* Decorative corners */}
          <div className="absolute top-3 right-3 w-12 h-12 sm:w-20 sm:h-20 border-t-2 border-r-2 border-indigo-500/40"></div>
          <div className="absolute bottom-3 left-3 w-12 h-12 sm:w-20 sm:h-20 border-b-2 border-l-2 border-indigo-500/40"></div>
          <div className="absolute top-3 left-3 w-12 h-12 sm:w-20 sm:h-20 border-t-2 border-l-2 border-indigo-500/40"></div>
          <div className="absolute bottom-3 right-3 w-12 h-12 sm:w-20 sm:h-20 border-b-2 border-r-2 border-indigo-500/40"></div>
        </div>
      ) : (
        <div className="relative w-full max-w-[700px] mx-auto aspect-[1.414/1] flex flex-col justify-center items-center overflow-hidden rounded-lg shadow-xl scale-[0.9] sm:scale-100 origin-top"
          style={{ 
            background: 'linear-gradient(135deg, #6a11cb 0%, #2575fc 100%)'
          }}
        >
          {/* Background decoration */}
          <div className="absolute inset-0 bg-white/10 bg-opacity-5">
            <div className="absolute top-0 left-0 w-full h-full opacity-10" 
              style={{ 
                backgroundImage: 'radial-gradient(circle, rgba(255,255,255,0.3) 1px, transparent 1px)',
                backgroundSize: '20px 20px' 
              }}>
            </div>
          </div>
          
          {/* Logo in corner */}
          <div className="absolute top-4 left-4 flex items-center space-x-1">
            <div className="w-10 h-10 sm:w-12 sm:h-12">
              <img src={logoPath} alt="Trikala Academy Logo" className="w-full h-full object-contain drop-shadow-md" />
            </div>
          </div>
          
          {/* Border ornaments */}
          <div className="absolute top-0 left-0 w-full h-3 bg-gradient-to-r from-indigo-500/60 via-purple-500/60 to-indigo-500/60"></div>
          <div className="absolute top-0 right-0 h-full w-3 bg-gradient-to-b from-indigo-500/60 via-purple-500/60 to-indigo-500/60"></div>
          <div className="absolute bottom-0 left-0 w-full h-3 bg-gradient-to-r from-indigo-500/60 via-purple-500/60 to-indigo-500/60"></div>
          <div className="absolute top-0 left-0 h-full w-3 bg-gradient-to-b from-indigo-500/60 via-purple-500/60 to-indigo-500/60"></div>
          
          {/* Main content */}
          <div className="relative z-10 flex flex-col items-center px-4 sm:px-8 py-6">
            <div className="mb-2 text-white/80 text-sm sm:text-lg font-medium tracking-wider">TRIKALA ACADEMY PRESENTS</div>
            
            <div className="w-20 h-20 sm:w-28 sm:h-28 mx-auto mb-4 animate-pulse">
              <img src={logoPath} alt="Trikala Academy Logo" className="w-full h-full object-contain drop-shadow-lg" />
            </div>
            
            <h1 className="text-2xl sm:text-4xl font-bold mb-2 sm:mb-3 text-center text-white drop-shadow-md">Congratulations!</h1>
            <h2 className="text-lg sm:text-xl font-medium mb-2 sm:mb-3 text-center text-white/90">{userName}</h2>
            
            <div className="w-32 sm:w-48 h-px bg-white/30 mx-auto mb-2 sm:mb-3"></div>
            
            <p className="text-sm sm:text-base mb-1 sm:mb-2 text-center text-white/80">
              You have successfully completed
            </p>
            <h3 className="text-sm sm:text-lg font-bold mb-4 sm:mb-5 text-center px-3 sm:px-4 py-1 sm:py-2 border border-white/20 rounded-lg backdrop-blur-sm max-w-[90%] sm:max-w-[80%] truncate">
              {courseTitle}
            </h3>
            
            <div className="flex items-center justify-center">
              <div className="px-3 sm:px-4 py-1 bg-white/10 backdrop-blur-sm rounded-full text-xs sm:text-sm animate-pulse text-white/90">
                Click "View Certificate" to see and download
              </div>
            </div>
          </div>
          
          {/* Animated particles */}
          <div className="absolute top-10 left-10 w-1 h-1 sm:w-2 sm:h-2 rounded-full bg-white/30 animate-ping" style={{ animationDuration: '3s', animationDelay: '0.5s' }}></div>
          <div className="absolute top-30 right-20 w-1 h-1 sm:w-2 sm:h-2 rounded-full bg-white/20 animate-ping" style={{ animationDuration: '4s', animationDelay: '1s' }}></div>
          <div className="absolute bottom-20 left-30 w-1 h-1 sm:w-2 sm:h-2 rounded-full bg-white/40 animate-ping" style={{ animationDuration: '2.5s', animationDelay: '0.2s' }}></div>
          <div className="absolute bottom-40 right-40 w-1 h-1 sm:w-2 sm:h-2 rounded-full bg-white/30 animate-ping" style={{ animationDuration: '3.5s', animationDelay: '1.5s' }}></div>
        </div>
      )}
    </div>
  );
}