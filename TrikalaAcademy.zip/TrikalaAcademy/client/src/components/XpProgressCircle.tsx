import { useEffect, useState } from "react";

interface XpProgressCircleProps {
  xp: number;
  goalXp?: number;
  className?: string;
  showText?: boolean;
  size?: 'sm' | 'md' | 'lg';
  color?: string;
}

export default function XpProgressCircle({ 
  xp, 
  goalXp = 5000, 
  className = "",
  showText = true,
  size = 'md',
  color = "indigo"
}: XpProgressCircleProps) {
  const [progress, setProgress] = useState(0);
  const [animateProgress, setAnimateProgress] = useState(0);

  // Determine circle dimensions based on size
  const dimensions = {
    sm: { width: 80, height: 80, cx: 40, cy: 40, r: 35, strokeWidth: 8, fontSize: 'text-base' },
    md: { width: 120, height: 120, cx: 60, cy: 60, r: 50, strokeWidth: 10, fontSize: 'text-xl' },
    lg: { width: 160, height: 160, cx: 80, cy: 80, r: 70, strokeWidth: 12, fontSize: 'text-2xl' }
  };

  const { width, height, cx, cy, r, strokeWidth, fontSize } = dimensions[size];
  const circumference = 2 * Math.PI * r;

  useEffect(() => {
    // Calculate actual percentage (capped at 100%)
    const percentage = Math.min((xp / goalXp) * 100, 100);
    setProgress(percentage);
    
    // Animate the progress
    let start = 0;
    const duration = 1000; // milliseconds
    const startTime = performance.now();
    
    const animate = (currentTime: number) => {
      const elapsedTime = currentTime - startTime;
      const progress = Math.min(elapsedTime / duration, 1);
      const currentProgress = progress * percentage;
      
      setAnimateProgress(currentProgress);
      
      if (progress < 1) {
        requestAnimationFrame(animate);
      }
    };
    
    requestAnimationFrame(animate);
  }, [xp, goalXp]);

  // Determine color classes based on color prop
  const colorClasses = {
    indigo: "stroke-indigo-500 dark:stroke-indigo-400",
    green: "stroke-green-500 dark:stroke-green-400",
    red: "stroke-red-500 dark:stroke-red-400",
    purple: "stroke-purple-500 dark:stroke-purple-400",
    amber: "stroke-amber-500 dark:stroke-amber-400",
    blue: "stroke-blue-500 dark:stroke-blue-400",
    teal: "stroke-teal-500 dark:stroke-teal-400"
  };

  const textColorClasses = {
    indigo: "text-indigo-600 dark:text-indigo-300",
    green: "text-green-600 dark:text-green-300",
    red: "text-red-600 dark:text-red-300",
    purple: "text-purple-600 dark:text-purple-300",
    amber: "text-amber-600 dark:text-amber-300",
    blue: "text-blue-600 dark:text-blue-300",
    teal: "text-teal-600 dark:text-teal-300"
  };

  const strokeColor = colorClasses[color as keyof typeof colorClasses] || colorClasses.indigo;
  const textColor = textColorClasses[color as keyof typeof textColorClasses] || textColorClasses.indigo;

  return (
    <div className={`flex flex-col items-center justify-center ${className}`}>
      <div className="relative">
        <svg 
          width={width} 
          height={height} 
          viewBox={`0 0 ${width} ${height}`} 
          className="transform -rotate-90"
        >
          {/* Background circle */}
          <circle
            cx={cx}
            cy={cy}
            r={r}
            fill="none"
            className="stroke-gray-200 dark:stroke-gray-700"
            strokeWidth={strokeWidth}
          />
          
          {/* Foreground circle (progress) */}
          <circle
            cx={cx}
            cy={cy}
            r={r}
            fill="none"
            className={strokeColor}
            strokeWidth={strokeWidth}
            strokeLinecap="round"
            strokeDasharray={circumference}
            strokeDashoffset={circumference - (circumference * animateProgress) / 100}
            style={{ transition: "stroke-dashoffset 0.5s ease" }}
          />
        </svg>
        
        <div className={`absolute inset-0 flex items-center justify-center font-bold ${fontSize} ${textColor}`}>
          {Math.round(animateProgress)}%
        </div>
      </div>
      
      {showText && (
        <div className={`mt-2 ${textColor} font-medium text-center text-sm`}>
          {xp.toLocaleString()} XP
          <span className="text-gray-500 dark:text-gray-400"> / {goalXp.toLocaleString()} XP</span>
        </div>
      )}
    </div>
  );
}