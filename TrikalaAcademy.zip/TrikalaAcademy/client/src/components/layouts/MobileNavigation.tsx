import { useLocation } from "wouter";
import { Link } from "wouter";
import { 
  Home, 
  BookOpen, 
  Timer, 
  Users, 
  User, 
  ChevronUp, 
  Settings
} from "lucide-react";

export default function MobileNavigation() {
  const [location] = useLocation();

  return (
    <div className="fixed bottom-0 left-0 right-0 bg-white dark:bg-gray-800 border-t border-gray-200 dark:border-gray-700 flex justify-around items-center py-1 z-20 md:hidden">
      <Link href="/dashboard">
        <div className={`flex flex-col items-center p-2 text-xs ${location === "/dashboard" ? "text-primary" : "text-gray-500 dark:text-gray-400"}`}>
          <Home className="h-5 w-5 mb-1" />
          <span>Home</span>
        </div>
      </Link>
      
      <Link href="/courses">
        <div className={`flex flex-col items-center p-2 text-xs ${location === "/courses" ? "text-primary" : "text-gray-500 dark:text-gray-400"}`}>
          <BookOpen className="h-5 w-5 mb-1" />
          <span>Courses</span>
        </div>
      </Link>
      
      <Link href="/meditation-timer">
        <div className={`flex flex-col items-center p-2 text-xs ${location === "/meditation-timer" ? "text-primary" : "text-gray-500 dark:text-gray-400"}`}>
          <Timer className="h-5 w-5 mb-1" />
          <span>Meditate</span>
        </div>
      </Link>
      
      <Link href="/community">
        <div className={`flex flex-col items-center p-2 text-xs ${location === "/community" ? "text-primary" : "text-gray-500 dark:text-gray-400"}`}>
          <Users className="h-5 w-5 mb-1" />
          <span>Community</span>
        </div>
      </Link>
      
      <Link href="/direct-enroll">
        <div className={`flex flex-col items-center p-2 text-xs ${location === "/direct-enroll" ? "text-primary" : "text-gray-500 dark:text-gray-400"}`}>
          <Settings className="h-5 w-5 mb-1" />
          <span>Debug</span>
        </div>
      </Link>
      
      <Link href="/more">
        <div className={`flex flex-col items-center p-2 text-xs ${location === "/more" ? "text-primary" : "text-gray-500 dark:text-gray-400"}`}>
          <ChevronUp className="h-5 w-5 mb-1" />
          <span>More</span>
        </div>
      </Link>
    </div>
  );
}