import { useState, useRef, useEffect } from "react";
import { Bell, User, X, CheckCircle, Calendar, Clock, Award } from "lucide-react";
import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { useAuth } from "@/contexts/AuthContext";
import { useTranslation } from "@/hooks/useTranslation";
import { ThemeToggle } from "@/components/ui/theme-toggle";
// Logo image is imported relatively 
import logoImage from "../../assets/logo.png";

// Define notification type
interface Notification {
  id: number;
  title: string;
  message: string;
  time: string;
  read: boolean;
  type: 'achievement' | 'reminder' | 'course' | 'ritual';
}

export default function Header() {
  const { user } = useAuth();
  const { t } = useTranslation();
  const [notificationsOpen, setNotificationsOpen] = useState(false);
  const notificationRef = useRef<HTMLDivElement>(null);
  const buttonRef = useRef<HTMLButtonElement>(null);
  
  // Close notifications when clicking outside
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (
        notificationRef.current && 
        !notificationRef.current.contains(event.target as Node) &&
        buttonRef.current &&
        !buttonRef.current.contains(event.target as Node)
      ) {
        setNotificationsOpen(false);
      }
    };
    
    document.addEventListener('mousedown', handleClickOutside);
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, []);

  const [notifications, setNotifications] = useState<Notification[]>([
    {
      id: 1,
      title: "Achievement Unlocked",
      message: "Congratulations! You've earned the 'Meditation Warrior' badge.",
      time: "2 hours ago",
      read: false,
      type: 'achievement'
    },
    {
      id: 2,
      title: "Daily Ritual Reminder",
      message: "Don't forget your morning meditation ritual today.",
      time: "5 hours ago",
      read: false,
      type: 'reminder'
    },
    {
      id: 3,
      title: "Course Progress",
      message: "You've completed 75% of 'Yoga for Beginners'. Keep it up!",
      time: "Yesterday",
      read: true,
      type: 'course'
    },
    {
      id: 4,
      title: "New Badge Available",
      message: "Complete your streak to unlock the 'Spiritual Titan' badge!",
      time: "2 days ago",
      read: true,
      type: 'achievement'
    }
  ]);
  
  const unreadCount = notifications.filter(n => !n.read).length;
  
  const markAllAsRead = () => {
    setNotifications(notifications.map(n => ({ ...n, read: true })));
  };
  
  const markAsRead = (id: number) => {
    setNotifications(notifications.map(n => 
      n.id === id ? { ...n, read: true } : n
    ));
  };
  
  const dismissNotification = (id: number) => {
    setNotifications(notifications.filter(n => n.id !== id));
  };

  return (
    <header className="h-16 py-2 bg-white dark:bg-gray-900 shadow-md flex items-center justify-between px-4 md:px-8 fixed left-0 right-0 top-0 z-10 border-b border-gray-100 dark:border-gray-800">
      <div className="flex items-center gap-3">
        <Link href="/" className="flex items-center gap-2">
          <img 
            src={logoImage} 
            alt="Trikala Academy Logo" 
            className="h-10 w-10 rounded-lg shadow-sm" 
          />
          <span className="text-lg font-bold inline-block bg-gradient-to-r from-indigo-600 to-purple-600 bg-clip-text text-transparent">
            Trikala Academy
          </span>
        </Link>
      </div>
      
      <div className="flex items-center gap-2 md:gap-3">
        <div className="relative">
          <Button
            ref={buttonRef}
            variant="ghost"
            size="icon"
            className="relative rounded-full hover:bg-gray-100 dark:hover:bg-gray-800 transition-all duration-300 transform hover:scale-105"
            title="Notifications"
            onClick={() => setNotificationsOpen(!notificationsOpen)}
          >
            <Bell className="h-5 w-5 text-gray-600 dark:text-gray-300 transition-colors duration-300" />
            {unreadCount > 0 && (
              <span className="absolute top-0 right-0 flex items-center justify-center min-w-[18px] h-[18px] text-xs font-medium rounded-full bg-red-500 text-white border-2 border-white dark:border-gray-900 transition-all duration-300">
                {unreadCount}
              </span>
            )}
          </Button>
          
          {notificationsOpen && (
            <div 
              ref={notificationRef}
              className="absolute right-0 mt-2 w-80 bg-white dark:bg-gray-800 rounded-md shadow-lg z-50 border border-gray-200 dark:border-gray-700 overflow-hidden animate-in fade-in slide-in-from-top-5 duration-300">
              <div className="p-3 border-b border-gray-100 dark:border-gray-700 flex items-center justify-between">
                <h3 className="font-medium text-sm">Notifications</h3>
                <Link href="/notification-settings" className="text-xs text-primary hover:underline">
                  Settings
                </Link>
              </div>
              
              <div className="max-h-80 overflow-y-auto">
                {notifications.length === 0 ? (
                  <div className="p-4 text-center text-gray-500 dark:text-gray-400 text-sm">
                    No notifications
                  </div>
                ) : (
                  notifications.map(notification => (
                    <div 
                      key={notification.id} 
                      className={`p-3 border-b border-gray-100 dark:border-gray-700 flex ${!notification.read ? 'bg-gray-50 dark:bg-gray-800/50' : ''} hover:bg-gray-100 dark:hover:bg-gray-700 cursor-pointer transition-all duration-300`}
                      onClick={() => markAsRead(notification.id)}
                    >
                      <div className="mr-3 mt-1">
                        {notification.type === 'achievement' && (
                          <div className="w-8 h-8 rounded-full bg-amber-100 dark:bg-amber-900/30 flex items-center justify-center">
                            <Award className="h-4 w-4 text-amber-600 dark:text-amber-400" />
                          </div>
                        )}
                        {notification.type === 'reminder' && (
                          <div className="w-8 h-8 rounded-full bg-blue-100 dark:bg-blue-900/30 flex items-center justify-center">
                            <Clock className="h-4 w-4 text-blue-600 dark:text-blue-400" />
                          </div>
                        )}
                        {notification.type === 'course' && (
                          <div className="w-8 h-8 rounded-full bg-green-100 dark:bg-green-900/30 flex items-center justify-center">
                            <CheckCircle className="h-4 w-4 text-green-600 dark:text-green-400" />
                          </div>
                        )}
                        {notification.type === 'ritual' && (
                          <div className="w-8 h-8 rounded-full bg-purple-100 dark:bg-purple-900/30 flex items-center justify-center">
                            <Calendar className="h-4 w-4 text-purple-600 dark:text-purple-400" />
                          </div>
                        )}
                      </div>
                      <div className="flex-1">
                        <div className="flex justify-between items-start">
                          <h4 className="text-sm font-medium">{notification.title}</h4>
                          <button 
                            className="text-gray-400 hover:text-gray-600 dark:hover:text-gray-300 -mt-1 -mr-1 p-1"
                            onClick={(e) => {
                              e.stopPropagation();
                              dismissNotification(notification.id);
                            }}
                          >
                            <X className="h-3 w-3" />
                          </button>
                        </div>
                        <p className="text-xs text-gray-600 dark:text-gray-400 my-1">
                          {notification.message}
                        </p>
                        <span className="text-xs text-gray-500 dark:text-gray-500">
                          {notification.time}
                        </span>
                      </div>
                    </div>
                  ))
                )}
              </div>
              
              {notifications.length > 0 && (
                <div className="p-2 border-t border-gray-100 dark:border-gray-700 text-center">
                  <button 
                    className="text-xs text-primary hover:underline w-full py-1"
                    onClick={() => setNotifications([])}
                  >
                    Clear all notifications
                  </button>
                </div>
              )}
            </div>
          )}
        </div>
        
        <Link href="/profile">
          <Button 
            variant="ghost" 
            size="icon" 
            className="relative rounded-full hover:bg-gray-100 dark:hover:bg-gray-800 transition-all duration-300 transform hover:scale-105" 
            title="Profile"
          >
            <User className="h-5 w-5 text-gray-600 dark:text-gray-300 transition-colors duration-300" />
          </Button>
        </Link>
        
        <ThemeToggle />
      </div>
    </header>
  );
}