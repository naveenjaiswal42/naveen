import { Link, useLocation } from "wouter";
import { useAuth } from "@/contexts/AuthContext";
import { ThemeToggle } from "@/components/ui/theme-toggle";
import Logo from "@/components/ui/logo";

export default function Sidebar() {
  const [location] = useLocation();
  const { logout } = useAuth();

  // Updated nav items to match existing routes in App.tsx
  const navItems = [
    { path: "/dashboard", label: "Dashboard", icon: "fas fa-home" },
    { path: "/courses", label: "Courses", icon: "fas fa-book" },
    { path: "/my-courses", label: "My Courses", icon: "fas fa-graduation-cap" },
    { path: "/chakra-tracker", label: "Chakras", icon: "fas fa-om" },
    { path: "/meditation-timer", label: "Meditation Timer", icon: "fas fa-stopwatch" },
    { path: "/daily-ritual", label: "Daily Ritual", icon: "fas fa-tasks" },
    { path: "/personal-challenge", label: "Personal Challenge", icon: "fas fa-rocket" },
    { path: "/healing-journey", label: "Healing Journey", icon: "fas fa-heartbeat" },
    { path: "/spiritual-journal", label: "Spiritual Journal", icon: "fas fa-book-open" },
    { path: "/mood-tracker", label: "Mood Tracker", icon: "fas fa-smile" },
    { path: "/mood-reflection", label: "Mood Reflection", icon: "fas fa-chart-pie" },
    { path: "/affirmations", label: "Affirmations", icon: "fas fa-magic" },
    { path: "/community", label: "Community", icon: "fas fa-users" },
    { path: "/notification-settings", label: "Notifications", icon: "fas fa-bell" },
    { path: "/profile", label: "Profile", icon: "fas fa-user" },
  ];

  const handleLogout = async () => {
    try {
      await logout();
    } catch (error) {
      console.error("Logout failed:", error);
    }
  };

  return (
    <>
      {/* Desktop Sidebar */}
      <div className="w-64 h-screen bg-primary dark:bg-gray-800 text-white flex flex-col py-8 px-4 fixed left-0 top-0 z-20 overflow-y-auto hidden md:flex">
        <div className="flex items-center justify-center mb-10">
          <Logo className="w-10 h-10 mr-3" />
          <h2 className="text-2xl font-heading font-semibold">Trikala Academy</h2>
        </div>

        <nav className="flex flex-col space-y-3 flex-1">
          {navItems.map((item) => (
            <Link key={item.path} href={item.path}>
              <a 
                className={`hover:bg-white/10 px-4 py-3 rounded-lg flex items-center transition-colors ${
                  location === item.path 
                    ? "bg-white/20 text-white font-medium" 
                    : "text-white/80"
                }`}
              >
                <i className={`${item.icon} w-5 h-5 mr-3`}></i>
                <span>{item.label}</span>
              </a>
            </Link>
          ))}
        </nav>

        <div className="mt-6 pt-6 border-t border-white/10">
          <div className="flex items-center justify-between mb-4">
            <span className="text-sm text-white/60">Theme</span>
            <ThemeToggle mode="dark" />
          </div>
          
          <button 
            onClick={handleLogout}
            className="w-full flex items-center text-white/80 hover:text-white px-4 py-3 rounded-lg hover:bg-white/10 transition-colors"
          >
            <i className="fas fa-sign-out-alt w-5 h-5 mr-3"></i>
            <span>Log out</span>
          </button>
        </div>
      </div>
      
      {/* Mobile Bottom Navigation */}
      <div className="fixed bottom-0 left-0 right-0 bg-white dark:bg-gray-800 border-t border-gray-200 dark:border-gray-700 flex justify-around py-2 z-20 md:hidden">
        <Link href="/dashboard">
          <a className={`flex flex-col items-center p-2 ${location === "/dashboard" ? "text-primary" : "text-gray-500 dark:text-gray-400"}`}>
            <i className="fas fa-home text-xl"></i>
            <span className="text-xs mt-1">Home</span>
          </a>
        </Link>
        <Link href="/courses">
          <a className={`flex flex-col items-center p-2 ${location === "/courses" ? "text-primary" : "text-gray-500 dark:text-gray-400"}`}>
            <i className="fas fa-book text-xl"></i>
            <span className="text-xs mt-1">Courses</span>
          </a>
        </Link>
        <Link href="/meditation-timer">
          <a className={`flex flex-col items-center p-2 ${location === "/meditation-timer" ? "text-primary" : "text-gray-500 dark:text-gray-400"}`}>
            <i className="fas fa-stopwatch text-xl"></i>
            <span className="text-xs mt-1">Meditate</span>
          </a>
        </Link>
        <Link href="/community">
          <a className={`flex flex-col items-center p-2 ${location === "/community" ? "text-primary" : "text-gray-500 dark:text-gray-400"}`}>
            <i className="fas fa-users text-xl"></i>
            <span className="text-xs mt-1">Community</span>
          </a>
        </Link>
        <Link href="/profile">
          <a className={`flex flex-col items-center p-2 ${location === "/profile" ? "text-primary" : "text-gray-500 dark:text-gray-400"}`}>
            <i className="fas fa-user text-xl"></i>
            <span className="text-xs mt-1">Profile</span>
          </a>
        </Link>
      </div>
    </>
  );
}