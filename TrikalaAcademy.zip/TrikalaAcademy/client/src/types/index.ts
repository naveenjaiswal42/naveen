// Shared types for the entire application

export interface Ritual {
  id: number;
  title: string;
  description: string;
  time: string;
  chakraType?: string;
  duration?: number;
  benefits?: string;
  instructions?: string;
}

export interface UserRitual {
  id: number;
  userId: number;
  ritualId: number;
  date: string;
  completedAt: Date | null;
  // For backwards compatibility with existing code
  completed?: boolean;
  completedDate?: string;
  streakCount?: number;
}

export interface Course {
  id: number;
  title: string;
  description: string;
  imageUrl?: string;
  totalLessons: number;
  chakraFocus?: string[];
  level: string;
  duration: string;
}

export interface UserCourse {
  id: number;
  userId: number;
  courseId: number;
  lessonsCompleted: number;
  enrolledDate: string;
  lastAccessedDate?: string;
  completedDate?: string;
}

export interface MeditationTrack {
  id: number;
  title: string;
  description?: string;
  duration?: number;
  durationSeconds?: number;
  chakraType?: string;
  audioUrl?: string;
  imageUrl?: string;
  frequency?: string;
}

export interface User {
  id: number;
  phone: string;
  name?: string;
  profile_image?: string;
  level: number;
  xp: number;
  streak?: number;
  lastActive?: string;
  active_chakras?: number;
  badges?: string[];
}