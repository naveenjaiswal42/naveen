import { useState } from "react";
import { useMutation } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { Container } from "@/components/ui/container";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";
import { Loader2, Sparkles, Star, Wand2, RefreshCw, Quote, RotateCw } from "lucide-react";
import { Badge } from "@/components/ui/badge";

// Predefined Switchwords with their meanings
const switchwordsList = [
  { word: "TOGETHER", meaning: "For connection and unity" },
  { word: "DIVINE", meaning: "For divine help and intervention" },
  { word: "REACH", meaning: "To access spiritual knowledge" },
  { word: "CHANGE", meaning: "To transform and evolve" },
  { word: "FIND", meaning: "To discover lost items or wisdom" },
  { word: "CLEAN", meaning: "To clear energy blocks" },
  { word: "BE", meaning: "To embrace the present moment" },
  { word: "DONE", meaning: "For manifestation and completion" },
  { word: "DIVINE ORDER", meaning: "For things to flow naturally" },
  { word: "COUNT", meaning: "For financial abundance" },
  { word: "BUBBLE", meaning: "For protection from negative energy" },
  { word: "PRAISE", meaning: "For gratitude and appreciation" }
];

// Sample affirmations for when API is not available
const sampleAffirmations = [
  "I am a divine being of light, and I am worthy of all things good.",
  "My chakras are aligned, balanced, and radiating with positive energy.",
  "I release all negativity and embrace the divine guidance within me.",
  "My spiritual journey unfolds perfectly according to divine timing.",
  "I am connected to the universal wisdom and guided by higher consciousness.",
  "My meditation practice deepens my spiritual awareness with each passing day.",
  "I am open to receiving the abundance that flows freely from the universe."
];

export default function AffirmationSwitchwordPage() {
  const [affirmation, setAffirmation] = useState("");
  const [switchword, setSwitchword] = useState("");
  const [explanation, setExplanation] = useState("");
  const { toast } = useToast();
  const [todayDate] = useState(new Date().toLocaleDateString("en-US", { 
    month: 'long', 
    day: 'numeric',
    year: 'numeric'
  }));

  // Use react-query for the API request
  const generateAffirmationMutation = useMutation({
    mutationFn: async () => {
      const query = "Generate a spiritually uplifting affirmation and a powerful switchword for today. Format as JSON with fields: affirmation (a sentence for spiritual growth), switchword (a single word or short phrase in ALL CAPS), and explanation (brief description of what the switchword helps with). Make the affirmation focused on spiritual growth and inner transformation.";
      
      const response = await apiRequest({
        method: "POST", 
        url: "/api/openai-test", 
        body: { query }
      });
      const data = await response.json();
      
      // Check if the response is in JSON format
      try {
        if (data.message) {
          const jsonMatch = data.message.match(/\{[\s\S]*\}/);
          if (jsonMatch) {
            const jsonData = JSON.parse(jsonMatch[0]);
            return {
              affirmation: jsonData.affirmation || "I radiate divine light and positive energy every day.",
              switchword: jsonData.switchword || "DIVINE-ORDER",
              explanation: jsonData.explanation || "This switchword helps align your energy with the universe's flow."
            };
          }
        }
        
        // If no valid JSON is found, extract from text
        const messageLines = data.message?.split('\n') || [];
        return {
          affirmation: messageLines.find((line: string) => line.includes("Affirmation:"))?.replace("Affirmation:", "").trim() 
            || "I am aligned with the divine energy of the universe.",
          switchword: messageLines.find((line: string) => line.includes("Switchword:"))?.replace("Switchword:", "").trim() 
            || "DIVINE",
          explanation: messageLines.find((line: string) => line.includes("Explanation:"))?.replace("Explanation:", "").trim()
            || "This switchword helps connect you with divine guidance and support."
        };
      } catch (error) {
        console.error("Error parsing response:", error);
        // Use a random sample if parsing fails
        const randomAffirmation = sampleAffirmations[Math.floor(Math.random() * sampleAffirmations.length)];
        const randomSwitchword = switchwordsList[Math.floor(Math.random() * switchwordsList.length)];
        
        return {
          affirmation: randomAffirmation,
          switchword: randomSwitchword.word,
          explanation: randomSwitchword.meaning
        };
      }
    },
    onSuccess: (data) => {
      setAffirmation(data.affirmation);
      setSwitchword(data.switchword);
      setExplanation(data.explanation);
      
      // Store in localStorage for today
      const today = new Date().toISOString().split('T')[0];
      localStorage.setItem('trikala_last_affirmation_date', today);
      localStorage.setItem('trikala_affirmation', data.affirmation);
      localStorage.setItem('trikala_switchword', data.switchword);
      localStorage.setItem('trikala_explanation', data.explanation);
    },
    onError: (error) => {
      console.error("Error generating affirmation:", error);
      toast({
        title: "Generation Error",
        description: "Unable to generate your daily affirmation and switchword. Please try again later.",
        variant: "destructive"
      });
      
      // Use a random sample on error
      const randomAffirmation = sampleAffirmations[Math.floor(Math.random() * sampleAffirmations.length)];
      const randomSwitchword = switchwordsList[Math.floor(Math.random() * switchwordsList.length)];
      
      setAffirmation(randomAffirmation);
      setSwitchword(randomSwitchword.word);
      setExplanation(randomSwitchword.meaning);
    }
  });

  // Load saved values or generate new ones on component mount
  useState(() => {
    const today = new Date().toISOString().split('T')[0];
    const savedDate = localStorage.getItem('trikala_last_affirmation_date');
    
    if (savedDate === today) {
      // Use saved values for today
      const savedAffirmation = localStorage.getItem('trikala_affirmation');
      const savedSwitchword = localStorage.getItem('trikala_switchword');
      const savedExplanation = localStorage.getItem('trikala_explanation');
      
      if (savedAffirmation && savedSwitchword) {
        setAffirmation(savedAffirmation);
        setSwitchword(savedSwitchword);
        setExplanation(savedExplanation || "");
        return;
      }
    }
    
    // Generate new ones if not already generated today
    if (!generateAffirmationMutation.isPending) {
      generateAffirmationMutation.mutate();
    }
  });

  const handleGenerate = () => {
    generateAffirmationMutation.mutate();
  };

  return (
    <Container className="py-8">
      <div className="mb-8">
        <h1 className="text-3xl font-bold tracking-tight flex items-center gap-2">
          <Sparkles className="h-8 w-8 text-indigo-600 dark:text-indigo-400" /> 
          Daily Affirmation & Switchword
        </h1>
        <p className="text-gray-500 dark:text-gray-400 mt-2">
          Receive spiritual guidance and energy activation for today
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
        {/* Main affirmation and switchword display */}
        <div className="md:col-span-2 space-y-6">
          <Card className="border-indigo-100 dark:border-indigo-800/30">
            <CardHeader>
              <CardTitle className="flex items-center justify-between">
                <span className="flex items-center gap-2">
                  <Star className="h-5 w-5 text-amber-500" />
                  Today's Guidance - {todayDate}
                </span>
                <Button 
                  variant="outline" 
                  size="sm" 
                  onClick={handleGenerate}
                  disabled={generateAffirmationMutation.isPending}
                >
                  {generateAffirmationMutation.isPending ? (
                    <RotateCw className="h-4 w-4 animate-spin" />
                  ) : (
                    <RefreshCw className="h-4 w-4" />
                  )}
                </Button>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-8">
                {generateAffirmationMutation.isPending ? (
                  <div className="flex flex-col items-center justify-center py-12">
                    <Loader2 className="h-12 w-12 text-indigo-500 animate-spin mb-4" />
                    <p className="text-gray-500 dark:text-gray-400">Connecting with divine energy...</p>
                  </div>
                ) : (
                  <>
                    {/* Affirmation Card */}
                    <div className="bg-gradient-to-r from-indigo-50/70 to-purple-50/70 dark:from-indigo-900/20 dark:to-purple-900/20 rounded-lg p-6 shadow-sm border border-indigo-100 dark:border-indigo-800/30">
                      <div className="flex items-center gap-2 mb-4">
                        <Quote className="h-5 w-5 text-indigo-600 dark:text-indigo-400" />
                        <h3 className="font-medium text-indigo-800 dark:text-indigo-300">Daily Affirmation</h3>
                      </div>
                      <blockquote className="text-xl font-serif italic text-gray-700 dark:text-gray-300 pl-4 border-l-2 border-indigo-300 dark:border-indigo-700">
                        "{affirmation}"
                      </blockquote>
                    </div>

                    {/* Switchword Card */}
                    <div className="bg-gradient-to-r from-amber-50/70 to-orange-50/70 dark:from-amber-900/20 dark:to-orange-900/20 rounded-lg p-6 shadow-sm border border-amber-100 dark:border-amber-800/30">
                      <div className="flex items-center gap-2 mb-4">
                        <Wand2 className="h-5 w-5 text-amber-600 dark:text-amber-400" />
                        <h3 className="font-medium text-amber-800 dark:text-amber-300">Switchword</h3>
                      </div>
                      <div className="flex flex-col items-center">
                        <div className="text-3xl font-bold tracking-wide text-amber-700 dark:text-amber-400 mb-3">
                          {switchword}
                        </div>
                        {explanation && (
                          <p className="text-gray-600 dark:text-gray-400 text-center">
                            {explanation}
                          </p>
                        )}
                      </div>
                    </div>
                  </>
                )}

                <div className="text-sm text-gray-500 dark:text-gray-400 italic">
                  <p>Repeat your affirmation 3 times in the morning and 3 times before bed for maximum benefit.</p>
                  <p className="mt-1">Speak your switchword whenever you need spiritual activation for its specific energy.</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Sidebar with information */}
        <div className="space-y-6">
          <Card className="border-indigo-100 dark:border-indigo-800/30">
            <CardHeader>
              <CardTitle className="text-lg">About Switchwords</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <p className="text-sm text-gray-600 dark:text-gray-400">
                Switchwords are single-word mantras that can help activate specific energies and 
                manifest intentions. They work as commands to your subconscious mind and the universe.
              </p>
              
              <div className="space-y-1">
                <h4 className="font-medium text-indigo-700 dark:text-indigo-400 text-sm">How to Use:</h4>
                <ol className="text-sm text-gray-600 dark:text-gray-400 space-y-1 list-decimal pl-4">
                  <li>Speak your switchword clearly with intention</li>
                  <li>Chant it during meditation for amplified results</li>
                  <li>Write it down and place it where you'll see it often</li>
                  <li>Visualize its energy activating as you say it</li>
                </ol>
              </div>
            </CardContent>
          </Card>

          <Card className="border-indigo-100 dark:border-indigo-800/30">
            <CardHeader>
              <CardTitle className="text-lg">Popular Switchwords</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex flex-wrap gap-2">
                {switchwordsList.slice(0, 9).map((item, index) => (
                  <div key={index} className="group relative">
                    <Badge className="bg-indigo-50 text-indigo-700 dark:bg-indigo-900/30 dark:text-indigo-300 hover:bg-indigo-100 dark:hover:bg-indigo-800/40 cursor-help">
                      {item.word}
                    </Badge>
                    <div className="absolute bottom-full mb-2 left-1/2 transform -translate-x-1/2 w-48 p-2 bg-white dark:bg-gray-800 rounded shadow-lg text-xs text-gray-700 dark:text-gray-300 invisible opacity-0 group-hover:visible group-hover:opacity-100 transition-opacity z-50 pointer-events-none">
                      {item.meaning}
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          <div className="bg-indigo-50 dark:bg-indigo-950/20 p-4 rounded-lg border border-indigo-100 dark:border-indigo-800/30">
            <h3 className="font-medium text-indigo-800 dark:text-indigo-300 mb-2">Daily Practice</h3>
            <ul className="space-y-2 text-sm text-gray-600 dark:text-gray-400">
              <li className="flex items-start gap-2">
                <span className="text-indigo-600 dark:text-indigo-400 mt-0.5">•</span>
                <span>Recite your affirmation during morning meditation</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-indigo-600 dark:text-indigo-400 mt-0.5">•</span>
                <span>Speak your switchword when you need energetic support</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-indigo-600 dark:text-indigo-400 mt-0.5">•</span>
                <span>Journal about the energetic shifts you experience</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-indigo-600 dark:text-indigo-400 mt-0.5">•</span>
                <span>Return for new guidance when you feel spiritually drained</span>
              </li>
            </ul>
          </div>
        </div>
      </div>
    </Container>
  );
}