import { useState, useEffect } from "react";
import { db } from "../firebase";
import { 
  collection, 
  getDocs, 
  doc, 
  updateDoc, 
  setDoc, 
  Timestamp, 
  query, 
  orderBy 
} from "firebase/firestore";
import { useAuth } from "@/contexts/AuthContext";
import { useToast } from "@/hooks/use-toast";
import { Container } from "@/components/ui/container";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { 
  CheckCircle, 
  Flag, 
  Star, 
  Calendar,
  Heart,
  Award
} from "lucide-react";
import ChallengeCompletionPopup from "@/components/ChallengeCompletionPopup";

// List of healing journey tasks - one for each day
const healingTasks = [
  "Day 1: Gratitude List - Write 5 things you're grateful for",
  "Day 2: 10 min Deep Breathing Meditation",
  "Day 3: Smile at a stranger today",
  "Day 4: Drink 2 litres of water mindfully",
  "Day 5: Morning Sun Salutation",
  "Day 6: Write a forgiveness letter (no need to send it)",
  "Day 7: Random act of kindness",
  "Day 8: Silent 5-minute meditation",
  "Day 9: Affirm: 'I am worthy of love and abundance'",
  "Day 10: Nature Walk - Feel the ground beneath you",
  "Day 11: Listen to healing frequencies (528Hz)",
  "Day 12: Visualize your dream life for 5 minutes",
  "Day 13: Practice Mirror Affirmations",
  "Day 14: 3-minute laughter exercise",
  "Day 15: Connect deeply with family member or friend",
  "Day 16: Digital detox for 2 hours",
  "Day 17: Grounding barefoot walk",
  "Day 18: Full moon intention setting (any day will work)",
  "Day 19: Create a vision board for your spiritual goals",
  "Day 20: List 10 positive qualities about yourself",
  "Day 21: Celebrate your healing journey completion!"
];

// Task categories for visual distinction
const taskCategories = {
  meditation: [1, 7, 10],
  gratitude: [0, 6, 19],
  physical: [3, 4, 16],
  mental: [5, 11, 18],
  social: [2, 6, 14],
  spiritual: [8, 12, 17],
  celebration: [13, 20]
};

// Benefit descriptions for the healing journey
const journeyBenefits = [
  {
    title: "Holistic Healing",
    description: "Address mind, body, and spirit through diverse daily practices",
    icon: Heart
  },
  {
    title: "Habit Formation",
    description: "21 days helps establish positive spiritual habits that last",
    icon: Calendar
  },
  {
    title: "Transformative Growth",
    description: "Experience gradual but profound shifts in your consciousness",
    icon: Award
  }
];

// Get the category for styling based on day index
const getTaskCategory = (index: number) => {
  for (const [category, days] of Object.entries(taskCategories)) {
    if (days.includes(index)) return category;
  }
  return "default";
};

// Get class names based on category
const getCategoryClassNames = (category: string, isCompleted: boolean) => {
  if (isCompleted) {
    return "bg-green-50 dark:bg-green-900/10 border-green-200 dark:border-green-800/30";
  }

  switch (category) {
    case "meditation":
      return "bg-purple-50 dark:bg-purple-900/10 border-purple-200 dark:border-purple-800/30";
    case "gratitude":
      return "bg-amber-50 dark:bg-amber-900/10 border-amber-200 dark:border-amber-800/30";
    case "physical":
      return "bg-blue-50 dark:bg-blue-900/10 border-blue-200 dark:border-blue-800/30";
    case "mental":
      return "bg-teal-50 dark:bg-teal-900/10 border-teal-200 dark:border-teal-800/30";
    case "social":
      return "bg-pink-50 dark:bg-pink-900/10 border-pink-200 dark:border-pink-800/30";
    case "spiritual":
      return "bg-indigo-50 dark:bg-indigo-900/10 border-indigo-200 dark:border-indigo-800/30";
    case "celebration":
      return "bg-rose-50 dark:bg-rose-900/10 border-rose-200 dark:border-rose-800/30";
    default:
      return "bg-gray-50 dark:bg-gray-800/10 border-gray-200 dark:border-gray-700/30";
  }
};

interface HealingDay {
  id: string;
  day: number;
  completed: boolean;
  completedAt: Timestamp | null;
}

export default function HealingJourneyPage() {
  const { user } = useAuth();
  const { toast } = useToast();
  const [completedDays, setCompletedDays] = useState<HealingDay[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [markingDay, setMarkingDay] = useState<number | null>(null);
  const [showCompletionPopup, setShowCompletionPopup] = useState(false);

  // Calculate progress percentage
  const progress = Math.round((completedDays.length / healingTasks.length) * 100);
  const isJourneyComplete = completedDays.length === healingTasks.length;
  
  // Fetch user's healing journey progress
  useEffect(() => {
    const fetchJourney = async () => {
      if (!user) {
        setIsLoading(false);
        return;
      }

      try {
        setIsLoading(true);
        
        // In development mode, we're using the user's ID as a string identifier
        const userId = user.id.toString();
        
        const journeyRef = collection(db, "users", userId, "healingJourney");
        const journeyQuery = query(journeyRef, orderBy("day", "asc"));
        const snapshot = await getDocs(journeyQuery);
        
        const days = snapshot.docs.map(doc => ({
          id: doc.id,
          ...doc.data()
        })) as HealingDay[];
        
        setCompletedDays(days);
      } catch (error) {
        console.error("Error fetching healing journey:", error);
        toast({
          title: "Error",
          description: "Failed to load your healing journey progress",
          variant: "destructive"
        });
      } finally {
        setIsLoading(false);
      }
    };

    fetchJourney();
  }, [user, toast]);

  // Mark a day as complete
  const markDayComplete = async (dayIndex: number) => {
    if (!user) return;
    
    try {
      setMarkingDay(dayIndex);
      
      // In development mode, we're using the user's ID as a string identifier
      const userId = user.id.toString();
      
      const dayDocId = `day${dayIndex + 1}`;
      const journeyRef = doc(db, "users", userId, "healingJourney", dayDocId);
      
      const dayData = {
        day: dayIndex + 1,
        completed: true,
        completedAt: Timestamp.now()
      };
      
      // Set the document (will create if doesn't exist)
      await setDoc(journeyRef, dayData);
      
      // Update local state
      const newCompletedDay = {
        id: dayDocId,
        ...dayData
      };
      
      setCompletedDays(prev => {
        const exists = prev.some(day => day.id === dayDocId);
        if (exists) return prev;
        return [...prev, newCompletedDay];
      });
      
      // Show success message
      toast({
        title: "Day Completed!",
        description: `You've completed Day ${dayIndex + 1} of your healing journey`,
        variant: "default"
      });
      
      // Check if the entire journey is complete
      if (completedDays.length + 1 === healingTasks.length) {
        // Show celebration popup
        setShowCompletionPopup(true);
        
        // Award XP here
        toast({
          title: "Journey Completed!",
          description: "You've earned 500 XP for completing the 21-Day Healing Journey",
          variant: "default"
        });
      }
    } catch (error) {
      console.error("Error marking day complete:", error);
      toast({
        title: "Error",
        description: "Failed to mark day as complete",
        variant: "destructive"
      });
    } finally {
      setMarkingDay(null);
    }
  };

  // Check if a specific day is completed
  const isDayCompleted = (dayIndex: number) => {
    return completedDays.some(day => day.day === dayIndex + 1);
  };

  return (
    <Container className="py-8">
      {/* Celebration Popup */}
      <ChallengeCompletionPopup 
        show={showCompletionPopup}
        onClose={() => setShowCompletionPopup(false)}
        challengeTitle="21-Day Healing Journey"
      />
      
      <div className="flex flex-col md:flex-row items-start md:items-center justify-between mb-6">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">🧿 21-Day Healing Journey</h1>
          <p className="text-gray-500 dark:text-gray-400 mt-2">
            A transformative daily practice for holistic spiritual growth
          </p>
        </div>
        
        <div className="mt-4 md:mt-0 bg-indigo-50 dark:bg-indigo-900/30 rounded-lg p-3">
          <div className="flex items-center gap-2">
            <Flag className="h-5 w-5 text-indigo-600 dark:text-indigo-400" />
            <p className="font-medium text-indigo-700 dark:text-indigo-300">
              {completedDays.length} of 21 days completed
            </p>
          </div>
        </div>
      </div>
      
      {/* Progress Bar */}
      <Card className="mb-8">
        <CardHeader className="pb-2">
          <div className="flex justify-between items-center">
            <CardTitle>Your Healing Progress</CardTitle>
            <span className="text-sm font-medium">{progress}%</span>
          </div>
        </CardHeader>
        <CardContent>
          <Progress value={progress} className="h-3" />
          
          <div className="flex justify-between mt-4 text-sm text-gray-500">
            <span>Day 1</span>
            <span>Day 10</span>
            <span>Day 21</span>
          </div>
        </CardContent>
      </Card>
      
      {/* Days List */}
      <div className="space-y-4 mb-8">
        {isLoading ? (
          <div className="flex items-center justify-center py-12">
            <div className="h-8 w-8 animate-spin rounded-full border-2 border-indigo-600 border-t-transparent"></div>
          </div>
        ) : (
          healingTasks.map((task, index) => {
            const dayCompleted = isDayCompleted(index);
            const category = getTaskCategory(index);
            const categoryClass = getCategoryClassNames(category, dayCompleted);
            
            return (
              <Card 
                key={index} 
                className={`overflow-hidden transition-colors ${categoryClass}`}
              >
                <CardContent className="p-5 flex justify-between items-center">
                  <div>
                    <h3 className="font-semibold mb-1">{task.split(':')[0]}</h3>
                    <p className="text-gray-700 dark:text-gray-300">{task.split(':')[1]}</p>
                  </div>
                  
                  {dayCompleted ? (
                    <div className="flex items-center text-green-600 dark:text-green-400 font-medium">
                      <CheckCircle className="h-5 w-5 mr-2" />
                      <span>Completed</span>
                    </div>
                  ) : (
                    <Button 
                      onClick={() => markDayComplete(index)}
                      disabled={markingDay === index}
                    >
                      {markingDay === index ? (
                        <>
                          <div className="mr-2 h-4 w-4 animate-spin rounded-full border-2 border-current border-t-transparent" />
                          Marking...
                        </>
                      ) : (
                        <>Mark Complete</>
                      )}
                    </Button>
                  )}
                </CardContent>
              </Card>
            );
          })
        )}
      </div>
      
      {/* Benefits Section */}
      <Card className="bg-indigo-50 dark:bg-indigo-900/10 border-indigo-100 dark:border-indigo-800/30">
        <CardHeader>
          <div className="flex items-center gap-2">
            <Star className="h-5 w-5 text-amber-500" />
            <CardTitle>Benefits of the 21-Day Healing Journey</CardTitle>
          </div>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {journeyBenefits.map((benefit, index) => (
              <div key={index} className="flex flex-col items-center text-center">
                <div className="w-12 h-12 rounded-full bg-indigo-100 dark:bg-indigo-800/30 flex items-center justify-center mb-3">
                  <benefit.icon className="h-6 w-6 text-indigo-600 dark:text-indigo-400" />
                </div>
                <h3 className="font-semibold mb-2">{benefit.title}</h3>
                <p className="text-sm text-gray-600 dark:text-gray-400">{benefit.description}</p>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </Container>
  );
}