import { useEffect, useState } from 'react';
import { useParams } from 'wouter';
import { useQuery } from '@tanstack/react-query';
import { apiRequest } from '@/lib/queryClient';
import { useToast } from '@/hooks/use-toast';
import { useLanguage } from '@/contexts/LanguageContext';
import { useAuth } from '@/contexts/AuthContext';
import { Course, UserCourse } from '@shared/schema';

import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle
} from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import { Progress } from '@/components/ui/progress';
import { BookOpen, BookText, Award, Sparkles, CheckCircle, ChevronLeft, Play } from 'lucide-react';
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from '@/components/ui/accordion';
import { Link } from 'wouter';

// Define a type that represents a course with properly mapped fields for frontend
interface CourseData {
  id: number;
  title: string;
  description: string | null;
  imageUrl: string | null;
  level: number | null;
  totalLessons: number | null;
  xpReward: number | null;
  // Lessons field will be added dynamically when available
  lessons?: LessonData[];
}

interface LessonData {
  id: number;
  title: string;
  description: string | null;
  duration: number | null; // in minutes
  videoUrl?: string | null;
  order: number | null;
}

// Demo lessons data for development
const demoLessons: Record<string, LessonData[]> = {
  'chakra-healing': [
    { id: 1, title: 'Introduction to Chakras', description: 'Learn about the seven main chakras and their significance in your spiritual journey.', duration: 15, order: 1 },
    { id: 2, title: 'Root Chakra Healing', description: 'Techniques to balance and heal your root chakra for stability and security.', duration: 20, order: 2 },
    { id: 3, title: 'Sacral Chakra Activation', description: 'Unlock your creativity and emotional balance by activating your sacral chakra.', duration: 25, order: 3 },
    { id: 4, title: 'Solar Plexus Empowerment', description: 'Build confidence and personal power by strengthening your solar plexus chakra.', duration: 20, order: 4 },
    { id: 5, title: 'Heart Chakra Opening', description: 'Open your heart to love and compassion through heart chakra practices.', duration: 30, order: 5 }
  ],
  'tarot-reading': [
    { id: 6, title: 'Tarot Basics', description: 'Understanding the structure and history of tarot cards.', duration: 15, order: 1 },
    { id: 7, title: 'Major Arcana Cards', description: 'Deep dive into the 22 major arcana cards and their meanings.', duration: 30, order: 2 },
    { id: 8, title: 'Minor Arcana Suits', description: 'Learn about the four suits and their symbolic meanings.', duration: 25, order: 3 },
    { id: 9, title: 'Simple Tarot Spreads', description: 'Practice basic three-card and five-card spreads for different questions.', duration: 20, order: 4 }
  ],
  'vedic-astrology': [
    { id: 10, title: 'Introduction to Vedic Astrology', description: 'Learn the basics and differences from Western astrology.', duration: 15, order: 1 },
    { id: 11, title: 'Understanding Your Birth Chart', description: 'How to read your Vedic birth chart and its significance.', duration: 30, order: 2 },
    { id: 12, title: 'Planets and Their Influence', description: 'The nine planets in Vedic astrology and their impact on your life.', duration: 25, order: 3 },
    { id: 13, title: 'Houses and Their Meanings', description: 'The twelve houses and what they represent in your life journey.', duration: 20, order: 4 },
    { id: 14, title: 'Dasha Systems', description: 'Understanding the timing of events in your life through Vedic astrology.', duration: 35, order: 5 }
  ]
};

export default function CourseDetailPage() {
  const { id } = useParams();
  const { user } = useAuth();
  const { toast } = useToast();
  const { language } = useLanguage();
  const [course, setCourse] = useState<CourseData | null>(null);
  const [isEnrolled, setIsEnrolled] = useState(false);
  const [progress, setProgress] = useState(0);
  const [completedLessons, setCompletedLessons] = useState<number[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchCourseDetails = async () => {
      if (!user || !id) return;
      
      try {
        setLoading(true);
        
        // Get course details through API
        let courseId = parseInt(id);
        if (isNaN(courseId)) {
          // Handle named routes like "chakra-healing"
          const courseMap: Record<string, number> = {
            'chakra-healing': 1,
            'tarot-reading': 2,
            'numerology-decoder': 3,
            'vedic-astrology': 4
          };
          courseId = courseMap[id] || 1;
        }
        
        // Get course data from API
        const courseData = await apiRequest<Course>({
          url: `/api/courses/${courseId}`,
          method: 'GET'
        });
        
        if (!courseData) {
          throw new Error("Course not found");
        }
        
        // Map API response to our frontend model
        const mappedCourse: CourseData = {
          id: courseData.id,
          title: courseData.title,
          description: courseData.description,
          imageUrl: courseData.imageUrl,
          level: courseData.level,
          totalLessons: courseData.totalLessons || 5,
          xpReward: courseData.xpReward || 100
        };
        
        // Add demo lessons based on course ID or slug
        if (demoLessons[id]) {
          mappedCourse.lessons = demoLessons[id];
        } else {
          // Use chakra healing lessons as default for now
          mappedCourse.lessons = demoLessons['chakra-healing'];
        }
        
        setCourse(mappedCourse);
        
        // Check if user is enrolled
        const userCoursesData = await apiRequest<UserCourse[]>({
          url: `/api/users/${user.id}/courses`,
          method: 'GET'
        });
        
        const userCourse = userCoursesData.find(uc => uc.courseId === courseId);
        if (userCourse) {
          setIsEnrolled(true);
          // Calculate progress
          const lessonsCompleted = userCourse.lessonsCompleted || 0;
          const totalLessons = mappedCourse.totalLessons || 5;
          const progressPercentage = Math.round((lessonsCompleted / totalLessons) * 100);
          setProgress(progressPercentage);
          
          // Set completed lessons (this would come from API in a real implementation)
          // For now, we'll assume first N lessons are completed based on lessonsCompleted count
          const completed = [];
          for (let i = 1; i <= lessonsCompleted; i++) {
            completed.push(i);
          }
          setCompletedLessons(completed);
        }
      } catch (error) {
        console.error("Error fetching course details:", error);
        toast({
          title: language === 'en' ? "Error" : "त्रुटि",
          description: language === 'en' ? "Failed to load course details" : "पाठ्यक्रम विवरण लोड करने में विफल",
          variant: "destructive",
        });
      } finally {
        setLoading(false);
      }
    };
    
    fetchCourseDetails();
  }, [user, id, toast, language]);

  const handleEnroll = async () => {
    if (!user || !course) return;
    
    try {
      // Enroll user in the course through API
      await apiRequest({
        url: `/api/users/${user.id}/courses`,
        method: 'POST',
        body: {
          userId: user.id,
          courseId: course.id,
          lessonsCompleted: 0
        }
      });
      
      // Update local state
      setIsEnrolled(true);
      setProgress(0);
      setCompletedLessons([]);
      
      toast({
        title: language === 'en' ? "Enrollment Successful" : "नामांकन सफल",
        description: language === 'en' ? "You are now enrolled in this course" : "आप पाठ्यक्रम में नामांकित हो गए हैं",
      });
    } catch (error) {
      console.error("Error enrolling in course:", error);
      toast({
        title: language === 'en' ? "Enrollment Failed" : "नामांकन विफल",
        description: language === 'en' ? "Failed to enroll in course" : "पाठ्यक्रम में नामांकन करने में विफल",
        variant: "destructive",
      });
    }
  };

  const completeLesson = async (lessonId: number) => {
    if (!user || !course || completedLessons.includes(lessonId)) return;
    
    try {
      // Calculate new progress
      const newCompletedLessons = [...completedLessons, lessonId];
      const totalLessons = course.totalLessons || 5;
      const newProgress = Math.round((newCompletedLessons.length / totalLessons) * 100);
      
      // Update user's course progress through API
      await apiRequest({
        url: `/api/users/${user.id}/courses/${course.id}/progress`,
        method: 'PATCH',
        body: {
          lessonsCompleted: newCompletedLessons.length
        }
      });
      
      // Update local state
      setCompletedLessons(newCompletedLessons);
      setProgress(newProgress);
      
      toast({
        title: language === 'en' ? "Lesson Completed" : "पाठ पूरा हुआ",
        description: language === 'en' ? "Your progress has been updated" : "आपकी प्रगति अपडेट हो गई है",
      });
      
      // Check if course is completed
      if (newProgress >= 100) {
        toast({
          title: language === 'en' ? "Course Completed!" : "पाठ्यक्रम पूरा हुआ!",
          description: language === 'en' ? `Congratulations! You've earned ${course.xpReward} XP` : `बधाई हो! आपने ${course.xpReward} XP अर्जित किए हैं`,
          variant: "default",
        });
      }
    } catch (error) {
      console.error("Error updating lesson progress:", error);
      toast({
        title: language === 'en' ? "Error" : "त्रुटि",
        description: language === 'en' ? "Failed to update lesson progress" : "पाठ प्रगति अपडेट करने में विफल",
        variant: "destructive",
      });
    }
  };

  if (loading) {
    return (
      <div className="p-8 max-w-5xl mx-auto">
        <h1 className="text-3xl font-bold mb-6">
          {language === 'en' ? "Loading course details..." : "पाठ्यक्रम विवरण लोड हो रहा है..."}
        </h1>
        <p className="text-center text-gray-500 dark:text-gray-400">
          {language === 'en' ? "Please wait" : "कृपया प्रतीक्षा करें"}
        </p>
      </div>
    );
  }

  if (!course) {
    return (
      <div className="p-8 max-w-5xl mx-auto">
        <h1 className="text-3xl font-bold mb-6 text-red-500">
          {language === 'en' ? "Course Not Found" : "पाठ्यक्रम नहीं मिला"}
        </h1>
        <p className="text-center text-gray-500 dark:text-gray-400 mb-8">
          {language === 'en' 
            ? "The course you're looking for doesn't exist or has been removed." 
            : "आप जिस पाठ्यक्रम की तलाश कर रहे हैं वह मौजूद नहीं है या हटा दिया गया है।"}
        </p>
        <div className="flex justify-center">
          <Button asChild>
            <Link href="/courses">
              <ChevronLeft className="h-4 w-4 mr-2" />
              {language === 'en' ? "Back to Courses" : "पाठ्यक्रमों पर वापस जाएं"}
            </Link>
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className="p-8 max-w-5xl mx-auto">
      {/* Back button */}
      <div className="mb-4">
        <Button variant="ghost" asChild>
          <Link href="/courses">
            <ChevronLeft className="h-4 w-4 mr-2" />
            Back to Courses
          </Link>
        </Button>
      </div>
      
      {/* Course header */}
      <div className="mb-8">
        <div className="flex flex-col md:flex-row justify-between items-start gap-4 mb-4">
          <div>
            <h1 className="text-3xl font-bold">{course.title}</h1>
            <div className="flex items-center gap-3 mt-2">
              <Badge className={`${
                course.level && course.level <= 2 
                  ? "bg-green-100 text-green-800 dark:bg-green-900/30 dark:text-green-400" 
                  : "bg-purple-100 text-purple-800 dark:bg-purple-900/30 dark:text-purple-400"
              }`}>
                {course.level && course.level <= 2 ? "🌱 Beginner" : "✨ Advanced"}
              </Badge>
              <div className="flex items-center text-sm text-gray-500 dark:text-gray-400">
                <BookOpen className="h-4 w-4 mr-1" />
                <span>{course.totalLessons} lessons</span>
              </div>
              <div className="flex items-center text-sm text-amber-600 dark:text-amber-400">
                <Sparkles className="h-4 w-4 mr-1 text-amber-500" />
                <span>{course.xpReward} XP</span>
              </div>
            </div>
          </div>
          
          {!isEnrolled ? (
            <Button onClick={handleEnroll} className="min-w-[150px]">
              <BookOpen className="h-4 w-4 mr-2" />
              Enroll Now
            </Button>
          ) : (
            <div className="flex flex-col items-end">
              <div className="flex items-center mb-2">
                <Badge variant="outline" className="bg-green-100 text-green-800 dark:bg-green-900/30 dark:text-green-400 border-0 flex items-center gap-1">
                  <CheckCircle className="h-3 w-3" /> 
                  Enrolled
                </Badge>
              </div>
              <div className="w-full max-w-[200px]">
                <div className="flex justify-between text-xs mb-1">
                  <span>Your Progress</span>
                  <span>{progress}%</span>
                </div>
                <Progress value={progress} className="h-2" />
              </div>
            </div>
          )}
        </div>
        
        <Card className="mb-8">
          <CardContent className="pt-6">
            <p className="text-gray-600 dark:text-gray-300">
              {course.description || "Develop your inner peace and knowledge with this spiritual journey."}
            </p>
          </CardContent>
        </Card>
      </div>
      
      {/* Course content/lessons */}
      <div>
        <h2 className="text-2xl font-bold mb-4">Course Content</h2>
        
        <Accordion type="single" collapsible className="mb-8">
          {course.lessons?.map((lesson) => {
            const isCompleted = completedLessons.includes(lesson.id);
            
            return (
              <AccordionItem key={lesson.id} value={`lesson-${lesson.id}`}>
                <AccordionTrigger className="hover:no-underline">
                  <div className="flex items-center justify-between w-full pr-4">
                    <div className="flex items-center">
                      {isCompleted ? (
                        <CheckCircle className="h-5 w-5 text-green-500 mr-3 flex-shrink-0" />
                      ) : (
                        <div className="h-5 w-5 rounded-full border-2 border-gray-300 dark:border-gray-600 mr-3 flex-shrink-0" />
                      )}
                      <div className="text-left">
                        <h3 className="font-medium">{lesson.title}</h3>
                        <div className="flex items-center text-xs text-gray-500 dark:text-gray-400 mt-1">
                          <Play className="h-3 w-3 mr-1" />
                          <span>{lesson.duration} min</span>
                        </div>
                      </div>
                    </div>
                    {isEnrolled && !isCompleted && (
                      <Button 
                        size="sm" 
                        variant="outline" 
                        onClick={(e) => {
                          e.stopPropagation();
                          completeLesson(lesson.id);
                        }}
                        className="ml-auto"
                      >
                        Mark as Completed
                      </Button>
                    )}
                  </div>
                </AccordionTrigger>
                <AccordionContent>
                  <div className="pl-11">
                    <p className="text-gray-600 dark:text-gray-300 mb-4">
                      {lesson.description}
                    </p>
                    
                    {isEnrolled ? (
                      <Button 
                        variant="outline" 
                        onClick={() => isCompleted || completeLesson(lesson.id)}
                        disabled={isCompleted}
                        className="mb-2"
                      >
                        {isCompleted ? (
                          <>
                            <CheckCircle className="h-4 w-4 mr-2 text-green-500" />
                            Completed
                          </>
                        ) : (
                          <>
                            <Play className="h-4 w-4 mr-2" />
                            Start Lesson
                          </>
                        )}
                      </Button>
                    ) : (
                      <Button onClick={handleEnroll} variant="outline" className="mb-2">
                        <BookOpen className="h-4 w-4 mr-2" />
                        Enroll to Access
                      </Button>
                    )}
                  </div>
                </AccordionContent>
              </AccordionItem>
            );
          })}
        </Accordion>
      </div>
    </div>
  );
}