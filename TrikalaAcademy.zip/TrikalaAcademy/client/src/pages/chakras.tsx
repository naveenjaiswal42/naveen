import { useState } from "react";
import { Link } from "wouter";
import ChakraVisualization from "@/components/chakras/ChakraVisualization";
import MeditationPlayer from "@/components/chakras/MeditationPlayer";
import { chakras } from "@/lib/chakras";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Button } from "@/components/ui/button";
import ChakraTracker from "./chakra-tracker";
import { Flower } from "lucide-react";

const Chakras = () => {
  const [selectedChakra, setSelectedChakra] = useState(chakras[0].id);

  return (
    <div className="p-4 pb-24">
      <div className="mb-6">
        <h1 className="text-2xl font-heading font-bold text-gray-800 dark:text-white mb-2">
          Chakra Energy Center
        </h1>
        <p className="text-gray-600 dark:text-gray-400">
          Balance and activate your energy centers through meditation and mindfulness.
        </p>
      </div>
      
      <div className="mb-8 bg-white dark:bg-gray-800 rounded-xl shadow-md border border-gray-100 dark:border-gray-700 p-4">
        <h3 className="text-lg font-semibold text-gray-800 dark:text-white mb-4 flex items-center">
          <Flower className="h-5 w-5 text-primary mr-2" />
          Chakra Activation Progress
        </h3>
        <ChakraTracker />
      </div>

      <Tabs defaultValue="visualization" className="mb-8">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="visualization">
            <i className="fas fa-om mr-2"></i>
            Visualization
          </TabsTrigger>
          <TabsTrigger value="meditation">
            <i className="fas fa-headphones mr-2"></i>
            Meditation
          </TabsTrigger>
          <TabsTrigger value="tracker">
            <i className="fas fa-balance-scale mr-2"></i>
            Chakra Tracker
          </TabsTrigger>
        </TabsList>
        
        <TabsContent value="visualization" className="pt-4">
          <ChakraVisualization />
        </TabsContent>
        
        <TabsContent value="meditation" className="pt-4">
          <div className="mb-4">
            <div className="flex justify-between items-center mb-3">
              <label className="block text-sm font-medium text-gray-700 dark:text-gray-300">
                Select Chakra for Meditation:
              </label>
              <Link href="/chakra-meditation">
                <Button variant="outline" size="sm">
                  <i className="fas fa-spa mr-2"></i>
                  Advanced Meditation Journey
                </Button>
              </Link>
            </div>
            <div className="grid grid-cols-7 gap-2">
              {chakras.map(chakra => (
                <button 
                  key={chakra.id}
                  className={`p-2 rounded-lg flex flex-col items-center ${
                    selectedChakra === chakra.id 
                      ? `${chakra.color} text-white` 
                      : 'bg-gray-100 dark:bg-gray-800 text-gray-700 dark:text-gray-300'
                  }`}
                  onClick={() => setSelectedChakra(chakra.id)}
                >
                  <i className={`${chakra.icon} mb-1`}></i>
                  <span className="text-xs">{chakra.name}</span>
                </button>
              ))}
            </div>
          </div>
          
          <MeditationPlayer selectedChakra={selectedChakra} />
          
          <div className="mt-6 bg-indigo-50 dark:bg-indigo-900/20 p-4 rounded-lg">
            <h3 className="text-lg font-medium mb-2 text-indigo-700 dark:text-indigo-300">
              Looking for more immersive meditation?
            </h3>
            <p className="text-gray-600 dark:text-gray-400 mb-4">
              Try our advanced chakra meditation journey for a complete guided experience with all seven chakras.
              This feature includes specialized audio tracks and XP rewards for your spiritual growth.
            </p>
            <Link href="/chakra-meditation">
              <Button>
                <i className="fas fa-headphones mr-2"></i>
                Start Meditation Journey
              </Button>
            </Link>
          </div>
        </TabsContent>
        
        <TabsContent value="tracker" className="pt-4">
          <ChakraTracker />
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default Chakras;
