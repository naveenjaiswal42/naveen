import { useState } from "react";
import { useAuth } from "@/contexts/AuthContext";
import NewCertificateDownload from "@/components/courses/NewCertificateDownload";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { ChevronLeft } from "lucide-react";
import { useLocation } from "wouter";

export default function CertificateViewPage() {
  const { user } = useAuth();
  const [, navigate] = useLocation();
  
  return (
    <div className="container max-w-4xl mx-auto py-8 px-4">
      <Button 
        variant="ghost" 
        onClick={() => navigate('/')}
        className="mb-4"
      >
        <ChevronLeft className="h-4 w-4 mr-2" />
        Back to Dashboard
      </Button>
      
      <Card className="mb-6">
        <CardHeader>
          <CardTitle className="text-2xl">View Your Certificate</CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-gray-600 dark:text-gray-400 mb-6">
            This is a demo of our new certificate system. You can preview and download this certificate.
          </p>
          
          <NewCertificateDownload 
            courseTitle="Spiritual Mastery"
            userName={user?.name || "Spiritual Seeker"}
            completionDate={new Date().toLocaleDateString()}
            isCourseCompleted={true} // Default certificate view page always allows download
          />
        </CardContent>
      </Card>
    </div>
  );
}