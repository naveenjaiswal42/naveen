import { useChakras } from "@/contexts/ChakraContext";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { ChakraType, chakras as chakraData } from "@/lib/chakras";
import { useState } from "react";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/contexts/AuthContext";
import { Sparkles, Lock, Unlock, Check } from "lucide-react";

// Required XP for each chakra
const CHAKRA_XP_REQUIREMENTS = {
  "root": 100,
  "sacral": 250,
  "solar": 400,
  "heart": 600,
  "throat": 800,
  "thirdEye": 1000,
  "crown": 1200
};

// Maximum XP needed for all chakras
const MAX_XP = 1200;

export default function ChakraTrackerPage() {
  const { chakras, progressPercentage, activateChakra, isLoading } = useChakras();
  const { user } = useAuth();
  const { toast } = useToast();
  const [activating, setActivating] = useState<ChakraType | null>(null);
  const [showUnlockAnimation, setShowUnlockAnimation] = useState<ChakraType | null>(null);
  
  // User's current XP
  const userXP = user?.xp || 0;
  
  const handleActivateChakra = async (chakraType: ChakraType) => {
    if (chakras[chakraType]) return; // Already activated
    
    // Check if user has enough XP
    if (userXP < CHAKRA_XP_REQUIREMENTS[chakraType]) {
      toast({
        title: "Not Enough XP",
        description: `You need ${CHAKRA_XP_REQUIREMENTS[chakraType]} XP to activate the ${getChakraName(chakraType)} chakra.`,
        variant: "destructive",
      });
      return;
    }
    
    try {
      setActivating(chakraType);
      await activateChakra(chakraType);
      
      // Show unlock animation
      setShowUnlockAnimation(chakraType);
      setTimeout(() => setShowUnlockAnimation(null), 3000);
      
      toast({
        title: "Chakra Activated!",
        description: `You have successfully activated your ${getChakraName(chakraType)} chakra.`,
      });
    } catch (error) {
      toast({
        title: "Activation Failed",
        description: "Could not activate chakra. Please try again.",
        variant: "destructive",
      });
    } finally {
      setActivating(null);
    }
  };
  
  const getChakraName = (type: ChakraType): string => {
    const chakra = chakraData.find(c => c.id === type);
    return chakra ? chakra.name : "";
  };
  
  const getChakraColor = (type: ChakraType): string => {
    switch (type) {
      case "root": return "bg-red-500";
      case "sacral": return "bg-orange-500";
      case "solar": return "bg-yellow-400";
      case "heart": return "bg-green-500";
      case "throat": return "bg-blue-500";
      case "thirdEye": return "bg-indigo-500";
      case "crown": return "bg-purple-600";
      default: return "bg-gray-400";
    }
  };
  
  const getBorderColor = (type: ChakraType): string => {
    if (chakras[type]) {
      switch (type) {
        case "root": return "border-red-500";
        case "sacral": return "border-orange-500";
        case "solar": return "border-yellow-400";
        case "heart": return "border-green-500";
        case "throat": return "border-blue-500";
        case "thirdEye": return "border-indigo-500";
        case "crown": return "border-purple-600";
        default: return "border-gray-400";
      }
    }
    return "border-gray-200 dark:border-gray-700";
  };
  
  const getTextColor = (type: ChakraType): string => {
    if (chakras[type] || userXP >= CHAKRA_XP_REQUIREMENTS[type]) {
      switch (type) {
        case "root": return "text-red-500";
        case "sacral": return "text-orange-500";
        case "solar": return "text-yellow-500";
        case "heart": return "text-green-500";
        case "throat": return "text-blue-500";
        case "thirdEye": return "text-indigo-500";
        case "crown": return "text-purple-600";
        default: return "text-gray-500";
      }
    }
    return "text-gray-500 dark:text-gray-400";
  };
  
  const canActivate = (type: ChakraType): boolean => {
    return userXP >= CHAKRA_XP_REQUIREMENTS[type];
  };

  // Sort chakras by their natural order: from root (bottom) to crown (top)
  const sortedChakras = [...chakraData].sort((a, b) => a.order - b.order);
  
  if (isLoading) {
    return (
      <div className="p-6">
        <h1 className="text-3xl font-heading font-bold mb-6 text-gray-800 dark:text-white">
          Chakra Energy Journey
        </h1>
        <p className="text-center text-gray-500 dark:text-gray-400 py-8">
          Loading your chakra data...
        </p>
      </div>
    );
  }
  
  return (
    <div className="p-3 xs:p-4 sm:p-6 pb-20 sm:pb-24">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-6">
        <div>
          <h1 className="text-3xl font-heading font-bold text-gray-800 dark:text-white">
            Your Chakra Journey
          </h1>
          <p className="text-gray-600 dark:text-gray-400 mt-1">
            Track your spiritual energy centers and balance
          </p>
        </div>
      </div>
      
      {/* XP Progress Bar */}
      <div className="bg-indigo-50 dark:bg-indigo-900/20 p-3 sm:p-4 rounded-lg shadow-sm mb-6 sm:mb-8">
        <div className="flex flex-col xs:flex-row justify-between gap-2 xs:items-center">
          <h2 className="text-lg xs:text-xl font-semibold text-indigo-600 dark:text-indigo-400">
            <span className="flex items-center gap-2">
              <span className="whitespace-nowrap">Your Chakra XP:</span> {userXP} 
              <span className="text-yellow-500"><Sparkles size={16} /></span>
            </span>
          </h2>
          <span className="text-sm text-gray-600 dark:text-gray-400 bg-indigo-100 dark:bg-indigo-900/30 px-2 py-1 rounded-full">
            {progressPercentage}% Activated
          </span>
        </div>
        <div className="w-full bg-gray-200 dark:bg-gray-700 rounded-full h-3 sm:h-4 mt-3 sm:mt-4 overflow-hidden">
          <div
            className="bg-indigo-600 dark:bg-indigo-400 h-full rounded-full transition-all duration-500 relative"
            style={{ width: `${Math.min((userXP / MAX_XP) * 100, 100)}%` }}
          >
            <span className="absolute inset-0 flex justify-center items-center">
              <span className="animate-pulse bg-white/30 w-4 h-4 rounded-full hidden sm:block"></span>
            </span>
          </div>
        </div>
      </div>
      
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 md:gap-6 mt-8">
        {sortedChakras.map((chakra) => {
          const isUnlocked = userXP >= CHAKRA_XP_REQUIREMENTS[chakra.id];
          const isActivated = chakras[chakra.id];
          const isAnimating = showUnlockAnimation === chakra.id;
          
          return (
            <Card 
              key={chakra.id}
              className={`overflow-hidden transition-all duration-300 ${getBorderColor(chakra.id)} border-2 
                ${isAnimating ? 'animate-pulse transform scale-105' : ''}
                ${isUnlocked ? 'hover:scale-105' : 'opacity-80'}`}
            >
              <div className={`h-3 ${isUnlocked ? getChakraColor(chakra.id) : 'bg-gray-300 dark:bg-gray-600'}`}></div>
              <CardHeader>
                <CardTitle className={getTextColor(chakra.id)}>
                  {chakra.name}
                </CardTitle>
                <CardDescription>
                  {chakra.element} • {chakra.frequency}
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="flex flex-col xs:flex-row justify-between gap-2 mb-3">
                  <span className={`text-xs sm:text-sm flex items-center gap-1 ${isActivated ? 'text-green-500' : isUnlocked ? 'text-amber-500' : 'text-gray-500'}`}>
                    {isActivated ? (
                      <>
                        <Sparkles className="h-3 w-3 flex-shrink-0" />
                        <span>Activated</span>
                      </>
                    ) : isUnlocked ? (
                      <>
                        <Unlock className="h-3 w-3 flex-shrink-0" />
                        <span>Ready to Activate</span>
                      </>
                    ) : (
                      <>
                        <Lock className="h-3 w-3 flex-shrink-0" />
                        <span className="line-clamp-1">Locked (Need {CHAKRA_XP_REQUIREMENTS[chakra.id]} XP)</span>
                      </>
                    )}
                  </span>
                  <span className="text-xs text-gray-500 dark:text-gray-400 whitespace-nowrap">
                    {userXP}/{CHAKRA_XP_REQUIREMENTS[chakra.id]} XP
                  </span>
                </div>
                
                <p className="text-xs sm:text-sm text-gray-600 dark:text-gray-400 mb-3 line-clamp-3 sm:line-clamp-none">
                  {chakra.description}
                </p>
                <div className={`p-2 sm:p-3 rounded-md ${isUnlocked ? 'bg-primary-50 dark:bg-primary-900/20' : 'bg-gray-100 dark:bg-gray-800'}`}>
                  <p className="text-xs sm:text-sm italic text-center">
                    "{chakra.affirmation}"
                  </p>
                </div>
              </CardContent>
              <CardFooter>
                <Button 
                  variant={isActivated ? "outline" : isUnlocked ? "default" : "secondary"}
                  className="w-full"
                  disabled={isActivated || !isUnlocked || activating !== null}
                  onClick={() => handleActivateChakra(chakra.id)}
                >
                  {activating === chakra.id ? (
                    "Activating..."
                  ) : isActivated ? (
                    <>
                      <Check className="h-4 w-4 mr-2" />
                      Activated
                    </>
                  ) : isUnlocked ? (
                    "Activate Now"
                  ) : (
                    `Need ${CHAKRA_XP_REQUIREMENTS[chakra.id] - userXP} more XP`
                  )}
                </Button>
              </CardFooter>
            </Card>
          );
        })}
      </div>
      
      <div className="mt-12 text-center">
        <h3 className="text-xl font-semibold mb-4 text-gray-800 dark:text-white">
          Chakra Activation Journey
        </h3>
        <p className="text-gray-600 dark:text-gray-400 max-w-2xl mx-auto">
          Activate each chakra to balance your spiritual energy and progress on your path to enlightenment.
          As you meditate and complete spiritual practices, you'll earn XP to unlock and activate deeper chakra connections.
        </p>
      </div>
    </div>
  );
}