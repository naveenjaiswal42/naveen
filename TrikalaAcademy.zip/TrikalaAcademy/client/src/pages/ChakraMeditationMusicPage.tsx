import { useState, useEffect, useRef } from "react";
import { Container } from "@/components/ui/container";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Slider } from "@/components/ui/slider";
import { 
  Play, 
  Pause, 
  Volume2, 
  SkipForward, 
  SkipBack, 
  Music, 
  Clock,
  Award
} from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import { Progress } from "@/components/ui/progress";
import { apiRequest } from "@/lib/queryClient";
import { useAuth } from "@/contexts/AuthContext";
import { useQuery } from "@tanstack/react-query";

// Chakra colors
const chakraColors = {
  root: {
    bg: "bg-red-50 dark:bg-red-950/20",
    text: "text-red-700 dark:text-red-400",
    border: "border-red-200 dark:border-red-800/30",
    hover: "hover:bg-red-100 dark:hover:bg-red-900/30",
    progress: "bg-red-500"
  },
  sacral: {
    bg: "bg-orange-50 dark:bg-orange-950/20",
    text: "text-orange-700 dark:text-orange-400",
    border: "border-orange-200 dark:border-orange-800/30",
    hover: "hover:bg-orange-100 dark:hover:bg-orange-900/30",
    progress: "bg-orange-500"
  },
  solar: {
    bg: "bg-yellow-50 dark:bg-yellow-950/20",
    text: "text-yellow-700 dark:text-yellow-400",
    border: "border-yellow-200 dark:border-yellow-800/30",
    hover: "hover:bg-yellow-100 dark:hover:bg-yellow-900/30",
    progress: "bg-yellow-500"
  },
  heart: {
    bg: "bg-green-50 dark:bg-green-950/20",
    text: "text-green-700 dark:text-green-400",
    border: "border-green-200 dark:border-green-800/30",
    hover: "hover:bg-green-100 dark:hover:bg-green-900/30",
    progress: "bg-green-500"
  },
  throat: {
    bg: "bg-blue-50 dark:bg-blue-950/20",
    text: "text-blue-700 dark:text-blue-400",
    border: "border-blue-200 dark:border-blue-800/30",
    hover: "hover:bg-blue-100 dark:hover:bg-blue-900/30",
    progress: "bg-blue-500"
  },
  thirdEye: {
    bg: "bg-indigo-50 dark:bg-indigo-950/20",
    text: "text-indigo-700 dark:text-indigo-400",
    border: "border-indigo-200 dark:border-indigo-800/30",
    hover: "hover:bg-indigo-100 dark:hover:bg-indigo-900/30",
    progress: "bg-indigo-500"
  },
  crown: {
    bg: "bg-purple-50 dark:bg-purple-950/20",
    text: "text-purple-700 dark:text-purple-400",
    border: "border-purple-200 dark:border-purple-800/30",
    hover: "hover:bg-purple-100 dark:hover:bg-purple-900/30",
    progress: "bg-purple-500"
  }
};

// ChakraTrack interface
interface ChakraTrack {
  id: number;
  title: string;
  chakraType: string;
  audioUrl: string;
  frequency: string;
  durationSeconds: number;
  imageUrl: string;
}

export default function ChakraMeditationMusicPage() {
  const [currentTrack, setCurrentTrack] = useState<ChakraTrack | null>(null);
  const [isPlaying, setIsPlaying] = useState(false);
  const [volume, setVolume] = useState(70);
  const [currentTime, setCurrentTime] = useState(0);
  const [duration, setDuration] = useState(0);
  const [completedTracks, setCompletedTracks] = useState<number[]>([]);
  const [xpAwarded, setXpAwarded] = useState<{[key: number]: boolean}>({});
  const audioRef = useRef<HTMLAudioElement | null>(null);
  const progressInterval = useRef<number | null>(null);
  const { toast } = useToast();
  const { user } = useAuth();

  // Fetch meditation tracks from the API
  const { data: tracks = [], isLoading } = useQuery({
    queryKey: ['/api/meditation-tracks'],
    queryFn: async () => {
      try {
        const response = await fetch('/api/meditation-tracks');
        const data = await response.json();
        return data as ChakraTrack[];
      } catch (error) {
        console.error("Error fetching meditation tracks:", error);
        return [] as ChakraTrack[];
      }
    }
  });

  const formatTime = (seconds: number): string => {
    const minutes = Math.floor(seconds / 60);
    const remainingSeconds = Math.floor(seconds % 60);
    return `${minutes}:${remainingSeconds.toString().padStart(2, '0')}`;
  };

  const handleTrackSelect = (track: ChakraTrack) => {
    if (currentTrack && currentTrack.id === track.id) {
      // Toggle play/pause if the same track is clicked
      togglePlayPause();
    } else {
      // Load new track
      setCurrentTrack(track);
      setIsPlaying(true);
      setCurrentTime(0);
      
      // Reset progress tracking
      if (progressInterval.current) {
        window.clearInterval(progressInterval.current);
        progressInterval.current = null;
      }
    }
  };

  const togglePlayPause = () => {
    setIsPlaying(!isPlaying);
  };

  const handleVolumeChange = (value: number[]) => {
    setVolume(value[0]);
    if (audioRef.current) {
      audioRef.current.volume = value[0] / 100;
    }
  };

  const handleTimeUpdate = () => {
    if (audioRef.current) {
      setCurrentTime(audioRef.current.currentTime);
    }
  };

  const handleLoadedMetadata = () => {
    if (audioRef.current) {
      setDuration(audioRef.current.duration);
    }
  };

  const handleSeek = (value: number[]) => {
    if (audioRef.current) {
      audioRef.current.currentTime = value[0];
      setCurrentTime(value[0]);
    }
  };

  const handleNextTrack = () => {
    if (!tracks?.length || !currentTrack) return;
    
    const currentIndex = tracks.findIndex(track => track.id === currentTrack.id);
    const nextIndex = (currentIndex + 1) % tracks.length;
    handleTrackSelect(tracks[nextIndex]);
  };

  const handlePrevTrack = () => {
    if (!tracks?.length || !currentTrack) return;
    
    const currentIndex = tracks.findIndex(track => track.id === currentTrack.id);
    const prevIndex = (currentIndex - 1 + tracks.length) % tracks.length;
    handleTrackSelect(tracks[prevIndex]);
  };

  const handleTrackEnd = () => {
    // Mark track as completed
    if (currentTrack && !completedTracks.includes(currentTrack.id)) {
      setCompletedTracks(prev => [...prev, currentTrack.id]);
      
      // Award XP if not already awarded for this track
      if (user && !xpAwarded[currentTrack.id]) {
        awardXP(currentTrack.id);
      }
    }
    
    // Auto-play next track
    handleNextTrack();
  };

  // Award XP for completing a meditation track
  const awardXP = async (trackId: number) => {
    if (!user || xpAwarded[trackId]) return;
    
    try {
      const xpAmount = 100; // 100 XP for each completed meditation track
      await apiRequest({
        method: "POST",
        url: `/api/users/${user.id}/xp`,
        body: { xpAmount }
      });
      
      // Mark XP as awarded for this track
      setXpAwarded(prev => ({...prev, [trackId]: true}));
      
      toast({
        title: "Meditation Complete!",
        description: `You've earned ${xpAmount} XP for completing this chakra meditation.`,
        variant: "default"
      });
    } catch (error) {
      console.error("Error awarding XP:", error);
    }
  };
  
  // Setup audio element and event listeners
  useEffect(() => {
    if (currentTrack && audioRef.current) {
      audioRef.current.src = currentTrack.audioUrl;
      audioRef.current.volume = volume / 100;
      
      if (isPlaying) {
        audioRef.current.play().catch(error => {
          console.error("Error playing audio:", error);
          setIsPlaying(false);
          toast({
            title: "Playback Error",
            description: "Could not play the selected track. Please try again.",
            variant: "destructive"
          });
        });
      } else {
        audioRef.current.pause();
      }
    }
  }, [currentTrack, isPlaying, toast]);

  // Handle play/pause state changes
  useEffect(() => {
    if (audioRef.current) {
      if (isPlaying) {
        audioRef.current.play().catch(error => {
          console.error("Error playing audio:", error);
          setIsPlaying(false);
        });
        
        // Setup progress tracking interval
        if (!progressInterval.current) {
          progressInterval.current = window.setInterval(() => {
            if (audioRef.current) {
              setCurrentTime(audioRef.current.currentTime);
            }
          }, 1000);
        }
      } else {
        audioRef.current.pause();
        
        // Clear interval when paused
        if (progressInterval.current) {
          window.clearInterval(progressInterval.current);
          progressInterval.current = null;
        }
      }
    }
    
    return () => {
      // Clean up interval on unmount
      if (progressInterval.current) {
        window.clearInterval(progressInterval.current);
      }
    };
  }, [isPlaying]);

  // Get chakra color based on chakra type
  const getChakraColor = (chakraType: string) => {
    switch (chakraType) {
      case 'root': return chakraColors.root;
      case 'sacral': return chakraColors.sacral;
      case 'solar': return chakraColors.solar;
      case 'heart': return chakraColors.heart;
      case 'throat': return chakraColors.throat;
      case 'thirdEye': return chakraColors.thirdEye;
      case 'crown': return chakraColors.crown;
      default: return chakraColors.heart; // Default color
    }
  };

  const getChakraName = (chakraType: string): string => {
    switch (chakraType) {
      case 'root': return 'Root Chakra';
      case 'sacral': return 'Sacral Chakra';
      case 'solar': return 'Solar Plexus Chakra';
      case 'heart': return 'Heart Chakra';
      case 'throat': return 'Throat Chakra';
      case 'thirdEye': return 'Third Eye Chakra';
      case 'crown': return 'Crown Chakra';
      default: return chakraType;
    }
  };
  
  return (
    <Container className="py-8">
      <div className="mb-8">
        <h1 className="text-3xl font-bold tracking-tight flex items-center gap-2">
          <Music className="h-8 w-8 text-indigo-600 dark:text-indigo-400" /> 
          Chakra Meditation Music
        </h1>
        <p className="text-gray-500 dark:text-gray-400 mt-2">
          Frequency-based sound healing for chakra balance and meditation
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
        {/* Track list */}
        <div className="md:col-span-2 space-y-4">
          {isLoading ? (
            <div className="flex justify-center py-12">
              <div className="animate-spin h-8 w-8 border-4 border-indigo-500 rounded-full border-t-transparent"></div>
            </div>
          ) : tracks.length === 0 ? (
            <Card className="bg-gray-50 dark:bg-gray-900/20 border-gray-200 dark:border-gray-800/30">
              <CardContent className="pt-6 text-center text-gray-500 dark:text-gray-400">
                <p>No meditation tracks available.</p>
              </CardContent>
            </Card>
          ) : (
            tracks.map((track) => {
              const colorSet = getChakraColor(track.chakraType);
              const isActive = currentTrack?.id === track.id;
              const isCompleted = completedTracks.includes(track.id);
              
              return (
                <Card 
                  key={track.id} 
                  className={`${colorSet.bg} ${colorSet.border} transition-all hover:shadow-md ${isActive ? 'ring-2 ring-indigo-500 dark:ring-indigo-400' : ''}`}
                >
                  <CardContent className="flex items-center p-4 gap-4">
                    <div className="flex-shrink-0 h-16 w-16 rounded-lg overflow-hidden relative">
                      <img 
                        src={track.imageUrl || `/images/${track.chakraType}-chakra.jpg`} 
                        alt={track.title}
                        className="h-full w-full object-cover" 
                      />
                      {isCompleted && (
                        <div className="absolute inset-0 bg-black/40 flex items-center justify-center">
                          <Award className="text-white h-8 w-8" />
                        </div>
                      )}
                    </div>
                    
                    <div className="flex-grow">
                      <div className="flex items-center">
                        <h3 className={`font-semibold ${colorSet.text}`}>{track.title}</h3>
                        {isCompleted && (
                          <Badge variant="outline" className="ml-2 bg-green-50 text-green-700 dark:bg-green-900/20 dark:text-green-400 border-green-200 dark:border-green-800/30">
                            Completed
                          </Badge>
                        )}
                      </div>
                      <div className="flex items-center text-sm text-gray-600 dark:text-gray-400 space-x-2">
                        <span>{getChakraName(track.chakraType)}</span>
                        <span>•</span>
                        <span>{track.frequency}</span>
                        <span>•</span>
                        <span className="flex items-center">
                          <Clock className="h-3 w-3 mr-1" />
                          {formatTime(track.durationSeconds)}
                        </span>
                      </div>
                    </div>
                    
                    <Button 
                      variant={isActive ? "default" : "outline"}
                      size="sm"
                      className={isActive ? "" : `${colorSet.text} ${colorSet.border} ${colorSet.hover}`}
                      onClick={() => handleTrackSelect(track)}
                    >
                      {isActive && isPlaying ? <Pause className="h-4 w-4" /> : <Play className="h-4 w-4" />}
                    </Button>
                  </CardContent>
                </Card>
              );
            })
          )}
        </div>

        {/* Sidebar with info */}
        <div className="space-y-6">
          <Card className="border-indigo-100 dark:border-indigo-800/30">
            <CardContent className="pt-6">
              <h3 className="font-semibold text-indigo-700 dark:text-indigo-400 mb-3">About Sound Healing</h3>
              <p className="text-sm text-gray-600 dark:text-gray-400 mb-4">
                Chakra sound healing uses specific frequency vibrations to activate and balance each energy center. 
                The frequencies in these tracks are tuned to resonate with your chakras' natural frequencies.
              </p>
              
              <h4 className="font-medium text-indigo-600 dark:text-indigo-300 text-sm mb-2">Frequencies:</h4>
              <ul className="text-sm text-gray-600 dark:text-gray-400 space-y-1">
                <li className="flex items-center gap-2">
                  <span className="w-3 h-3 rounded-full bg-red-500"></span>
                  <span>Root Chakra: 396 Hz (Liberating Fear)</span>
                </li>
                <li className="flex items-center gap-2">
                  <span className="w-3 h-3 rounded-full bg-orange-500"></span>
                  <span>Sacral Chakra: 417 Hz (Facilitating Change)</span>
                </li>
                <li className="flex items-center gap-2">
                  <span className="w-3 h-3 rounded-full bg-yellow-500"></span>
                  <span>Solar Plexus: 528 Hz (Transformation)</span>
                </li>
                <li className="flex items-center gap-2">
                  <span className="w-3 h-3 rounded-full bg-green-500"></span>
                  <span>Heart Chakra: 639 Hz (Connection)</span>
                </li>
                <li className="flex items-center gap-2">
                  <span className="w-3 h-3 rounded-full bg-blue-500"></span>
                  <span>Throat Chakra: 741 Hz (Expression)</span>
                </li>
                <li className="flex items-center gap-2">
                  <span className="w-3 h-3 rounded-full bg-indigo-500"></span>
                  <span>Third Eye: 852 Hz (Intuition)</span>
                </li>
                <li className="flex items-center gap-2">
                  <span className="w-3 h-3 rounded-full bg-purple-500"></span>
                  <span>Crown Chakra: 963 Hz (Connection to Divine)</span>
                </li>
              </ul>
            </CardContent>
          </Card>

          <Card className="border-indigo-100 dark:border-indigo-800/30">
            <CardContent className="pt-6">
              <h3 className="font-semibold text-indigo-700 dark:text-indigo-400 mb-3">How to Practice</h3>
              <ol className="text-sm text-gray-600 dark:text-gray-400 space-y-3 list-decimal pl-4">
                <li>
                  Find a quiet, comfortable space where you won't be disturbed
                </li>
                <li>
                  Sit in a comfortable position with spine straight but relaxed
                </li>
                <li>
                  Use headphones for the best experience and energy activation
                </li>
                <li>
                  Focus your awareness on the chakra associated with the track
                </li>
                <li>
                  Breathe deeply and allow the sound frequencies to resonate
                </li>
                <li>
                  Complete each track to earn XP and track your meditation progress
                </li>
              </ol>
            </CardContent>
          </Card>
        </div>
      </div>

      {/* Audio element (hidden) */}
      <audio 
        ref={audioRef}
        onTimeUpdate={handleTimeUpdate}
        onLoadedMetadata={handleLoadedMetadata}
        onEnded={handleTrackEnd}
        className="hidden"
      />

      {/* Audio player controls - fixed at bottom */}
      {currentTrack && (
        <div className="fixed bottom-0 left-0 right-0 bg-white dark:bg-gray-800 border-t border-gray-200 dark:border-gray-700 p-4 z-50">
          <div className="max-w-7xl mx-auto">
            <div className="flex flex-col md:flex-row md:items-center gap-4">
              {/* Track info */}
              <div className="flex items-center gap-3 flex-shrink-0">
                <div className="w-12 h-12 rounded-md overflow-hidden">
                  <img 
                    src={currentTrack.imageUrl || `/images/${currentTrack.chakraType}-chakra.jpg`} 
                    alt={currentTrack.title}
                    className="h-full w-full object-cover" 
                  />
                </div>
                <div>
                  <h3 className="font-semibold text-gray-900 dark:text-gray-100">{currentTrack.title}</h3>
                  <p className="text-xs text-gray-500 dark:text-gray-400">{currentTrack.frequency}</p>
                </div>
              </div>
              
              {/* Progress bar */}
              <div className="flex-grow space-y-1">
                <div className="w-full flex items-center gap-2">
                  <span className="text-xs text-gray-500 dark:text-gray-400 w-10 text-right">{formatTime(currentTime)}</span>
                  <Progress 
                    value={(currentTime / duration) * 100} 
                    className="h-1.5 flex-grow"
                  />
                  <span className="text-xs text-gray-500 dark:text-gray-400 w-10">{formatTime(duration)}</span>
                </div>
                
                {/* Controls */}
                <div className="flex justify-center items-center space-x-4">
                  <Button variant="ghost" size="sm" onClick={handlePrevTrack}>
                    <SkipBack className="h-4 w-4" />
                  </Button>
                  <Button 
                    variant="outline" 
                    size="icon"
                    className="h-10 w-10 rounded-full"
                    onClick={togglePlayPause}
                  >
                    {isPlaying ? <Pause className="h-5 w-5" /> : <Play className="h-5 w-5" />}
                  </Button>
                  <Button variant="ghost" size="sm" onClick={handleNextTrack}>
                    <SkipForward className="h-4 w-4" />
                  </Button>
                </div>
              </div>
              
              {/* Volume control */}
              <div className="flex items-center gap-2 w-full md:w-40 flex-shrink-0">
                <Volume2 className="h-4 w-4 text-gray-500 dark:text-gray-400" />
                <Slider
                  value={[volume]}
                  max={100}
                  step={1}
                  onValueChange={handleVolumeChange}
                  className="flex-grow"
                />
              </div>
            </div>
          </div>
        </div>
      )}
    </Container>
  );
}