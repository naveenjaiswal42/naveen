import React, { useState, useEffect } from 'react';
import { useQuery, useMutation } from '@tanstack/react-query';
import { apiRequest } from '@/lib/queryClient';
import { queryClient } from '@/lib/queryClient';
// Create a simple container component since we might not have it yet
const Container = ({ className, children }: { className?: string, children: React.ReactNode }) => (
  <div className={`max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 ${className || ''}`}>
    {children}
  </div>
);
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Progress } from '@/components/ui/progress';
import { Separator } from '@/components/ui/separator';
import { Badge } from '@/components/ui/badge';
import { Ritual, UserRitual } from '@/types';
import { useAuth } from '@/contexts/AuthContext';
import { useToast } from '@/hooks/use-toast';
import { CheckCircle, Clock, ArrowUpCircle, Calendar, Star, Award, Medal } from 'lucide-react';
import { updateDailyRitualStreak } from '@/services/streakService.js';

// Stub notification hook to prevent errors
const useNotifications = () => ({
  showRitualReminder: (title: string, ritualId?: number, ritualName?: string, time?: string, description?: string) => {
    console.log('Reminder set for ritual', { title, ritualId, ritualName, time, description });
  }
});

const DailyRitualTrackerPage: React.FC = () => {
  const { user } = useAuth();
  const { showRitualReminder } = useNotifications();
  const { toast } = useToast();
  const [completedCount, setCompletedCount] = useState(0);
  const [todayDate] = useState(new Date().toISOString().split('T')[0]);
  
  // Get all rituals
  const { data: rituals, isLoading: ritualsLoading } = useQuery({
    queryKey: ['/api/rituals'],
    queryFn: () => apiRequest({
      url: '/api/rituals',
      method: 'GET'
    })
  });
  
  // Get user's ritual progress for today
  const { data: userRituals, isLoading: userRitualsLoading } = useQuery({
    queryKey: ['/api/users', user?.id, 'rituals'],
    queryFn: () => apiRequest({
      url: `/api/users/${user?.id}/rituals`,
      method: 'GET'
    }),
    enabled: !!user?.id
  });
  
  // Mark ritual as complete mutation
  const markCompleteMutation = useMutation({
    mutationFn: (userRitual: UserRitual) => 
      apiRequest({
        url: `/api/users/${user?.id}/rituals/${userRitual.ritualId}/complete`,
        method: 'POST',
        body: { 
          completedDate: todayDate 
        }
      }),
    onSuccess: () => {
      // Invalidate queries to refresh data
      queryClient.invalidateQueries({ queryKey: ['/api/users', user?.id, 'rituals'] });
      queryClient.invalidateQueries({ queryKey: ['/api/users', user?.id] });
    }
  });
  
  // Calculate completed rituals
  useEffect(() => {
    if (userRituals && rituals) {
      const today = new Date().toISOString().split('T')[0];
      
      // Filter user rituals completed today (handle both formats)
      const todayCompleted = userRituals.filter(
        (userRitual: UserRitual) => 
          // Check both formats for backwards compatibility
          ((userRitual.completed && userRitual.completedDate && userRitual.completedDate.includes(today)) ||
           (userRitual.completedAt && userRitual.date === today))
      );
      
      setCompletedCount(todayCompleted.length);
    }
  }, [userRituals, rituals]);
  
  // Handle marking a ritual as complete
  const handleMarkComplete = async (ritual: Ritual) => {
    if (!user) return;
    
    // Create user ritual object
    const userRitual: UserRitual = {
      id: 0, // Will be assigned by the server
      userId: user.id,
      ritualId: ritual.id,
      date: todayDate,
      completedAt: new Date(),
      // Keep for backwards compatibility
      completed: true,
      completedDate: todayDate
    };
    
    try {
      // Call the mutation
      await markCompleteMutation.mutateAsync(userRitual);
      
      // Update the daily ritual streak
      const ritualStreak = await updateDailyRitualStreak(user.id);
      
      // Show success toast
      toast({
        title: "Ritual Completed!",
        description: `You earned +50 XP for completing "${ritual.title}"`,
        variant: "default",
      });
      
      // If this completion has extended the streak, show a special message
      if (ritualStreak > 1) {
        toast({
          title: "Ritual Streak Extended!",
          description: `Your daily ritual streak is now ${ritualStreak} days. Keep it up!`,
          variant: "default",
        });
        
        // If it's milestone day (5, 10, 15, etc), show a badge notification
        if (ritualStreak % 5 === 0) {
          toast({
            title: "Achievement Unlocked: Daily Ritual Master",
            description: `Amazing! You've maintained your rituals for ${ritualStreak} days.`,
            variant: "default",
          });
        }
      }
      
    } catch (error) {
      console.error("Error completing ritual:", error);
      toast({
        title: "Failed to complete ritual",
        description: "Please try again later",
        variant: "destructive",
      });
    }
  };
  
  // Check if a ritual is completed today
  const isRitualCompletedToday = (ritualId: number): boolean => {
    if (!userRituals) return false;
    
    const today = new Date().toISOString().split('T')[0];
    
    return userRituals.some(
      (userRitual: UserRitual) => 
        userRitual.ritualId === ritualId && 
        // Check both formats for backwards compatibility
        ((userRitual.completed && userRitual.completedDate && userRitual.completedDate.includes(today)) ||
         (userRitual.completedAt && userRitual.date === today))
    );
  };
  
  // Loading state
  if (ritualsLoading || userRitualsLoading) {
    return (
      <Container className="py-8">
        <div className="flex flex-col items-center justify-center min-h-[60vh]">
          <div className="w-16 h-16 border-4 border-indigo-400 border-t-transparent rounded-full animate-spin"></div>
          <p className="mt-4 text-lg font-medium text-gray-600 dark:text-gray-300">Loading your daily rituals...</p>
        </div>
      </Container>
    );
  }
  
  // Calculate progress percentage
  const progressPercentage = rituals ? Math.round((completedCount / rituals.length) * 100) : 0;
  
  return (
    <Container className="py-8">
      <div className="flex flex-col md:flex-row items-start md:items-center justify-between mb-6">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">🕉️ Daily Ritual Tracker</h1>
          <p className="text-gray-500 dark:text-gray-400 mt-2">
            Complete your daily rituals to earn XP and maintain your spiritual streak.
          </p>
        </div>
        <div className="mt-4 md:mt-0 bg-indigo-50 dark:bg-indigo-900/30 rounded-lg p-3">
          <div className="flex items-center gap-2">
            <Calendar className="h-5 w-5 text-indigo-600 dark:text-indigo-400" />
            <p className="font-medium text-indigo-700 dark:text-indigo-300">
              {new Date().toLocaleDateString('en-US', { 
                weekday: 'long', 
                year: 'numeric', 
                month: 'long', 
                day: 'numeric' 
              })}
            </p>
          </div>
        </div>
      </div>
      
      {/* Progress card */}
      <Card className="mb-8 border-indigo-100 dark:border-indigo-800/30 shadow-sm">
        <CardHeader className="pb-3">
          <CardTitle>Today's Progress</CardTitle>
          <CardDescription>
            {completedCount} out of {rituals ? rituals.length : 0} rituals completed
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-2">
            <Progress value={progressPercentage} className="h-3" />
            <div className="flex justify-between text-sm text-muted-foreground">
              <span>{progressPercentage}% completed</span>
              {progressPercentage === 100 && (
                <div className="flex items-center gap-1 text-green-600 dark:text-green-400">
                  <CheckCircle className="h-4 w-4" />
                  <span>All rituals completed!</span>
                </div>
              )}
            </div>
          </div>
        </CardContent>
      </Card>
      
      {/* Rituals list */}
      <div className="space-y-4">
        <h2 className="text-xl font-semibold flex items-center gap-2">
          <Star className="h-5 w-5 text-amber-500" />
          Today's Spiritual Rituals
        </h2>
        
        {rituals && rituals.map((ritual: Ritual) => {
          const isCompleted = isRitualCompletedToday(ritual.id);
          
          return (
            <Card 
              key={ritual.id} 
              className={`overflow-hidden transition-all duration-200 ${
                isCompleted 
                  ? 'border-green-200 dark:border-green-800/30 bg-green-50/50 dark:bg-green-900/10' 
                  : 'hover:border-indigo-200 dark:hover:border-indigo-800/30'
              }`}
            >
              <CardHeader className="pb-2">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className={`p-2 rounded-full ${
                      isCompleted 
                        ? 'bg-green-100 dark:bg-green-900/30 text-green-600 dark:text-green-400' 
                        : 'bg-indigo-100 dark:bg-indigo-900/30 text-indigo-600 dark:text-indigo-400'
                    }`}>
                      {isCompleted ? (
                        <CheckCircle className="h-5 w-5" />
                      ) : (
                        <Clock className="h-5 w-5" />
                      )}
                    </div>
                    <div>
                      <CardTitle className="text-lg">{ritual.title}</CardTitle>
                      <CardDescription>{ritual.description}</CardDescription>
                    </div>
                  </div>
                  
                  <Badge variant={isCompleted ? "default" : "outline"} className="ml-2">
                    {ritual.time}
                  </Badge>
                </div>
              </CardHeader>
              
              <CardContent>
                <div className="text-sm text-gray-600 dark:text-gray-400 mt-2">
                  {ritual.instructions}
                </div>
                
                {ritual.benefits && (
                  <div className="mt-3 text-sm">
                    <span className="font-medium text-indigo-700 dark:text-indigo-400">Benefits: </span>
                    <span className="text-gray-600 dark:text-gray-300">{ritual.benefits}</span>
                  </div>
                )}
                
                {ritual.chakraType && (
                  <Badge variant="outline" className="mt-3 bg-purple-50 dark:bg-purple-900/20 text-purple-700 dark:text-purple-300 border-purple-200 dark:border-purple-800/30">
                    {ritual.chakraType} Chakra
                  </Badge>
                )}
              </CardContent>
              
              <CardFooter className="border-t border-gray-100 dark:border-gray-800 pt-3 flex justify-between items-center">
                <div className="flex items-center gap-1 text-amber-600 dark:text-amber-400">
                  <Award className="h-4 w-4" />
                  <span className="text-sm font-medium">+50 XP</span>
                </div>
                
                <div className="flex gap-2">
                  <Button 
                    variant="outline" 
                    size="sm"
                    onClick={() => showRitualReminder(
                      "Ritual Reminder",
                      ritual.id,
                      ritual.title,
                      ritual.time,
                      ritual.description
                    )}
                  >
                    Set Reminder
                  </Button>
                  
                  <Button 
                    variant={isCompleted ? "success" : "default"}
                    size="sm"
                    onClick={() => !isCompleted && handleMarkComplete(ritual)}
                    disabled={isCompleted || markCompleteMutation.isPending}
                  >
                    {isCompleted ? (
                      <>
                        <CheckCircle className="mr-1 h-4 w-4" />
                        Completed
                      </>
                    ) : markCompleteMutation.isPending ? (
                      <>
                        <div className="mr-1 h-4 w-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
                        Completing...
                      </>
                    ) : (
                      <>
                        <ArrowUpCircle className="mr-1 h-4 w-4" />
                        Mark Complete
                      </>
                    )}
                  </Button>
                </div>
              </CardFooter>
            </Card>
          );
        })}
        
        {rituals && rituals.length === 0 && (
          <Card className="bg-gray-50 dark:bg-gray-800/50 border-dashed">
            <CardContent className="flex flex-col items-center justify-center py-10">
              <div className="rounded-full bg-gray-100 dark:bg-gray-700 p-3 mb-4">
                <Calendar className="h-8 w-8 text-gray-400" />
              </div>
              <p className="text-lg font-medium text-gray-600 dark:text-gray-300">No rituals available</p>
              <p className="text-sm text-gray-500 dark:text-gray-400 mt-1">
                Check back later for your daily spiritual practices
              </p>
            </CardContent>
          </Card>
        )}
      </div>
      
      {/* Rewards section */}
      <div className="mt-10">
        <Separator className="my-6" />
        <div className="flex items-center gap-2 mb-4">
          <Medal className="h-5 w-5 text-amber-500" />
          <h2 className="text-xl font-semibold">Rewards & Streaks</h2>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <Card className="bg-gradient-to-br from-amber-50 to-amber-100 dark:from-amber-900/20 dark:to-amber-800/10 border-amber-200 dark:border-amber-800/30">
            <CardHeader className="pb-2">
              <CardTitle className="text-lg text-amber-700 dark:text-amber-400">Daily Completion</CardTitle>
            </CardHeader>
            <CardContent className="pt-0">
              <p className="text-sm text-amber-600 dark:text-amber-300">
                Complete all rituals today to earn a bonus 100 XP and maintain your streak!
              </p>
            </CardContent>
          </Card>
          
          <Card className="bg-gradient-to-br from-indigo-50 to-indigo-100 dark:from-indigo-900/20 dark:to-indigo-800/10 border-indigo-200 dark:border-indigo-800/30">
            <CardHeader className="pb-2">
              <CardTitle className="text-lg text-indigo-700 dark:text-indigo-400">Ritual Streak</CardTitle>
            </CardHeader>
            <CardContent className="pt-0">
              <p className="text-sm text-indigo-600 dark:text-indigo-300">
                Maintain a 5-day ritual streak to unlock the "Daily Ritual Master" badge!
              </p>
            </CardContent>
          </Card>
          
          <Card className="bg-gradient-to-br from-purple-50 to-purple-100 dark:from-purple-900/20 dark:to-purple-800/10 border-purple-200 dark:border-purple-800/30">
            <CardHeader className="pb-2">
              <CardTitle className="text-lg text-purple-700 dark:text-purple-400">Spiritual Discipline</CardTitle>
            </CardHeader>
            <CardContent className="pt-0">
              <p className="text-sm text-purple-600 dark:text-purple-300">
                Complete a 30-day ritual streak to earn the "Spiritual Discipline Master" badge and 1500 XP bonus!
              </p>
            </CardContent>
          </Card>
        </div>
      </div>
    </Container>
  );
};

export default DailyRitualTrackerPage;