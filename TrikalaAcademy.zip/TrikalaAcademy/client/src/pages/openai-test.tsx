import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Textarea } from '@/components/ui/textarea';
import { AlertCircle, CheckCircle2 } from 'lucide-react';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';

export default function OpenAITestPage() {
  const [loading, setLoading] = useState(false);
  const [query, setQuery] = useState('');
  const [result, setResult] = useState<{
    success: boolean;
    message: string;
    modelUsed?: string;
  } | null>(null);

  const testOpenAI = async () => {
    if (!query.trim()) return;
    
    setLoading(true);
    try {
      const response = await fetch('/api/openai-test', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ query }),
      });
      
      const data = await response.json();
      
      setResult({
        success: data.success,
        message: data.message || JSON.stringify(data),
        modelUsed: data.modelUsed,
      });
    } catch (error: any) {
      setResult({
        success: false,
        message: error.message || 'An error occurred',
      });
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="container mx-auto py-10 max-w-2xl">
      <h1 className="text-3xl font-bold mb-6 text-center">OpenAI API Direct Test</h1>
      
      <Card className="mb-6">
        <CardHeader>
          <CardTitle>Test Your OpenAI Integration</CardTitle>
        </CardHeader>
        <CardContent>
          <Textarea
            placeholder="Enter a question for OpenAI..."
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            rows={5}
            className="mb-4"
          />
        </CardContent>
        <CardFooter>
          <Button 
            onClick={testOpenAI} 
            disabled={loading || !query.trim()} 
            className="w-full"
          >
            {loading ? 'Testing...' : 'Test OpenAI API'}
          </Button>
        </CardFooter>
      </Card>
      
      {result && (
        <Alert variant={result.success ? "default" : "destructive"} className="mb-6">
          <div className="flex items-center gap-2">
            {result.success ? (
              <CheckCircle2 className="h-4 w-4" />
            ) : (
              <AlertCircle className="h-4 w-4" />
            )}
            <AlertTitle>{result.success ? 'Success' : 'Error'}</AlertTitle>
          </div>
          <AlertDescription className="mt-2">
            {result.success && result.modelUsed && (
              <p className="text-sm text-muted-foreground">Using model: {result.modelUsed}</p>
            )}
            <pre className="bg-muted p-4 rounded-md whitespace-pre-wrap text-sm mt-2">
              {result.message}
            </pre>
          </AlertDescription>
        </Alert>
      )}
    </div>
  );
}