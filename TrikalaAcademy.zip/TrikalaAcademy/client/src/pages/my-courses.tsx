import { useEffect, useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { apiRequest } from '@/lib/queryClient';
import { useAuth } from '@/contexts/AuthContext';
import { Link, useLocation } from 'wouter';

import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle
} from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Button } from '@/components/ui/button';
import { BookOpen, Play, CheckCircle, GraduationCap, Award } from 'lucide-react';
import { Separator } from '@/components/ui/separator';

// Define interfaces for our data
interface Course {
  id: number;
  title: string;
  description: string | null;
  imageUrl: string | null;
  level: number | null;
  totalLessons: number | null;
  xpReward: number | null;
}

interface UserCourse {
  id: number;
  userId: number;
  courseId: number;
  lessonsCompleted: number;
  enrolledAt: string;
  course?: Course; // This will be populated via join operation
}

export default function MyCoursesPage() {
  const { user } = useAuth();
  const [, navigate] = useLocation();
  const [enrolledCourses, setEnrolledCourses] = useState<UserCourse[]>([]);
  
  // Fetch user's enrolled courses
  const { data: userCourses, isLoading, error } = useQuery({
    queryKey: ['/api/users', user?.id, 'courses'],
    queryFn: () => apiRequest<UserCourse[]>({
      url: `/api/users/${user?.id}/courses`,
      method: 'GET'
    }),
    enabled: !!user?.id
  });
  
  // Fetch all courses to get detailed course info
  const { data: courses } = useQuery({
    queryKey: ['/api/courses'],
    queryFn: () => apiRequest<Course[]>({
      url: '/api/courses',
      method: 'GET'
    })
  });
  
  useEffect(() => {
    if (userCourses && courses) {
      // Join user courses with course details
      const enrichedCourses = userCourses.map(userCourse => {
        const courseDetails = courses.find(c => c.id === userCourse.courseId);
        return {
          ...userCourse,
          course: courseDetails
        };
      });
      
      setEnrolledCourses(enrichedCourses);
    }
  }, [userCourses, courses]);
  
  const calculateProgress = (completedLessons: number, totalLessons: number | null): number => {
    if (!totalLessons || totalLessons === 0) return 0;
    return Math.round((completedLessons / totalLessons) * 100);
  };
  
  if (isLoading) {
    return (
      <div className="p-8 max-w-6xl mx-auto">
        <h1 className="text-3xl font-bold mb-6">Loading your courses...</h1>
      </div>
    );
  }
  
  if (error) {
    return (
      <div className="p-8 max-w-6xl mx-auto">
        <h1 className="text-3xl font-bold mb-6 text-red-500">Error loading courses</h1>
        <p>There was a problem loading your enrolled courses. Please try again later.</p>
      </div>
    );
  }
  
  if (enrolledCourses.length === 0) {
    return (
      <div className="p-8 max-w-6xl mx-auto">
        <h1 className="text-3xl font-bold mb-6">My Courses</h1>
        
        <Card className="bg-gradient-to-r from-purple-50 to-indigo-50 dark:from-purple-900/30 dark:to-indigo-900/30">
          <CardContent className="pt-6 pb-6 flex flex-col items-center">
            <div className="mb-4 bg-purple-100 dark:bg-purple-900/30 p-4 rounded-full">
              <GraduationCap className="h-12 w-12 text-primary" />
            </div>
            <h2 className="text-2xl font-bold mb-2">You haven't enrolled in any courses yet</h2>
            <p className="text-center text-gray-600 dark:text-gray-400 mb-6 max-w-md">
              Explore our spiritual courses to deepen your practice and enhance your journey
            </p>
            <Button asChild>
              <Link href="/courses">
                <BookOpen className="h-4 w-4 mr-2" />
                Browse Courses
              </Link>
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }
  
  return (
    <div className="p-8 max-w-6xl mx-auto">
      <div className="mb-8">
        <h1 className="text-3xl font-bold mb-2">My Courses</h1>
        <p className="text-gray-500 dark:text-gray-400">
          Track your learning progress and continue your spiritual journey
        </p>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {enrolledCourses.map((enrolledCourse) => {
          const course = enrolledCourse.course;
          if (!course) return null;
          
          const progress = calculateProgress(enrolledCourse.lessonsCompleted, course.totalLessons);
          const isCompleted = progress >= 100;
          
          return (
            <Card key={enrolledCourse.id} className="overflow-hidden">
              <div 
                className="h-2 w-full bg-gradient-to-r from-purple-500 to-indigo-500"
                style={{ opacity: progress / 100 }}
              ></div>
              <CardHeader className="pb-2">
                <div className="flex justify-between items-start">
                  <CardTitle className="text-xl">{course.title}</CardTitle>
                  <Badge 
                    variant="outline" 
                    className={isCompleted 
                      ? "bg-green-100 dark:bg-green-900/30 text-green-800 dark:text-green-400 border-0" 
                      : ""}
                  >
                    {isCompleted ? (
                      <span className="flex items-center">
                        <CheckCircle className="h-3 w-3 mr-1" />
                        Completed
                      </span>
                    ) : `Level ${course.level || 1}`}
                  </Badge>
                </div>
                <CardDescription className="line-clamp-2">
                  {course.description || "Develop your inner peace and knowledge with this spiritual journey."}
                </CardDescription>
              </CardHeader>
              
              <CardContent className="pb-2">
                <div className="flex justify-between text-sm mb-1">
                  <span>Your Progress</span>
                  <span>{progress}%</span>
                </div>
                <Progress value={progress} className="h-2 mb-4" />
                
                <div className="flex items-center justify-between text-sm text-gray-500 dark:text-gray-400">
                  <div className="flex items-center">
                    <BookOpen className="h-4 w-4 mr-1" />
                    <span>{enrolledCourse.lessonsCompleted}/{course.totalLessons || 0} lessons</span>
                  </div>
                  {course.xpReward && (
                    <div className="flex items-center">
                      <Award className="h-4 w-4 mr-1 text-amber-500" />
                      <span>{course.xpReward} XP Reward</span>
                    </div>
                  )}
                </div>
              </CardContent>
              
              <CardFooter className="flex flex-col gap-2">
                <Button asChild className="w-full">
                  <Link href={`/my-courses/${enrolledCourse.courseId}/lessons`}>
                    {isCompleted ? (
                      <>
                        <CheckCircle className="h-4 w-4 mr-2" />
                        Review Lessons
                      </>
                    ) : (
                      <>
                        <Play className="h-4 w-4 mr-2" />
                        Continue Learning
                      </>
                    )}
                  </Link>
                </Button>
                
                {isCompleted && (
                  <Button 
                    variant="secondary" 
                    className="w-full bg-gradient-to-r from-purple-500/10 to-indigo-500/10"
                    onClick={() => navigate(`/certificate/${enrolledCourse.courseId}`)}
                  >
                    <Award className="h-4 w-4 mr-2" />
                    View Certificate
                  </Button>
                )}
                
                <Button asChild variant="outline" className="w-full">
                  <Link href={`/courses/${course.id}`}>
                    <BookOpen className="h-4 w-4 mr-2" />
                    Course Details
                  </Link>
                </Button>
              </CardFooter>
            </Card>
          );
        })}
      </div>
    </div>
  );
}