import { useEffect, useState } from "react";
import { useQuery, useMutation, QueryClient } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Card, CardContent, CardFooter, CardHeader } from "@/components/ui/card";
import { Separator } from "@/components/ui/separator";
import { Heart, MessageCircle, Send } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Loader2 } from "lucide-react";
import { apiRequest } from "@/lib/queryClient";
import { formatDistanceToNow } from "date-fns";
import { useLocation } from "wouter";

// Interface for community posts
interface Comment {
  id: number;
  postId: number;
  userId: number;
  text: string;
  author: string;
  createdAt: string;
}

interface Post {
  id: number;
  userId: number;
  text: string;
  author: string;
  likes: number;
  createdAt: string;
  comments: Comment[];
  isLiked?: boolean;
}

// WebSocket connection
let socket: WebSocket | null = null;

export default function CommunityWallPage() {
  const { toast } = useToast();
  const [postText, setPostText] = useState("");
  const [commentText, setCommentText] = useState<Record<number, string>>({});
  const [activePost, setActivePost] = useState<number | null>(null);
  const [location, navigate] = useLocation();
  
  // Query and cache setup
  const queryClient = new QueryClient();
  
  // Get posts
  const { 
    data: posts,
    isLoading: postsLoading,
    error: postsError,
    refetch: refetchPosts
  } = useQuery<Post[]>({
    queryKey: ["/api/community"],
    queryFn: async () => {
      const res = await fetch("/api/community");
      if (!res.ok) {
        throw new Error("Failed to fetch community posts");
      }
      return res.json();
    }
  });
  
  // Create post mutation
  const createPostMutation = useMutation<any, Error, string>({
    mutationFn: async (text: string) => {
      const res = await apiRequest("POST", "/api/community", { text });
      return res.json();
    },
    onSuccess: () => {
      setPostText("");
      queryClient.invalidateQueries({ queryKey: ["/api/community"] });
      refetchPosts();
      toast({
        title: "Post Created",
        description: "Your spiritual insight has been shared with the community!",
        variant: "default",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Error Creating Post",
        description: error.message,
        variant: "destructive",
      });
    }
  });
  
  // Add comment mutation
  const addCommentMutation = useMutation<any, Error, { postId: number; text: string }>({
    mutationFn: async ({ postId, text }) => {
      const res = await apiRequest("POST", `/api/community/${postId}/comment`, { text });
      return res.json();
    },
    onSuccess: (_data, variables) => {
      // Clear comment text for this post
      setCommentText(prev => ({
        ...prev,
        [variables.postId]: ""
      }));
      
      queryClient.invalidateQueries({ queryKey: ["/api/community"] });
      refetchPosts();
      toast({
        title: "Comment Added",
        description: "Your comment has been added!",
        variant: "default",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Error Adding Comment",
        description: error.message,
        variant: "destructive",
      });
    }
  });
  
  // Like post mutation
  const likePostMutation = useMutation<any, Error, number>({
    mutationFn: async (postId: number) => {
      const res = await apiRequest("POST", `/api/community/${postId}/like`, {});
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/community"] });
      refetchPosts();
    },
    onError: (error: Error) => {
      toast({
        title: "Error Liking Post",
        description: error.message,
        variant: "destructive",
      });
    }
  });
  
  // Setup WebSocket connection for real-time updates
  useEffect(() => {
    const protocol = window.location.protocol === "https:" ? "wss:" : "ws:";
    const wsUrl = `${protocol}//${window.location.host}/ws`;
    
    socket = new WebSocket(wsUrl);
    
    socket.addEventListener("open", () => {
      console.log("Connected to WebSocket server");
    });
    
    socket.addEventListener("message", (event) => {
      try {
        const data = JSON.parse(event.data);
        
        // Handle different types of WebSocket messages
        if (data.type === "post_created" || data.type === "comment_added" || data.type === "post_liked") {
          refetchPosts();
        }
        
      } catch (error) {
        console.error("Error parsing WebSocket message:", error);
      }
    });
    
    socket.addEventListener("close", () => {
      console.log("Disconnected from WebSocket server");
    });
    
    return () => {
      socket?.close();
    };
  }, []);
  
  // Handle post submission
  const handlePostSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!postText.trim()) {
      toast({
        title: "Post Required",
        description: "Please enter a message to post.",
        variant: "destructive",
      });
      return;
    }
    
    createPostMutation.mutate(postText);
  };
  
  // Handle comment submission
  const handleCommentSubmit = (postId: number) => (e: React.FormEvent) => {
    e.preventDefault();
    
    const text = commentText[postId];
    if (!text || !text.trim()) {
      toast({
        title: "Comment Required",
        description: "Please enter a comment.",
        variant: "destructive",
      });
      return;
    }
    
    addCommentMutation.mutate({ postId, text });
  };
  
  // Handle like button click
  const handleLike = (postId: number) => {
    likePostMutation.mutate(postId);
  };
  
  // Handle expanding comments for a post
  const toggleComments = (postId: number) => {
    if (activePost === postId) {
      setActivePost(null);
    } else {
      setActivePost(postId);
    }
  };
  
  // Format date for display
  const formatDate = (dateString: string) => {
    try {
      return formatDistanceToNow(new Date(dateString), { addSuffix: true });
    } catch (error) {
      return "some time ago";
    }
  };
  
  if (postsLoading) {
    return (
      <div className="flex flex-col items-center justify-center min-h-[50vh] p-4">
        <Loader2 className="h-10 w-10 animate-spin text-primary mb-4" />
        <p className="text-lg text-muted-foreground">Loading spiritual insights...</p>
      </div>
    );
  }
  
  if (postsError) {
    return (
      <div className="p-4">
        <Alert variant="destructive" className="mb-4">
          <AlertDescription>
            Error loading community posts. Please try again later.
          </AlertDescription>
        </Alert>
        <Button onClick={() => refetchPosts()}>Retry</Button>
      </div>
    );
  }
  
  return (
    <div className="container mx-auto p-4 max-w-4xl">
      <div className="mb-8 text-center">
        <h1 className="text-3xl font-bold text-primary mb-2">Spiritual Community</h1>
        <p className="text-muted-foreground max-w-2xl mx-auto">
          Share your spiritual insights, ask questions, and connect with fellow seekers on their journey of self-discovery and enlightenment.
        </p>
      </div>
      
      {/* Create post form */}
      <Card className="mb-8">
        <CardHeader className="pb-2">
          <h2 className="text-xl font-medium">Share Your Spiritual Insight</h2>
        </CardHeader>
        <form onSubmit={handlePostSubmit}>
          <CardContent>
            <Textarea
              placeholder="What spiritual insights or questions would you like to share today?"
              value={postText}
              onChange={(e) => setPostText(e.target.value)}
              className="min-h-[100px]"
            />
          </CardContent>
          <CardFooter className="flex justify-end space-x-2">
            <Button 
              type="submit" 
              disabled={createPostMutation.isPending || !postText.trim()}
              className="bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-700 hover:to-indigo-700"
            >
              {createPostMutation.isPending ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Posting...
                </>
              ) : (
                <>
                  <Send className="mr-2 h-4 w-4" />
                  Share
                </>
              )}
            </Button>
          </CardFooter>
        </form>
      </Card>
      
      {/* Posts list */}
      <div className="space-y-6">
        {posts && posts.length > 0 ? (
          posts.map((post) => (
            <Card key={post.id} className="border border-muted rounded-lg shadow-sm">
              <CardHeader className="pb-2">
                <div className="flex items-center gap-3">
                  <Avatar>
                    <AvatarImage src={`https://api.dicebear.com/7.x/bottts/svg?seed=${post.userId}`} />
                    <AvatarFallback>{post.author[0]}</AvatarFallback>
                  </Avatar>
                  <div>
                    <div className="font-medium">{post.author}</div>
                    <div className="text-xs text-muted-foreground">
                      {formatDate(post.createdAt)}
                    </div>
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <p className="whitespace-pre-line">{post.text}</p>
              </CardContent>
              <CardFooter className="py-2 flex justify-between items-center">
                <div className="flex gap-4">
                  <Button 
                    variant="ghost" 
                    size="sm" 
                    onClick={() => handleLike(post.id)}
                    className={post.isLiked ? "text-red-500" : ""}
                    disabled={likePostMutation.isPending}
                  >
                    <Heart className={`h-4 w-4 mr-1 ${post.isLiked ? "fill-red-500" : ""}`} />
                    {post.likes || 0}
                  </Button>
                  <Button 
                    variant="ghost" 
                    size="sm"
                    onClick={() => toggleComments(post.id)}
                  >
                    <MessageCircle className="h-4 w-4 mr-1" />
                    {post.comments.length}
                  </Button>
                </div>
                {post.comments.length > 0 && activePost !== post.id && (
                  <Badge variant="outline" className="text-xs">
                    {post.comments.length} {post.comments.length === 1 ? "comment" : "comments"}
                  </Badge>
                )}
              </CardFooter>
              
              {/* Comment section (only visible when active) */}
              {activePost === post.id && (
                <div className="px-4 pb-4">
                  <Separator className="mb-4" />
                  
                  {/* Comments list */}
                  <div className="space-y-4 mb-4">
                    {post.comments.length > 0 ? (
                      post.comments.map((comment) => (
                        <div key={comment.id} className="flex gap-3">
                          <Avatar className="h-8 w-8">
                            <AvatarImage src={`https://api.dicebear.com/7.x/bottts/svg?seed=${comment.userId}`} />
                            <AvatarFallback>{comment.author[0]}</AvatarFallback>
                          </Avatar>
                          <div className="flex-1">
                            <div className="bg-muted p-3 rounded-lg">
                              <div className="font-medium text-sm">{comment.author}</div>
                              <p className="text-sm">{comment.text}</p>
                            </div>
                            <div className="text-xs text-muted-foreground mt-1">
                              {formatDate(comment.createdAt)}
                            </div>
                          </div>
                        </div>
                      ))
                    ) : (
                      <p className="text-center text-sm text-muted-foreground py-2">
                        No comments yet. Be the first to comment!
                      </p>
                    )}
                  </div>
                  
                  {/* Add comment form */}
                  <form onSubmit={handleCommentSubmit(post.id)} className="flex gap-2">
                    <Textarea
                      placeholder="Add a comment..."
                      value={commentText[post.id] || ""}
                      onChange={(e) => setCommentText(prev => ({
                        ...prev,
                        [post.id]: e.target.value
                      }))}
                      className="min-h-[80px] text-sm"
                    />
                    <Button 
                      type="submit" 
                      size="sm" 
                      disabled={addCommentMutation.isPending || !commentText[post.id]?.trim()}
                      className="self-end"
                    >
                      {addCommentMutation.isPending ? (
                        <Loader2 className="h-4 w-4 animate-spin" />
                      ) : (
                        <Send className="h-4 w-4" />
                      )}
                    </Button>
                  </form>
                </div>
              )}
            </Card>
          ))
        ) : (
          <div className="text-center py-8">
            <p className="text-muted-foreground mb-4">No posts yet. Be the first to share your spiritual insights!</p>
          </div>
        )}
      </div>
    </div>
  );
}