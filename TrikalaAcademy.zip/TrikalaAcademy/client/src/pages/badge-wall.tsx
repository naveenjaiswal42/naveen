import { useEffect, useState } from 'react';
import { useLocation } from 'wouter';
import { ShieldCheck, Award, Zap, Sun, Star, Medal, Trophy } from 'lucide-react';
import axios from 'axios';
import { useToast } from '@/hooks/use-toast';
import { useAuth } from '@/contexts/AuthContext';
import { Card } from '@/components/ui/card';
import BadgeShareCard from '@/components/BadgeShareCard';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from '@/components/ui/dialog';
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";

interface Badge {
  id: string;
  title: string;
  description: string;
  category: string; 
  dateEarned: string;
  iconType?: string;
}

export default function BadgeWallPage() {
  const [badges, setBadges] = useState<Badge[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedBadge, setSelectedBadge] = useState<Badge | null>(null);
  const [filters, setFilters] = useState({
    category: 'all',
  });
  const { toast } = useToast();
  const { user } = useAuth();
  const [, setLocation] = useLocation();

  useEffect(() => {
    if (!user) {
      setLocation('/auth');
      return;
    }

    fetchBadges();
  }, [user, setLocation]);

  const fetchBadges = async () => {
    try {
      setLoading(true);
      const response = await axios.get(`/api/users/${user?.id}/badges`);
      setBadges(response.data);
    } catch (error) {
      console.error('Error fetching badges:', error);
      toast({
        title: 'Error',
        description: 'Failed to load badges. Please try again later.',
        variant: 'destructive',
      });
    } finally {
      setLoading(false);
    }
  };

  const getBadgeIcon = (badge: Badge) => {
    const iconProps = { className: 'h-16 w-16 mb-2' };
    
    switch (badge.iconType) {
      case 'streak':
        return <Zap {...iconProps} />;
      case 'chakra':
        return <Sun {...iconProps} />;
      case 'level':
        return <Star {...iconProps} />;
      case 'ritual':
        return <Medal {...iconProps} />;
      case 'achievement':
        return <Trophy {...iconProps} />;
      default:
        return <Award {...iconProps} />;
    }
  };

  const getBadgeColor = (badge: Badge) => {
    switch (badge.category) {
      case 'streak':
        return 'bg-gradient-to-br from-blue-500 to-blue-700 text-white';
      case 'chakra':
        return 'bg-gradient-to-br from-purple-500 to-indigo-700 text-white';
      case 'level':
        return 'bg-gradient-to-br from-yellow-500 to-amber-700 text-white';
      case 'ritual':
        return 'bg-gradient-to-br from-green-500 to-green-700 text-white';
      case 'achievement':
        return 'bg-gradient-to-br from-red-500 to-rose-700 text-white';
      default:
        return 'bg-gradient-to-br from-gray-500 to-gray-700 text-white';
    }
  };

  const filteredBadges = filters.category === 'all' 
    ? badges 
    : badges.filter(badge => badge.category === filters.category);

  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return new Intl.DateTimeFormat('en-US', { 
      year: 'numeric', 
      month: 'long', 
      day: 'numeric' 
    }).format(date);
  };

  return (
    <div className="container mx-auto p-6">
      <header className="mb-8 text-center">
        <h1 className="text-3xl font-bold text-primary">Your Spiritual Badge Wall</h1>
        <p className="text-muted-foreground mt-2">
          Showcase your spiritual achievements and milestones
        </p>
      </header>

      <div className="flex justify-center mb-6">
        <div className="inline-flex rounded-md shadow-sm">
          <button
            onClick={() => setFilters({ ...filters, category: 'all' })}
            className={`px-4 py-2 text-sm font-medium rounded-l-md ${
              filters.category === 'all'
                ? 'bg-primary text-white'
                : 'bg-background text-foreground border border-input hover:bg-accent hover:text-accent-foreground'
            }`}
          >
            All
          </button>
          <button
            onClick={() => setFilters({ ...filters, category: 'streak' })}
            className={`px-4 py-2 text-sm font-medium ${
              filters.category === 'streak'
                ? 'bg-primary text-white'
                : 'bg-background text-foreground border-y border-r border-input hover:bg-accent hover:text-accent-foreground'
            }`}
          >
            Streaks
          </button>
          <button
            onClick={() => setFilters({ ...filters, category: 'chakra' })}
            className={`px-4 py-2 text-sm font-medium ${
              filters.category === 'chakra'
                ? 'bg-primary text-white'
                : 'bg-background text-foreground border-y border-r border-input hover:bg-accent hover:text-accent-foreground'
            }`}
          >
            Chakras
          </button>
          <button
            onClick={() => setFilters({ ...filters, category: 'level' })}
            className={`px-4 py-2 text-sm font-medium ${
              filters.category === 'level'
                ? 'bg-primary text-white'
                : 'bg-background text-foreground border-y border-r border-input hover:bg-accent hover:text-accent-foreground'
            }`}
          >
            Levels
          </button>
          <button
            onClick={() => setFilters({ ...filters, category: 'ritual' })}
            className={`px-4 py-2 text-sm font-medium rounded-r-md ${
              filters.category === 'ritual'
                ? 'bg-primary text-white'
                : 'bg-background text-foreground border-y border-r border-input hover:bg-accent hover:text-accent-foreground'
            }`}
          >
            Rituals
          </button>
        </div>
      </div>

      {loading ? (
        <div className="flex justify-center items-center min-h-[400px]">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div>
        </div>
      ) : filteredBadges.length === 0 ? (
        <div className="text-center py-16 bg-muted rounded-lg">
          <ShieldCheck className="mx-auto h-12 w-12 text-muted-foreground" />
          <h3 className="mt-4 text-lg font-medium">No badges found</h3>
          <p className="mt-2 text-sm text-muted-foreground max-w-md mx-auto">
            {filters.category === 'all'
              ? "You haven't earned any badges yet. Continue your spiritual practice to unlock achievements."
              : `You haven't earned any ${filters.category} badges yet. Focus on your ${filters.category} practices to unlock them.`}
          </p>
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
          {filteredBadges.map((badge) => (
            <Card
              key={badge.id}
              className={`flex flex-col items-center text-center p-6 cursor-pointer transform transition-all duration-300 hover:scale-105 hover:shadow-xl ${getBadgeColor(
                badge
              )}`}
              onClick={() => setSelectedBadge(badge)}
            >
              <div className="flex-1 flex items-center justify-center mb-4">
                {getBadgeIcon(badge)}
              </div>
              <h3 className="text-lg font-semibold mb-1">{badge.title}</h3>
              <p className="text-sm opacity-90 mb-3">{badge.description}</p>
              <div className="text-xs opacity-75">
                Earned on {formatDate(badge.dateEarned)}
              </div>
            </Card>
          ))}
        </div>
      )}

      <Dialog open={!!selectedBadge} onOpenChange={() => setSelectedBadge(null)}>
        {selectedBadge && (
          <DialogContent className="sm:max-w-[550px] max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle className="text-center">{selectedBadge.title}</DialogTitle>
              <DialogDescription className="text-center">
                Badge Details
              </DialogDescription>
            </DialogHeader>
            
            <Tabs defaultValue="details" className="w-full">
              <TabsList className="grid w-full grid-cols-2">
                <TabsTrigger value="details">Details</TabsTrigger>
                <TabsTrigger value="share">Share Badge</TabsTrigger>
              </TabsList>
              
              <TabsContent value="details" className="mt-4">
                <div className="flex flex-col items-center justify-center py-4">
                  <div className={`p-6 rounded-full mb-4 ${getBadgeColor(selectedBadge)}`}>
                    {getBadgeIcon(selectedBadge)}
                  </div>
                  
                  <div className="space-y-4 text-center">
                    <div>
                      <h4 className="text-sm font-medium text-muted-foreground">Description</h4>
                      <p className="text-foreground">{selectedBadge.description}</p>
                    </div>
                    
                    <div>
                      <h4 className="text-sm font-medium text-muted-foreground">Category</h4>
                      <p className="text-foreground capitalize">{selectedBadge.category}</p>
                    </div>
                    
                    <div>
                      <h4 className="text-sm font-medium text-muted-foreground">Date Earned</h4>
                      <p className="text-foreground">{formatDate(selectedBadge.dateEarned)}</p>
                    </div>
                  </div>
                </div>
              </TabsContent>
              
              <TabsContent value="share" className="mt-4">
                <div className="flex flex-col items-center justify-center py-2">
                  <p className="text-sm text-muted-foreground mb-4 text-center">
                    Share your spiritual achievement with friends and inspire others on their journey
                  </p>
                  
                  <BadgeShareCard 
                    badgeTitle={selectedBadge.title}
                    badgeDescription={selectedBadge.description}
                    earnedDate={formatDate(selectedBadge.dateEarned)}
                    badgeColor={selectedBadge.category === 'streak' ? 'blue' : 
                               selectedBadge.category === 'chakra' ? 'purple' :
                               selectedBadge.category === 'level' ? 'yellow' :
                               selectedBadge.category === 'ritual' ? 'green' :
                               selectedBadge.category === 'achievement' ? 'red' : 'indigo'}
                    badgeIcon={selectedBadge.category === 'streak' ? '⚡' : 
                             selectedBadge.category === 'chakra' ? '☀️' :
                             selectedBadge.category === 'level' ? '⭐' :
                             selectedBadge.category === 'ritual' ? '🔮' :
                             selectedBadge.category === 'achievement' ? '🏆' : '🌟'}
                  />
                </div>
              </TabsContent>
            </Tabs>
            
            <DialogFooter className="mt-4">
              <p className="text-xs text-muted-foreground text-center w-full">
                Sharing your spiritual achievements can inspire others on their journey
              </p>
            </DialogFooter>
          </DialogContent>
        )}
      </Dialog>
    </div>
  );
}