import { useState } from 'react';
import axios from 'axios';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Switch } from '@/components/ui/switch';
import { Label } from '@/components/ui/label';
import { useToast } from '@/hooks/use-toast';
import { Loader2, Send, Mails, Mail } from 'lucide-react';

export default function EmailDigestTestPage() {
  const [email, setEmail] = useState<string>('');
  const [isSending, setIsSending] = useState<boolean>(false);
  const [isSendingToAll, setIsSendingToAll] = useState<boolean>(false);
  const [showSendAll, setShowSendAll] = useState<boolean>(false);
  const { toast } = useToast();
  
  const validateEmail = (email: string): boolean => {
    const re = /\S+@\S+\.\S+/;
    return re.test(email);
  };
  
  const handleSendTest = async () => {
    if (!validateEmail(email)) {
      toast({
        title: 'Invalid Email',
        description: 'Please enter a valid email address',
        variant: 'destructive',
      });
      return;
    }
    
    try {
      setIsSending(true);
      
      const response = await axios.post('/api/admin/send-test-email', { email });
      
      toast({
        title: 'Test Email Sent',
        description: `Weekly digest email sent to ${email}`,
        variant: 'default',
      });
    } catch (error) {
      console.error('Error sending test email:', error);
      toast({
        title: 'Error Sending Email',
        description: 'Failed to send test email. Please try again.',
        variant: 'destructive',
      });
    } finally {
      setIsSending(false);
    }
  };
  
  const handleSendToAll = async () => {
    try {
      setIsSendingToAll(true);
      
      const response = await axios.post('/api/admin/send-weekly-digest');
      
      const { results } = response.data;
      
      toast({
        title: 'Weekly Digests Sent',
        description: `Successfully sent ${results.success} emails, with ${results.failed} failures.`,
        variant: 'default',
      });
    } catch (error) {
      console.error('Error sending weekly digest emails:', error);
      toast({
        title: 'Error Sending Emails',
        description: 'Failed to send weekly digest emails. Please try again.',
        variant: 'destructive',
      });
    } finally {
      setIsSendingToAll(false);
    }
  };
  
  return (
    <div className="container max-w-3xl mx-auto p-6">
      <h1 className="text-3xl font-bold text-center mb-6">Weekly Email Digest System</h1>
      
      <div className="space-y-6">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center">
              <Mail className="h-5 w-5 mr-2" />
              Send Test Email
            </CardTitle>
            <CardDescription>
              Send a test weekly digest email to verify the email template and delivery
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="email">Recipient Email Address</Label>
                <Input
                  id="email"
                  type="email"
                  placeholder="example@example.com"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                />
              </div>
            </div>
          </CardContent>
          <CardFooter>
            <Button
              onClick={handleSendTest}
              disabled={isSending || !email}
              className="w-full"
            >
              {isSending ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Sending...
                </>
              ) : (
                <>
                  <Send className="mr-2 h-4 w-4" />
                  Send Test Email
                </>
              )}
            </Button>
          </CardFooter>
        </Card>
        
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center">
              <Mails className="h-5 w-5 mr-2" />
              Weekly Digest Controls
            </CardTitle>
            <CardDescription>
              Manage the weekly digest email system for all users
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="flex items-center justify-between space-x-2">
                <Label htmlFor="admin-mode" className="flex-1">
                  Enable Admin Controls
                  <p className="text-sm text-muted-foreground mt-1">
                    Allow sending weekly digests to all users
                  </p>
                </Label>
                <Switch
                  id="admin-mode"
                  checked={showSendAll}
                  onCheckedChange={setShowSendAll}
                />
              </div>
              
              {showSendAll && (
                <div className="mt-4 rounded-md bg-amber-50 dark:bg-amber-950 p-4">
                  <h3 className="font-semibold text-amber-800 dark:text-amber-300">
                    Admin Function
                  </h3>
                  <p className="text-sm text-amber-700 dark:text-amber-400 mt-1 mb-4">
                    This will send weekly digest emails to all active users in the system.
                    For testing purposes, this will send to a small set of 3 sample users.
                  </p>
                  <Button
                    variant="outline"
                    className="w-full border-amber-600 text-amber-700 hover:bg-amber-100 dark:text-amber-300 dark:hover:bg-amber-900"
                    onClick={handleSendToAll}
                    disabled={isSendingToAll}
                  >
                    {isSendingToAll ? (
                      <>
                        <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                        Sending to All Users...
                      </>
                    ) : (
                      <>
                        <Mails className="mr-2 h-4 w-4" />
                        Send Weekly Digest to All Users
                      </>
                    )}
                  </Button>
                </div>
              )}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}