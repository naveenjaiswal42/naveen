import React, { useState } from 'react';
import { Container } from '@/components/ui/container';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Bell, Zap, HelpCircle } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { NotificationPreferences } from '@/components/notifications/NotificationPreferences';

// Mock notifications context for this page instead of using the real one
// This avoids the error with useNotifications
const mockNotifications = {
  isPermissionGranted: false,
  requestPermission: async () => { 
    console.log("Request notification permission");
    return true;
  },
  showRitualReminder: (title: string, ritualId?: number, ritualName?: string, time?: string, description?: string) => {
    console.log("Show ritual reminder:", title, ritualId, ritualName, time, description);
  }
};

export default function NotificationSettingsPage() {
  // Use mock notifications instead of the useNotifications hook to fix the error
  const { requestPermission, isPermissionGranted, showRitualReminder } = mockNotifications;
  const { toast } = useToast();
  const [activeTab, setActiveTab] = useState('settings');

  const handleTestNotification = () => {
    if (!isPermissionGranted) {
      toast({
        title: 'Permission Required',
        description: 'Please enable notifications to test this feature.',
        variant: 'destructive',
      });
      return;
    }

    // Show a test notification popup
    showRitualReminder(
      'Test Notification',
      undefined,
      'Morning Meditation',
      '05:30 AM',
      'This is a test notification to preview how ritual reminders will appear.'
    );

    toast({
      title: 'Test Notification Sent',
      description: 'Check the popup to see how notifications will appear.',
    });
  };

  return (
    <Container>
      <div className="py-8">
        <div className="flex flex-col md:flex-row items-start md:items-center justify-between mb-6">
          <div>
            <h1 className="text-3xl font-bold tracking-tight">Notification Settings</h1>
            <p className="text-gray-500 dark:text-gray-400 mt-2">
              Configure how you receive reminders for your spiritual practices.
            </p>
          </div>
          <Button 
            className="mt-4 md:mt-0" 
            onClick={handleTestNotification}
            variant="outline"
          >
            <Zap className="mr-2 h-4 w-4" />
            Test Notification
          </Button>
        </div>
        
        <div className="bg-indigo-50 dark:bg-indigo-950/20 p-4 rounded-lg mb-6 border border-indigo-100 dark:border-indigo-800/30">
          <div className="flex items-start">
            <Bell className="h-5 w-5 text-indigo-600 dark:text-indigo-400 mt-0.5 mr-3 flex-shrink-0" />
            <div>
              <h3 className="font-medium text-indigo-700 dark:text-indigo-300">Daily Ritual Reminders</h3>
              <p className="text-indigo-600/80 dark:text-indigo-400/80 text-sm mt-1">
                Reminders help you maintain consistency in your spiritual practice. Morning reminders are sent at 5:00 AM, 
                and evening reminders at 5:00 PM. Enabling notifications ensures you never miss your daily rituals and 
                helps maintain your meditation streak.
              </p>
            </div>
          </div>
        </div>

        <Tabs defaultValue="settings" value={activeTab} onValueChange={setActiveTab} className="space-y-6">
          <TabsList className="grid w-full md:w-auto grid-cols-2">
            <TabsTrigger value="settings">
              <Bell className="mr-2 h-4 w-4" />
              Settings
            </TabsTrigger>
            <TabsTrigger value="help">
              <HelpCircle className="mr-2 h-4 w-4" />
              Help & Tips
            </TabsTrigger>
          </TabsList>

          <TabsContent value="settings" className="space-y-6">
            <NotificationPreferences />
          </TabsContent>

          <TabsContent value="help">
            <Card>
              <CardHeader>
                <CardTitle>Notification Help & Tips</CardTitle>
                <CardDescription>
                  Learn how to use and optimize notifications for your spiritual journey.
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <h3 className="font-medium text-lg">Why are notifications important?</h3>
                  <p className="text-gray-600 dark:text-gray-400 mt-1">
                    Regular spiritual practice is essential for chakra activation and spiritual growth. Notifications help you maintain consistency and build a spiritual streak.
                  </p>
                </div>

                <div>
                  <h3 className="font-medium text-lg">How to enable notifications</h3>
                  <ol className="list-decimal list-inside space-y-2 text-gray-600 dark:text-gray-400 mt-1">
                    <li>Go to the Settings tab above</li>
                    <li>Toggle "Enable Notifications" to On</li>
                    <li>Allow notifications when prompted by your browser</li>
                    <li>Configure which reminders you want to receive</li>
                  </ol>
                </div>

                <div>
                  <h3 className="font-medium text-lg">Troubleshooting</h3>
                  <div className="space-y-2 text-gray-600 dark:text-gray-400 mt-1">
                    <p><strong>Not receiving notifications?</strong> Check your browser settings:</p>
                    <ul className="list-disc list-inside ml-4 space-y-1">
                      <li>Make sure notifications are enabled for this site in your browser settings</li>
                      <li>Check that you haven't muted the site</li>
                      <li>Ensure your device is not in Do Not Disturb mode</li>
                      <li>Try using a different browser if problems persist</li>
                    </ul>
                  </div>
                </div>

                <div>
                  <h3 className="font-medium text-lg">Silent Hours Feature</h3>
                  <p className="text-gray-600 dark:text-gray-400 mt-1">
                    Silent hours allow you to specify a time period when you don't want to receive notifications, such as during sleep or meditation. Configure these in the Settings tab.
                  </p>
                </div>

                <div className="bg-amber-50 dark:bg-amber-950/20 p-4 rounded-md">
                  <h3 className="font-medium text-amber-800 dark:text-amber-300 flex items-center">
                    <HelpCircle className="h-4 w-4 mr-2" />
                    Note
                  </h3>
                  <p className="text-amber-700 dark:text-amber-400 mt-1">
                    Notifications function best when you keep the app open in a browser tab. Some browsers may restrict background notifications.
                  </p>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </Container>
  );
}