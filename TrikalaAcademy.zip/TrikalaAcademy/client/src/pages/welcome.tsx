import AuthContainer from "@/components/auth/AuthContainer";
import FirebaseTest from "@/components/firebase-test";

const Welcome = () => {
  // Used FirebaseTest for testing Firebase connectivity
  return (
    <>
      <FirebaseTest />
    </>
  );
};

export default Welcome;
