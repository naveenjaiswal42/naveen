import { useState, useEffect } from "react";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import SpiritualGuidanceAssistant from "@/components/guidance/SpiritualGuidanceAssistant";
import ChakraRecommendations from "@/components/guidance/ChakraRecommendations";
import SpiritualGrowthPlanner from "@/components/guidance/SpiritualGrowthPlanner";
import { CheckCircle2, HelpCircle, Lightbulb } from "lucide-react";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";

export default function GuidancePage() {
  const [activeTab, setActiveTab] = useState("assistant");
  const { toast } = useToast();
  // The key is now provided by environment variables and available through process.env
  const [hasOpenAIKey, setHasOpenAIKey] = useState(true);
  
  useEffect(() => {
    // Toast a success message that the AI features are available
    toast({
      title: "AI Features Enabled",
      description: "Spiritual guidance features are now available with AI assistance.",
      duration: 3000,
    });
  }, [toast]);

  return (
    <div className="container max-w-4xl py-8">
      <h1 className="text-3xl font-bold mb-2 text-center">AI Spiritual Guidance</h1>
      <p className="text-muted-foreground text-center mb-8">
        Receive personalized spiritual guidance, chakra recommendations, and growth plans
      </p>

      <Alert className="mb-6 bg-green-50 border-green-200 dark:bg-green-950 dark:border-green-900">
        <CheckCircle2 className="h-4 w-4 text-green-600 dark:text-green-400" />
        <AlertTitle className="text-green-700 dark:text-green-300">AI Features Enabled</AlertTitle>
        <AlertDescription className="text-green-600 dark:text-green-400">
          All spiritual guidance features are active and powered by advanced AI technology
          to provide personalized spiritual guidance on your journey.
        </AlertDescription>
      </Alert>

      <Alert className="mb-6 bg-primary/10 border-primary/20">
        <Lightbulb className="h-4 w-4 text-primary" />
        <AlertTitle>Divine Wisdom</AlertTitle>
        <AlertDescription>
          The guidance provided combines ancient Vedic wisdom with modern AI technology
          to support your unique spiritual journey.
        </AlertDescription>
      </Alert>

      <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
        <TabsList className="grid grid-cols-3 mb-6">
          <TabsTrigger value="assistant">Spiritual Assistant</TabsTrigger>
          <TabsTrigger value="chakra">Chakra Insights</TabsTrigger>
          <TabsTrigger value="planner">Growth Planner</TabsTrigger>
        </TabsList>
        
        <TabsContent value="assistant" className="pt-2">
          <SpiritualGuidanceAssistant />
        </TabsContent>
        
        <TabsContent value="chakra" className="pt-2">
          <ChakraRecommendations />
        </TabsContent>
        
        <TabsContent value="planner" className="pt-2">
          <SpiritualGrowthPlanner />
        </TabsContent>
      </Tabs>
    </div>
  );
}