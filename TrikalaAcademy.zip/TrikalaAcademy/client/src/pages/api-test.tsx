import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { ChakraType } from '@/lib/chakras';
import { getSpiritualGuidance, getChakraRecommendations } from '@/lib/openai';

export default function ApiTestPage() {
  const [loading, setLoading] = useState(false);
  const [output, setOutput] = useState<string>('');
  const [guidanceQuery, setGuidanceQuery] = useState<string>('');
  const [chakraType, setChakraType] = useState<ChakraType>('crown');
  const [apiStatus, setApiStatus] = useState<{
    openai: boolean | null;
    firebase: boolean | null;
  }>({
    openai: null,
    firebase: null,
  });

  useEffect(() => {
    // Test API connections on mount
    testOpenAI();
    testFirebase();
  }, []);

  const testOpenAI = async () => {
    try {
      const response = await fetch('/api/openai-test');
      const result = await response.json();
      setApiStatus(prev => ({ ...prev, openai: result.success }));
    } catch (error) {
      console.error('Error testing OpenAI:', error);
      setApiStatus(prev => ({ ...prev, openai: false }));
    }
  };

  const testFirebase = async () => {
    try {
      const response = await fetch('/api/firebase-test');
      const result = await response.json();
      setApiStatus(prev => ({ ...prev, firebase: result.success }));
    } catch (error) {
      console.error('Error testing Firebase:', error);
      setApiStatus(prev => ({ ...prev, firebase: false }));
    }
  };

  const handleGuidanceGeneration = async () => {
    if (!guidanceQuery.trim()) return;
    
    setLoading(true);
    setOutput('Generating response...');
    
    try {
      const response = await getSpiritualGuidance(guidanceQuery);
      setOutput(response);
    } catch (error: any) {
      setOutput(`Error: ${error.message || 'Failed to generate guidance'}`);
    } finally {
      setLoading(false);
    }
  };

  const handleChakraRecommendations = async () => {
    setLoading(true);
    setOutput('Generating chakra recommendations...');
    
    try {
      const recommendations = await getChakraRecommendations(chakraType, 'intermediate');
      setOutput(JSON.stringify(recommendations, null, 2));
    } catch (error: any) {
      setOutput(`Error: ${error.message || 'Failed to generate recommendations'}`);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="container mx-auto py-10">
      <h1 className="text-3xl font-bold mb-6 text-center">Trikala Academy API Test</h1>
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
        <ApiStatusCard 
          title="OpenAI API Status" 
          status={apiStatus.openai} 
          description="Checks connection to ChatGPT for spiritual guidance" 
          onRetest={testOpenAI}
        />
        <ApiStatusCard 
          title="Firebase API Status" 
          status={apiStatus.firebase} 
          description="Checks connection to Firebase for authentication and data storage" 
          onRetest={testFirebase}
        />
      </div>
      
      <Tabs defaultValue="guidance" className="w-full">
        <TabsList className="grid w-full grid-cols-2">
          <TabsTrigger value="guidance">Spiritual Guidance</TabsTrigger>
          <TabsTrigger value="chakra">Chakra Recommendations</TabsTrigger>
        </TabsList>
        
        <TabsContent value="guidance" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Ask for Spiritual Guidance</CardTitle>
              <CardDescription>
                Ask any question about spiritual practice, meditation, or Vedic tradition
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid w-full items-center gap-4">
                <div className="flex flex-col space-y-1.5">
                  <Label htmlFor="guidance-query">Your Question</Label>
                  <Input
                    id="guidance-query"
                    placeholder="How can I balance my chakras daily?"
                    value={guidanceQuery}
                    onChange={(e) => setGuidanceQuery(e.target.value)}
                  />
                </div>
              </div>
            </CardContent>
            <CardFooter className="flex justify-end">
              <Button onClick={handleGuidanceGeneration} disabled={loading || !guidanceQuery.trim()}>
                Generate Guidance
              </Button>
            </CardFooter>
          </Card>
        </TabsContent>
        
        <TabsContent value="chakra" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Get Chakra Recommendations</CardTitle>
              <CardDescription>
                Receive personalized recommendations for balancing a specific chakra
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid w-full items-center gap-4">
                <div className="flex flex-col space-y-1.5">
                  <Label htmlFor="chakra-type">Select Chakra</Label>
                  <select
                    id="chakra-type"
                    className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background file:border-0 file:bg-transparent file:text-sm file:font-medium focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50"
                    value={chakraType}
                    onChange={(e) => setChakraType(e.target.value as ChakraType)}
                  >
                    <option value="crown">Crown (Sahasrara)</option>
                    <option value="thirdEye">Third Eye (Ajna)</option>
                    <option value="throat">Throat (Vishuddha)</option>
                    <option value="heart">Heart (Anahata)</option>
                    <option value="solar">Solar Plexus (Manipura)</option>
                    <option value="sacral">Sacral (Svadhisthana)</option>
                    <option value="root">Root (Muladhara)</option>
                  </select>
                </div>
              </div>
            </CardContent>
            <CardFooter className="flex justify-end">
              <Button onClick={handleChakraRecommendations} disabled={loading}>
                Get Recommendations
              </Button>
            </CardFooter>
          </Card>
        </TabsContent>
      </Tabs>
      
      {output && (
        <div className="mt-8">
          <Card>
            <CardHeader>
              <CardTitle>API Response</CardTitle>
            </CardHeader>
            <CardContent>
              <pre className="bg-muted p-4 rounded-md whitespace-pre-wrap text-sm">
                {output}
              </pre>
            </CardContent>
          </Card>
        </div>
      )}
    </div>
  );
}

function ApiStatusCard({ 
  title, 
  status, 
  description, 
  onRetest 
}: { 
  title: string; 
  status: boolean | null; 
  description: string; 
  onRetest: () => void;
}) {
  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center justify-between">
          {title}
          <StatusIndicator status={status} />
        </CardTitle>
        <CardDescription>{description}</CardDescription>
      </CardHeader>
      <CardFooter>
        <Button variant="outline" onClick={onRetest}>
          Test Connection
        </Button>
      </CardFooter>
    </Card>
  );
}

function StatusIndicator({ status }: { status: boolean | null }) {
  if (status === null) {
    return <div className="h-4 w-4 rounded-full bg-gray-300"></div>;
  }
  
  return status ? (
    <div className="h-4 w-4 rounded-full bg-green-500" title="Connected"></div>
  ) : (
    <div className="h-4 w-4 rounded-full bg-red-500" title="Failed"></div>
  );
}