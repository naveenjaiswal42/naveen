import { useState } from "react";
import { Link, useLocation } from "wouter";
import MainLayout from "@/components/layouts/MainLayout";
import { 
  Settings, 
  Award, 
  Calendar, 
  FileText, 
  HelpCircle, 
  LogOut, 
  Music, 
  Target, 
  Sparkles
} from "lucide-react";
import { Button } from "@/components/ui/button";

interface NavItem {
  path: string;
  label: string;
  icon: any;
  description: string;
}

export default function MorePage() {
  const [, setLocation] = useLocation();
  const [isLoggingOut, setIsLoggingOut] = useState(false);
  
  const navItems: NavItem[] = [
    {
      path: "/rituals",
      label: "Daily Rituals",
      icon: <Calendar className="w-6 h-6" />,
      description: "Track your spiritual practices"
    },
    {
      path: "/badges",
      label: "Badges & Achievements",
      icon: <Award className="w-6 h-6" />,
      description: "View your earned achievements"
    },
    {
      path: "/guided-meditation",
      label: "Guided Meditations",
      icon: <Music className="w-6 h-6" />,
      description: "Audio-guided spiritual journeys"
    },
    {
      path: "/chakra-music",
      label: "Chakra Music",
      icon: <Music className="w-6 h-6" />,
      description: "Frequency-based chakra healing sounds"
    },
    {
      path: "/journal",
      label: "Spiritual Journal",
      icon: <FileText className="w-6 h-6" />,
      description: "Record your spiritual insights"
    },
    {
      path: "/challenges",
      label: "Personal Challenges",
      icon: <Target className="w-6 h-6" />,
      description: "Create and track spiritual goals"
    },
    {
      path: "/healing-journey",
      label: "Healing Journey",
      icon: <Sparkles className="w-6 h-6" />,
      description: "21-day guided healing program"
    },
    {
      path: "/spiritual-goal",
      label: "Spiritual Goals",
      icon: <Target className="w-6 h-6" />,
      description: "Set long-term spiritual targets"
    },
    {
      path: "/settings",
      label: "Settings",
      icon: <Settings className="w-6 h-6" />,
      description: "Customize your experience"
    },
    {
      path: "/help",
      label: "Help & Support",
      icon: <HelpCircle className="w-6 h-6" />,
      description: "Get assistance and resources"
    },
  ];
  
  const handleLogout = async () => {
    try {
      setIsLoggingOut(true);
      // Call your logout API here
      const response = await fetch("/api/logout", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
      });
      
      if (response.ok) {
        // Redirect to login page
        setLocation("/auth");
      } else {
        throw new Error("Logout failed");
      }
    } catch (error) {
      console.error("Logout error:", error);
    } finally {
      setIsLoggingOut(false);
    }
  };
  
  return (
    <MainLayout>
      <div className="container max-w-4xl mx-auto">
        <h1 className="text-2xl font-bold mb-6 text-gray-800 dark:text-white">More Options</h1>
        
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
          {navItems.map((item) => (
            <Link key={item.path} href={item.path}>
              <div className="block p-4 rounded-lg bg-white dark:bg-gray-800 shadow hover:shadow-md transition-all duration-300 border border-gray-100 dark:border-gray-700">
                <div className="flex items-start">
                  <div className="bg-primary/10 dark:bg-primary/20 p-3 rounded-full mr-4">
                    {item.icon}
                  </div>
                  <div>
                    <h3 className="font-medium text-gray-900 dark:text-white">{item.label}</h3>
                    <p className="text-sm text-gray-500 dark:text-gray-400 mt-1">{item.description}</p>
                  </div>
                </div>
              </div>
            </Link>
          ))}
        </div>
        
        <div className="mt-8 border-t border-gray-200 dark:border-gray-700 pt-6">
          <Button 
            variant="destructive" 
            className="w-full mb-4 bg-red-100 hover:bg-red-200 text-red-600 border border-red-200"
            onClick={handleLogout}
            disabled={isLoggingOut}
          >
            <LogOut className="w-4 h-4 mr-2" />
            {isLoggingOut ? "Logging out..." : "Log out"}
          </Button>
          
          <p className="text-center text-xs text-gray-500 dark:text-gray-400">
            Trikala Academy v1.0.0 - Spiritual Growth Platform
          </p>
        </div>
      </div>
    </MainLayout>
  );
}