import { useState, useEffect } from "react";
import { useLocation, useParams } from "wouter";
import { useQuery, useMutation } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { Button } from "@/components/ui/button";
import { Loader2, CheckCircle, BookOpen, Award } from "lucide-react";
import { useAuth } from "@/contexts/AuthContext";
import CertificateCongratulations from "@/components/courses/CertificateCongratulations";

interface Lesson {
  id: number;
  title: string;
  description: string;
  content: string;
  order: number;
  completed: boolean;
}

export default function CourseLessonsPage() {
  const { id } = useParams<{ id: string }>();
  const courseId = parseInt(id);
  const { toast } = useToast();
  const { user } = useAuth();
  const [, navigate] = useLocation();
  const [showCertificate, setShowCertificate] = useState(false);

  // Mock lessons for now - would come from API in real implementation
  const [lessons, setLessons] = useState<Lesson[]>([]);
  
  // Fetch course details
  const { data: course, isLoading: courseLoading } = useQuery({
    queryKey: ['/api/courses', courseId],
    queryFn: () => apiRequest({ 
      url: `/api/courses/${courseId}`,
      method: 'GET'
    }),
    enabled: !!courseId,
  });

  // Fetch user course progress
  const { data: userCourse, isLoading: progressLoading } = useQuery({
    queryKey: ['/api/users', user?.id, 'courses', courseId],
    queryFn: () => apiRequest({ 
      url: `/api/users/${user?.id}/courses/${courseId}`,
      method: 'GET'
    }),
    enabled: !!user?.id && !!courseId,
  });

  // Create lessons based on total lessons count
  useEffect(() => {
    if (course && course.total_lessons) {
      const mockLessons: Lesson[] = [];
      for (let i = 0; i < course.total_lessons; i++) {
        mockLessons.push({
          id: i + 1,
          title: `Lesson ${i + 1}`,
          description: `Description for Lesson ${i + 1}`,
          content: `Content for Lesson ${i + 1}`,
          order: i + 1,
          completed: userCourse?.lessons_completed > i
        });
      }
      setLessons(mockLessons);
    }
  }, [course, userCourse]);

  // Mutation to update lesson progress
  const updateProgressMutation = useMutation({
    mutationFn: (lessonsCompleted: number) => 
      apiRequest({
        url: `/api/users/${user?.id}/courses/${courseId}`,
        method: 'PATCH',
        body: JSON.stringify({ lessonsCompleted })
      }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/users', user?.id, 'courses'] });
      queryClient.invalidateQueries({ queryKey: ['/api/users', user?.id, 'courses', courseId] });
      toast({
        title: "Progress updated",
        description: "Your course progress has been saved.",
      });
    },
    onError: () => {
      toast({
        title: "Error updating progress",
        description: "Failed to update your course progress. Please try again.",
        variant: "destructive",
      });
    }
  });

  const handleCompleteLesson = (lessonIndex: number) => {
    // Calculate new lessons completed count
    const newCompletedCount = lessonIndex + 1;
    
    // Only update if this would increase the completion count
    if (userCourse?.lessons_completed < newCompletedCount) {
      updateProgressMutation.mutate(newCompletedCount);
      
      // Update local state for immediate feedback
      setLessons(prev => prev.map((lesson, idx) => 
        idx <= lessonIndex ? { ...lesson, completed: true } : lesson
      ));
      
      // Show certificate celebration if all lessons are now completed
      const isLastLesson = newCompletedCount === course?.total_lessons;
      if (isLastLesson) {
        // Small delay to let the progress update UI reflect first
        setTimeout(() => {
          setShowCertificate(true);
        }, 500);
      }
    }
  };

  if (courseLoading || progressLoading) {
    return (
      <div className="flex items-center justify-center min-h-[60vh]">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  if (!course) {
    return (
      <div className="text-center py-10">
        <h2 className="text-2xl font-bold mb-2">Course not found</h2>
        <p className="mb-4">The course you're looking for doesn't exist.</p>
        <Button onClick={() => navigate('/courses')}>Browse Courses</Button>
      </div>
    );
  }

  const completedLessons = userCourse?.lessons_completed || 0;
  const totalLessons = course?.total_lessons || 0;
  const progressPercentage = totalLessons > 0 ? (completedLessons / totalLessons) * 100 : 0;

  return (
    <div className="container mx-auto py-6 max-w-4xl relative">
      {showCertificate && (
        <CertificateCongratulations 
          courseTitle={course.title}
          userName={user?.name || "Spiritual Student"}
          onClose={() => setShowCertificate(false)} 
          isCourseCompleted={completedLessons >= totalLessons}
        />
      )}

      <Button 
        variant="ghost" 
        onClick={() => navigate('/my-courses')}
        className="mb-4"
      >
        &larr; Back to My Courses
      </Button>
      
      <Card>
        <CardHeader>
          <CardTitle className="text-2xl flex items-center gap-2">
            <BookOpen className="h-6 w-6 text-primary" />
            {course.title} - Lessons
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="mb-6">
            <div className="flex justify-between items-center mb-2">
              <span className="text-sm text-gray-600 dark:text-gray-400">
                Your progress
              </span>
              <span className="text-sm font-medium">
                {completedLessons}/{totalLessons} lessons completed
              </span>
            </div>
            <Progress value={progressPercentage} className="h-2" />
          </div>

          <div className="space-y-4">
            {lessons.map((lesson, idx) => (
              <Card key={lesson.id} className={lesson.completed ? "border-primary/40 bg-primary/5" : ""}>
                <CardContent className="p-4">
                  <div className="flex justify-between items-center">
                    <div>
                      <h3 className="font-medium flex items-center gap-2">
                        {lesson.completed && <CheckCircle className="h-4 w-4 text-primary" />}
                        {lesson.title}
                      </h3>
                      <p className="text-sm text-gray-600 dark:text-gray-400 mt-1">
                        {lesson.description}
                      </p>
                    </div>
                    <Button 
                      variant={lesson.completed ? "outline" : "default"}
                      disabled={updateProgressMutation.isPending || (idx > 0 && !lessons[idx-1]?.completed)}
                      onClick={() => handleCompleteLesson(idx)}
                    >
                      {updateProgressMutation.isPending && idx === lessons.findIndex(l => !l.completed) && (
                        <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                      )}
                      {lesson.completed ? "Completed" : "Mark as Complete"}
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>

          {completedLessons >= totalLessons && (
            <div className="mt-6 p-4 bg-green-50 dark:bg-green-900/20 rounded-lg border border-green-200 dark:border-green-900/30 text-center">
              <h3 className="text-lg font-medium text-green-800 dark:text-green-300 mb-1 flex items-center justify-center gap-2">
                <Award className="h-4 w-4" /> Congratulations
              </h3>
              <p className="text-green-700 dark:text-green-400">
                You've completed all lessons in this course.
              </p>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}