import { useState } from "react";
import { useMutation } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { Container } from "@/components/ui/container";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";
import { Loader2, Send, Brain, Sparkles, RefreshCw, HelpCircle } from "lucide-react";
import { Badge } from "@/components/ui/badge";

// Sample spiritual topics for suggestions
const sampleTopics = [
  "How can I balance my root chakra?",
  "What meditation practice is best for beginners?",
  "How to maintain spiritual discipline daily?",
  "What are the signs of spiritual awakening?",
  "How can I release negative energy from my aura?",
  "What dietary practices support spiritual growth?",
  "How to connect with my higher self?"
];

export default function SpiritualCoachPage() {
  const [question, setQuestion] = useState("");
  const [answer, setAnswer] = useState("");
  const { toast } = useToast();

  // Use react-query for the API request
  const askCoachMutation = useMutation({
    mutationFn: async (questionText: string) => {
      const response = await apiRequest({
        method: "POST", 
        url: "/api/openai-test", 
        body: { query: questionText }
      });
      const data = await response.json();
      
      return data.message || data.response || "I couldn't process your question at this time. Please try again later.";
    },
    onSuccess: (data) => {
      setAnswer(data);
    },
    onError: (error) => {
      console.error("Error asking coach:", error);
      toast({
        title: "Connection Error",
        description: "Unable to connect to the Spiritual Coach. Please try again later.",
        variant: "destructive"
      });
    }
  });

  const handleAskCoach = () => {
    if (!question.trim()) {
      toast({
        title: "Question Required",
        description: "Please enter a question for the spiritual coach.",
        variant: "destructive"
      });
      return;
    }

    // Enhance the prompt with spiritual coaching instructions
    const enhancedQuestion = `As a wise and compassionate spiritual coach specializing in meditation, chakras, healing, and divine guidance, please provide uplifting and empowering guidance on this question: ${question}`;
    
    askCoachMutation.mutate(enhancedQuestion);
  };

  const handleSuggestionClick = (topic: string) => {
    setQuestion(topic);
  };

  const handleClearAll = () => {
    setQuestion("");
    setAnswer("");
  };

  return (
    <Container className="py-8">
      <div className="mb-8">
        <h1 className="text-3xl font-bold tracking-tight flex items-center gap-2">
          <Brain className="h-8 w-8 text-indigo-600 dark:text-indigo-400" /> 
          Personal Spiritual Coach
        </h1>
        <p className="text-gray-500 dark:text-gray-400 mt-2">
          Get personalized spiritual guidance for your meditation journey and inner growth
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {/* Main interaction area */}
        <div className="md:col-span-2 space-y-6">
          <Card className="border-indigo-100 dark:border-indigo-800/30">
            <CardHeader>
              <CardTitle>Ask Your Question</CardTitle>
              <CardDescription>
                Inquire about meditation, chakras, spiritual practices, or personal growth
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <Textarea
                  value={question}
                  onChange={(e) => setQuestion(e.target.value)}
                  placeholder="What spiritual guidance do you seek today?"
                  className="min-h-[120px] resize-none"
                />
                <div className="flex flex-wrap gap-2">
                  <Button 
                    onClick={handleAskCoach} 
                    disabled={askCoachMutation.isPending || !question.trim()}
                    className="bg-indigo-600 hover:bg-indigo-700"
                  >
                    {askCoachMutation.isPending ? (
                      <>
                        <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                        Consulting...
                      </>
                    ) : (
                      <>
                        <Send className="mr-2 h-4 w-4" />
                        Ask Coach
                      </>
                    )}
                  </Button>
                  <Button 
                    variant="outline" 
                    onClick={handleClearAll}
                    disabled={askCoachMutation.isPending}
                  >
                    <RefreshCw className="mr-2 h-4 w-4" />
                    Clear
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>

          {answer && (
            <Card className="border-indigo-100 dark:border-indigo-800/30 bg-gradient-to-r from-indigo-50/50 to-purple-50/50 dark:from-indigo-950/20 dark:to-purple-950/20">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Sparkles className="h-5 w-5 text-amber-500" />
                  Spiritual Guidance
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="prose dark:prose-invert max-w-none">
                  {answer.split('\n\n').map((paragraph, index) => (
                    <p key={index}>{paragraph}</p>
                  ))}
                </div>
              </CardContent>
            </Card>
          )}
        </div>

        {/* Sidebar with suggestions and info */}
        <div className="space-y-6">
          <Card className="border-indigo-100 dark:border-indigo-800/30">
            <CardHeader>
              <CardTitle className="text-lg flex items-center gap-2">
                <HelpCircle className="h-5 w-5 text-indigo-600 dark:text-indigo-400" />
                Suggested Topics
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {sampleTopics.map((topic, index) => (
                  <div 
                    key={index}
                    className="p-3 bg-indigo-50 dark:bg-indigo-900/20 rounded-md cursor-pointer hover:bg-indigo-100 dark:hover:bg-indigo-900/30 transition-colors"
                    onClick={() => handleSuggestionClick(topic)}
                  >
                    <p className="text-sm text-indigo-700 dark:text-indigo-300">{topic}</p>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          <Card className="border-indigo-100 dark:border-indigo-800/30">
            <CardHeader>
              <CardTitle className="text-lg">Coach's Expertise</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex flex-wrap gap-2">
                <Badge variant="outline" className="bg-red-50 dark:bg-red-950/20 text-red-600 dark:text-red-400 border-red-200 dark:border-red-800/30">
                  Root Chakra
                </Badge>
                <Badge variant="outline" className="bg-orange-50 dark:bg-orange-950/20 text-orange-600 dark:text-orange-400 border-orange-200 dark:border-orange-800/30">
                  Sacral Chakra
                </Badge>
                <Badge variant="outline" className="bg-yellow-50 dark:bg-yellow-950/20 text-yellow-600 dark:text-yellow-400 border-yellow-200 dark:border-yellow-800/30">
                  Solar Plexus
                </Badge>
                <Badge variant="outline" className="bg-green-50 dark:bg-green-950/20 text-green-600 dark:text-green-400 border-green-200 dark:border-green-800/30">
                  Heart Chakra
                </Badge>
                <Badge variant="outline" className="bg-blue-50 dark:bg-blue-950/20 text-blue-600 dark:text-blue-400 border-blue-200 dark:border-blue-800/30">
                  Throat Chakra
                </Badge>
                <Badge variant="outline" className="bg-indigo-50 dark:bg-indigo-950/20 text-indigo-600 dark:text-indigo-400 border-indigo-200 dark:border-indigo-800/30">
                  Third Eye
                </Badge>
                <Badge variant="outline" className="bg-purple-50 dark:bg-purple-950/20 text-purple-600 dark:text-purple-400 border-purple-200 dark:border-purple-800/30">
                  Crown Chakra
                </Badge>
                <Badge variant="outline" className="bg-slate-50 dark:bg-slate-950/20 text-slate-600 dark:text-slate-400 border-slate-200 dark:border-slate-800/30">
                  Meditation
                </Badge>
                <Badge variant="outline" className="bg-emerald-50 dark:bg-emerald-950/20 text-emerald-600 dark:text-emerald-400 border-emerald-200 dark:border-emerald-800/30">
                  Spiritual Growth
                </Badge>
                <Badge variant="outline" className="bg-amber-50 dark:bg-amber-950/20 text-amber-600 dark:text-amber-400 border-amber-200 dark:border-amber-800/30">
                  Inner Healing
                </Badge>
                <Badge variant="outline" className="bg-pink-50 dark:bg-pink-950/20 text-pink-600 dark:text-pink-400 border-pink-200 dark:border-pink-800/30">
                  Divine Connection
                </Badge>
              </div>
            </CardContent>
          </Card>

          <div className="bg-indigo-50 dark:bg-indigo-950/20 p-4 rounded-lg border border-indigo-100 dark:border-indigo-800/30">
            <h3 className="font-medium text-indigo-800 dark:text-indigo-300 mb-2">Why Consult the Spiritual Coach?</h3>
            <ul className="space-y-2 text-sm text-gray-600 dark:text-gray-400">
              <li className="flex items-start gap-2">
                <span className="text-indigo-600 dark:text-indigo-400 mt-0.5">•</span>
                <span>Get personalized guidance on your spiritual journey</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-indigo-600 dark:text-indigo-400 mt-0.5">•</span>
                <span>Learn advanced meditation and chakra techniques</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-indigo-600 dark:text-indigo-400 mt-0.5">•</span>
                <span>Overcome energy blockages and spiritual obstacles</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-indigo-600 dark:text-indigo-400 mt-0.5">•</span>
                <span>Receive wisdom based on ancient spiritual traditions</span>
              </li>
            </ul>
          </div>
        </div>
      </div>
    </Container>
  );
}