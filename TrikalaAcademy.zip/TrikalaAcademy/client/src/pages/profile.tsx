import { useEffect, useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { apiRequest } from '@/lib/queryClient';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { useAuth } from '@/contexts/AuthContext';
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { getCurrentStreak, getDailyRitualStreak } from '@/services/streakService.js';
import { User, Trophy, Flame, Gem, GraduationCap, Award, BookOpen, Calendar } from 'lucide-react';
import { Link } from 'wouter';
import { BadgesList } from '@/components/profile/BadgesList';

export default function ProfilePage() {
  const { user } = useAuth();
  const [streak, setStreak] = useState(0);
  const [ritualStreak, setRitualStreak] = useState(0);
  
  // Fetch user data
  const { data: userData, isLoading } = useQuery({
    queryKey: ['/api/users', user?.id],
    queryFn: () => apiRequest({ 
      url: `/api/users/${user?.id}`, 
      method: 'GET' 
    }),
    enabled: !!user?.id
  });
  
  // Fetch completed courses
  const { data: userCourses } = useQuery({
    queryKey: ['/api/users', user?.id, 'courses'],
    queryFn: () => apiRequest({ 
      url: `/api/users/${user?.id}/courses`, 
      method: 'GET' 
    }),
    enabled: !!user?.id
  });
  
  // Fetch all courses to get their details
  const { data: allCourses } = useQuery({
    queryKey: ['/api/courses'],
    queryFn: () => apiRequest({ 
      url: `/api/courses`, 
      method: 'GET' 
    }),
  });

  useEffect(() => {
    const fetchStreaks = async () => {
      if (user?.id) {
        try {
          // Fetch meditation streak
          const currentStreak = await getCurrentStreak(user.id);
          setStreak(currentStreak);
          
          // Fetch daily ritual streak
          const currentRitualStreak = await getDailyRitualStreak(user.id);
          setRitualStreak(currentRitualStreak);
        } catch (error) {
          console.error("Error fetching streaks:", error);
        }
      }
    };
    
    fetchStreaks();
  }, [user?.id]);

  if (isLoading) {
    return (
      <div className="p-8 max-w-6xl mx-auto">
        <h1 className="text-3xl font-bold mb-6">Loading Profile...</h1>
      </div>
    );
  }

  return (
    <div className="p-8 max-w-6xl mx-auto">
      <div className="mb-8">
        <h1 className="text-3xl font-bold mb-2 flex items-center gap-2">
          <User className="h-8 w-8" /> My Profile
        </h1>
        <p className="text-gray-500 dark:text-gray-400">
          Track your spiritual progress and move towards your goals
        </p>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-10">
        {/* User Info Card */}
        <Card className="bg-gradient-to-r from-purple-50 to-indigo-50 dark:from-purple-900/30 dark:to-indigo-900/30 border-purple-100 dark:border-purple-800">
          <CardContent className="pt-6">
            <div className="flex flex-col sm:flex-row items-center sm:items-start gap-4">
              <div className="w-24 h-24 bg-gradient-to-r from-purple-500 to-indigo-500 rounded-full flex items-center justify-center text-white text-3xl font-bold">
                {user?.name ? user.name.charAt(0).toUpperCase() : "U"}
              </div>
              <div>
                <h2 className="text-2xl font-bold text-center sm:text-left mb-1">{user?.name || "User"}</h2>
                <p className="text-gray-500 dark:text-gray-400 text-center sm:text-left">{user?.phone}</p>
                
                <div className="mt-3 flex flex-wrap gap-2">
                  <Badge variant="outline" className="bg-purple-100 dark:bg-purple-900/30 border-purple-200 dark:border-purple-800 text-purple-700 dark:text-purple-300">
                    Level {userData?.level || 1}
                  </Badge>
                  
                  {streak > 0 && (
                    <Badge className="bg-amber-100 dark:bg-amber-900/30 border-amber-200 dark:border-amber-800 text-amber-700 dark:text-amber-300 flex items-center gap-1">
                      <Flame className="h-3.5 w-3.5" /> {streak} Day Streak
                    </Badge>
                  )}
                  
                  {ritualStreak > 0 && (
                    <Badge className="bg-indigo-100 dark:bg-indigo-900/30 border-indigo-200 dark:border-indigo-800 text-indigo-700 dark:text-indigo-300 flex items-center gap-1">
                      <Calendar className="h-3.5 w-3.5" /> {ritualStreak} Day Rituals
                    </Badge>
                  )}
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
        
        {/* XP Stats Card */}
        <Card>
          <CardContent className="pt-6">
            <h3 className="text-xl font-bold mb-4">Spiritual Progress</h3>
            
            <div className="space-y-6">
              <div>
                <div className="flex justify-between mb-2">
                  <span className="font-medium">Experience Points (XP)</span>
                  <span className="font-bold text-purple-600 dark:text-purple-400">{userData?.xp || 0}</span>
                </div>
                <div className="w-full h-3 bg-gray-100 dark:bg-gray-800 rounded-full overflow-hidden">
                  <div 
                    className="h-full bg-gradient-to-r from-purple-500 to-indigo-500" 
                    style={{ width: `${Math.min(100, ((userData?.xp || 0) % 1000) / 10)}%` }}
                  />
                </div>
                <div className="flex justify-between text-sm text-gray-500 mt-1">
                  <span>Next Level: {userData?.level ? userData.level + 1 : 2}</span>
                  <span>Need {1000 - ((userData?.xp || 0) % 1000)} more XP</span>
                </div>
              </div>
              
              <div className="flex justify-between items-center">
                <div>
                  <h4 className="font-medium">Meditation Streak</h4>
                  <p className="text-sm text-gray-500">Extra XP for regular meditation</p>
                </div>
                <div className="text-right">
                  <div className="text-2xl font-bold text-amber-500">{streak}</div>
                  <div className="text-sm text-gray-500">Consecutive days</div>
                </div>
              </div>
              
              <div className="flex justify-between items-center">
                <div>
                  <h4 className="font-medium">Daily Ritual Streak</h4>
                  <p className="text-sm text-gray-500">Consistency builds your aura strength</p>
                </div>
                <div className="text-right">
                  <div className="flex items-center gap-1">
                    <Calendar className="h-5 w-5 text-indigo-500" />
                    <div className="text-2xl font-bold text-indigo-500">{ritualStreak}</div>
                  </div>
                  <div className="text-sm text-gray-500">Days of rituals</div>
                </div>
              </div>
              
              <div className="flex justify-between items-center">
                <div>
                  <h4 className="font-medium">Active Chakras</h4>
                  <p className="text-sm text-gray-500">Unlocked powers</p>
                </div>
                <Badge variant="outline" className="text-lg px-3 py-1">{userData?.active_chakras || 0}/7</Badge>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
      
      <Tabs defaultValue="achievements">
        <TabsList className="mb-6">
          <TabsTrigger value="achievements">Achievements</TabsTrigger>
          <TabsTrigger value="completed">Completed Courses</TabsTrigger>
          <TabsTrigger value="history">History</TabsTrigger>
          <TabsTrigger value="settings">Settings</TabsTrigger>
        </TabsList>
        
        <TabsContent value="achievements">
          {/* Display badges */}
          <BadgesList user={userData} />
          
          <Card>
            <CardContent className="pt-6">
              <h3 className="text-xl font-bold mb-4">Your Achievements</h3>
              
              {streak >= 3 ? (
                <div className="p-4 border border-green-100 dark:border-green-800 rounded-lg bg-green-50 dark:bg-green-900/20 flex items-center gap-4 mb-4">
                  <div className="text-2xl text-green-600 dark:text-green-400">
                    <Trophy className="h-8 w-8" />
                  </div>
                  <div>
                    <h4 className="font-bold">Regular Yogi</h4>
                    <p className="text-sm text-gray-600 dark:text-gray-400">Meditate for 3 consecutive days</p>
                  </div>
                </div>
              ) : (
                <div className="p-4 border border-gray-200 dark:border-gray-700 rounded-lg bg-gray-50 dark:bg-gray-800 flex items-center gap-4 mb-4 opacity-60">
                  <div className="text-2xl text-gray-400">
                    <Trophy className="h-8 w-8" />
                  </div>
                  <div>
                    <h4 className="font-bold">Regular Yogi</h4>
                    <p className="text-sm text-gray-600 dark:text-gray-400">Meditate for 3 consecutive days</p>
                    <div className="text-xs text-amber-600 mt-1">Progress: {streak}/3 days</div>
                  </div>
                </div>
              )}
              
              {ritualStreak >= 5 ? (
                <div className="p-4 border border-indigo-100 dark:border-indigo-800 rounded-lg bg-indigo-50 dark:bg-indigo-900/20 flex items-center gap-4 mb-4">
                  <div className="text-2xl text-indigo-600 dark:text-indigo-400">
                    <Calendar className="h-8 w-8" />
                  </div>
                  <div>
                    <h4 className="font-bold">Daily Ritual Master</h4>
                    <p className="text-sm text-gray-600 dark:text-gray-400">Complete daily rituals for 5 consecutive days</p>
                  </div>
                </div>
              ) : (
                <div className="p-4 border border-gray-200 dark:border-gray-700 rounded-lg bg-gray-50 dark:bg-gray-800 flex items-center gap-4 mb-4 opacity-60">
                  <div className="text-2xl text-gray-400">
                    <Calendar className="h-8 w-8" />
                  </div>
                  <div>
                    <h4 className="font-bold">Daily Ritual Master</h4>
                    <p className="text-sm text-gray-600 dark:text-gray-400">Complete daily rituals for 5 consecutive days</p>
                    <div className="text-xs text-indigo-600 mt-1">Progress: {ritualStreak}/5 days</div>
                  </div>
                </div>
              )}
              
              <div className="p-4 border border-gray-200 dark:border-gray-700 rounded-lg bg-gray-50 dark:bg-gray-800 flex items-center gap-4 opacity-60">
                <div className="text-2xl text-purple-400">
                  <Gem className="h-8 w-8" />
                </div>
                <div>
                  <h4 className="font-bold">Chakra Master</h4>
                  <p className="text-sm text-gray-600 dark:text-gray-400">Unlock all 7 chakras</p>
                  <div className="text-xs text-amber-600 mt-1">Progress: {userData?.active_chakras || 0}/7 chakras</div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
        
        <TabsContent value="completed">
          <Card>
            <CardContent className="pt-6">
              <h3 className="text-xl font-bold mb-4 flex items-center gap-2">
                <GraduationCap className="h-5 w-5" /> Completed Courses
              </h3>
              
              {!userCourses || userCourses.length === 0 ? (
                <p className="text-gray-500 text-center py-10">You haven't completed any courses yet.</p>
              ) : (
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                  {userCourses.filter((userCourse: any) => {
                    const course = allCourses?.find((c: any) => c.id === userCourse.courseId);
                    return course && userCourse.lessonsCompleted >= course.totalLessons;
                  }).map((userCourse: any) => {
                    const course = allCourses?.find((c: any) => c.id === userCourse.courseId);
                    return course ? (
                      <div 
                        key={userCourse.id}
                        className="bg-gradient-to-br from-purple-50 to-indigo-50 dark:from-purple-900/30 dark:to-indigo-900/30 
                                  p-6 rounded-lg shadow-sm border border-purple-100 dark:border-purple-800 
                                  hover:shadow-md transition-all duration-300"
                      >
                        <div className="flex justify-between items-start mb-4">
                          <h4 className="text-xl font-semibold mb-2">{course.title}</h4>
                          <div>
                            <Badge 
                              variant="outline" 
                              className="bg-green-100 dark:bg-green-900/30 text-green-700 dark:text-green-400 border-0"
                            >
                              Completed
                            </Badge>
                          </div>
                        </div>
                        
                        <div className="flex items-center gap-2 text-purple-600 dark:text-purple-400 mb-4">
                          <BookOpen className="h-4 w-4" />
                          <span className="text-sm">
                            {userCourse.lessonsCompleted}/{course.totalLessons} lessons
                          </span>
                        </div>
                        
                        <div className="flex justify-between items-center mt-4">
                          <div className="flex items-center text-amber-600 dark:text-amber-400">
                            <Award className="h-5 w-5 mr-1" /> 
                            <span className="text-sm font-medium">Certificate Available</span>
                          </div>
                          
                          <button 
                            onClick={() => window.location.href = `/certificate/${course.id}`}
                            className="text-primary hover:underline text-sm cursor-pointer bg-transparent border-none p-0"
                          >
                            View
                          </button>
                        </div>
                      </div>
                    ) : null;
                  })}
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>
        
        <TabsContent value="history">
          <Card>
            <CardContent className="pt-6">
              <h3 className="text-xl font-bold mb-4">Meditation History</h3>
              <p className="text-gray-500 text-center py-10">Your meditation history will appear here</p>
            </CardContent>
          </Card>
        </TabsContent>
        
        <TabsContent value="settings">
          <Card>
            <CardContent className="pt-6">
              <h3 className="text-xl font-bold mb-4">Account Settings</h3>
              <p className="text-gray-500 text-center py-10">Account settings will appear here</p>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}