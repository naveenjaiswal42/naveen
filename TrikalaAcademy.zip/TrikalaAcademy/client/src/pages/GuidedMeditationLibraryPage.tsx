import { useState, useEffect } from "react";
import { Container } from "@/components/ui/container";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Headphones, Play, Download, Heart, Clock } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/contexts/AuthContext";
import { apiRequest } from "@/lib/queryClient";

interface GuidedMeditation {
  id: number;
  title: string;
  url: string;
  duration: string;
  category: string;
  description: string;
}

export default function GuidedMeditationLibraryPage() {
  const [currentAudio, setCurrentAudio] = useState<GuidedMeditation | null>(null);
  const [favorites, setFavorites] = useState<number[]>([]);
  const [filter, setFilter] = useState<string>("all");
  const [loading, setLoading] = useState(false);
  const { toast } = useToast();
  const { user } = useAuth();
  
  const guidedMeditations: GuidedMeditation[] = [
    { 
      id: 1, 
      title: "Morning Gratitude Meditation", 
      url: "/guided/morning-gratitude.mp3", 
      duration: "10 min", 
      category: "gratitude",
      description: "Start your day with a powerful gratitude practice to set a positive intention and energy." 
    },
    { 
      id: 2, 
      title: "Chakra Balancing Meditation", 
      url: "/guided/chakra-balancing.mp3", 
      duration: "15 min", 
      category: "chakra",
      description: "Harmonize and align your seven main energy centers with this balancing meditation." 
    },
    { 
      id: 3, 
      title: "Deep Sleep Meditation", 
      url: "/guided/deep-sleep.mp3", 
      duration: "20 min", 
      category: "sleep",
      description: "Release the tensions of the day and prepare your mind and body for a restorative sleep." 
    },
    { 
      id: 4, 
      title: "Self Love Affirmation Meditation", 
      url: "/guided/self-love.mp3", 
      duration: "12 min", 
      category: "affirmation",
      description: "Nurture your relationship with yourself through powerful affirmations and guided visualization." 
    },
  ];
  
  const filteredMeditations = filter === "all" 
    ? guidedMeditations 
    : filter === "favorites" 
      ? guidedMeditations.filter(med => favorites.includes(med.id))
      : guidedMeditations.filter(med => med.category === filter);
      
  const toggleFavorite = (id: number) => {
    if (favorites.includes(id)) {
      setFavorites(favorites.filter(favId => favId !== id));
    } else {
      setFavorites([...favorites, id]);
    }
  };
  
  const handlePlayClick = (meditation: GuidedMeditation) => {
    setCurrentAudio(meditation);
    
    // Award XP for starting a meditation
    if (user) {
      awardXP(25); // 25 XP for starting a guided meditation
    }
  };
  
  const handleDownload = (meditation: GuidedMeditation) => {
    // Set loading state
    setLoading(true);
    
    // Create a direct download link
    const link = document.createElement('a');
    link.href = meditation.url;
    link.download = `${meditation.title.toLowerCase().replace(/\s+/g, '-')}.mp3`;
    document.body.appendChild(link);
    
    // Create a timeout to simulate download preparation
    setTimeout(() => {
      // Trigger the download
      link.click();
      document.body.removeChild(link);
      setLoading(false);
      
      // Award XP for downloading a meditation
      if (user) {
        awardXP(15); // 15 XP for downloading a meditation
      }
      
      toast({
        title: "Meditation Downloaded",
        description: `${meditation.title} is now available offline. You earned 15 XP!`,
        variant: "default",
      });
    }, 1500);
  };
  
  const awardXP = async (xpAmount: number) => {
    if (!user) return;
    
    try {
      await apiRequest({
        method: "POST",
        url: `/api/users/${user.id}/xp`,
        body: { xpAmount }
      });
      
      toast({
        title: "XP Awarded!",
        description: `You've earned ${xpAmount} XP for your spiritual practice.`,
        variant: "default",
      });
    } catch (error) {
      console.error("Error awarding XP:", error);
    }
  };
  
  const categories = [
    { value: "all", label: "All Meditations" },
    { value: "favorites", label: "My Favorites" },
    { value: "gratitude", label: "Gratitude" },
    { value: "chakra", label: "Chakra Balancing" },
    { value: "sleep", label: "Sleep" },
    { value: "affirmation", label: "Affirmations" },
  ];

  return (
    <Container className="py-8">
      <div className="mb-8">
        <h1 className="text-3xl font-bold tracking-tight flex items-center gap-2">
          <Headphones className="h-8 w-8 text-indigo-600 dark:text-indigo-400" /> 
          Guided Meditation Library
        </h1>
        <p className="text-gray-500 dark:text-gray-400 mt-2">
          Explore our collection of guided meditations for relaxation, healing, and spiritual growth
        </p>
      </div>
      
      {/* Category Filters */}
      <div className="flex flex-wrap gap-2 mb-6">
        {categories.map(category => (
          <Button 
            key={category.value}
            variant={filter === category.value ? "default" : "outline"}
            size="sm"
            onClick={() => setFilter(category.value)}
            className={filter === category.value ? "bg-indigo-600 hover:bg-indigo-700" : ""}
          >
            {category.label}
          </Button>
        ))}
      </div>
      
      {/* Meditation Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-24">
        {filteredMeditations.map((meditation) => (
          <Card key={meditation.id} className="overflow-hidden border-indigo-100 dark:border-indigo-800/30">
            <CardContent className="p-6">
              <div className="flex justify-between items-start mb-3">
                <h2 className="text-xl font-semibold line-clamp-2">{meditation.title}</h2>
                <Button 
                  variant="ghost" 
                  size="icon"
                  onClick={() => toggleFavorite(meditation.id)}
                  className="text-gray-400 hover:text-rose-500"
                >
                  <Heart className={`h-5 w-5 ${favorites.includes(meditation.id) ? "fill-rose-500 text-rose-500" : ""}`} />
                </Button>
              </div>
              
              <div className="flex items-center gap-2 mb-4">
                <Badge variant="outline" className="flex items-center gap-1 bg-indigo-50 dark:bg-indigo-950/20">
                  <Clock className="h-3 w-3" />
                  {meditation.duration}
                </Badge>
                <Badge variant="outline" className="capitalize bg-indigo-50 dark:bg-indigo-950/20">
                  {meditation.category}
                </Badge>
              </div>
              
              <p className="text-gray-600 dark:text-gray-400 text-sm mb-4 line-clamp-2">
                {meditation.description}
              </p>
              
              <div className="flex gap-2">
                <Button 
                  onClick={() => handlePlayClick(meditation)}
                  className="flex-1 bg-indigo-600 hover:bg-indigo-700"
                >
                  <Play className="mr-2 h-4 w-4" />
                  Play
                </Button>
                <Button 
                  variant="outline" 
                  onClick={() => handleDownload(meditation)}
                  disabled={loading}
                  className="flex-1 bg-green-600 hover:bg-green-700 text-white border-none"
                >
                  <Download className="mr-2 h-4 w-4" />
                  Download
                </Button>
              </div>
              <div className="mt-2">
                <p className="text-xs text-center text-gray-500 dark:text-gray-400">
                  📥 Download and listen offline!
                </p>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
      
      {/* Audio Player */}
      {currentAudio && (
        <div className="fixed bottom-0 left-0 right-0 bg-indigo-600 dark:bg-indigo-800 p-4 flex flex-col md:flex-row justify-between items-center text-white z-50">
          <div className="mb-3 md:mb-0 text-center md:text-left">
            <h2 className="text-lg font-semibold">{currentAudio.title}</h2>
            <p className="text-indigo-200 text-sm">{currentAudio.duration}</p>
          </div>
          <audio 
            src={currentAudio.url} 
            controls 
            autoPlay 
            className="w-full md:w-1/2 max-w-md" 
            onEnded={() => {
              // Award XP for completing a meditation
              if (user) {
                awardXP(50); // 50 XP for completing a guided meditation
              }
            }}
          />
        </div>
      )}
    </Container>
  );
}