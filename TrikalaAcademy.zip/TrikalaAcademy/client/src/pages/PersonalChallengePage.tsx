import React, { useState, useEffect } from 'react';
import { db } from '../firebase';
import { 
  collection, 
  addDoc, 
  getDocs, 
  deleteDoc, 
  doc, 
  query, 
  where, 
  Timestamp, 
  updateDoc 
} from 'firebase/firestore';
import { useAuth } from '@/contexts/AuthContext';
import { useToast } from '@/hooks/use-toast';
import { Container } from '@/components/ui/container';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Progress } from '@/components/ui/progress';
import { Separator } from '@/components/ui/separator';
import ChallengeCompletionPopup from '@/components/ChallengeCompletionPopup';
import { 
  CalendarDays, 
  Target, 
  Award, 
  Trash2, 
  PlusCircle, 
  CheckCircle, 
  Calendar, 
  ArrowUpCircle,
  Trophy,
  Star
} from 'lucide-react';

// Define challenge types
interface Challenge {
  id: string;
  title: string;
  targetDays: number;
  progress: number;
  createdAt: Timestamp;
  completedDates?: string[];
}

const PersonalChallengePage: React.FC = () => {
  const { user } = useAuth();
  const { toast } = useToast();
  const [challenges, setChallenges] = useState<Challenge[]>([]);
  const [newChallenge, setNewChallenge] = useState('');
  const [targetDays, setTargetDays] = useState(7);
  const [isLoading, setIsLoading] = useState(true);
  const [loadingAction, setLoadingAction] = useState('');
  const [showCompletionPopup, setShowCompletionPopup] = useState(false);
  const [completedChallenge, setCompletedChallenge] = useState("");

  // Fetch user's personal challenges
  useEffect(() => {
    const fetchChallenges = async () => {
      if (!user) {
        setIsLoading(false);
        return;
      }

      try {
        setIsLoading(true);
        
        // In development mode, we're using the user's ID as a string identifier
        // In production, we would use Firebase auth.currentUser.uid
        const userId = user.id.toString();
        
        const challengesRef = collection(db, 'users', userId, 'personalChallenges');
        const snapshot = await getDocs(challengesRef);
        const list = snapshot.docs.map(doc => ({ 
          id: doc.id, 
          ...doc.data() 
        })) as Challenge[];
        
        // Sort by created date (newest first)
        list.sort((a, b) => b.createdAt.seconds - a.createdAt.seconds);
        
        setChallenges(list);
      } catch (error) {
        console.error("Error fetching challenges:", error);
        toast({
          title: "Error",
          description: "Failed to load your personal challenges",
          variant: "destructive",
        });
      } finally {
        setIsLoading(false);
      }
    };

    fetchChallenges();
  }, [user, toast]);

  // Create a new personal challenge
  const createChallenge = async () => {
    if (!newChallenge.trim() || !user) return;
    
    try {
      setLoadingAction('creating');
      
      // In development mode, we're using the user's ID as a string identifier
      const userId = user.id.toString();
      
      // Create the challenge in Firestore
      const challengesRef = collection(db, 'users', userId, 'personalChallenges');
      const newChallengeData = {
        title: newChallenge,
        targetDays: targetDays,
        progress: 0,
        createdAt: Timestamp.now(),
        completedDates: [],
      };
      
      const docRef = await addDoc(challengesRef, newChallengeData);
      
      // Add to local state
      setChallenges([
        { 
          id: docRef.id, 
          ...newChallengeData 
        }, 
        ...challenges
      ]);
      
      // Reset form
      setNewChallenge('');
      setTargetDays(7);
      
      // Show success toast
      toast({
        title: "Challenge Created!",
        description: "Your spiritual challenge has been created successfully",
        variant: "default",
      });
    } catch (error) {
      console.error("Error creating challenge:", error);
      toast({
        title: "Error",
        description: "Failed to create your challenge",
        variant: "destructive",
      });
    } finally {
      setLoadingAction('');
    }
  };

  // Delete a personal challenge
  const deleteChallenge = async (id: string) => {
    if (!user) return;
    
    try {
      setLoadingAction(`deleting-${id}`);
      
      // In development mode, we're using the user's ID as a string identifier
      const userId = user.id.toString();
      
      // Delete from Firestore
      const challengeRef = doc(db, 'users', userId, 'personalChallenges', id);
      await deleteDoc(challengeRef);
      
      // Remove from local state
      setChallenges(challenges.filter(challenge => challenge.id !== id));
      
      toast({
        title: "Challenge Deleted",
        description: "Your challenge has been deleted successfully",
        variant: "default",
      });
    } catch (error) {
      console.error("Error deleting challenge:", error);
      toast({
        title: "Error",
        description: "Failed to delete your challenge",
        variant: "destructive",
      });
    } finally {
      setLoadingAction('');
    }
  };

  // Mark today as completed for a challenge
  const markDayComplete = async (challenge: Challenge) => {
    if (!user) return;
    
    try {
      setLoadingAction(`completing-${challenge.id}`);
      
      // Get today's date in YYYY-MM-DD format
      const today = new Date().toISOString().split('T')[0];
      
      // Check if today is already marked complete
      const completedDates = challenge.completedDates || [];
      if (completedDates.includes(today)) {
        toast({
          title: "Already Completed",
          description: "You've already marked this challenge as complete today",
          variant: "default",
        });
        setLoadingAction('');
        return;
      }
      
      // Add today to completed dates
      const updatedDates = [...completedDates, today];
      
      // Calculate new progress
      const newProgress = Math.min(Math.round((updatedDates.length / challenge.targetDays) * 100), 100);
      
      // In development mode, we're using the user's ID as a string identifier
      const userId = user.id.toString();
      
      // Update Firestore document
      const challengeRef = doc(db, 'users', userId, 'personalChallenges', challenge.id);
      await updateDoc(challengeRef, {
        completedDates: updatedDates,
        progress: newProgress
      });
      
      // Update local state
      setChallenges(challenges.map(c => 
        c.id === challenge.id 
          ? { ...c, completedDates: updatedDates, progress: newProgress } 
          : c
      ));
      
      // Show success toast
      toast({
        title: "Day Completed!",
        description: `Great job! You've completed day ${updatedDates.length} of ${challenge.targetDays}`,
        variant: "default",
      });
      
      // Check if challenge is now complete
      if (updatedDates.length >= challenge.targetDays) {
        // Show celebration popup instead of toast notifications
        setCompletedChallenge(challenge.title);
        setShowCompletionPopup(true);
        
        // Award XP bonus (backend API call would go here)
        // Log achievement to user's activity history (backend API call would go here)
        
        // For development, we'll keep these toast notifications for debugging
        // In production, we would just show the celebration popup
        toast({
          title: "Challenge Completed! 🎉",
          description: "Amazing! You've successfully completed this spiritual challenge",
          variant: "default",
        });
      }
    } catch (error) {
      console.error("Error marking day complete:", error);
      toast({
        title: "Error",
        description: "Failed to mark day as complete",
        variant: "destructive",
      });
    } finally {
      setLoadingAction('');
    }
  };

  // Check if challenge day is completed today
  const isCompletedToday = (challenge: Challenge): boolean => {
    const today = new Date().toISOString().split('T')[0];
    return (challenge.completedDates || []).includes(today);
  };

  return (
    <Container className="py-8">
      {/* Celebration Popup */}
      <ChallengeCompletionPopup 
        show={showCompletionPopup}
        onClose={() => setShowCompletionPopup(false)}
        challengeTitle={completedChallenge}
      />
      
      <div className="flex flex-col md:flex-row items-start md:items-center justify-between mb-6">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">🚀 Personal Challenge Creator</h1>
          <p className="text-gray-500 dark:text-gray-400 mt-2">
            Create custom spiritual challenges to elevate your practice and earn rewards.
          </p>
        </div>
        <div className="mt-4 md:mt-0 bg-indigo-50 dark:bg-indigo-900/30 rounded-lg p-3">
          <div className="flex items-center gap-2">
            <Calendar className="h-5 w-5 text-indigo-600 dark:text-indigo-400" />
            <p className="font-medium text-indigo-700 dark:text-indigo-300">
              {new Date().toLocaleDateString('en-US', { 
                weekday: 'long', 
                year: 'numeric', 
                month: 'long', 
                day: 'numeric' 
              })}
            </p>
          </div>
        </div>
      </div>

      {/* Create Challenge Form */}
      <Card className="mb-8 border-indigo-100 dark:border-indigo-800/30 shadow-sm">
        <CardHeader>
          <CardTitle>Create New Challenge</CardTitle>
          <CardDescription>
            Set a custom spiritual challenge like meditation, gratitude or yoga practice
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid gap-4">
            <div className="grid gap-2">
              <Label htmlFor="challenge-title">Challenge Title</Label>
              <Input
                id="challenge-title"
                placeholder="Example: 21 Days Meditation Challenge"
                value={newChallenge}
                onChange={(e) => setNewChallenge(e.target.value)}
              />
            </div>
            <div className="grid gap-2">
              <Label htmlFor="target-days">Target Days</Label>
              <div className="flex gap-2 items-center">
                <Input
                  id="target-days"
                  type="number"
                  min="1"
                  max="90"
                  value={targetDays}
                  onChange={(e) => setTargetDays(parseInt(e.target.value))}
                />
                <span className="text-sm text-gray-500 dark:text-gray-400">days</span>
              </div>
              <p className="text-sm text-gray-500 dark:text-gray-400 mt-1">
                Recommended: 7 days (beginner), 21 days (intermediate), 30+ days (advanced)
              </p>
            </div>
          </div>
        </CardContent>
        <CardFooter>
          <Button 
            onClick={createChallenge} 
            disabled={!newChallenge.trim() || loadingAction === 'creating'}
            className="w-full md:w-auto"
          >
            {loadingAction === 'creating' ? (
              <>
                <div className="mr-2 h-4 w-4 animate-spin rounded-full border-2 border-current border-t-transparent" />
                Creating...
              </>
            ) : (
              <>
                <PlusCircle className="mr-2 h-4 w-4" />
                Create Challenge
              </>
            )}
          </Button>
        </CardFooter>
      </Card>

      {/* Challenges List */}
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <h2 className="text-xl font-semibold flex items-center gap-2">
            <Target className="h-5 w-5 text-indigo-500" />
            Your Active Challenges
          </h2>
          
          <div className="text-sm text-gray-500">
            {challenges.length} {challenges.length === 1 ? 'challenge' : 'challenges'}
          </div>
        </div>

        {isLoading ? (
          <div className="flex items-center justify-center py-10">
            <div className="h-8 w-8 animate-spin rounded-full border-2 border-indigo-600 border-t-transparent" />
          </div>
        ) : challenges.length === 0 ? (
          <Card className="bg-gray-50 dark:bg-gray-800/50 border-dashed">
            <CardContent className="flex flex-col items-center justify-center py-10">
              <div className="rounded-full bg-gray-100 dark:bg-gray-700 p-3 mb-4">
                <Target className="h-8 w-8 text-gray-400" />
              </div>
              <p className="text-lg font-medium text-gray-600 dark:text-gray-300">No active challenges</p>
              <p className="text-sm text-gray-500 dark:text-gray-400 mt-1">
                Create your first personal challenge to start tracking your progress
              </p>
            </CardContent>
          </Card>
        ) : (
          challenges.map((challenge) => {
            const isCompletedForToday = isCompletedToday(challenge);
            const challengeComplete = challenge.progress >= 100;
            return (
              <Card 
                key={challenge.id} 
                className={`overflow-hidden transition-all duration-200 ${
                  challengeComplete 
                    ? 'border-amber-200 dark:border-amber-800/30 bg-amber-50/50 dark:bg-amber-900/10' 
                    : isCompletedForToday
                      ? 'border-green-200 dark:border-green-800/30 bg-green-50/50 dark:bg-green-900/10'
                      : 'hover:border-indigo-200 dark:hover:border-indigo-800/30'
                }`}
              >
                <CardHeader className="pb-3">
                  <div className="flex justify-between items-start">
                    <div className="flex items-start gap-3">
                      <div className={`p-2 rounded-full ${
                        challengeComplete 
                          ? 'bg-amber-100 dark:bg-amber-900/30 text-amber-600 dark:text-amber-400' 
                          : isCompletedForToday
                            ? 'bg-green-100 dark:bg-green-900/30 text-green-600 dark:text-green-400'
                            : 'bg-indigo-100 dark:bg-indigo-900/30 text-indigo-600 dark:text-indigo-400'
                      }`}>
                        {challengeComplete ? (
                          <Trophy className="h-5 w-5" />
                        ) : isCompletedForToday ? (
                          <CheckCircle className="h-5 w-5" />
                        ) : (
                          <CalendarDays className="h-5 w-5" />
                        )}
                      </div>
                      <div>
                        <CardTitle className="text-lg">{challenge.title}</CardTitle>
                        <CardDescription>
                          {challenge.completedDates?.length || 0} of {challenge.targetDays} days completed
                        </CardDescription>
                      </div>
                    </div>
                    
                    <div className="flex gap-2">
                      <Button
                        variant="ghost"
                        size="icon"
                        className="text-red-500 hover:text-red-700 hover:bg-red-50 dark:hover:bg-red-900/20"
                        onClick={() => deleteChallenge(challenge.id)}
                        disabled={loadingAction === `deleting-${challenge.id}`}
                      >
                        {loadingAction === `deleting-${challenge.id}` ? (
                          <div className="h-4 w-4 animate-spin rounded-full border-2 border-current border-t-transparent" />
                        ) : (
                          <Trash2 className="h-4 w-4" />
                        )}
                      </Button>
                    </div>
                  </div>
                </CardHeader>
                
                <CardContent className="pb-3">
                  <div className="space-y-4">
                    <div className="space-y-2">
                      <div className="flex justify-between text-sm">
                        <span>Progress</span>
                        <span className="font-medium">{challenge.progress}%</span>
                      </div>
                      <Progress value={challenge.progress} className="h-2" />
                    </div>
                    
                    <div className="flex items-center justify-between text-sm">
                      <div className="flex items-center gap-1 text-gray-600 dark:text-gray-400">
                        <CalendarDays className="h-4 w-4" />
                        <span>Started {challenge.createdAt.toDate().toLocaleDateString()}</span>
                      </div>
                      
                      {challenge.progress >= 100 && (
                        <div className="flex items-center gap-1 text-amber-600 dark:text-amber-400">
                          <Trophy className="h-4 w-4" />
                          <span>Challenge Completed!</span>
                        </div>
                      )}
                    </div>
                  </div>
                </CardContent>
                
                <CardFooter className="border-t border-gray-100 dark:border-gray-800 pt-3 flex justify-between items-center">
                  <div className="flex items-center gap-1 text-amber-600 dark:text-amber-400">
                    <Award className="h-4 w-4" />
                    <span className="text-sm font-medium">
                      {challenge.targetDays >= 30 ? '+300 XP' : 
                       challenge.targetDays >= 21 ? '+200 XP' : '+100 XP'} reward
                    </span>
                  </div>
                  
                  <Button 
                    variant={isCompletedForToday ? "success" : "default"}
                    size="sm"
                    disabled={isCompletedForToday || challengeComplete || loadingAction === `completing-${challenge.id}`}
                    onClick={() => markDayComplete(challenge)}
                  >
                    {isCompletedForToday ? (
                      <>
                        <CheckCircle className="mr-1 h-4 w-4" />
                        Completed Today
                      </>
                    ) : challengeComplete ? (
                      <>
                        <Trophy className="mr-1 h-4 w-4" />
                        Challenge Complete
                      </>
                    ) : loadingAction === `completing-${challenge.id}` ? (
                      <>
                        <div className="mr-1 h-4 w-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
                        Marking Complete...
                      </>
                    ) : (
                      <>
                        <ArrowUpCircle className="mr-1 h-4 w-4" />
                        Mark Today Complete
                      </>
                    )}
                  </Button>
                </CardFooter>
              </Card>
            );
          })
        )}
      </div>

      {/* Benefits Section */}
      <div className="mt-10">
        <Separator className="my-6" />
        <div className="flex items-center gap-2 mb-4">
          <Star className="h-5 w-5 text-amber-500" />
          <h2 className="text-xl font-semibold">Benefits of Personal Challenges</h2>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <Card className="bg-gradient-to-br from-amber-50 to-amber-100 dark:from-amber-900/20 dark:to-amber-800/10 border-amber-200 dark:border-amber-800/30">
            <CardHeader className="pb-2">
              <CardTitle className="text-lg text-amber-700 dark:text-amber-400">Consistency Building</CardTitle>
            </CardHeader>
            <CardContent className="pt-0">
              <p className="text-sm text-amber-600 dark:text-amber-300">
                Creating personal challenges helps build consistency in your spiritual practices
              </p>
            </CardContent>
          </Card>
          
          <Card className="bg-gradient-to-br from-indigo-50 to-indigo-100 dark:from-indigo-900/20 dark:to-indigo-800/10 border-indigo-200 dark:border-indigo-800/30">
            <CardHeader className="pb-2">
              <CardTitle className="text-lg text-indigo-700 dark:text-indigo-400">XP Rewards</CardTitle>
            </CardHeader>
            <CardContent className="pt-0">
              <p className="text-sm text-indigo-600 dark:text-indigo-300">
                Complete challenges to earn XP and unlock special spiritual badges
              </p>
            </CardContent>
          </Card>
          
          <Card className="bg-gradient-to-br from-purple-50 to-purple-100 dark:from-purple-900/20 dark:to-purple-800/10 border-purple-200 dark:border-purple-800/30">
            <CardHeader className="pb-2">
              <CardTitle className="text-lg text-purple-700 dark:text-purple-400">Personal Growth</CardTitle>
            </CardHeader>
            <CardContent className="pt-0">
              <p className="text-sm text-purple-600 dark:text-purple-300">
                Challenge yourself to grow spiritually and track your progress over time
              </p>
            </CardContent>
          </Card>
        </div>
      </div>
    </Container>
  );
};

export default PersonalChallengePage;