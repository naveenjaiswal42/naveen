import { useState } from "react";
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Label } from "@/components/ui/label";
import { useToast } from "@/hooks/use-toast";
import { BookOpen, Phone, Lock, User, LogIn } from "lucide-react";

export default function AuthPage() {
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const user = null; // In a real app, this would come from auth context
  const [isLoggingIn, setIsLoggingIn] = useState(false);
  
  // Login form states
  const [phone, setPhone] = useState("");
  const [otp, setOtp] = useState("");
  const [showOtpField, setShowOtpField] = useState(false);
  
  // Registration form states
  const [regName, setRegName] = useState("");
  const [regPhone, setRegPhone] = useState("");
  
  // If already logged in, redirect to dashboard
  if (user) {
    setLocation("/dashboard");
    return null;
  }
  
  // Request OTP (simulated)
  const requestOtp = () => {
    if (!phone || phone.length < 10) {
      toast({
        title: "Invalid Phone Number",
        description: "Please enter a valid phone number",
        variant: "destructive",
      });
      return;
    }
    
    // Simulate OTP being sent
    toast({
      title: "OTP Sent",
      description: "A 6-digit OTP has been sent to your phone",
    });
    
    setShowOtpField(true);
  };
  
  // Login with OTP (simulated)
  const handleLoginWithOtp = async () => {
    if (!otp || otp.length < 4) {
      toast({
        title: "Invalid OTP",
        description: "Please enter the 6-digit OTP sent to your phone",
        variant: "destructive",
      });
      return;
    }
    
    setIsLoggingIn(true);
    
    try {
      // In a real app, this would make an API call
      // For demo, simulate success
      setTimeout(() => {
        toast({
          title: "Login Successful",
          description: "Welcome to Trikala Academy!",
        });
        setLocation("/dashboard");
      }, 1500);
    } catch (error) {
      toast({
        title: "Login Failed",
        description: "Please check your credentials and try again",
        variant: "destructive",
      });
    } finally {
      setIsLoggingIn(false);
    }
  };
  
  // Registration with phone (simulated)
  const handleRegister = async () => {
    if (!regName || regName.length < 2) {
      toast({
        title: "Invalid Name",
        description: "Please enter your full name",
        variant: "destructive",
      });
      return;
    }
    
    if (!regPhone || regPhone.length < 10) {
      toast({
        title: "Invalid Phone Number",
        description: "Please enter a valid phone number",
        variant: "destructive",
      });
      return;
    }
    
    setIsLoggingIn(true);
    
    try {
      // In a real app, this would make an API call
      // For demo, simulate success
      setTimeout(() => {
        toast({
          title: "Registration Successful", 
          description: "Your account has been created. Welcome to Trikala Academy!",
        });
        setLocation("/dashboard");
      }, 1500);
    } catch (error) {
      toast({
        title: "Registration Failed",
        description: "There was an error creating your account. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsLoggingIn(false);
    }
  };
  
  // Demo Account Login
  const handleDemoLogin = () => {
    setIsLoggingIn(true);
    
    try {
      // Simulate login delay
      setTimeout(() => {
        toast({
          title: "Demo Login Successful",
          description: "You are now logged in as a demo user",
        });
        setLocation("/dashboard");
      }, 1000);
    } catch (error) {
      toast({
        title: "Login Failed",
        description: "Failed to log in with demo account",
        variant: "destructive",
      });
    } finally {
      setIsLoggingIn(false);
    }
  };
  
  return (
    <div className="min-h-screen flex flex-col md:flex-row items-stretch">
      {/* Hero Section */}
      <div className="bg-gradient-to-br from-primary/90 to-primary-foreground/90 text-white p-8 md:w-1/2 flex flex-col justify-center items-center">
        <div className="max-w-md mx-auto text-center">
          <div className="mb-4 text-center">
            <div className="h-20 w-20 mx-auto bg-white/10 rounded-full flex items-center justify-center mb-4">
              <BookOpen className="h-10 w-10" />
            </div>
            <h1 className="text-3xl font-bold mb-2">Trikala Academy</h1>
            <p className="text-xl font-light">Spiritual Growth Platform</p>
          </div>
          
          <div className="space-y-6 mt-8">
            <div className="bg-white/10 p-4 rounded-lg">
              <h3 className="font-medium mb-2">Transform Your Spiritual Journey</h3>
              <p className="text-sm opacity-90">Access guided meditations, chakra healing, and spiritual courses designed to elevate your consciousness.</p>
            </div>
            
            <div className="bg-white/10 p-4 rounded-lg">
              <h3 className="font-medium mb-2">Track Your Progress</h3>
              <p className="text-sm opacity-90">Monitor your spiritual growth with XP rewards, badges, and personalized insights.</p>
            </div>
            
            <div className="bg-white/10 p-4 rounded-lg">
              <h3 className="font-medium mb-2">Join Our Community</h3>
              <p className="text-sm opacity-90">Connect with like-minded individuals on their own spiritual paths.</p>
            </div>
          </div>
        </div>
      </div>
      
      {/* Auth Forms */}
      <div className="p-8 md:w-1/2 flex items-center justify-center bg-background">
        <Card className="w-full max-w-md">
          <CardHeader>
            <CardTitle className="text-2xl font-bold text-center">Welcome</CardTitle>
            <CardDescription className="text-center">Sign in to your account or create a new one</CardDescription>
          </CardHeader>
          
          <Tabs defaultValue="login" className="w-full">
            <TabsList className="grid w-full grid-cols-2 mb-4">
              <TabsTrigger value="login">Login</TabsTrigger>
              <TabsTrigger value="register">Register</TabsTrigger>
            </TabsList>
            
            <TabsContent value="login">
              <CardContent className="space-y-4">
                {!showOtpField ? (
                  <div className="space-y-2">
                    <Label htmlFor="phone">Phone Number</Label>
                    <div className="flex gap-2">
                      <Input
                        id="phone"
                        type="tel"
                        placeholder="Enter your phone number"
                        value={phone}
                        onChange={(e) => setPhone(e.target.value)}
                      />
                      <Button 
                        onClick={requestOtp} 
                        type="button"
                        size="sm"
                        disabled={isLoggingIn}
                      >
                        Send OTP
                      </Button>
                    </div>
                  </div>
                ) : (
                  <div className="space-y-2">
                    <Label htmlFor="otp">Enter OTP</Label>
                    <Input
                      id="otp"
                      type="text"
                      placeholder="6-digit OTP"
                      value={otp}
                      onChange={(e) => setOtp(e.target.value)}
                    />
                    <div className="text-sm text-right">
                      <button 
                        type="button" 
                        className="text-primary hover:underline"
                        onClick={() => requestOtp()}
                      >
                        Resend OTP
                      </button>
                    </div>
                  </div>
                )}
              </CardContent>
              
              <CardFooter className="flex flex-col gap-4">
                <Button 
                  className="w-full" 
                  onClick={showOtpField ? handleLoginWithOtp : requestOtp}
                  disabled={isLoggingIn}
                >
                  {isLoggingIn ? (
                    "Logging in..."
                  ) : showOtpField ? (
                    "Verify & Login"
                  ) : (
                    "Continue with Phone"
                  )}
                </Button>
                
                <div className="relative w-full">
                  <div className="absolute inset-0 flex items-center">
                    <div className="w-full border-t border-gray-200 dark:border-gray-700"></div>
                  </div>
                  <div className="relative flex justify-center text-xs">
                    <span className="bg-background px-2 text-muted-foreground">
                      or
                    </span>
                  </div>
                </div>
                
                <Button 
                  variant="outline" 
                  className="w-full"
                  onClick={handleDemoLogin}
                  disabled={isLoggingIn}
                >
                  <LogIn className="mr-2 h-4 w-4" />
                  Login with Demo Account
                </Button>
              </CardFooter>
            </TabsContent>
            
            <TabsContent value="register">
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="name">Full Name</Label>
                  <div className="flex">
                    <Input
                      id="name"
                      type="text"
                      placeholder="Enter your name"
                      value={regName}
                      onChange={(e) => setRegName(e.target.value)}
                    />
                  </div>
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="reg-phone">Phone Number</Label>
                  <div className="flex">
                    <Input
                      id="reg-phone"
                      type="tel"
                      placeholder="Enter your phone number"
                      value={regPhone}
                      onChange={(e) => setRegPhone(e.target.value)}
                    />
                  </div>
                </div>
              </CardContent>
              
              <CardFooter className="flex flex-col gap-4">
                <Button 
                  className="w-full" 
                  onClick={handleRegister}
                  disabled={isLoggingIn}
                >
                  {isLoggingIn ? "Creating Account..." : "Create Account"}
                </Button>
                
                <div className="relative w-full">
                  <div className="absolute inset-0 flex items-center">
                    <div className="w-full border-t border-gray-200 dark:border-gray-700"></div>
                  </div>
                  <div className="relative flex justify-center text-xs">
                    <span className="bg-background px-2 text-muted-foreground">
                      or
                    </span>
                  </div>
                </div>
                
                <Button 
                  variant="outline" 
                  className="w-full"
                  onClick={handleDemoLogin}
                  disabled={isLoggingIn}
                >
                  <LogIn className="mr-2 h-4 w-4" />
                  Continue with Demo Account
                </Button>
              </CardFooter>
            </TabsContent>
          </Tabs>
        </Card>
      </div>
    </div>
  );
}