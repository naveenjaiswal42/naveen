import { useState } from "react";
import CertificateDownload from "@/components/courses/CertificateDownload";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Award } from "lucide-react";

export default function CertificateDemoPage() {
  const [userName, setUserName] = useState("Dev User");
  const [courseTitle, setCourseTitle] = useState("Chakra Healing");
  const [completionDate, setCompletionDate] = useState(new Date().toLocaleDateString());
  
  return (
    <div className="container mx-auto py-8 px-4 max-w-5xl">
      <Card className="mb-8">
        <CardHeader>
          <div className="flex items-center gap-2">
            <Award className="h-6 w-6 text-primary" />
            <CardTitle>Certificate Demo</CardTitle>
          </div>
          <CardDescription>
            Test the certificate generation and download functionality
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 gap-4 md:grid-cols-3">
            <div>
              <Label htmlFor="userName">Your Name</Label>
              <Input
                id="userName"
                value={userName}
                onChange={(e) => setUserName(e.target.value)}
                className="mb-4"
              />
            </div>
            <div>
              <Label htmlFor="courseTitle">Course Title</Label>
              <Input
                id="courseTitle"
                value={courseTitle}
                onChange={(e) => setCourseTitle(e.target.value)}
                className="mb-4"
              />
            </div>
            <div>
              <Label htmlFor="completionDate">Completion Date</Label>
              <Input
                id="completionDate"
                value={completionDate}
                onChange={(e) => setCompletionDate(e.target.value)}
                className="mb-4"
              />
            </div>
          </div>
        </CardContent>
      </Card>
      
      <div className="max-w-4xl mx-auto">
        <CertificateDownload 
          courseTitle={courseTitle}
          userName={userName}
          completionDate={completionDate}
        />
      </div>
    </div>
  );
}