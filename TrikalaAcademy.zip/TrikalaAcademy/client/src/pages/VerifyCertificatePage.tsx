import { useState, useEffect, useCallback } from "react";
import { useLocation } from "wouter";
import { Check, Search, AlertTriangle } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Separator } from "@/components/ui/separator";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import logoPath from "@assets/logo.png";

// This would come from API in production
interface Certificate {
  id: string;
  studentName: string;
  courseName: string;
  issueDate: string;
  status: "verified" | "invalid" | "expired";
}

export default function VerifyCertificatePage() {
  const [location] = useLocation();
  const [certificateId, setCertificateId] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [certificate, setCertificate] = useState<Certificate | null>(null);
  const [error, setError] = useState<string | null>(null);

  // Parse query params from URL if any
  const searchParams = new URLSearchParams(location.split("?")[1] || "");
  const urlCertId = searchParams.get("cert");
  const userId = searchParams.get("u");
  const courseId = searchParams.get("c");

  // This would be replaced with an actual API call in production
  const handleVerify = useCallback(async (certId: string) => {
    setIsLoading(true);
    setError(null);
    
    try {
      // Simulate API call
      await new Promise(resolve => setTimeout(resolve, 1500));
      
      // Dummy data - in production, this would come from the database
      if (certId.startsWith("CERT-")) {
        setCertificate({
          id: certId,
          studentName: "Dev User",
          courseName: "Yoga for Beginners",
          issueDate: new Date().toLocaleDateString(),
          status: "verified"
        });
      } else {
        setError("Certificate not found. Please check the ID and try again.");
      }
    } catch (err) {
      setError("An error occurred while verifying the certificate. Please try again later.");
    } finally {
      setIsLoading(false);
    }
  }, []);

  // Auto-verify if certificate ID is in URL
  useEffect(() => {
    if (urlCertId) {
      setCertificateId(urlCertId);
      handleVerify(urlCertId);
    }
  }, [urlCertId, handleVerify]);

  return (
    <div className="container max-w-4xl mx-auto py-10 px-4">
      <div className="flex flex-col items-center mb-8">
        <div className="flex items-center gap-3 mb-4">
          <img src={logoPath} alt="Trikala Academy Logo" className="w-12 h-12" />
          <h1 className="text-3xl font-bold text-indigo-800">Certificate Verification</h1>
        </div>
        <p className="text-gray-600 text-center max-w-2xl">
          Verify the authenticity of certificates issued by Trikala Academy. 
          Enter the certificate ID or scan the QR code from the certificate.
        </p>
      </div>

      <Tabs defaultValue="id" className="w-full">
        <TabsList className="grid w-full grid-cols-2 mb-8">
          <TabsTrigger value="id">Verify by ID</TabsTrigger>
          <TabsTrigger value="qr">Scan QR Code</TabsTrigger>
        </TabsList>
        
        <TabsContent value="id">
          <Card>
            <CardHeader>
              <CardTitle>Enter Certificate ID</CardTitle>
              <CardDescription>
                Enter the certificate ID found on the top right corner of the certificate.
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="flex gap-2">
                <Input 
                  placeholder="e.g. CERT-20250428-X7A2"
                  value={certificateId}
                  onChange={(e) => setCertificateId(e.target.value)}
                  className="flex-1"
                />
                <Button 
                  onClick={() => handleVerify(certificateId)}
                  disabled={isLoading || !certificateId}
                >
                  {isLoading ? "Verifying..." : "Verify"}
                </Button>
              </div>

              {error && (
                <Alert variant="destructive" className="mt-4">
                  <AlertTriangle className="h-4 w-4" />
                  <AlertTitle>Error</AlertTitle>
                  <AlertDescription>{error}</AlertDescription>
                </Alert>
              )}
            </CardContent>
          </Card>
        </TabsContent>
        
        <TabsContent value="qr">
          <Card>
            <CardHeader>
              <CardTitle>Scan QR Code</CardTitle>
              <CardDescription>
                Use your device's camera to scan the QR code on the certificate.
              </CardDescription>
            </CardHeader>
            <CardContent className="flex flex-col items-center">
              <div className="bg-gray-100 rounded-lg p-8 w-full flex flex-col items-center">
                <div className="bg-white p-4 rounded-lg shadow-inner border border-gray-200 mb-4">
                  <Search className="h-20 w-20 text-gray-400" />
                </div>
                <p className="text-sm text-gray-500 text-center">
                  Position the QR code within the frame to scan. 
                  <br />
                  <span className="text-xs mt-1 block">
                    Note: Camera access is required for this feature.
                  </span>
                </p>
              </div>
              <Button variant="outline" className="mt-4">
                Enable Camera
              </Button>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {certificate && (
        <div className="mt-8 animate-in fade-in slide-in-from-bottom-4 duration-500">
          <h2 className="text-xl font-semibold mb-4 flex items-center gap-2">
            <Check className="h-5 w-5 text-green-500" />
            Verification Result
          </h2>
          
          <Card className="bg-gradient-to-r from-indigo-50 to-purple-50 border-indigo-200">
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle>Certificate Information</CardTitle>
                <div className="px-3 py-1 bg-green-100 text-green-800 text-sm font-medium rounded-full">
                  ✓ Verified
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <div className="grid gap-4">
                <div>
                  <h3 className="text-sm font-medium text-gray-500">Certificate ID</h3>
                  <p className="text-base font-medium">{certificate.id}</p>
                </div>
                <Separator />
                <div>
                  <h3 className="text-sm font-medium text-gray-500">Student Name</h3>
                  <p className="text-base font-medium">{certificate.studentName}</p>
                </div>
                <Separator />
                <div>
                  <h3 className="text-sm font-medium text-gray-500">Course</h3>
                  <p className="text-base font-medium">{certificate.courseName}</p>
                </div>
                <Separator />
                <div>
                  <h3 className="text-sm font-medium text-gray-500">Issue Date</h3>
                  <p className="text-base font-medium">{certificate.issueDate}</p>
                </div>
              </div>
            </CardContent>
            <CardFooter className="bg-indigo-50/50 flex justify-between items-center">
              <div className="text-sm text-indigo-700">
                <span className="font-medium">Trikala Academy</span> • Official Certificate
              </div>
              <img src={logoPath} alt="Trikala Academy Logo" className="w-8 h-8" />
            </CardFooter>
          </Card>
        </div>
      )}
    </div>
  );
}