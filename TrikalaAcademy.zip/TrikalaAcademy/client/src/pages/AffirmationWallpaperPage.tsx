import React, { useState } from "react";
import { useToast } from "@/hooks/use-toast";
import { 
  Card, 
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { 
  Select, 
  SelectContent, 
  SelectItem, 
  SelectTrigger, 
  SelectValue 
} from "@/components/ui/select";
import { Label } from "@/components/ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Download, RefreshCw, Sparkles } from "lucide-react";

// Background color options for wallpapers
const backgroundColors = [
  { value: "#e0e7ff", label: "Light Indigo" },
  { value: "#ede9fe", label: "Light Purple" },
  { value: "#fae8ff", label: "Light Pink" },
  { value: "#f5f5f4", label: "Light Gray" },
  { value: "#ecfccb", label: "Light Green" },
  { value: "#cffafe", label: "Light Blue" },
];

// Text color options for wallpapers
const textColors = [
  { value: "#4f46e5", label: "Indigo" },
  { value: "#7c3aed", label: "Purple" },
  { value: "#db2777", label: "Pink" },
  { value: "#0f172a", label: "Dark Gray" },
  { value: "#166534", label: "Green" },
  { value: "#0369a1", label: "Blue" },
];

// Font options for wallpapers
const fontOptions = [
  { value: "serif", label: "Serif" },
  { value: "sans-serif", label: "Sans-serif" },
  { value: "monospace", label: "Monospace" },
  { value: "cursive", label: "Cursive" },
  { value: "fantasy", label: "Fantasy" },
];

const wallpaperSizes = [
  { value: "phone", label: "Phone (1080x1920)", width: 1080, height: 1920 },
  { value: "desktop", label: "Desktop (1920x1080)", width: 1920, height: 1080 },
  { value: "square", label: "Square (1080x1080)", width: 1080, height: 1080 },
];

// Sample affirmations
const sampleAffirmations = [
  "I am a being of light, connected to the universal consciousness.",
  "My spiritual journey unfolds perfectly in divine timing.",
  "I release what no longer serves my highest good.",
  "I am aligned with my soul's purpose and highest wisdom.",
  "Divine energy flows through me, guiding my actions.",
  "My awareness expands with each breath I take.",
  "I am worthy of enlightenment and spiritual growth.",
  "I surrender to the divine plan unfolding in my life.",
  "My inner wisdom guides me to my highest potential.",
  "I am one with the universe and all living beings."
];

const AffirmationWallpaperPage: React.FC = () => {
  const { toast } = useToast();
  const [customAffirmation, setCustomAffirmation] = useState("");
  const [affirmation, setAffirmation] = useState("");
  const [bgColor, setBgColor] = useState(backgroundColors[0].value);
  const [textColor, setTextColor] = useState(textColors[0].value);
  const [fontFamily, setFontFamily] = useState(fontOptions[0].value);
  const [wallpaperSize, setWallpaperSize] = useState(wallpaperSizes[0].value);
  const [activeTab, setActiveTab] = useState("ai");
  const [isGenerating, setIsGenerating] = useState(false);

  // Simple function to generate a random affirmation
  const handleGenerateAffirmation = () => {
    setIsGenerating(true);
    
    // Simulate API call with timeout
    setTimeout(() => {
      const randomIndex = Math.floor(Math.random() * sampleAffirmations.length);
      setAffirmation(sampleAffirmations[randomIndex]);
      
      toast({
        title: "Affirmation Generated",
        description: "Your daily affirmation is ready to download.",
      });
      
      setIsGenerating(false);
    }, 800);
  };

  const handleUseCustomAffirmation = () => {
    if (!customAffirmation.trim()) {
      toast({
        title: "Please enter an affirmation",
        description: "You need to type an affirmation before proceeding.",
        variant: "destructive",
      });
      return;
    }
    setAffirmation(customAffirmation);
  };

  const downloadWallpaper = () => {
    const selectedSize = wallpaperSizes.find(size => size.value === wallpaperSize);
    if (!selectedSize) return;

    const canvas = document.createElement("canvas");
    canvas.width = selectedSize.width;
    canvas.height = selectedSize.height;
    const ctx = canvas.getContext("2d");
    
    if (!ctx) return;

    // Draw background
    ctx.fillStyle = bgColor;
    ctx.fillRect(0, 0, canvas.width, canvas.height);

    // Draw text
    ctx.fillStyle = textColor;
    ctx.font = `bold ${Math.min(selectedSize.width, selectedSize.height) / 20}px ${fontFamily}`;
    ctx.textAlign = "center";
    ctx.textBaseline = "middle";
    
    // Handle text wrapping by splitting into multiple lines
    const maxWidth = canvas.width * 0.8;
    const words = affirmation.split(' ');
    const lines = [];
    let currentLine = '';
    
    words.forEach(word => {
      const testLine = currentLine ? `${currentLine} ${word}` : word;
      const metrics = ctx.measureText(testLine);
      
      if (metrics.width > maxWidth && currentLine !== '') {
        lines.push(currentLine);
        currentLine = word;
      } else {
        currentLine = testLine;
      }
    });
    
    if (currentLine) {
      lines.push(currentLine);
    }
    
    // Calculate vertical position for text
    const lineHeight = Math.min(selectedSize.width, selectedSize.height) / 16;
    const textHeight = lines.length * lineHeight;
    let textY = (canvas.height - textHeight) / 2;
    
    // Draw each line of text
    lines.forEach(line => {
      ctx.fillText(line, canvas.width / 2, textY);
      textY += lineHeight;
    });
    
    // Draw small logo or attribution
    ctx.font = `${Math.min(selectedSize.width, selectedSize.height) / 60}px ${fontFamily}`;
    ctx.fillText("Trikala Academy", canvas.width / 2, canvas.height - 40);

    // Download the image
    const link = document.createElement("a");
    link.download = "spiritual-affirmation-wallpaper.png";
    link.href = canvas.toDataURL("image/png");
    link.click();

    toast({
      title: "Wallpaper Downloaded!",
      description: "You've earned 15 XP for downloading your spiritual affirmation.",
    });
  };

  const renderPreview = () => {
    if (!affirmation) return null;
    
    const selectedSize = wallpaperSizes.find(size => size.value === wallpaperSize);
    if (!selectedSize) return null;
    
    // Calculate aspect ratio for preview
    const aspectRatio = selectedSize.width / selectedSize.height;
    let previewStyle = {};
    
    if (aspectRatio > 1) {
      // Landscape
      previewStyle = {
        width: '100%',
        maxWidth: '400px',
        height: `${(400 / aspectRatio)}px`
      };
    } else {
      // Portrait or square
      previewStyle = {
        width: `${(400 * aspectRatio)}px`,
        maxWidth: '400px',
        height: '400px'
      };
    }
    
    return (
      <div className="mt-6 flex flex-col items-center">
        <h3 className="text-xl font-semibold mb-3">Preview</h3>
        <div 
          style={{
            ...previewStyle,
            backgroundColor: bgColor,
            color: textColor,
            fontFamily: fontFamily,
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            padding: '20px',
            textAlign: 'center',
            borderRadius: '8px',
            boxShadow: '0 4px 6px rgba(0, 0, 0, 0.1)',
            position: 'relative',
            overflow: 'hidden'
          }}
        >
          <div className="p-4">
            <p className="font-bold" style={{ fontSize: '1.25rem' }}>{affirmation}</p>
            <p style={{ fontSize: '0.6rem', position: 'absolute', bottom: '10px', left: 0, right: 0, textAlign: 'center' }}>
              Trikala Academy
            </p>
          </div>
        </div>
      </div>
    );
  };

  return (
    <div className="container py-10 max-w-4xl mx-auto">
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between mb-6">
        <div>
          <h1 className="text-3xl font-bold text-primary">Affirmation Wallpaper Generator</h1>
          <p className="text-muted-foreground">
            Create beautiful wallpapers with spiritual affirmations to inspire your daily practice
          </p>
        </div>
      </div>

      <div className="grid grid-cols-1 gap-6">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center">
              <Sparkles className="mr-2 h-5 w-5" />
              Create Your Affirmation
            </CardTitle>
            <CardDescription>
              Choose between AI-generated spiritual affirmations or write your own
            </CardDescription>
          </CardHeader>
          <CardContent>
            <Tabs defaultValue="ai" value={activeTab} onValueChange={setActiveTab} className="w-full">
              <TabsList className="grid w-full grid-cols-2 mb-6">
                <TabsTrigger value="ai">
                  AI-Generated
                </TabsTrigger>
                <TabsTrigger value="custom">
                  Write Your Own
                </TabsTrigger>
              </TabsList>

              <TabsContent value="ai" className="space-y-4">
                <div className="flex flex-col space-y-4">
                  <Button
                    onClick={handleGenerateAffirmation}
                    disabled={isGenerating}
                    className="w-full sm:w-auto"
                  >
                    {isGenerating ? (
                      <>
                        <svg className="animate-spin mr-2 h-4 w-4" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                          <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                          <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                        </svg>
                        Generating...
                      </>
                    ) : (
                      <>
                        <RefreshCw className="mr-2 h-4 w-4" />
                        Generate Spiritual Affirmation
                      </>
                    )}
                  </Button>
                  
                  {affirmation && activeTab === "ai" && (
                    <div className="p-4 bg-secondary/20 rounded-lg border border-secondary">
                      <p className="text-xl font-medium text-center">{affirmation}</p>
                    </div>
                  )}
                </div>
              </TabsContent>
              
              <TabsContent value="custom" className="space-y-4">
                <div className="grid gap-4">
                  <div className="grid grid-cols-1 gap-2">
                    <Label htmlFor="custom-affirmation">Your Affirmation</Label>
                    <Textarea
                      id="custom-affirmation"
                      placeholder="I am connected to the universal wisdom that guides my spiritual journey..."
                      value={customAffirmation}
                      onChange={(e) => setCustomAffirmation(e.target.value)}
                      rows={3}
                    />
                  </div>
                  <Button 
                    onClick={handleUseCustomAffirmation}
                    disabled={!customAffirmation.trim()}
                    className="w-full sm:w-auto"
                  >
                    Use This Affirmation
                  </Button>
                </div>
              </TabsContent>
            </Tabs>
          </CardContent>
        </Card>

        {affirmation && (
          <Card>
            <CardHeader>
              <CardTitle>Customize Your Wallpaper</CardTitle>
              <CardDescription>
                Adjust the colors, font, and size to create your perfect wallpaper
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4 mb-6">
                <div className="space-y-2">
                  <Label htmlFor="bg-color">Background Color</Label>
                  <Select value={bgColor} onValueChange={setBgColor}>
                    <SelectTrigger id="bg-color">
                      <SelectValue placeholder="Select background color" />
                    </SelectTrigger>
                    <SelectContent>
                      {backgroundColors.map((color) => (
                        <SelectItem key={color.value} value={color.value}>
                          <div className="flex items-center">
                            <div 
                              className="w-4 h-4 rounded-full mr-2" 
                              style={{ backgroundColor: color.value }}
                            />
                            {color.label}
                          </div>
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="text-color">Text Color</Label>
                  <Select value={textColor} onValueChange={setTextColor}>
                    <SelectTrigger id="text-color">
                      <SelectValue placeholder="Select text color" />
                    </SelectTrigger>
                    <SelectContent>
                      {textColors.map((color) => (
                        <SelectItem key={color.value} value={color.value}>
                          <div className="flex items-center">
                            <div 
                              className="w-4 h-4 rounded-full mr-2" 
                              style={{ backgroundColor: color.value }}
                            />
                            {color.label}
                          </div>
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="font-family">Font Style</Label>
                  <Select value={fontFamily} onValueChange={setFontFamily}>
                    <SelectTrigger id="font-family">
                      <SelectValue placeholder="Select font" />
                    </SelectTrigger>
                    <SelectContent>
                      {fontOptions.map((font) => (
                        <SelectItem key={font.value} value={font.value}>
                          <span style={{ fontFamily: font.value }}>{font.label}</span>
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2 sm:col-span-2 md:col-span-3">
                  <Label htmlFor="wallpaper-size">Wallpaper Size</Label>
                  <Select value={wallpaperSize} onValueChange={setWallpaperSize}>
                    <SelectTrigger id="wallpaper-size">
                      <SelectValue placeholder="Select size" />
                    </SelectTrigger>
                    <SelectContent>
                      {wallpaperSizes.map((size) => (
                        <SelectItem key={size.value} value={size.value}>
                          {size.label}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>

              {renderPreview()}
            </CardContent>
            <CardFooter>
              <Button onClick={downloadWallpaper} className="w-full">
                <Download className="mr-2 h-4 w-4" />
                Download Wallpaper
              </Button>
            </CardFooter>
          </Card>
        )}
      </div>
    </div>
  );
};

export default AffirmationWallpaperPage;