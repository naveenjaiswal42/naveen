import React, { useEffect, useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle, CardFooter } from '@/components/ui/card';
import { Link, useLocation } from 'wouter';
import { BookOpen, Award, CheckCircle } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { EnrollmentDebugger } from '@/components/EnrollmentDebugger';

// This is a direct enrollment page with a very simple design for testing purposes
export default function DirectEnroll() {
  const [enrolledCourses, setEnrolledCourses] = useState<number[]>([]);
  const [, navigate] = useLocation();
  const { toast } = useToast();

  // Load enrolled courses from localStorage on mount
  useEffect(() => {
    const stored = localStorage.getItem('enrolledCourses');
    if (stored) {
      try {
        setEnrolledCourses(JSON.parse(stored));
      } catch (e) {
        console.error("Failed to parse enrolled courses:", e);
        setEnrolledCourses([]);
      }
    }
  }, []);

  // Save enrolled courses to localStorage
  const saveEnrolledCourses = (courses: number[]) => {
    localStorage.setItem('enrolledCourses', JSON.stringify(courses));
    setEnrolledCourses(courses);
  };

  // Toggle enrollment for a course
  const toggleEnrollment = (courseId: number) => {
    const isEnrolled = enrolledCourses.includes(courseId);
    
    let updatedCourses: number[];
    
    if (isEnrolled) {
      // Unenroll from course
      updatedCourses = enrolledCourses.filter(id => id !== courseId);
      saveEnrolledCourses(updatedCourses);
      
      toast({
        title: "Unenrolled",
        description: `You have been unenrolled from course ${courseId}`,
      });
    } else {
      // Enroll in course
      updatedCourses = [...enrolledCourses, courseId];
      saveEnrolledCourses(updatedCourses);
      
      toast({
        title: "Enrolled!",
        description: `You have been enrolled in course ${courseId}`,
      });
    }
  };

  const coursesList = [
    { id: 1, title: "Chakra Healing Fundamentals" },
    { id: 2, title: "Tarot Reading for Beginners" },
    { id: 3, title: "Advanced Meditation Techniques" },
    { id: 4, title: "Vedic Astrology Foundations" },
  ];

  return (
    <div className="container mx-auto p-8">
      <h1 className="text-3xl font-bold mb-6 flex items-center gap-2">
        <BookOpen className="h-8 w-8 text-primary" />
        Direct Enrollment Manager
      </h1>
      
      <p className="mb-8 text-gray-600 dark:text-gray-400">
        This is a simplified page to directly manage your course enrollments.
      </p>
      
      <EnrollmentDebugger />
      
      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
        {coursesList.map(course => {
          const isEnrolled = enrolledCourses.includes(course.id);
          
          return (
            <Card key={course.id} className={`${isEnrolled ? 'border-primary' : ''}`}>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  {course.title}
                  {isEnrolled && <CheckCircle className="h-5 w-5 text-green-500" />}
                </CardTitle>
              </CardHeader>
              
              <CardContent>
                <p className="text-sm text-gray-600 dark:text-gray-400">
                  Course ID: {course.id}
                </p>
                {isEnrolled && (
                  <div className="mt-4 p-2 bg-green-50 dark:bg-green-900/20 text-green-700 dark:text-green-400 rounded-md text-sm">
                    You are currently enrolled in this course
                  </div>
                )}
              </CardContent>
              
              <CardFooter>
                <Button 
                  className="w-full" 
                  variant={isEnrolled ? "outline" : "default"}
                  onClick={() => toggleEnrollment(course.id)}
                >
                  {isEnrolled ? (
                    <>
                      <Award className="h-4 w-4 mr-2" />
                      Unenroll
                    </>
                  ) : (
                    <>
                      <BookOpen className="h-4 w-4 mr-2" />
                      Enroll Now
                    </>
                  )}
                </Button>
              </CardFooter>
            </Card>
          );
        })}
      </div>
      
      <div className="mt-12">
        <Button variant="outline" onClick={() => navigate('/courses')}>
          Return to Courses Page
        </Button>
      </div>
    </div>
  );
}