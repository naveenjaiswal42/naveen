import { useState, useEffect, useRef } from "react";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/contexts/AuthContext";
import { apiRequest } from "@/lib/queryClient";
import { Container } from "@/components/ui/container";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import CelebrationPopup from "@/components/CelebrationPopup";
import {
  Play,
  Pause,
  RotateCcw,
  Clock,
  Award,
  Volume2,
  VolumeX,
  Settings
} from "lucide-react";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";
import { Badge } from "@/components/ui/badge";
import { Switch } from "@/components/ui/switch";
import { format } from "date-fns";

export default function MeditationTimerPage() {
  // Timer settings
  const DEFAULT_DURATION = 300; // 5 minutes in seconds
  const [duration, setDuration] = useState(DEFAULT_DURATION);
  const [timeLeft, setTimeLeft] = useState(duration);
  const [running, setRunning] = useState(false);
  const [completed, setCompleted] = useState(false);
  const [progress, setProgress] = useState(0);
  const [ambient, setAmbient] = useState(true);
  const [showBreathingGuide, setShowBreathingGuide] = useState(true);
  const [breathPhase, setBreathPhase] = useState<"inhale" | "hold" | "exhale">("inhale");
  const [breathCount, setBreathCount] = useState(0);
  const [streak, setStreak] = useState(0);
  const [loading, setLoading] = useState(false);
  const [showCelebration, setShowCelebration] = useState(false);
  
  // References
  const timerRef = useRef<NodeJS.Timeout | null>(null);
  const breathingTimerRef = useRef<NodeJS.Timeout | null>(null);
  const audioRef = useRef<HTMLAudioElement | null>(null);
  
  const { toast } = useToast();
  const { user } = useAuth();
  
  // Fetch user's meditation streak on component mount
  useEffect(() => {
    const fetchStreak = async () => {
      if (!user) return;
      
      try {
        setLoading(true);
        const response = await apiRequest({
          method: "GET",
          url: `/api/users/${user.id}/streak`
        });
        
        const data = await response.json();
        setStreak(data.streak || 0);
      } catch (error) {
        console.error("Error fetching meditation streak:", error);
      } finally {
        setLoading(false);
      }
    };
    
    fetchStreak();
  }, [user]);
  
  // Initialize audio
  useEffect(() => {
    audioRef.current = new Audio("/audio/ambient-meditation.mp3");
    audioRef.current.loop = true;
    audioRef.current.volume = 0.5;
    
    return () => {
      if (audioRef.current) {
        audioRef.current.pause();
        audioRef.current = null;
      }
    };
  }, []);
  
  // Timer effect
  useEffect(() => {
    if (running && timeLeft > 0) {
      timerRef.current = setInterval(() => {
        setTimeLeft(prev => {
          const newTime = prev - 1;
          setProgress(100 - (newTime / duration * 100));
          return newTime;
        });
      }, 1000);
    } else if (timeLeft === 0 && !completed) {
      setRunning(false);
      setCompleted(true);
      setShowCelebration(true); // Show celebration popup
      awardXpBonus();
      
      // Play completion sound
      const completionSound = new Audio("/audio/meditation-complete.mp3");
      completionSound.play();
      
      // Stop ambient music
      if (audioRef.current) {
        audioRef.current.pause();
      }
    }
    
    return () => {
      if (timerRef.current) {
        clearInterval(timerRef.current);
        timerRef.current = null;
      }
    };
  }, [running, timeLeft, completed, duration]);
  
  // Breathing guide effect
  useEffect(() => {
    if (running && showBreathingGuide) {
      const breathCycle = () => {
        // Cycle: 4s inhale -> 4s hold -> 6s exhale
        if (breathPhase === "inhale") {
          setBreathPhase("hold");
          breathingTimerRef.current = setTimeout(() => {
            setBreathPhase("exhale");
            breathingTimerRef.current = setTimeout(() => {
              setBreathPhase("inhale");
              setBreathCount(prev => prev + 1);
              breathCycle();
            }, 6000); // exhale for 6 seconds
          }, 4000); // hold for 4 seconds
        } else {
          setBreathPhase("inhale");
          breathingTimerRef.current = setTimeout(() => {
            breathCycle();
          }, 4000); // inhale for 4 seconds
        }
      };
      
      setBreathPhase("inhale");
      breathCycle();
    }
    
    return () => {
      if (breathingTimerRef.current) {
        clearTimeout(breathingTimerRef.current);
        breathingTimerRef.current = null;
      }
    };
  }, [running, showBreathingGuide]);
  
  // Ambient music control
  useEffect(() => {
    if (running && ambient && audioRef.current) {
      audioRef.current.play().catch(err => console.error("Error playing audio:", err));
    } else if (audioRef.current) {
      audioRef.current.pause();
    }
  }, [running, ambient]);
  
  const startTimer = () => {
    setTimeLeft(duration);
    setProgress(0);
    setRunning(true);
    setCompleted(false);
    setBreathCount(0);
    setShowCelebration(false);
  };
  
  const pauseTimer = () => {
    setRunning(false);
    if (audioRef.current) {
      audioRef.current.pause();
    }
  };
  
  const resumeTimer = () => {
    setRunning(true);
    if (ambient && audioRef.current) {
      audioRef.current.play().catch(err => console.error("Error playing audio:", err));
    }
  };
  
  const resetTimer = () => {
    setRunning(false);
    setTimeLeft(duration);
    setProgress(0);
    setCompleted(false);
    setBreathCount(0);
    setShowCelebration(false);
    
    if (audioRef.current) {
      audioRef.current.pause();
      audioRef.current.currentTime = 0;
    }
  };
  
  const toggleAmbient = () => {
    setAmbient(!ambient);
  };
  
  const toggleBreathingGuide = () => {
    setShowBreathingGuide(!showBreathingGuide);
  };
  
  const selectDuration = (seconds: number) => {
    setDuration(seconds);
    setTimeLeft(seconds);
    setProgress(0);
    setCompleted(false);
    setShowCelebration(false);
  };
  
  const awardXpBonus = async () => {
    if (!user) return;
    
    try {
      // Calculate XP based on duration (longer sessions = more XP)
      const minutes = Math.floor(duration / 60);
      const xpAmount = Math.min(500, minutes * 30); // 30 XP per minute, capped at 500
      
      await apiRequest({
        method: "POST",
        url: `/api/users/${user.id}/xp`,
        body: { xpAmount }
      });
      
      // Update meditation streak
      const today = format(new Date(), "yyyy-MM-dd");
      const response = await apiRequest({
        method: "POST",
        url: `/api/users/${user.id}/streak`,
        body: { date: today }
      });
      
      // Update streak in UI
      const data = await response.json();
      setStreak(data.streak || 0);
      
      toast({
        title: "Meditation Complete!",
        description: `Well done! You've earned ${xpAmount} XP for your mindfulness practice.`,
        variant: "default",
      });
    } catch (error) {
      console.error("Error awarding XP:", error);
      toast({
        title: "Error",
        description: "Failed to update your progress. Please try again.",
        variant: "destructive",
      });
    }
  };
  
  const formatTime = (seconds: number) => {
    const minutes = Math.floor(seconds / 60);
    const remainingSeconds = seconds % 60;
    return `${minutes.toString().padStart(2, '0')}:${remainingSeconds.toString().padStart(2, '0')}`;
  };
  
  const getBreathingText = () => {
    switch (breathPhase) {
      case "inhale": return "Breathe in...";
      case "hold": return "Hold...";
      case "exhale": return "Breathe out...";
      default: return "";
    }
  };
  
  const getBreathingClassName = () => {
    switch (breathPhase) {
      case "inhale": return "animate-breathe-in";
      case "hold": return "animate-breathe-hold";
      case "exhale": return "animate-breathe-out";
      default: return "";
    }
  };

  return (
    <Container className="py-8">
      {/* Celebration Popup */}
      <CelebrationPopup 
        show={showCelebration} 
        onClose={() => setShowCelebration(false)} 
        message={`You've completed your meditation! Earned ${Math.min(500, Math.floor(duration / 60) * 30)} XP.`} 
      />

      <div className="mb-8">
        <h1 className="text-3xl font-bold tracking-tight flex items-center gap-2">
          <Clock className="h-8 w-8 text-indigo-600 dark:text-indigo-400" /> 
          Meditation Timer
        </h1>
        <p className="text-gray-500 dark:text-gray-400 mt-2">
          Practice mindfulness and focus with timed meditation sessions
        </p>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
        <div className="md:col-span-2">
          <Card className="border-indigo-100 dark:border-indigo-800/30">
            <CardContent className="pt-6 flex flex-col items-center justify-center min-h-[400px]">
              {/* Timer Circle */}
              <div className="relative flex items-center justify-center mb-6">
                <div className="w-64 h-64 rounded-full border-8 border-indigo-50 dark:border-indigo-950/30 flex items-center justify-center">
                  <div className="absolute w-64 h-64 -m-2">
                    <svg className="w-full h-full" viewBox="0 0 100 100">
                      <circle 
                        className="text-indigo-100 dark:text-indigo-950/30 stroke-current" 
                        strokeWidth="4"
                        fill="transparent" 
                        r="42" 
                        cx="50" 
                        cy="50" 
                      />
                      <circle 
                        className="text-indigo-500 dark:text-indigo-400 stroke-current" 
                        strokeWidth="4"
                        fill="transparent" 
                        r="42" 
                        cx="50" 
                        cy="50" 
                        strokeDasharray="264"
                        strokeDashoffset={264 - (264 * progress) / 100}
                        strokeLinecap="round"
                        transform="rotate(-90 50 50)"
                      />
                    </svg>
                  </div>
                  <div className="text-center z-10">
                    <div className="text-5xl font-bold text-gray-800 dark:text-gray-100">
                      {formatTime(timeLeft)}
                    </div>
                    {running && showBreathingGuide && (
                      <div className="mt-2 text-indigo-600 dark:text-indigo-400">
                        {getBreathingText()}
                      </div>
                    )}
                  </div>
                </div>
                
                {/* Breathing visualization */}
                {running && showBreathingGuide && (
                  <div 
                    className={`absolute w-40 h-40 bg-indigo-100 dark:bg-indigo-900/20 rounded-full opacity-50 ${getBreathingClassName()}`}
                  ></div>
                )}
              </div>
              
              {/* Controls */}
              <div className="flex items-center space-x-4">
                {!running && !completed && (
                  <Button 
                    onClick={startTimer} 
                    size="lg" 
                    className="bg-indigo-600 hover:bg-indigo-700"
                  >
                    <Play className="mr-2 h-4 w-4" />
                    Start
                  </Button>
                )}
                
                {running && (
                  <Button 
                    onClick={pauseTimer} 
                    size="lg" 
                    variant="outline"
                  >
                    <Pause className="mr-2 h-4 w-4" />
                    Pause
                  </Button>
                )}
                
                {!running && timeLeft < duration && !completed && (
                  <Button 
                    onClick={resumeTimer} 
                    size="lg" 
                    className="bg-indigo-600 hover:bg-indigo-700"
                  >
                    <Play className="mr-2 h-4 w-4" />
                    Resume
                  </Button>
                )}
                
                {(running || (!running && timeLeft < duration)) && (
                  <Button 
                    onClick={resetTimer} 
                    size="lg" 
                    variant="outline"
                  >
                    <RotateCcw className="mr-2 h-4 w-4" />
                    Reset
                  </Button>
                )}
              </div>
              
              {completed && (
                <div className="mt-8 text-center">
                  <div className="inline-flex items-center justify-center p-4 bg-green-50 dark:bg-green-900/20 rounded-full mb-4">
                    <Award className="h-12 w-12 text-green-500" />
                  </div>
                  <h2 className="text-2xl font-bold text-green-600 dark:text-green-400">
                    Meditation Complete!
                  </h2>
                  <p className="text-gray-600 dark:text-gray-400 mt-2 mb-4">
                    You've taken an important step in your spiritual journey
                  </p>
                  <Button 
                    onClick={startTimer} 
                    size="lg" 
                    className="bg-indigo-600 hover:bg-indigo-700"
                  >
                    <Play className="mr-2 h-4 w-4" />
                    Start New Session
                  </Button>
                </div>
              )}
              
              {running && showBreathingGuide && (
                <div className="mt-8 text-sm text-gray-500 dark:text-gray-400">
                  <span className="font-medium">{breathCount}</span> breath cycles completed
                </div>
              )}
            </CardContent>
          </Card>
        </div>
        
        <div className="space-y-6">
          {/* Session Settings */}
          <Card className="border-indigo-100 dark:border-indigo-800/30">
            <CardContent className="pt-6">
              <h3 className="text-lg font-medium mb-4 flex items-center">
                <Settings className="h-5 w-5 mr-2 text-indigo-500" />
                Session Settings
              </h3>
              
              <div className="space-y-4">
                <div>
                  <div className="font-medium mb-2">Duration</div>
                  <div className="flex flex-wrap gap-2">
                    <TooltipProvider>
                      <Tooltip>
                        <TooltipTrigger asChild>
                          <Button 
                            variant={duration === 300 ? "default" : "outline"} 
                            size="sm"
                            onClick={() => selectDuration(300)}
                            className={duration === 300 ? "bg-indigo-600 hover:bg-indigo-700" : ""}
                          >
                            5 min
                          </Button>
                        </TooltipTrigger>
                        <TooltipContent>
                          <p>5 minute meditation (150 XP)</p>
                        </TooltipContent>
                      </Tooltip>
                    </TooltipProvider>
                    
                    <TooltipProvider>
                      <Tooltip>
                        <TooltipTrigger asChild>
                          <Button 
                            variant={duration === 600 ? "default" : "outline"} 
                            size="sm"
                            onClick={() => selectDuration(600)}
                            className={duration === 600 ? "bg-indigo-600 hover:bg-indigo-700" : ""}
                          >
                            10 min
                          </Button>
                        </TooltipTrigger>
                        <TooltipContent>
                          <p>10 minute meditation (300 XP)</p>
                        </TooltipContent>
                      </Tooltip>
                    </TooltipProvider>
                    
                    <TooltipProvider>
                      <Tooltip>
                        <TooltipTrigger asChild>
                          <Button 
                            variant={duration === 1200 ? "default" : "outline"} 
                            size="sm"
                            onClick={() => selectDuration(1200)}
                            className={duration === 1200 ? "bg-indigo-600 hover:bg-indigo-700" : ""}
                          >
                            20 min
                          </Button>
                        </TooltipTrigger>
                        <TooltipContent>
                          <p>20 minute meditation (500 XP)</p>
                        </TooltipContent>
                      </Tooltip>
                    </TooltipProvider>
                  </div>
                </div>
                
                <div className="flex items-center justify-between">
                  <div className="font-medium">Ambient Sound</div>
                  <div className="flex items-center space-x-2">
                    <Button 
                      variant="ghost" 
                      size="icon" 
                      onClick={toggleAmbient}
                      disabled={running}
                    >
                      {ambient ? (
                        <Volume2 className="h-4 w-4 text-indigo-500" />
                      ) : (
                        <VolumeX className="h-4 w-4" />
                      )}
                    </Button>
                    <Switch 
                      checked={ambient} 
                      onCheckedChange={toggleAmbient}
                      disabled={running}
                    />
                  </div>
                </div>
                
                <div className="flex items-center justify-between">
                  <div className="font-medium">Breathing Guide</div>
                  <Switch 
                    checked={showBreathingGuide} 
                    onCheckedChange={toggleBreathingGuide}
                    disabled={running}
                  />
                </div>
              </div>
            </CardContent>
          </Card>
          
          {/* Benefits */}
          <Card className="border-indigo-100 dark:border-indigo-800/30">
            <CardContent className="pt-6">
              <h3 className="text-lg font-medium mb-4 flex items-center">
                <Award className="h-5 w-5 mr-2 text-indigo-500" />
                Benefits
              </h3>
              
              {/* Current streak */}
              <div className="mb-6 bg-indigo-50 dark:bg-indigo-900/20 rounded-lg p-4">
                <div className="flex items-center justify-between mb-2">
                  <h4 className="font-medium text-indigo-700 dark:text-indigo-300">Your Streak</h4>
                  <Badge variant="outline" className="bg-indigo-100/50 dark:bg-indigo-800/30 text-indigo-700 dark:text-indigo-300 border-indigo-200 dark:border-indigo-700">
                    {loading ? "Loading..." : `${streak} ${streak === 1 ? 'day' : 'days'}`}
                  </Badge>
                </div>
                <p className="text-xs text-indigo-600/80 dark:text-indigo-400/80">
                  {streak >= 7 ? (
                    "Impressive dedication! You've unlocked the Meditation Warrior badge."
                  ) : streak >= 3 ? (
                    "Great progress! Keep going to unlock the Meditation Warrior badge."
                  ) : (
                    "Consistency is key. Meditate daily to build your streak."
                  )}
                </p>
              </div>
              
              <div className="space-y-3">
                <div className="flex items-start">
                  <Badge className="bg-indigo-50 text-indigo-600 dark:bg-indigo-950/20 dark:text-indigo-400 mt-0.5">XP Boost</Badge>
                  <p className="text-sm text-gray-600 dark:text-gray-400 ml-2">
                    Earn up to 500 XP for longer sessions
                  </p>
                </div>
                
                <div className="flex items-start">
                  <Badge className="bg-indigo-50 text-indigo-600 dark:bg-indigo-950/20 dark:text-indigo-400 mt-0.5">Streak</Badge>
                  <p className="text-sm text-gray-600 dark:text-gray-400 ml-2">
                    Daily meditation builds your streak and unlocks badges
                  </p>
                </div>
                
                <div className="flex items-start">
                  <Badge className="bg-indigo-50 text-indigo-600 dark:bg-indigo-950/20 dark:text-indigo-400 mt-0.5">Focus</Badge>
                  <p className="text-sm text-gray-600 dark:text-gray-400 ml-2">
                    Improves concentration and mental clarity
                  </p>
                </div>
                
                <div className="flex items-start">
                  <Badge className="bg-indigo-50 text-indigo-600 dark:bg-indigo-950/20 dark:text-indigo-400 mt-0.5">Balance</Badge>
                  <p className="text-sm text-gray-600 dark:text-gray-400 ml-2">
                    Restores emotional equilibrium and reduces stress
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
      
    </Container>
  );
}