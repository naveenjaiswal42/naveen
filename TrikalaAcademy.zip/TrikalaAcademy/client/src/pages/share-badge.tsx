import { useEffect, useState } from 'react';
import { useLocation, Link, useRoute } from 'wouter';
import { ChevronLeft, Share2, Download } from 'lucide-react';
import axios from 'axios';
import { useToast } from '@/hooks/use-toast';
import { useAuth } from '@/contexts/AuthContext';
import { Button } from '@/components/ui/button';
import BadgeShareCard from '@/components/BadgeShareCard';

interface Badge {
  id: string;
  title: string;
  description: string;
  category: string;
  dateEarned: string;
  iconType?: string;
}

export default function ShareBadgePage() {
  const [badge, setBadge] = useState<Badge | null>(null);
  const [loading, setLoading] = useState(true);
  const { toast } = useToast();
  const { user } = useAuth();
  const [match, params] = useRoute('/share-badge/:id');
  const [, setLocation] = useLocation();

  useEffect(() => {
    if (!user) {
      setLocation('/auth');
      return;
    }

    const badgeId = params && params.id;
    if (badgeId) {
      fetchBadge(badgeId);
    } else {
      toast({
        title: 'Error',
        description: 'Badge ID is missing.',
        variant: 'destructive',
      });
      setLoading(false);
    }
  }, [user, params, setLocation, toast]);

  const fetchBadge = async (badgeId: string) => {
    try {
      setLoading(true);
      const response = await axios.get(`/api/users/${user?.id}/badges/${badgeId}`);
      setBadge(response.data);
    } catch (error) {
      console.error('Error fetching badge:', error);
      toast({
        title: 'Error',
        description: 'Failed to load badge. Please try again later.',
        variant: 'destructive',
      });
    } finally {
      setLoading(false);
    }
  };

  const getBadgeIcon = (category: string) => {
    switch (category) {
      case 'streak':
        return '⚡';
      case 'chakra':
        return '☀️';
      case 'level':
        return '⭐';
      case 'ritual':
        return '🔮';
      case 'achievement':
        return '🏆';
      default:
        return '🌟';
    }
  };

  const getBadgeColor = (category: string) => {
    switch (category) {
      case 'streak':
        return 'blue';
      case 'chakra':
        return 'purple';
      case 'level':
        return 'yellow';
      case 'ritual':
        return 'green';
      case 'achievement':
        return 'red';
      default:
        return 'indigo';
    }
  };

  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return new Intl.DateTimeFormat('en-US', {
      year: 'numeric',
      month: 'long',
      day: 'numeric',
    }).format(date);
  };

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="mb-6">
        <Button variant="ghost" asChild className="flex items-center gap-2">
          <Link to="/badge-wall">
            <ChevronLeft className="h-4 w-4" />
            Back to Badge Wall
          </Link>
        </Button>
      </div>

      <header className="mb-8 text-center">
        <h1 className="text-3xl font-bold text-primary">Share Your Achievement</h1>
        <p className="text-muted-foreground mt-2">
          Download your badge or share it with friends and inspire them
        </p>
      </header>

      {loading ? (
        <div className="flex justify-center items-center min-h-[400px]">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div>
        </div>
      ) : badge ? (
        <div className="flex flex-col items-center justify-center">
          <BadgeShareCard
            badgeTitle={badge.title}
            badgeDescription={badge.description}
            earnedDate={formatDate(badge.dateEarned)}
            badgeColor={getBadgeColor(badge.category)}
            badgeIcon={getBadgeIcon(badge.category)}
          />

          <div className="mt-8 text-center max-w-md mx-auto">
            <h3 className="text-lg font-medium mb-2">Why Share Your Achievement?</h3>
            <p className="text-muted-foreground mb-6">
              Sharing your spiritual journey can inspire others and create a positive ripple effect in your community. Your dedication can motivate friends to begin their own spiritual practice!
            </p>

            <div className="flex flex-col sm:flex-row justify-center gap-4 mt-4">
              <Button 
                variant="default" 
                className="flex items-center gap-2"
                onClick={() => window.history.back()}
              >
                <ChevronLeft className="h-4 w-4" />
                Back to Badge Wall
              </Button>
            </div>
          </div>
        </div>
      ) : (
        <div className="text-center py-16 bg-muted rounded-lg">
          <h3 className="text-lg font-medium">Badge not found</h3>
          <p className="mt-2 text-sm text-muted-foreground max-w-md mx-auto">
            The badge you're looking for could not be found. Please return to your badge wall and try again.
          </p>
          <Button 
            variant="default" 
            className="mt-4"
            asChild
          >
            <Link to="/badge-wall">Go to Badge Wall</Link>
          </Button>
        </div>
      )}
    </div>
  );
}