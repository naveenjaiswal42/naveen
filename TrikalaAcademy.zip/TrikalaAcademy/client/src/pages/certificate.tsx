import { useEffect, useState } from "react";
import { useParams, useLocation } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useAuth } from "@/contexts/AuthContext";
import { Button } from "@/components/ui/button";
import { Loader2, ChevronLeft } from "lucide-react";
import NewCertificateDownload from "@/components/courses/NewCertificateDownload";

export default function CertificatePage() {
  const { id } = useParams<{ id: string }>();
  const courseId = parseInt(id);
  const { user } = useAuth();
  const [, navigate] = useLocation();
  const [userFullName, setUserFullName] = useState("");
  
  // Fetch course details
  const { data: course, isLoading: courseLoading } = useQuery({
    queryKey: ['/api/courses', courseId],
    queryFn: () => apiRequest({ 
      url: `/api/courses/${courseId}`,
      method: 'GET'
    }),
    enabled: !!courseId,
  });

  // Fetch user course progress
  const { data: userCourse, isLoading: progressLoading } = useQuery({
    queryKey: ['/api/users', user?.id, 'courses', courseId],
    queryFn: () => apiRequest({ 
      url: `/api/users/${user?.id}/courses/${courseId}`,
      method: 'GET'
    }),
    enabled: !!user?.id && !!courseId,
  });

  useEffect(() => {
    // Set user name from auth context
    if (user) {
      setUserFullName(user.name || "Spiritual Seeker");
    }
  }, [user]);

  // Check if user has completed this course
  // Use >= instead of === to handle cases where lessonsCompleted might exceed totalLessons
  const isCompleted = userCourse && course && 
    userCourse.lessonsCompleted >= course.totalLessons;
  
  // Log for debugging
  const debugInfo = { 
    courseId,
    courseLoading,
    progressLoading,
    userCourse: userCourse || null,
    course: course || null,
    lessonsCompleted: userCourse?.lessonsCompleted, 
    totalLessons: course?.totalLessons,
    isCompleted 
  };
  console.log("Certificate Page - FULL DEBUG INFO:", debugInfo);

  if (courseLoading || progressLoading) {
    return (
      <div className="flex items-center justify-center min-h-[60vh]">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  if (!course) {
    return (
      <div className="text-center py-10">
        <h2 className="text-2xl font-bold mb-2">Course not found</h2>
        <p className="mb-4">The course you're looking for doesn't exist.</p>
        <Button onClick={() => navigate('/courses')}>Browse Courses</Button>
      </div>
    );
  }

  // Force isCompleted to true if lessonsCompleted >= totalLessons
  const forceIsCompleted = userCourse && course && 
    userCourse.lessonsCompleted >= course.totalLessons;
  
  console.log("FORCE completed check:", { 
    forceIsCompleted, 
    userCourseLessons: userCourse?.lessonsCompleted,
    courseTotalLessons: course?.totalLessons
  });
  
  if (!forceIsCompleted) {
    return (
      <div className="container max-w-4xl mx-auto py-8 px-4">
        <Button 
          variant="ghost" 
          onClick={() => navigate('/my-courses')}
          className="mb-4"
        >
          <ChevronLeft className="h-4 w-4 mr-2" />
          Back to My Courses
        </Button>
        
        <div className="text-center py-10 bg-gray-50 dark:bg-gray-800 rounded-lg">
          <h2 className="text-2xl font-bold mb-2">Course Not Completed</h2>
          <p className="mb-6">You need to complete all lessons in this course to receive your certificate.</p>
          <Button onClick={() => navigate(`/my-courses/${courseId}/lessons`)}>
            Continue Learning
          </Button>
        </div>
      </div>
    );
  }

  // Format completion date
  const completionDate = userCourse?.updatedAt 
    ? new Date(userCourse.updatedAt).toLocaleDateString() 
    : new Date().toLocaleDateString();

  return (
    <div className="container max-w-4xl mx-auto py-8 px-4">
      <Button 
        variant="ghost" 
        onClick={() => navigate('/my-courses')}
        className="mb-4"
      >
        <ChevronLeft className="h-4 w-4 mr-2" />
        Back to My Courses
      </Button>
      
      <div className="text-center mb-6">
        <h1 className="text-3xl font-bold">Your Certificate of Completion</h1>
        <p className="text-gray-600 dark:text-gray-400 mt-2">
          Congratulations on completing {course.title}!
        </p>
      </div>
      
      <NewCertificateDownload 
        courseTitle={course.title}
        userName={userFullName}
        completionDate={completionDate}
        isCourseCompleted={forceIsCompleted}
      />
    </div>
  );
}