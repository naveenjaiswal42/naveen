import React, { useState, useEffect } from 'react';
import { useQuery } from '@tanstack/react-query';
import { useAuth } from '@/hooks/use-auth';
import { useToast } from '@/hooks/use-toast';
import { Button } from '@/components/ui/button';
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from '@/components/ui/card';
import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
} from '@/components/ui/tabs';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Loader2, Calendar, BarChart, LineChart, PieChart } from 'lucide-react';
import { format, parseISO, subDays, subMonths, formatISO, startOfMonth, endOfMonth, isValid } from 'date-fns';
import { apiRequest } from '@/lib/queryClient';
import { MoodEntry } from '@/lib/types';
import { Separator } from '@/components/ui/separator';

type MoodDisplayProps = {
  mood: string;
  size?: 'sm' | 'md' | 'lg';
};

const MoodDisplay = ({ mood, size = 'md' }: MoodDisplayProps) => {
  const moodEmojis: Record<string, string> = {
    joyful: '😄',
    grateful: '🙏',
    calm: '😌',
    neutral: '😐',
    anxious: '😟',
    sad: '😢',
    angry: '😠',
    fearful: '😨',
    stressed: '😰',
    peaceful: '🧘',
    inspired: '✨',
    loving: '❤️',
  };

  const sizeClasses = {
    sm: 'text-xl',
    md: 'text-3xl',
    lg: 'text-5xl',
  };

  return (
    <span className={`${sizeClasses[size]} inline-block`}>
      {moodEmojis[mood] || '❓'}
    </span>
  );
};

type DateRange = {
  start: string;
  end: string;
  label: string;
};

const MoodReflectionSummaryPage: React.FC = () => {
  const { user } = useAuth();
  const { toast } = useToast();
  const [activeTab, setActiveTab] = useState('weekly');
  const [selectedDateRange, setSelectedDateRange] = useState<DateRange>({
    start: formatISO(subDays(new Date(), 7), { representation: 'date' }),
    end: formatISO(new Date(), { representation: 'date' }),
    label: 'Past 7 days'
  });
  
  const [customStart, setCustomStart] = useState(
    formatISO(subDays(new Date(), 7), { representation: 'date' })
  );
  const [customEnd, setCustomEnd] = useState(
    formatISO(new Date(), { representation: 'date' })
  );

  const dateRanges: Record<string, DateRange> = {
    week: {
      start: formatISO(subDays(new Date(), 7), { representation: 'date' }),
      end: formatISO(new Date(), { representation: 'date' }),
      label: 'Past 7 days'
    },
    month: {
      start: formatISO(subDays(new Date(), 30), { representation: 'date' }),
      end: formatISO(new Date(), { representation: 'date' }),
      label: 'Past 30 days'
    },
    threeMonths: {
      start: formatISO(subMonths(new Date(), 3), { representation: 'date' }),
      end: formatISO(new Date(), { representation: 'date' }),
      label: 'Past 3 months'
    },
    custom: {
      start: customStart,
      end: customEnd,
      label: 'Custom range'
    }
  };

  // Fetch all mood entries
  const { data: allEntries, isLoading: isLoadingEntries } = useQuery({
    queryKey: ['/api/users', user?.id, 'mood-entries'],
    queryFn: async () => {
      if (!user) return [];
      const res = await apiRequest('GET', `/api/users/${user.id}/mood-entries`);
      return await res.json();
    },
    enabled: !!user,
  });

  // Fetch mood summary for the selected date range
  const { data: moodSummary, isLoading: isLoadingSummary } = useQuery({
    queryKey: [
      '/api/users', 
      user?.id, 
      'mood-summary', 
      selectedDateRange.start, 
      selectedDateRange.end
    ],
    queryFn: async () => {
      if (!user) return [];
      const res = await apiRequest(
        'GET', 
        `/api/users/${user.id}/mood-summary?startDate=${selectedDateRange.start}&endDate=${selectedDateRange.end}`
      );
      return await res.json();
    },
    enabled: !!user,
  });

  // Handle date range selection
  const handleDateRangeChange = (range: string) => {
    if (range === 'custom') {
      setSelectedDateRange({
        ...dateRanges.custom,
        label: `${format(new Date(customStart), 'MMM d, yyyy')} - ${format(new Date(customEnd), 'MMM d, yyyy')}`
      });
    } else {
      setSelectedDateRange(dateRanges[range]);
    }
  };

  // Filter entries based on selected date range
  const filteredEntries = allEntries?.filter((entry: MoodEntry) => {
    const entryDate = new Date(entry.date);
    return (
      entryDate >= new Date(selectedDateRange.start) && 
      entryDate <= new Date(selectedDateRange.end)
    );
  }) || [];

  // Generate mood frequency data for chart
  const moodFrequencyData = moodSummary || [];

  const getEmotionalInsights = () => {
    if (!moodFrequencyData.length) return "Not enough data to generate insights.";
    
    // Sort moods by frequency
    const sortedMoods = [...moodFrequencyData].sort((a, b) => b.count - a.count);
    const totalCount = sortedMoods.reduce((sum, item) => sum + item.count, 0);
    const mostFrequent = sortedMoods[0];
    
    // Check for positive moods
    const positiveMoods = ['joyful', 'grateful', 'calm', 'peaceful', 'inspired', 'loving'];
    const positiveCount = sortedMoods
      .filter(item => positiveMoods.includes(item.mood))
      .reduce((sum, item) => sum + item.count, 0);
    
    const positivePercentage = Math.round((positiveCount / totalCount) * 100);
    
    // Check for negative moods
    const negativeMoods = ['anxious', 'sad', 'angry', 'fearful', 'stressed'];
    const negativeCount = sortedMoods
      .filter(item => negativeMoods.includes(item.mood))
      .reduce((sum, item) => sum + item.count, 0);
    
    const negativePercentage = Math.round((negativeCount / totalCount) * 100);
    
    let insights = '';
    
    if (positivePercentage > 70) {
      insights = `Your spiritual journey appears to be going well. ${positivePercentage}% of your recorded moods were positive, with "${mostFrequent.mood}" being most frequent. This suggests your spiritual practices may be contributing to your emotional well-being.`;
    } else if (positivePercentage > 50) {
      insights = `You're maintaining good emotional balance. ${positivePercentage}% of your recorded moods were positive, with "${mostFrequent.mood}" being most frequent. Consider increasing practices that specifically target your less frequent positive states.`;
    } else if (negativePercentage > 70) {
      insights = `You've been experiencing some emotional challenges. ${negativePercentage}% of your recorded moods were in challenging emotional states, with "${mostFrequent.mood}" being most frequent. Consider incorporating more grounding exercises and self-compassion practices.`;
    } else {
      insights = `Your emotional landscape has been mixed. Your most frequent mood was "${mostFrequent.mood}". Pay attention to what practices help shift you toward more positive states, and consider journaling about what triggers your challenging emotions.`;
    }
    
    return insights;
  };

  const getRecommendedPractices = () => {
    if (!moodFrequencyData.length) return [];
    
    // Define practice recommendations for each mood type
    const moodPractices: Record<string, string[]> = {
      'anxious': [
        'Grounding meditation with focus on breath',
        'Nature walks with mindful attention',
        'Gentle yin yoga to release tension'
      ],
      'sad': [
        'Heart chakra healing meditation',
        'Gratitude journaling practice',
        'Community connection circles'
      ],
      'angry': [
        'Movement practices like dynamic yoga',
        'Mindful breathing with extended exhales',
        'Compassion meditation for yourself and others'
      ],
      'fearful': [
        'Root chakra meditation for stability',
        'Progressive muscle relaxation',
        'Mantra practice with courage affirmations'
      ],
      'stressed': [
        'Body scan meditation',
        'Digital detox periods',
        'Sacred space creation in your home'
      ],
      'neutral': [
        'Curiosity practices to deepen awareness',
        'Meditation on life purpose',
        'Creative expression through art or music'
      ]
    };
    
    // Sort moods by frequency, focusing on challenging moods
    const challengingMoods = ['anxious', 'sad', 'angry', 'fearful', 'stressed', 'neutral'];
    const relevantMoods = moodFrequencyData
      .filter(item => challengingMoods.includes(item.mood))
      .sort((a, b) => b.count - a.count)
      .slice(0, 2); // Focus on top 2 challenging moods
    
    // If no challenging moods, give general recommendations
    if (relevantMoods.length === 0) {
      return [
        'Continue your current practices that support your positive states',
        'Consider adding loving-kindness meditation to expand compassion',
        'Explore advanced states through longer meditation sessions'
      ];
    }
    
    // Collect recommendations based on mood frequency
    const recommendations: string[] = [];
    relevantMoods.forEach(mood => {
      const practices = moodPractices[mood.mood];
      if (practices && practices.length) {
        recommendations.push(...practices);
      }
    });
    
    // Return top practices without duplicates
    return Array.from(new Set(recommendations)).slice(0, 5);
  };

  return (
    <div className="container py-10 max-w-6xl mx-auto">
      <div className="mb-6">
        <h1 className="text-3xl font-bold text-primary">Mood Reflection Summary</h1>
        <p className="text-muted-foreground">
          Insights and patterns from your emotional journey
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
        <div className="md:col-span-3">
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-lg">Date Range</CardTitle>
            </CardHeader>
            <CardContent>
              <Tabs defaultValue="week" value={activeTab} onValueChange={(value) => {
                setActiveTab(value);
                handleDateRangeChange(value);
              }}>
                <TabsList className="grid grid-cols-4">
                  <TabsTrigger value="week">Week</TabsTrigger>
                  <TabsTrigger value="month">Month</TabsTrigger>
                  <TabsTrigger value="threeMonths">3 Months</TabsTrigger>
                  <TabsTrigger value="custom">Custom</TabsTrigger>
                </TabsList>
                <TabsContent value="custom" className="mt-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label className="text-sm font-medium mb-1 block">Start Date</label>
                      <input
                        type="date"
                        value={customStart}
                        onChange={(e) => setCustomStart(e.target.value)}
                        className="w-full px-3 py-2 border rounded-md"
                        max={customEnd}
                      />
                    </div>
                    <div>
                      <label className="text-sm font-medium mb-1 block">End Date</label>
                      <input
                        type="date"
                        value={customEnd}
                        onChange={(e) => setCustomEnd(e.target.value)}
                        className="w-full px-3 py-2 border rounded-md"
                        min={customStart}
                        max={formatISO(new Date(), { representation: 'date' })}
                      />
                    </div>
                  </div>
                  <Button 
                    className="mt-4"
                    onClick={() => handleDateRangeChange('custom')}
                  >
                    Apply Range
                  </Button>
                </TabsContent>
              </Tabs>
            </CardContent>
          </Card>
        </div>
        
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-lg">Mood Entries</CardTitle>
          </CardHeader>
          <CardContent className="flex flex-col items-center justify-center">
            <div className="text-4xl font-bold text-primary">
              {filteredEntries.length}
            </div>
            <p className="text-sm text-muted-foreground mt-2">
              {selectedDateRange.label}
            </p>
          </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-1 gap-6">
        {/* Mood Distribution */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center">
              <PieChart className="mr-2 h-5 w-5" />
              Mood Distribution
            </CardTitle>
            <CardDescription>
              {selectedDateRange.label}
            </CardDescription>
          </CardHeader>
          <CardContent>
            {isLoadingSummary ? (
              <div className="flex justify-center py-8">
                <Loader2 className="h-8 w-8 animate-spin text-primary" />
              </div>
            ) : moodFrequencyData.length > 0 ? (
              <div className="space-y-6">
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                  <div>
                    <h3 className="text-sm font-medium mb-3">By Frequency</h3>
                    <div className="space-y-3">
                      {moodFrequencyData
                        .sort((a, b) => b.count - a.count)
                        .map((item) => (
                          <div key={item.mood} className="flex items-center">
                            <MoodDisplay mood={item.mood} size="sm" />
                            <div className="ml-2 flex-1">
                              <div className="flex justify-between text-sm">
                                <span className="capitalize">{item.mood}</span>
                                <span className="text-muted-foreground">
                                  {item.count}× ({Math.round((item.count / moodFrequencyData.reduce((acc, curr) => acc + curr.count, 0)) * 100)}%)
                                </span>
                              </div>
                              <div className="w-full bg-muted rounded-full h-2 mt-1">
                                <div 
                                  className="bg-primary h-2 rounded-full" 
                                  style={{ 
                                    width: `${(item.count / moodFrequencyData.reduce((acc, curr) => acc + curr.count, 0)) * 100}%` 
                                  }}
                                />
                              </div>
                            </div>
                          </div>
                        ))}
                    </div>
                  </div>
                  
                  <div className="flex flex-col">
                    <h3 className="text-sm font-medium mb-3">Mood Categories</h3>
                    <div className="flex-1 grid grid-cols-2 gap-4">
                      {/* Positive Moods */}
                      <Card className="border-2 border-emerald-100">
                        <CardHeader className="pb-2 pt-4">
                          <CardTitle className="text-sm font-medium text-emerald-600">Positive Moods</CardTitle>
                        </CardHeader>
                        <CardContent>
                          <div className="text-2xl font-bold">
                            {Math.round((moodFrequencyData
                              .filter(m => ['joyful', 'grateful', 'calm', 'peaceful', 'inspired', 'loving'].includes(m.mood))
                              .reduce((acc, curr) => acc + curr.count, 0) / 
                              moodFrequencyData.reduce((acc, curr) => acc + curr.count, 0)) * 100)}%
                          </div>
                          <div className="mt-2 flex flex-wrap gap-1">
                            {['joyful', 'grateful', 'calm', 'peaceful', 'inspired', 'loving']
                              .filter(mood => moodFrequencyData.some(m => m.mood === mood))
                              .map(mood => (
                                <span key={mood} className="inline-flex items-center">
                                  <MoodDisplay mood={mood} size="sm" />
                                </span>
                              ))}
                          </div>
                        </CardContent>
                      </Card>
                      
                      {/* Negative Moods */}
                      <Card className="border-2 border-red-100">
                        <CardHeader className="pb-2 pt-4">
                          <CardTitle className="text-sm font-medium text-red-600">Challenging Moods</CardTitle>
                        </CardHeader>
                        <CardContent>
                          <div className="text-2xl font-bold">
                            {Math.round((moodFrequencyData
                              .filter(m => ['anxious', 'sad', 'angry', 'fearful', 'stressed'].includes(m.mood))
                              .reduce((acc, curr) => acc + curr.count, 0) / 
                              moodFrequencyData.reduce((acc, curr) => acc + curr.count, 0)) * 100)}%
                          </div>
                          <div className="mt-2 flex flex-wrap gap-1">
                            {['anxious', 'sad', 'angry', 'fearful', 'stressed']
                              .filter(mood => moodFrequencyData.some(m => m.mood === mood))
                              .map(mood => (
                                <span key={mood} className="inline-flex items-center">
                                  <MoodDisplay mood={mood} size="sm" />
                                </span>
                              ))}
                          </div>
                        </CardContent>
                      </Card>
                    </div>
                  </div>
                </div>
              </div>
            ) : (
              <div className="text-center py-8">
                <p className="text-muted-foreground">No mood data available for the selected period.</p>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Spiritual Insights */}
        <Card>
          <CardHeader>
            <CardTitle>Spiritual Insights</CardTitle>
            <CardDescription>
              Understanding your emotional patterns on your spiritual journey
            </CardDescription>
          </CardHeader>
          <CardContent>
            {isLoadingSummary ? (
              <div className="flex justify-center py-8">
                <Loader2 className="h-8 w-8 animate-spin text-primary" />
              </div>
            ) : moodFrequencyData.length > 0 ? (
              <div className="space-y-6">
                <div>
                  <h3 className="font-medium mb-2">Emotional Insights</h3>
                  <p className="text-sm">{getEmotionalInsights()}</p>
                </div>
                
                <Separator />
                
                <div>
                  <h3 className="font-medium mb-2">Recommended Practices</h3>
                  <ul className="list-disc pl-5 space-y-1">
                    {getRecommendedPractices().map((practice, index) => (
                      <li key={index} className="text-sm">{practice}</li>
                    ))}
                  </ul>
                </div>

                <Separator />
                
                <div>
                  <h3 className="font-medium mb-2">Reflection Prompts</h3>
                  <div className="space-y-2">
                    <p className="text-sm italic">
                      • What spiritual practices have helped most when you felt {
                          moodFrequencyData.sort((a, b) => b.count - a.count)[0]?.mood
                        }?
                    </p>
                    <p className="text-sm italic">
                      • How do your emotions relate to your spiritual progress?
                    </p>
                    <p className="text-sm italic">
                      • What patterns do you notice between your daily activities and your emotional states?
                    </p>
                  </div>
                </div>
              </div>
            ) : (
              <div className="text-center py-8">
                <p className="text-muted-foreground">Track your moods regularly to receive spiritual insights.</p>
              </div>
            )}
          </CardContent>
        </Card>
        
        {/* Recent Entries */}
        <Card>
          <CardHeader>
            <CardTitle>Recent Mood Entries</CardTitle>
            <CardDescription>
              Your most recent reflections
            </CardDescription>
          </CardHeader>
          <CardContent>
            {isLoadingEntries ? (
              <div className="flex justify-center py-8">
                <Loader2 className="h-8 w-8 animate-spin text-primary" />
              </div>
            ) : filteredEntries.length > 0 ? (
              <div className="space-y-4">
                {filteredEntries
                  .sort((a: MoodEntry, b: MoodEntry) => 
                    new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
                  )
                  .slice(0, 5)
                  .map((entry: MoodEntry) => (
                    <div key={entry.id} className="border rounded-lg p-4">
                      <div className="flex items-start gap-3">
                        <MoodDisplay mood={entry.mood} size="md" />
                        <div>
                          <div className="flex items-center gap-2">
                            <h4 className="font-medium capitalize">{entry.mood}</h4>
                            <span className="text-xs text-muted-foreground">
                              {format(new Date(entry.date), 'MMM d')} at {format(new Date(entry.createdAt), 'h:mm a')}
                            </span>
                          </div>
                          {entry.reflection ? (
                            <p className="mt-1 text-sm">{entry.reflection}</p>
                          ) : (
                            <p className="mt-1 text-sm text-muted-foreground italic">No reflection provided</p>
                          )}
                        </div>
                      </div>
                    </div>
                  ))}
              </div>
            ) : (
              <div className="text-center py-8">
                <p className="text-muted-foreground">No mood entries for the selected period.</p>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default MoodReflectionSummaryPage;