import { useEffect, useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { Card } from "@/components/ui/card";
import { Container } from "@/components/ui/container";
import { Loader2, Trophy, Award, User, Users, Calendar } from "lucide-react";
import { useAuth } from "@/contexts/AuthContext";
import { Badge } from "@/components/ui/badge";
import { format } from "date-fns";

interface LeaderData {
  id: number;
  name: string;
  xp: number;
  rank?: number;
  level: number;
  streak?: number;
  ritualStreak?: number;
  avatar?: string;
}

export default function WeeklyLeaderboardPage() {
  const { user } = useAuth();
  const [startOfWeek, endOfWeek] = useGetWeekRange();
  
  // Fetch leaderboard data
  const { data: leaders, isLoading } = useQuery<LeaderData[]>({
    queryKey: ['/api/leaderboard'],
    queryFn: () => apiRequest({
      url: '/api/leaderboard',
      method: 'GET'
    }),
  });
  
  if (isLoading) {
    return (
      <Container className="py-8">
        <div className="flex flex-col items-center justify-center min-h-[60vh]">
          <Loader2 className="h-10 w-10 animate-spin text-indigo-600 dark:text-indigo-400" />
          <p className="mt-4 text-lg font-medium text-gray-600 dark:text-gray-300">Loading leaderboard data...</p>
        </div>
      </Container>
    );
  }
  
  return (
    <Container className="py-8">
      <div className="mb-8">
        <h1 className="text-3xl font-bold mb-2 flex items-center gap-2">
          <Trophy className="h-8 w-8 text-amber-500" /> Weekly Ritual Leaderboard
        </h1>
        <p className="text-gray-500 dark:text-gray-400 mb-2">
          Top spiritual seekers for the week of {startOfWeek} - {endOfWeek}
        </p>
        <p className="text-sm text-gray-500 dark:text-gray-400">
          Complete your daily rituals to earn XP and climb the ranks!
        </p>
      </div>
      
      {!leaders || leaders.length === 0 ? (
        <Card className="p-8 text-center">
          <p className="text-lg text-gray-500 dark:text-gray-400">No leaderboard data available yet.</p>
          <p className="mt-2 text-gray-500 dark:text-gray-400">Complete some rituals to see yourself on the board!</p>
        </Card>
      ) : (
        <div className="space-y-4">
          {/* Top 3 leaders with special styling */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-8">
            {leaders.slice(0, 3).map((leader, idx) => {
              // Colors for top 3
              const colors = [
                { bg: "bg-amber-50 dark:bg-amber-900/20", border: "border-amber-200 dark:border-amber-800/30", text: "text-amber-700 dark:text-amber-300" },
                { bg: "bg-gray-50 dark:bg-gray-800/50", border: "border-gray-200 dark:border-gray-700", text: "text-gray-700 dark:text-gray-300" },
                { bg: "bg-orange-50 dark:bg-orange-900/20", border: "border-orange-200 dark:border-orange-800/30", text: "text-orange-700 dark:text-orange-300" }
              ];
              
              // Trophy emojis for top 3
              const trophies = ["🥇", "🥈", "🥉"];
              
              return (
                <Card 
                  key={leader.id} 
                  className={`overflow-hidden border-2 ${idx === 0 ? "order-2 md:scale-110 z-10" : idx === 1 ? "order-1" : "order-3"} ${colors[idx].border} ${colors[idx].bg} transition-all hover:shadow-md`}
                >
                  <div className="p-6 flex flex-col items-center">
                    <div className="text-4xl mb-3">{trophies[idx]}</div>
                    <div className="w-16 h-16 rounded-full bg-gradient-to-r from-indigo-500 to-purple-600 flex items-center justify-center text-white text-xl font-bold mb-3">
                      {leader.avatar || leader.name.charAt(0).toUpperCase()}
                    </div>
                    <h3 className={`text-xl font-bold mb-1 ${colors[idx].text}`}>{leader.name}</h3>
                    <div className="flex items-center gap-2 mb-3">
                      <Badge variant="outline" className="bg-purple-100 dark:bg-purple-900/30 border-purple-200 dark:border-purple-800/30 text-purple-700 dark:text-purple-300">
                        Level {leader.level}
                      </Badge>
                    </div>
                    <div className={`text-2xl font-bold ${colors[idx].text}`}>{leader.xp} XP</div>
                    
                    {/* Display streaks if available */}
                    {(leader.streak || leader.ritualStreak) && (
                      <div className="flex flex-wrap gap-2 mt-2 justify-center">
                        {leader.streak && (
                          <Badge className="bg-amber-100 dark:bg-amber-900/30 border-amber-200 dark:border-amber-800/30 text-amber-700 dark:text-amber-300">
                            🔥 {leader.streak} day streak
                          </Badge>
                        )}
                        {leader.ritualStreak && (
                          <Badge className="bg-indigo-100 dark:bg-indigo-900/30 border-indigo-200 dark:border-indigo-800/30 text-indigo-700 dark:text-indigo-300">
                            📆 {leader.ritualStreak} ritual days
                          </Badge>
                        )}
                      </div>
                    )}
                  </div>
                </Card>
              );
            })}
          </div>
          
          {/* Rest of the leaderboard */}
          {leaders.slice(3).map((leader, idx) => (
            <Card 
              key={leader.id}
              className={`overflow-hidden hover:border-indigo-200 dark:hover:border-indigo-800/30 transition-all ${
                leader.id === user?.id ? "border-indigo-300 dark:border-indigo-700 bg-indigo-50/50 dark:bg-indigo-900/10" : ""
              }`}
            >
              <div className="p-4 flex items-center justify-between">
                <div className="flex items-center gap-4">
                  <div className="w-10 h-10 flex items-center justify-center font-bold text-gray-500 dark:text-gray-400">
                    {idx + 4}.
                  </div>
                  <div className="w-10 h-10 rounded-full bg-gradient-to-r from-indigo-500 to-purple-600 flex items-center justify-center text-white text-sm font-bold">
                    {leader.avatar || leader.name.charAt(0).toUpperCase()}
                  </div>
                  <div>
                    <h3 className="font-semibold">{leader.name}</h3>
                    <div className="flex items-center gap-1 text-sm text-gray-500 dark:text-gray-400">
                      <Award className="h-3.5 w-3.5" />
                      <span>Level {leader.level}</span>
                    </div>
                  </div>
                </div>
                
                <div className="flex flex-col items-end">
                  <span className="font-bold text-lg text-indigo-600 dark:text-indigo-400">{leader.xp} XP</span>
                  <div className="flex flex-wrap gap-2 justify-end">
                    {leader.streak && (
                      <span className="text-xs text-amber-600 dark:text-amber-400 flex items-center">
                        🔥 {leader.streak} days
                      </span>
                    )}
                    {leader.ritualStreak && (
                      <span className="text-xs text-indigo-600 dark:text-indigo-400 flex items-center">
                        📆 {leader.ritualStreak} rituals
                      </span>
                    )}
                  </div>
                </div>
              </div>
            </Card>
          ))}
        </div>
      )}
      
      {/* Information card */}
      <Card className="mt-8 p-6 bg-gradient-to-r from-indigo-50 to-purple-50 dark:from-indigo-900/30 dark:to-purple-900/30 border-indigo-100 dark:border-indigo-800/30">
        <div className="flex flex-col md:flex-row gap-6">
          <div className="flex-1">
            <h3 className="text-lg font-semibold mb-2 flex items-center gap-2">
              <Trophy className="h-5 w-5 text-amber-500" /> How the Leaderboard Works
            </h3>
            <ul className="space-y-2 text-sm">
              <li className="flex items-start gap-2">
                <span className="text-indigo-600 dark:text-indigo-400">•</span>
                <span>Leaderboard resets every Monday at midnight</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-indigo-600 dark:text-indigo-400">•</span>
                <span>Earn <b>+50 XP</b> for each completed daily ritual</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-indigo-600 dark:text-indigo-400">•</span>
                <span>Earn <b>+100 XP</b> for each meditation session</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-indigo-600 dark:text-indigo-400">•</span>
                <span>Weekly winners receive special badges in their profile</span>
              </li>
            </ul>
          </div>
          
          <div className="flex-1">
            <h3 className="text-lg font-semibold mb-2 flex items-center gap-2">
              <Award className="h-5 w-5 text-purple-500" /> Weekly Rewards
            </h3>
            <ul className="space-y-2 text-sm">
              <li className="flex items-start gap-2">
                <span className="text-indigo-600 dark:text-indigo-400">•</span>
                <span><b>1st Place:</b> 500 bonus XP + "Spiritual Champion" badge</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-indigo-600 dark:text-indigo-400">•</span>
                <span><b>2nd Place:</b> 300 bonus XP + "Spiritual Devotee" badge</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-indigo-600 dark:text-indigo-400">•</span>
                <span><b>3rd Place:</b> 200 bonus XP + "Spiritual Aspirant" badge</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-indigo-600 dark:text-indigo-400">•</span>
                <span><b>Top 10:</b> Recognition on the Hall of Fame board</span>
              </li>
            </ul>
          </div>
        </div>
      </Card>
    </Container>
  );
}

function useGetWeekRange() {
  const [weekRange, setWeekRange] = useState<string[]>(['', '']);
  
  useEffect(() => {
    const now = new Date();
    const dayOfWeek = now.getDay(); // 0 is Sunday, 1 is Monday, etc.
    
    // Calculate the start of the week (Monday)
    const startOfWeek = new Date(now);
    const daysFromMonday = dayOfWeek === 0 ? 6 : dayOfWeek - 1;
    startOfWeek.setDate(now.getDate() - daysFromMonday);
    
    // Calculate the end of the week (Sunday)
    const endOfWeek = new Date(startOfWeek);
    endOfWeek.setDate(startOfWeek.getDate() + 6);
    
    // Format as readable dates
    const startStr = format(startOfWeek, 'MMM d');
    const endStr = format(endOfWeek, 'MMM d, yyyy');
    
    setWeekRange([startStr, endStr]);
  }, []);
  
  return weekRange;
}