import { useState, useEffect, useRef } from 'react';
import { useQuery, useMutation } from '@tanstack/react-query';
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { ChakraType, chakras as chakraData } from "@/lib/chakras";
import { Loader2, Play, Pause, SkipForward, Square, PersonStanding, Sparkles, Flame } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/contexts/AuthContext";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { AudioGenerator } from "@/components/chakras/AudioGenerator";
import ChakraCelebration from "@/components/chakras/ChakraCelebration";
import { useChakras } from "@/contexts/ChakraContext";
import { updateDailyStreak } from "@/services/streakService";
import { completeMeditation } from "@/services/missionService";

interface MeditationTrack {
  id: number;
  title: string;
  description?: string | null;
  duration?: number;
  durationSeconds?: number;
  chakra_type?: string;
  chakraType?: string;
  audio_url?: string | null;
  audioUrl?: string | null;
  image_url?: string | null;
  imageUrl?: string | null;
  frequency?: string;
}

export default function ChakraMeditationPage() {
  const { user } = useAuth();
  const { toast } = useToast();
  const { chakras, activateChakra } = useChakras();
  const [activeChakra, setActiveChakra] = useState<ChakraType>("root");
  const [activeMeditation, setActiveMeditation] = useState<MeditationTrack | null>(null);
  const [isPlaying, setIsPlaying] = useState(false);
  const [progress, setProgress] = useState(0);
  const [xpEarned, setXpEarned] = useState(0);
  const audioRef = useRef<HTMLAudioElement | null>(null);
  const progressInterval = useRef<NodeJS.Timeout | null>(null);
  
  // Celebration states
  const [showCelebration, setShowCelebration] = useState(false);
  const [unlockedChakraName, setUnlockedChakraName] = useState('');
  const [unlockedChakraType, setUnlockedChakraType] = useState<ChakraType>("root");

  // Fetch all meditation tracks
  const { data: allMeditationTracks, isLoading: tracksLoading } = useQuery({
    queryKey: ['/api/meditation-tracks'],
    queryFn: () => apiRequest<MeditationTrack[]>({ 
      url: `/api/meditation-tracks`, 
      method: 'GET' 
    })
  });
  
  // Filter tracks for current chakra
  const meditationTracks = allMeditationTracks?.filter(
    track => track.chakra_type === activeChakra || track.chakraType === activeChakra
  ) || [];

  // Mutation for earning XP
  const earnXpMutation = useMutation({
    mutationFn: (xpAmount: number) => apiRequest({
      url: `/api/users/${user?.id}/xp`,
      method: 'POST',
      body: { amount: xpAmount }
    }),
    onSuccess: () => {
      toast({
        title: "XP Earned!",
        description: `You've earned ${activeMeditation?.duration || 0} XP from your meditation.`,
      });
      // Invalidate user data query to refresh XP display across the app
      queryClient.invalidateQueries({ queryKey: ['/api/users', user?.id] });
    }
  });

  // Handle chakra tab change
  const handleChakraChange = (value: string) => {
    // Stop current meditation if playing
    if (isPlaying) {
      handleStop();
    }
    setActiveChakra(value as ChakraType);
    setActiveMeditation(null);
  };

  // Start meditation
  const handleStartMeditation = (meditation: MeditationTrack) => {
    // Ensure the meditation has a duration for XP calculation
    const fixedMeditation = {
      ...meditation,
      duration: meditation.duration || meditation.durationSeconds || 60
    };
    
    setActiveMeditation(fixedMeditation);
    setProgress(0);
    setIsPlaying(true);
    
    if (audioRef.current) {
      audioRef.current.src = meditation.audio_url || meditation.audioUrl || "";
      audioRef.current.play().catch(error => {
        console.error("Error playing audio:", error);
        toast({
          title: "Playback Error",
          description: "There was an error playing this meditation track.",
          variant: "destructive",
        });
      });
    }

    // Set up progress tracking
    if (progressInterval.current) {
      clearInterval(progressInterval.current);
    }

    progressInterval.current = setInterval(() => {
      if (audioRef.current) {
        const currentProgress = (audioRef.current.currentTime / audioRef.current.duration) * 100;
        setProgress(currentProgress);
      }
    }, 1000);
  };

  // Toggle play/pause
  const handlePlayPause = () => {
    if (!activeMeditation) return;

    if (isPlaying) {
      audioRef.current?.pause();
    } else {
      audioRef.current?.play();
    }
    setIsPlaying(!isPlaying);
  };

  // Stop meditation
  const handleStop = () => {
    if (audioRef.current) {
      audioRef.current.pause();
      audioRef.current.currentTime = 0;
    }
    
    if (progressInterval.current) {
      clearInterval(progressInterval.current);
      progressInterval.current = null;
    }
    
    setIsPlaying(false);
    setProgress(0);
  };

  // Handle meditation completion
  const handleMeditationComplete = async () => {
    // Award XP based on meditation duration
    const xpAmount = activeMeditation?.duration || 0;
    setXpEarned(prev => prev + xpAmount);
    
    // Call API to update user XP
    if (user?.id && xpAmount > 0) {
      // First, the regular XP for meditation duration
      earnXpMutation.mutate(xpAmount);
      
      // Second, attempt to complete daily mission for bonus XP
      try {
        // Complete meditation mission (awards 100 XP if first meditation of the day)
        const missionResult = await completeMeditation(user.id, activeChakra);
        
        // Update daily meditation streak
        const streak = await updateDailyStreak(user.id);
        
        // Prepare notification message
        let streakMessage = streak > 1 ? `${streak} day streak! ` : '';
        let missionMessage = missionResult.xpAwarded && missionResult.xpAwarded > 0 ? 
          `Daily mission completed: +${missionResult.xpAwarded} bonus XP! ` : '';
        
        // Full message with streak + mission + base XP
        const fullDescription = `${streakMessage}${missionMessage}You've earned ${xpAmount} XP from your meditation session!`;
        
        // Show completion message
        toast({
          title: "Meditation Completed",
          description: fullDescription,
        });
        
        // If mission awarded bonus XP, add it to the display total
        if (missionResult.xpAwarded && missionResult.xpAwarded > 0) {
          setXpEarned(prev => prev + missionResult.xpAwarded);
        }
        
        // Check if a weekly streak bonus was achieved
        if (missionResult.weeklyStreakAchieved) {
          // Award weekly streak bonus (500 XP is handled by the backend)
          setTimeout(() => {
            toast({
              title: "🏆 Weekly Streak Achievement!",
              description: "You've completed 7 consecutive days of meditation! +500 XP bonus and '7-Day Meditation Warrior' Badge Unlocked!",
              variant: "default",
              duration: 6000,
            });
            
            // Refresh user data to show updated XP and badges
            queryClient.invalidateQueries({ queryKey: ['/api/users', user.id] });
            
            // Add the weekly streak bonus to the displayed XP
            setXpEarned(prev => prev + 500);
          }, 1500);
        }
      } catch (error) {
        console.error("Error with mission or streak:", error);
        
        // Still show basic completion message if updates fail
        toast({
          title: "Meditation Completed",
          description: `You've earned ${xpAmount} XP! Congratulations on completing your meditation practice!`,
        });
      }
      
      // Try to activate chakra for the first time if enough XP earned
      if (xpEarned >= 300) {
        try {
          // Find the chakra information
          const currentChakraInfo = chakraData.find(c => c.id === activeChakra);
          
          // Only show celebration if this chakra wasn't already active
          if (currentChakraInfo && !chakras[activeChakra]) {
            // Activate the chakra
            await activateChakra(activeChakra);
            
            // Set celebration properties
            setUnlockedChakraName(currentChakraInfo.name);
            setUnlockedChakraType(activeChakra);
            setShowCelebration(true);
            
            // Award bonus XP for unlocking a new chakra
            const bonusXP = 500;
            setTimeout(() => {
              earnXpMutation.mutate(bonusXP);
              setXpEarned(prev => prev + bonusXP);
            }, 1500);
          }
        } catch (error) {
          console.error("Error activating chakra:", error);
        }
      }
      
      // If user completes a full chakra meditation session, offer bonus XP
      if (xpEarned >= 1000) {
        // Award bonus XP
        const bonusXP = 500;
        setTimeout(() => {
          earnXpMutation.mutate(bonusXP);
          toast({
            title: "Chakra Master Bonus!",
            description: `For your dedication to spiritual practice, you've earned a ${bonusXP} XP bonus!`,
            variant: "default",
          });
          setXpEarned(prev => prev + bonusXP);
        }, 1500);
      }
    }
    
    // Reset player
    handleStop();
  };
  
  // Handle closing the celebration
  const handleCloseCelebration = () => {
    setShowCelebration(false);
  };

  // Clean up on unmount
  useEffect(() => {
    return () => {
      if (progressInterval.current) {
        clearInterval(progressInterval.current);
      }
      if (audioRef.current) {
        audioRef.current.pause();
      }
    };
  }, []);

  // Get chakra color
  const getChakraColor = (type: ChakraType): string => {
    switch (type) {
      case "root": return "bg-red-500";
      case "sacral": return "bg-orange-500";
      case "solar": return "bg-yellow-400";
      case "heart": return "bg-green-500";
      case "throat": return "bg-blue-500";
      case "thirdEye": return "bg-indigo-500";
      case "crown": return "bg-purple-600";
      default: return "bg-gray-400";
    }
  };

  return (
    <div className="container py-8 px-4 sm:px-6 lg:px-8 max-w-6xl mx-auto relative">
      {/* Chakra Celebration */}
      {showCelebration && (
        <ChakraCelebration
          chakraName={unlockedChakraName}
          chakraType={unlockedChakraType}
          onClose={handleCloseCelebration}
        />
      )}
      
      {/* Hero Section */}
      <div className="relative mb-12 rounded-xl bg-gradient-to-r from-purple-600/30 to-indigo-600/30 dark:from-purple-900/30 dark:to-indigo-900/30 p-8 overflow-hidden">
        <div className="absolute inset-0 opacity-5 bg-[url('data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNjAiIGhlaWdodD0iNjAiIHZpZXdCb3g9IjAgMCA2MCA2MCIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48ZyBmaWxsPSJub25lIiBmaWxsLXJ1bGU9ImV2ZW5vZGQiPjxnIGZpbGw9IiM5MzNFQ0MiIGZpbGwtb3BhY2l0eT0iMC40Ij48cGF0aCBkPSJNMzYgMzRjMC0yLjIxLTEuNzktNC00LTRzLTQgMS43OS00IDQgMS43OSA0IDQgNCA0LTEuNzkgNC00ek0zMCAwQzEzLjQzIDAgMCAxMy40MyAwIDMwczEzLjQzIDMwIDMwIDMwIDMwLTEzLjQzIDMwLTMwUzQ2LjU3IDAgMzAgMHptMCA1MmMtMTIuMTUgMC0yMi05Ljg1LTIyLTIyczkuODUtMjIgMjItMjIgMjIgOS44NSAyMiAyMi05Ljg1IDIyLTIyIDIyeiI+PC9wYXRoPjwvZz48L2c+PC9zdmc+')]"></div>
        <div className="relative z-10 text-center">
          <h1 className="text-4xl font-bold mb-3 bg-clip-text text-transparent bg-gradient-to-r from-purple-600 to-indigo-600 dark:from-purple-400 dark:to-indigo-400 flex items-center justify-center gap-3">
            <PersonStanding className="h-10 w-10" />
            <span>Chakra Meditation Journey</span>
          </h1>
          <p className="text-lg text-gray-700 dark:text-gray-300 max-w-2xl mx-auto">
            Balance your energy centers with guided meditation practices
          </p>
        </div>
      </div>

      {/* XP Earned Display */}
      {xpEarned > 0 && (
        <div className="bg-gradient-to-r from-indigo-50 to-purple-50 dark:from-indigo-900/30 dark:to-purple-900/30 p-6 rounded-lg shadow-sm mb-8 text-center border border-indigo-100 dark:border-indigo-800 animate-pulse">
          <h2 className="text-xl font-semibold text-indigo-600 dark:text-indigo-400 flex items-center justify-center gap-2">
            <Sparkles className="h-6 w-6" /> Today's Meditation XP: {xpEarned} <Sparkles className="h-6 w-6" />
          </h2>
        </div>
      )}
      
      {/* Chakra Selection Tabs */}
      <div className="bg-white dark:bg-gray-900 rounded-lg shadow-md p-6 mb-8">
        <Tabs defaultValue="root" onValueChange={handleChakraChange} className="w-full">
          <TabsList className="grid grid-cols-7 w-full mb-6 bg-gray-100 dark:bg-gray-800 p-1 rounded-lg">
            {chakraData.map((chakra) => (
              <TabsTrigger 
                key={chakra.id} 
                value={chakra.id}
                className="flex flex-col items-center py-3"
              >
                <div className={`w-6 h-6 rounded-full ${getChakraColor(chakra.id)} mb-2 shadow-inner`}></div>
                <span className="hidden md:inline text-xs">{chakra.name}</span>
              </TabsTrigger>
            ))}
          </TabsList>
          
          {chakraData.map((chakra) => (
            <TabsContent key={chakra.id} value={chakra.id} className="pt-4">
              <div className="text-center mb-8 bg-gradient-to-r from-gray-50 to-white dark:from-gray-800 dark:to-gray-900 p-6 rounded-lg shadow-sm border border-gray-100 dark:border-gray-800">
                <div className={`w-16 h-16 rounded-full ${getChakraColor(chakra.id)} mb-4 mx-auto flex items-center justify-center`}>
                  <div className="w-8 h-8 bg-white dark:bg-gray-900 rounded-full opacity-30 animate-pulse"></div>
                </div>
                <h2 className="text-2xl font-bold mb-2">{chakra.name} Meditation</h2>
                <p className="text-md text-indigo-600 dark:text-indigo-400 mb-2 font-medium">
                  Frequency: {chakra.frequency}
                </p>
                <div className="bg-gray-50 dark:bg-gray-800 p-3 rounded-md inline-block">
                  <p className="italic text-gray-700 dark:text-gray-300">"{chakra.affirmation}"</p>
                </div>
              </div>
              
              {/* Audio Player */}
              {activeMeditation && (
                <Card className="mb-8 border-2 border-indigo-100 dark:border-indigo-900 overflow-hidden">
                  <div className={`h-2 ${getChakraColor(activeChakra)} w-full`}></div>
                  <CardContent className="py-6 px-6">
                    <div className="flex flex-col items-center">
                      <h3 className="text-xl font-semibold mb-4 text-center">{activeMeditation.title}</h3>
                      
                      {/* Progress Bar */}
                      <div className="w-full mb-6 px-4">
                        <div className="text-right text-sm mb-1 text-gray-500">
                          {Math.round(progress)}%
                        </div>
                        <Progress value={progress} className="h-3 rounded-full" />
                      </div>
                      
                      {/* Player Controls */}
                      <div className="flex items-center justify-center gap-6 mb-4">
                        <Button 
                          variant="outline" 
                          size="icon"
                          className="w-12 h-12 rounded-full border-2"
                          onClick={handleStop}
                        >
                          <Square className="h-5 w-5" />
                        </Button>
                        
                        <Button 
                          variant={isPlaying ? "default" : "outline"}
                          size="icon"
                          className={`w-16 h-16 rounded-full border-2 ${isPlaying ? getChakraColor(activeChakra) : ''}`}
                          onClick={handlePlayPause}
                        >
                          {isPlaying ? 
                            <Pause className="h-8 w-8 text-white" /> : 
                            <Play className="h-8 w-8" />
                          }
                        </Button>
                        
                        <Button 
                          variant="outline" 
                          size="icon"
                          className="w-12 h-12 rounded-full border-2"
                          onClick={handleMeditationComplete}
                        >
                          <SkipForward className="h-5 w-5" />
                        </Button>
                      </div>
                      
                      <div className="flex items-center justify-center space-x-4 text-sm text-gray-600 dark:text-gray-400 mt-2 bg-gray-50 dark:bg-gray-800 rounded-lg px-4 py-2">
                        <div className="flex items-center">
                          <span className="font-medium mr-1">Duration:</span> {activeMeditation.duration || 0} seconds
                        </div>
                        <div className="w-1 h-1 bg-gray-300 dark:bg-gray-600 rounded-full"></div>
                        <div className="flex items-center">
                          <span className="font-medium mr-1">XP:</span> {activeMeditation.duration || 0} points
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              )}
              
              {/* Audio generation - hidden elements */}
              {isPlaying && activeMeditation && (
                <>
                  {/* Fallback audio element for audio files (hidden) */}
                  <audio 
                    ref={audioRef} 
                    onEnded={handleMeditationComplete}
                    className="hidden"
                  />
                  
                  {/* Audio generator for frequencies */}
                  {activeChakra === "root" && (
                    <AudioGenerator
                      frequency={396}
                      isPlaying={isPlaying}
                      onEnded={handleMeditationComplete}
                      duration={activeMeditation.duration}
                      gain={0.3}
                    />
                  )}
                  {activeChakra === "sacral" && (
                    <AudioGenerator
                      frequency={417}
                      isPlaying={isPlaying}
                      onEnded={handleMeditationComplete}
                      duration={activeMeditation.duration}
                      gain={0.3}
                    />
                  )}
                  {activeChakra === "solar" && (
                    <AudioGenerator
                      frequency={528}
                      isPlaying={isPlaying}
                      onEnded={handleMeditationComplete}
                      duration={activeMeditation.duration}
                      gain={0.3}
                    />
                  )}
                  {activeChakra === "heart" && (
                    <AudioGenerator
                      frequency={639}
                      isPlaying={isPlaying}
                      onEnded={handleMeditationComplete}
                      duration={activeMeditation.duration}
                      gain={0.3}
                    />
                  )}
                  {activeChakra === "throat" && (
                    <AudioGenerator
                      frequency={741}
                      isPlaying={isPlaying}
                      onEnded={handleMeditationComplete}
                      duration={activeMeditation.duration}
                      gain={0.3}
                    />
                  )}
                  {activeChakra === "thirdEye" && (
                    <AudioGenerator
                      frequency={852}
                      isPlaying={isPlaying}
                      onEnded={handleMeditationComplete}
                      duration={activeMeditation.duration}
                      gain={0.3}
                    />
                  )}
                  {activeChakra === "crown" && (
                    <AudioGenerator
                      frequency={963}
                      isPlaying={isPlaying}
                      onEnded={handleMeditationComplete}
                      duration={activeMeditation.duration}
                      gain={0.3}
                    />
                  )}
                </>
              )}
              
              {/* Meditation Selection Section Heading */}
              <div className="flex items-center justify-between mb-6">
                <h3 className="text-lg font-medium">Meditation Tracks</h3>
                <div className="text-sm text-gray-500 dark:text-gray-400">Choose a meditation practice</div>
              </div>
              
              {/* Meditation track selection */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {tracksLoading ? (
                  <div className="col-span-full flex justify-center py-12">
                    <Loader2 className="h-10 w-10 animate-spin text-primary" />
                  </div>
                ) : !meditationTracks || meditationTracks.length === 0 ? (
                  <div className="col-span-full text-center py-12 bg-gray-50 dark:bg-gray-800 rounded-lg">
                    <p className="text-gray-500 dark:text-gray-400">No meditation tracks found for this chakra.</p>
                  </div>
                ) : (
                  meditationTracks.map((track) => (
                    <Card 
                      key={track.id}
                      className={`cursor-pointer hover:shadow-lg transition-all overflow-hidden ${
                        activeMeditation?.id === track.id ? `border-2 ${getChakraColor(activeChakra)}` : 'border border-gray-200 dark:border-gray-700'
                      }`}
                      onClick={() => handleStartMeditation({
                        ...track,
                        // Ensure duration is set for XP calculation
                        duration: track.duration || track.durationSeconds || 60
                      })}
                    >
                      <CardContent className="p-0">
                        <div className="flex items-center p-4">
                          <div className={`w-14 h-14 rounded-full flex items-center justify-center ${getChakraColor(activeChakra)} shadow-lg mr-4`}>
                            <Play className="h-6 w-6 text-white" />
                          </div>
                          <div className="flex-1">
                            <h3 className="font-medium text-lg">{track.title}</h3>
                            <div className="flex items-center text-sm text-gray-600 dark:text-gray-400 mt-1">
                              <span className="rounded bg-gray-100 dark:bg-gray-800 px-2 py-0.5">
                                {track.duration || track.durationSeconds || 60} seconds
                              </span>
                              {track.frequency && (
                                <span className="ml-2 text-indigo-600 dark:text-indigo-400 text-xs">
                                  {track.frequency}
                                </span>
                              )}
                            </div>
                            {track.description && (
                              <p className="text-xs mt-2 text-gray-500 line-clamp-2">
                                {track.description}
                              </p>
                            )}
                          </div>
                        </div>
                        <div className={`h-1 w-full ${getChakraColor(activeChakra)}`}></div>
                      </CardContent>
                    </Card>
                  ))
                )}
              </div>
            </TabsContent>
          ))}
        </Tabs>
      </div>
    </div>
  );
}