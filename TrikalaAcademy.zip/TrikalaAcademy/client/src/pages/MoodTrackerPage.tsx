import React, { useState, useEffect } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { useAuth } from '@/hooks/use-auth';
import { useToast } from '@/hooks/use-toast';
import { Button } from '@/components/ui/button';
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from '@/components/ui/card';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Loader2, PlusCircle, Calendar, BarChart, Edit, Trash2 } from 'lucide-react';
import { format, parseISO, isValid, isToday, startOfWeek, endOfWeek, formatISO, subDays } from 'date-fns';
import { MoodEntry } from '@/lib/types';
import { apiRequest } from '@/lib/queryClient';

type MoodDisplayProps = {
  mood: string;
  size?: 'sm' | 'md' | 'lg';
};

const MoodDisplay = ({ mood, size = 'md' }: MoodDisplayProps) => {
  const moodEmojis: Record<string, string> = {
    joyful: '😄',
    grateful: '🙏',
    calm: '😌',
    neutral: '😐',
    anxious: '😟',
    sad: '😢',
    angry: '😠',
    fearful: '😨',
    stressed: '😰',
    peaceful: '🧘',
    inspired: '✨',
    loving: '❤️',
  };

  const sizeClasses = {
    sm: 'text-xl',
    md: 'text-3xl',
    lg: 'text-5xl',
  };

  return (
    <span className={`${sizeClasses[size]} inline-block`}>
      {moodEmojis[mood] || '❓'}
    </span>
  );
};

const MoodTrackerPage: React.FC = () => {
  const { user } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [activeTab, setActiveTab] = useState('today');
  const [isAddMoodOpen, setIsAddMoodOpen] = useState(false);
  const [isEditMoodOpen, setIsEditMoodOpen] = useState(false);
  const [newMood, setNewMood] = useState('');
  const [newReflection, setNewReflection] = useState('');
  const [selectedEntry, setSelectedEntry] = useState<MoodEntry | null>(null);
  const [editMood, setEditMood] = useState('');
  const [editReflection, setEditReflection] = useState('');
  const [dateRange, setDateRange] = useState({
    start: formatISO(startOfWeek(new Date()), { representation: 'date' }),
    end: formatISO(endOfWeek(new Date()), { representation: 'date' }),
  });

  const today = formatISO(new Date(), { representation: 'date' });
  const last7Days = formatISO(subDays(new Date(), 6), { representation: 'date' });

  // Fetch all mood entries
  const { data: allEntries, isLoading: isLoadingEntries } = useQuery({
    queryKey: ['/api/users', user?.id, 'mood-entries'],
    queryFn: async () => {
      if (!user) return [];
      const res = await apiRequest('GET', `/api/users/${user.id}/mood-entries`);
      return await res.json();
    },
    enabled: !!user,
  });

  // Fetch mood summary for the last 7 days
  const { data: moodSummary, isLoading: isLoadingSummary } = useQuery({
    queryKey: ['/api/users', user?.id, 'mood-summary', dateRange.start, dateRange.end],
    queryFn: async () => {
      if (!user) return [];
      const res = await apiRequest(
        'GET', 
        `/api/users/${user.id}/mood-summary?startDate=${dateRange.start}&endDate=${dateRange.end}`
      );
      return await res.json();
    },
    enabled: !!user,
  });

  // Create mood entry mutation
  const createMoodMutation = useMutation({
    mutationFn: async (data: { mood: string; reflection: string }) => {
      if (!user) throw new Error('User not authenticated');
      
      const res = await apiRequest('POST', `/api/users/${user.id}/mood-entries`, {
        mood: data.mood,
        reflection: data.reflection,
        date: today,
        userId: user.id,
      });
      
      return await res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/users', user?.id, 'mood-entries'] });
      queryClient.invalidateQueries({ 
        queryKey: ['/api/users', user?.id, 'mood-summary', dateRange.start, dateRange.end] 
      });
      
      toast({
        title: 'Mood tracked!',
        description: 'Your mood has been recorded successfully. +20 XP',
      });
      
      setIsAddMoodOpen(false);
      setNewMood('');
      setNewReflection('');
    },
    onError: (error) => {
      toast({
        title: 'Error tracking mood',
        description: error instanceof Error ? error.message : 'Something went wrong',
        variant: 'destructive',
      });
    },
  });

  // Update mood entry mutation
  const updateMoodMutation = useMutation({
    mutationFn: async (data: { entryId: number; mood: string; reflection: string }) => {
      if (!user) throw new Error('User not authenticated');
      
      const res = await apiRequest('PATCH', `/api/users/${user.id}/mood-entries/${data.entryId}`, {
        mood: data.mood,
        reflection: data.reflection,
      });
      
      return await res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/users', user?.id, 'mood-entries'] });
      queryClient.invalidateQueries({ 
        queryKey: ['/api/users', user?.id, 'mood-summary', dateRange.start, dateRange.end] 
      });
      
      toast({
        title: 'Mood updated',
        description: 'Your mood entry has been updated successfully.',
      });
      
      setIsEditMoodOpen(false);
      setSelectedEntry(null);
      setEditMood('');
      setEditReflection('');
    },
    onError: (error) => {
      toast({
        title: 'Error updating mood',
        description: error instanceof Error ? error.message : 'Something went wrong',
        variant: 'destructive',
      });
    },
  });

  // Delete mood entry mutation
  const deleteMoodMutation = useMutation({
    mutationFn: async (entryId: number) => {
      if (!user) throw new Error('User not authenticated');
      
      const res = await apiRequest('DELETE', `/api/users/${user.id}/mood-entries/${entryId}`);
      return await res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/users', user?.id, 'mood-entries'] });
      queryClient.invalidateQueries({ 
        queryKey: ['/api/users', user?.id, 'mood-summary', dateRange.start, dateRange.end] 
      });
      
      toast({
        title: 'Mood deleted',
        description: 'Your mood entry has been deleted successfully.',
      });
    },
    onError: (error) => {
      toast({
        title: 'Error deleting mood',
        description: error instanceof Error ? error.message : 'Something went wrong',
        variant: 'destructive',
      });
    },
  });

  const handleCreateMood = () => {
    if (!newMood) {
      toast({
        title: 'Please select a mood',
        variant: 'destructive',
      });
      return;
    }
    
    createMoodMutation.mutate({
      mood: newMood,
      reflection: newReflection,
    });
  };

  const handleUpdateMood = () => {
    if (!selectedEntry || !editMood) return;
    
    updateMoodMutation.mutate({
      entryId: selectedEntry.id,
      mood: editMood,
      reflection: editReflection,
    });
  };

  const handleDeleteMood = (entryId: number) => {
    if (window.confirm('Are you sure you want to delete this mood entry?')) {
      deleteMoodMutation.mutate(entryId);
    }
  };

  const handleEditClick = (entry: MoodEntry) => {
    setSelectedEntry(entry);
    setEditMood(entry.mood);
    setEditReflection(entry.reflection || '');
    setIsEditMoodOpen(true);
  };

  // Filter entries based on active tab
  const filteredEntries = allEntries?.filter((entry: MoodEntry) => {
    if (activeTab === 'today') {
      return isToday(new Date(entry.date));
    } else if (activeTab === 'week') {
      const entryDate = new Date(entry.date);
      return entryDate >= new Date(last7Days) && entryDate <= new Date();
    }
    return true;
  });

  // Generate mood frequency data for chart
  const moodFrequencyData = moodSummary || [];

  return (
    <div className="container py-10 max-w-6xl mx-auto">
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between mb-6">
        <div>
          <h1 className="text-3xl font-bold text-primary">Mood Tracker</h1>
          <p className="text-muted-foreground">Track your emotions and reflect on your spiritual journey</p>
        </div>
        <Dialog open={isAddMoodOpen} onOpenChange={setIsAddMoodOpen}>
          <DialogTrigger asChild>
            <Button className="mt-4 sm:mt-0" size="lg">
              <PlusCircle className="mr-2 h-4 w-4" />
              Track Today's Mood
            </Button>
          </DialogTrigger>
          <DialogContent className="sm:max-w-[425px]">
            <DialogHeader>
              <DialogTitle>Track Your Mood</DialogTitle>
              <DialogDescription>
                How are you feeling today? Tracking your emotional state helps develop awareness.
              </DialogDescription>
            </DialogHeader>
            <div className="grid gap-4 py-4">
              <div className="grid grid-cols-1 gap-2">
                <Label htmlFor="mood">Select your mood</Label>
                <Select value={newMood} onValueChange={setNewMood}>
                  <SelectTrigger id="mood">
                    <SelectValue placeholder="How are you feeling?" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="joyful">Joyful 😄</SelectItem>
                    <SelectItem value="grateful">Grateful 🙏</SelectItem>
                    <SelectItem value="calm">Calm 😌</SelectItem>
                    <SelectItem value="neutral">Neutral 😐</SelectItem>
                    <SelectItem value="anxious">Anxious 😟</SelectItem>
                    <SelectItem value="sad">Sad 😢</SelectItem>
                    <SelectItem value="angry">Angry 😠</SelectItem>
                    <SelectItem value="fearful">Fearful 😨</SelectItem>
                    <SelectItem value="stressed">Stressed 😰</SelectItem>
                    <SelectItem value="peaceful">Peaceful 🧘</SelectItem>
                    <SelectItem value="inspired">Inspired ✨</SelectItem>
                    <SelectItem value="loving">Loving ❤️</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="grid grid-cols-1 gap-2">
                <Label htmlFor="reflection">Reflection (optional)</Label>
                <Textarea
                  id="reflection"
                  placeholder="What thoughts or events led to this emotion?"
                  value={newReflection}
                  onChange={(e) => setNewReflection(e.target.value)}
                  rows={4}
                />
              </div>
            </div>
            <DialogFooter>
              <Button
                onClick={handleCreateMood}
                disabled={createMoodMutation.isPending || !newMood}
              >
                {createMoodMutation.isPending && (
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                )}
                Save Mood
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>

        {/* Edit Mood Dialog */}
        <Dialog open={isEditMoodOpen} onOpenChange={setIsEditMoodOpen}>
          <DialogContent className="sm:max-w-[425px]">
            <DialogHeader>
              <DialogTitle>Edit Mood Entry</DialogTitle>
              <DialogDescription>
                Update your mood entry from {selectedEntry ? format(new Date(selectedEntry.date), 'PPP') : ''}
              </DialogDescription>
            </DialogHeader>
            <div className="grid gap-4 py-4">
              <div className="grid grid-cols-1 gap-2">
                <Label htmlFor="edit-mood">Select your mood</Label>
                <Select value={editMood} onValueChange={setEditMood}>
                  <SelectTrigger id="edit-mood">
                    <SelectValue placeholder="How were you feeling?" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="joyful">Joyful 😄</SelectItem>
                    <SelectItem value="grateful">Grateful 🙏</SelectItem>
                    <SelectItem value="calm">Calm 😌</SelectItem>
                    <SelectItem value="neutral">Neutral 😐</SelectItem>
                    <SelectItem value="anxious">Anxious 😟</SelectItem>
                    <SelectItem value="sad">Sad 😢</SelectItem>
                    <SelectItem value="angry">Angry 😠</SelectItem>
                    <SelectItem value="fearful">Fearful 😨</SelectItem>
                    <SelectItem value="stressed">Stressed 😰</SelectItem>
                    <SelectItem value="peaceful">Peaceful 🧘</SelectItem>
                    <SelectItem value="inspired">Inspired ✨</SelectItem>
                    <SelectItem value="loving">Loving ❤️</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="grid grid-cols-1 gap-2">
                <Label htmlFor="edit-reflection">Reflection (optional)</Label>
                <Textarea
                  id="edit-reflection"
                  placeholder="What thoughts or events led to this emotion?"
                  value={editReflection}
                  onChange={(e) => setEditReflection(e.target.value)}
                  rows={4}
                />
              </div>
            </div>
            <DialogFooter>
              <Button
                onClick={handleUpdateMood}
                disabled={updateMoodMutation.isPending || !editMood}
              >
                {updateMoodMutation.isPending && (
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                )}
                Update Mood
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>

      <Tabs defaultValue="today" value={activeTab} onValueChange={setActiveTab} className="w-full">
        <TabsList className="grid w-full grid-cols-3 mb-8">
          <TabsTrigger value="today">
            Today
          </TabsTrigger>
          <TabsTrigger value="week">
            Past Week
          </TabsTrigger>
          <TabsTrigger value="all">
            All Entries
          </TabsTrigger>
        </TabsList>

        <TabsContent value="today" className="mt-0">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <Calendar className="mr-2 h-5 w-5" />
                Today's Mood
              </CardTitle>
              <CardDescription>
                {format(new Date(), 'EEEE, MMMM do, yyyy')}
              </CardDescription>
            </CardHeader>
            <CardContent>
              {isLoadingEntries ? (
                <div className="flex justify-center py-8">
                  <Loader2 className="h-8 w-8 animate-spin text-primary" />
                </div>
              ) : filteredEntries?.length > 0 ? (
                <div className="space-y-4">
                  {filteredEntries.map((entry: MoodEntry) => (
                    <div 
                      key={entry.id} 
                      className="flex items-start justify-between border rounded-lg p-4"
                    >
                      <div className="flex items-start gap-4">
                        <div className="flex-shrink-0">
                          <MoodDisplay mood={entry.mood} size="lg" />
                        </div>
                        <div>
                          <h3 className="font-medium capitalize">{entry.mood}</h3>
                          <p className="text-sm text-muted-foreground">
                            {format(new Date(entry.createdAt), 'h:mm a')}
                          </p>
                          {entry.reflection && (
                            <p className="mt-2 text-sm">{entry.reflection}</p>
                          )}
                        </div>
                      </div>
                      <div className="flex space-x-2">
                        <Button 
                          size="icon" 
                          variant="ghost" 
                          onClick={() => handleEditClick(entry)}
                        >
                          <Edit className="h-4 w-4" />
                        </Button>
                        <Button 
                          size="icon" 
                          variant="ghost" 
                          onClick={() => handleDeleteMood(entry.id)}
                          disabled={deleteMoodMutation.isPending}
                        >
                          <Trash2 className="h-4 w-4 text-destructive" />
                        </Button>
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="text-center py-8">
                  <p className="text-muted-foreground">No mood entries for today.</p>
                  <Button 
                    variant="outline" 
                    className="mt-4"
                    onClick={() => setIsAddMoodOpen(true)}
                  >
                    <PlusCircle className="mr-2 h-4 w-4" />
                    Track Your Mood
                  </Button>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="week" className="mt-0">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <BarChart className="mr-2 h-5 w-5" />
                Past Week Mood Summary
              </CardTitle>
              <CardDescription>
                {format(new Date(last7Days), 'MMM do')} - {format(new Date(), 'MMM do, yyyy')}
              </CardDescription>
            </CardHeader>
            <CardContent>
              {isLoadingSummary ? (
                <div className="flex justify-center py-8">
                  <Loader2 className="h-8 w-8 animate-spin text-primary" />
                </div>
              ) : moodFrequencyData.length > 0 ? (
                <div className="space-y-4">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <h3 className="font-medium mb-2">Mood Distribution</h3>
                      <div className="space-y-2">
                        {moodFrequencyData.map((item: {mood: string, count: number}) => (
                          <div key={item.mood} className="flex items-center">
                            <MoodDisplay mood={item.mood} size="sm" />
                            <div className="ml-2 flex-1">
                              <div className="flex justify-between text-sm">
                                <span className="capitalize">{item.mood}</span>
                                <span>{item.count}×</span>
                              </div>
                              <div className="w-full bg-muted rounded-full h-2 mt-1">
                                <div 
                                  className="bg-primary h-2 rounded-full" 
                                  style={{ 
                                    width: `${(item.count / moodFrequencyData.reduce((acc, curr) => acc + curr.count, 0)) * 100}%` 
                                  }}
                                />
                              </div>
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                    <div>
                      <h3 className="font-medium mb-2">Recent Entries</h3>
                      <div className="space-y-2 max-h-60 overflow-y-auto pr-2">
                        {filteredEntries?.slice(0, 5).map((entry: MoodEntry) => (
                          <div 
                            key={entry.id} 
                            className="border rounded-lg p-3 flex justify-between items-center"
                          >
                            <div className="flex items-center gap-2">
                              <MoodDisplay mood={entry.mood} size="sm" />
                              <div>
                                <p className="text-xs text-muted-foreground">
                                  {format(new Date(entry.date), 'MMM d')} at {format(new Date(entry.createdAt), 'h:mm a')}
                                </p>
                                <p className="capitalize text-sm">{entry.mood}</p>
                              </div>
                            </div>
                            <Button 
                              size="icon" 
                              variant="ghost"
                              className="h-7 w-7"
                              onClick={() => handleEditClick(entry)}
                            >
                              <Edit className="h-3 w-3" />
                            </Button>
                          </div>
                        ))}
                      </div>
                    </div>
                  </div>

                  <div className="pt-4 border-t">
                    <h3 className="font-medium mb-2">Mood Reflection</h3>
                    <p className="text-sm text-muted-foreground">
                      {moodFrequencyData.length > 0 
                        ? `You've recorded ${moodFrequencyData.reduce((acc, curr) => acc + curr.count, 0)} moods this week. Your most frequent mood was "${
                            moodFrequencyData.sort((a, b) => b.count - a.count)[0]?.mood || 'unknown'
                          }".`
                        : 'No mood data for this period.'}
                    </p>
                  </div>
                </div>
              ) : (
                <div className="text-center py-8">
                  <p className="text-muted-foreground">No mood entries for the past week.</p>
                  <Button 
                    variant="outline" 
                    className="mt-4"
                    onClick={() => setIsAddMoodOpen(true)}
                  >
                    <PlusCircle className="mr-2 h-4 w-4" />
                    Track Your Mood
                  </Button>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="all" className="mt-0">
          <Card>
            <CardHeader>
              <CardTitle>All Mood Entries</CardTitle>
              <CardDescription>Your complete mood history</CardDescription>
            </CardHeader>
            <CardContent>
              {isLoadingEntries ? (
                <div className="flex justify-center py-8">
                  <Loader2 className="h-8 w-8 animate-spin text-primary" />
                </div>
              ) : filteredEntries?.length > 0 ? (
                <div className="space-y-6">
                  {Array.from(
                    new Set(
                      filteredEntries.map((entry: MoodEntry) => 
                        format(new Date(entry.date), 'yyyy-MM-dd')
                      )
                    )
                  ).sort((a, b) => new Date(b).getTime() - new Date(a).getTime())
                  .map((date) => (
                    <div key={date} className="border rounded-lg p-4">
                      <h3 className="font-medium mb-3">
                        {format(new Date(date), 'EEEE, MMMM do, yyyy')}
                      </h3>
                      <div className="space-y-3">
                        {filteredEntries
                          .filter((entry: MoodEntry) => 
                            format(new Date(entry.date), 'yyyy-MM-dd') === date
                          )
                          .sort((a: MoodEntry, b: MoodEntry) => 
                            new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
                          )
                          .map((entry: MoodEntry) => (
                            <div key={entry.id} className="flex items-start justify-between pl-2 border-l-2 border-primary">
                              <div className="flex items-start gap-3">
                                <MoodDisplay mood={entry.mood} size="md" />
                                <div>
                                  <div className="flex items-center gap-2">
                                    <h4 className="font-medium capitalize">{entry.mood}</h4>
                                    <span className="text-xs text-muted-foreground">
                                      {format(new Date(entry.createdAt), 'h:mm a')}
                                    </span>
                                  </div>
                                  {entry.reflection && (
                                    <p className="mt-1 text-sm">{entry.reflection}</p>
                                  )}
                                </div>
                              </div>
                              <div className="flex space-x-2">
                                <Button 
                                  size="icon" 
                                  variant="ghost" 
                                  onClick={() => handleEditClick(entry)}
                                >
                                  <Edit className="h-4 w-4" />
                                </Button>
                                <Button 
                                  size="icon" 
                                  variant="ghost" 
                                  onClick={() => handleDeleteMood(entry.id)}
                                  disabled={deleteMoodMutation.isPending}
                                >
                                  <Trash2 className="h-4 w-4 text-destructive" />
                                </Button>
                              </div>
                            </div>
                          ))}
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="text-center py-8">
                  <p className="text-muted-foreground">No mood entries found.</p>
                  <Button 
                    variant="outline" 
                    className="mt-4"
                    onClick={() => setIsAddMoodOpen(true)}
                  >
                    <PlusCircle className="mr-2 h-4 w-4" />
                    Track Your Mood
                  </Button>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default MoodTrackerPage;