import { useState, useEffect } from "react";
import { useAuth } from "@/contexts/AuthContext";
import { Sparkles, Medal, Trophy, Calendar, Flame } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

interface Achievement {
  id: string;
  title: string;
  description: string;
  date: {
    seconds: number;
    nanoseconds: number;
  };
  type: string;
  icon?: string;
}

export default function AchievementTimelinePage() {
  const [achievements, setAchievements] = useState<Achievement[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const { user } = useAuth();
  const { toast } = useToast();

  useEffect(() => {
    const fetchAchievements = async () => {
      if (user) {
        setIsLoading(true);
        try {
          const response = await fetch(`/api/users/${user.id}/achievements`);
          if (response.ok) {
            const data = await response.json();
            setAchievements(data);
          } else {
            throw new Error('Failed to fetch achievements');
          }
        } catch (error) {
          console.error("Error fetching achievements:", error);
          toast({
            title: "Could not load achievements",
            description: "Please try again later",
            variant: "destructive",
          });
          setAchievements([]);
        } finally {
          setIsLoading(false);
        }
      } else {
        setIsLoading(false);
      }
    };

    fetchAchievements();
  }, [user, toast]);

  const getIconForType = (type: string) => {
    switch (type) {
      case 'course':
        return <Medal className="h-5 w-5 text-green-500" />;
      case 'streak':
        return <Flame className="h-5 w-5 text-orange-500" />;
      case 'chakra':
        return <Sparkles className="h-5 w-5 text-purple-500" />;
      case 'milestone':
        return <Trophy className="h-5 w-5 text-yellow-500" />;
      default:
        return <Calendar className="h-5 w-5 text-blue-500" />;
    }
  };

  const getColorForType = (type: string) => {
    switch (type) {
      case 'course':
        return 'border-green-500';
      case 'streak':
        return 'border-orange-500';
      case 'chakra':
        return 'border-purple-500';
      case 'milestone':
        return 'border-yellow-500';
      default:
        return 'border-blue-500';
    }
  };

  if (isLoading) {
    return (
      <div className="p-3 xs:p-4 sm:p-6 min-h-screen">
        <h1 className="text-2xl sm:text-3xl font-bold mb-8 text-indigo-600 dark:text-indigo-400">
          <span className="flex items-center gap-2">
            <Sparkles className="h-6 w-6" />
            Your Spiritual Journey
          </span>
        </h1>
        <div className="flex justify-center items-center h-40">
          <div className="animate-pulse flex space-x-4">
            <div className="flex-1 space-y-4 py-1">
              <div className="h-4 bg-gray-200 dark:bg-gray-700 rounded w-3/4"></div>
              <div className="space-y-2">
                <div className="h-4 bg-gray-200 dark:bg-gray-700 rounded"></div>
                <div className="h-4 bg-gray-200 dark:bg-gray-700 rounded w-5/6"></div>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="p-3 xs:p-4 sm:p-6 min-h-screen pb-20">
      <h1 className="text-2xl sm:text-3xl font-bold mb-4 sm:mb-8 text-indigo-600 dark:text-indigo-400">
        <span className="flex items-center gap-2">
          <Sparkles className="h-6 w-6" />
          Your Spiritual Journey
        </span>
      </h1>
      
      {achievements.length === 0 ? (
        <div className="bg-indigo-50 dark:bg-indigo-900/20 rounded-lg p-6 text-center">
          <Trophy className="h-12 w-12 mx-auto mb-4 text-indigo-400" />
          <h2 className="text-xl font-semibold mb-2 text-indigo-600 dark:text-indigo-400">No Achievements Yet</h2>
          <p className="text-gray-600 dark:text-gray-400">
            Begin your spiritual journey by completing rituals, activating chakras, or enrolling in courses.
            Your achievements will be recorded here.
          </p>
        </div>
      ) : (
        <div className="space-y-4 sm:space-y-6 relative">
          {/* Vertical line */}
          <div className="absolute top-0 bottom-0 left-6 sm:left-8 w-0.5 bg-indigo-200 dark:bg-indigo-800/50 z-0"></div>
          
          {achievements.map((achievement) => (
            <div
              key={achievement.id}
              className={`relative z-10 ml-16 sm:ml-20 pl-6 py-4 bg-white dark:bg-gray-800 rounded-lg shadow-sm border-l-4 ${getColorForType(achievement.type)}`}
            >
              {/* Circle marker */}
              <div className="absolute top-4 left-[-40px] sm:left-[-50px] bg-white dark:bg-gray-800 rounded-full p-2 border-2 border-indigo-200 dark:border-indigo-800 shadow-sm">
                {getIconForType(achievement.type)}
              </div>
              
              <div>
                <h2 className="text-lg sm:text-xl font-semibold text-gray-800 dark:text-white">{achievement.title}</h2>
                <p className="text-xs text-gray-500 dark:text-gray-400 mb-2">
                  {new Date(achievement.date.seconds * 1000).toLocaleDateString('en-US', {
                    day: 'numeric',
                    month: 'long',
                    year: 'numeric'
                  })}
                </p>
                <p className="text-sm text-gray-600 dark:text-gray-300">{achievement.description}</p>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}