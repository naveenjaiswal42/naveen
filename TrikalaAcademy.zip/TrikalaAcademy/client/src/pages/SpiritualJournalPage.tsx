import { useState, useEffect } from "react";
import { useAuth } from "@/contexts/AuthContext";
import { useToast } from "@/hooks/use-toast";
import { format } from "date-fns";
import { apiRequest } from "@/lib/queryClient";
import { Container } from "@/components/ui/container";
import { Card, CardContent } from "@/components/ui/card";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import { Loader2, BookHeart, Trash2, Calendar, Edit3 } from "lucide-react";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

interface JournalEntry {
  id: number;
  userId: number;
  content: string;
  category: string;
  mood: string | null;
  createdAt: string;
}

const JOURNAL_CATEGORIES = [
  { value: "gratitude", label: "Gratitude" },
  { value: "meditation", label: "Meditation Insights" },
  { value: "reflection", label: "Daily Reflection" },
  { value: "intention", label: "Intentions & Goals" },
  { value: "dream", label: "Dream Journal" },
];

const MOOD_OPTIONS = [
  { value: "peaceful", label: "Peaceful", icon: "😌" },
  { value: "joyful", label: "Joyful", icon: "😊" },
  { value: "inspired", label: "Inspired", icon: "✨" },
  { value: "focused", label: "Focused", icon: "🧘" },
  { value: "confused", label: "Confused", icon: "😕" },
  { value: "stressed", label: "Stressed", icon: "😓" },
];

export default function SpiritualJournalPage() {
  const [entries, setEntries] = useState<JournalEntry[]>([]);
  const [newEntry, setNewEntry] = useState("");
  const [isLoading, setIsLoading] = useState(true);
  const [isSaving, setIsSaving] = useState(false);
  const [isDeleting, setIsDeleting] = useState(false);
  const [selectedCategory, setSelectedCategory] = useState("reflection");
  const [selectedMood, setSelectedMood] = useState<string | null>("peaceful");
  const [filterCategory, setFilterCategory] = useState<string | null>(null);
  
  const { user } = useAuth();
  const { toast } = useToast();
  
  useEffect(() => {
    fetchEntries();
  }, [user]);
  
  const fetchEntries = async () => {
    if (!user) return;
    
    try {
      setIsLoading(true);
      const data = await apiRequest<JournalEntry[]>({
        method: "GET",
        url: `/api/users/${user.id}/journal-entries`
      });
      
      setEntries(data);
    } catch (error) {
      console.error("Error fetching journal entries:", error);
      toast({
        title: "Error",
        description: "Failed to load your journal entries. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };
  
  const saveEntry = async () => {
    if (!newEntry.trim() || !user) return;
    
    try {
      setIsSaving(true);
      
      const savedEntry = await apiRequest<JournalEntry>({
        method: "POST",
        url: `/api/users/${user.id}/journal-entries`,
        body: {
          content: newEntry,
          category: selectedCategory,
          mood: selectedMood
        }
      });
      
      setEntries([savedEntry, ...entries]);
      setNewEntry("");
      
      toast({
        title: "Journal Entry Saved",
        description: "Your reflection has been saved to your spiritual journal.",
      });
    } catch (error) {
      console.error("Error saving journal entry:", error);
      toast({
        title: "Error",
        description: "Failed to save your journal entry. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsSaving(false);
    }
  };
  
  const deleteEntry = async (id: number) => {
    if (!user) return;
    
    try {
      setIsDeleting(true);
      
      await apiRequest<void>({
        method: "DELETE",
        url: `/api/users/${user.id}/journal-entries/${id}`
      });
      
      setEntries(entries.filter(entry => entry.id !== id));
      
      toast({
        title: "Entry Deleted",
        description: "Your journal entry has been deleted.",
      });
    } catch (error) {
      console.error("Error deleting journal entry:", error);
      toast({
        title: "Error",
        description: "Failed to delete journal entry. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsDeleting(false);
    }
  };
  
  const getCategoryLabel = (value: string) => {
    return JOURNAL_CATEGORIES.find(cat => cat.value === value)?.label || value;
  };
  
  const getCategoryIcon = (category: string) => {
    switch (category) {
      case "gratitude":
        return "🙏";
      case "meditation":
        return "🧘";
      case "reflection":
        return "✨";
      case "intention":
        return "🎯";
      case "dream":
        return "💫";
      default:
        return "📝";
    }
  };
  
  const filteredEntries = filterCategory 
    ? entries.filter(entry => entry.category === filterCategory)
    : entries;
  
  return (
    <Container className="py-8">
      <div className="mb-8">
        <h1 className="text-3xl font-bold tracking-tight flex items-center gap-2">
          <BookHeart className="h-8 w-8 text-indigo-600 dark:text-indigo-400" /> 
          Spiritual Journal
        </h1>
        <p className="text-gray-500 dark:text-gray-400 mt-2">
          Capture your spiritual insights, reflections, and gratitude moments
        </p>
      </div>
      
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-1 space-y-6">
          <Card>
            <CardContent className="pt-6">
              <h3 className="text-lg font-medium mb-4">New Journal Entry</h3>
              
              <div className="mb-4">
                <Select
                  value={selectedCategory}
                  onValueChange={setSelectedCategory}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Entry Type" />
                  </SelectTrigger>
                  <SelectContent>
                    {JOURNAL_CATEGORIES.map((category) => (
                      <SelectItem key={category.value} value={category.value}>
                        {getCategoryIcon(category.value)} {category.label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              
              <div className="mb-4">
                <label className="block text-sm font-medium mb-2">
                  How are you feeling?
                </label>
                <div className="flex flex-wrap gap-2">
                  {MOOD_OPTIONS.map((mood) => (
                    <Button
                      key={mood.value}
                      type="button"
                      variant={selectedMood === mood.value ? "default" : "outline"}
                      size="sm"
                      onClick={() => setSelectedMood(mood.value)}
                      className="flex items-center gap-1"
                    >
                      <span>{mood.icon}</span>
                      <span>{mood.label}</span>
                    </Button>
                  ))}
                </div>
              </div>
              
              <Textarea
                value={newEntry}
                onChange={(e) => setNewEntry(e.target.value)}
                placeholder="Write your thoughts, insights, or gratitude..."
                className="min-h-[200px] resize-none"
              />
              
              <Button
                onClick={saveEntry}
                className="w-full mt-4"
                disabled={!newEntry.trim() || isSaving}
              >
                {isSaving ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Saving...
                  </>
                ) : (
                  <>
                    <Edit3 className="mr-2 h-4 w-4" />
                    Save Entry
                  </>
                )}
              </Button>
            </CardContent>
          </Card>
          
          <Card>
            <CardContent className="pt-6">
              <h3 className="text-lg font-medium mb-4">Filter Entries</h3>
              
              <div className="space-y-2">
                <Button
                  variant={filterCategory === null ? "default" : "outline"}
                  size="sm"
                  className="mr-2 mb-2"
                  onClick={() => setFilterCategory(null)}
                >
                  All Entries
                </Button>
                
                {JOURNAL_CATEGORIES.map((category) => (
                  <Button
                    key={category.value}
                    variant={filterCategory === category.value ? "default" : "outline"}
                    size="sm"
                    className="mr-2 mb-2"
                    onClick={() => setFilterCategory(category.value)}
                  >
                    {getCategoryIcon(category.value)} {category.label}
                  </Button>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>
        
        <div className="lg:col-span-2">
          <h2 className="text-xl font-semibold mb-4">
            {filterCategory 
              ? `${getCategoryLabel(filterCategory)} Entries`
              : "All Journal Entries"
            }
          </h2>
          
          {isLoading ? (
            <div className="flex justify-center items-center h-64">
              <Loader2 className="h-8 w-8 animate-spin text-indigo-600" />
            </div>
          ) : filteredEntries.length === 0 ? (
            <div className="text-center py-12 bg-indigo-50 dark:bg-indigo-900/10 rounded-lg">
              <BookHeart className="h-12 w-12 mx-auto text-indigo-400 mb-4" />
              <h3 className="text-lg font-medium mb-2">No entries yet</h3>
              <p className="text-gray-500 dark:text-gray-400">
                {filterCategory
                  ? `Start adding ${getCategoryLabel(filterCategory).toLowerCase()} entries to your spiritual journal.`
                  : "Start capturing your spiritual journey with daily reflections and insights."
                }
              </p>
            </div>
          ) : (
            <div className="space-y-4">
              {filteredEntries.map((entry) => (
                <Card key={entry.id} className="border-indigo-100 dark:border-indigo-800/30">
                  <CardContent className="pt-6">
                    <div className="flex justify-between items-start mb-3">
                      <div className="flex items-center">
                        <span className="text-2xl mr-2">{getCategoryIcon(entry.category)}</span>
                        <span className="font-medium">{getCategoryLabel(entry.category)}</span>
                      </div>
                      
                      <div className="flex items-center text-gray-500 dark:text-gray-400">
                        <Calendar className="h-4 w-4 mr-1" />
                        <span className="text-sm">
                          {new Date(entry.createdAt).toLocaleDateString()}
                        </span>
                      </div>
                    </div>
                    
                    {entry.mood && (
                      <div className="mb-2 text-sm text-gray-500 dark:text-gray-400 flex items-center">
                        <span className="mr-1">Feeling:</span>
                        <span className="text-base mr-1">
                          {MOOD_OPTIONS.find(m => m.value === entry.mood)?.icon || ""}
                        </span>
                        <span>{MOOD_OPTIONS.find(m => m.value === entry.mood)?.label || entry.mood}</span>
                      </div>
                    )}
                    
                    <div className="whitespace-pre-wrap text-gray-700 dark:text-gray-300 mb-4">
                      {entry.content}
                    </div>
                    
                    <div className="flex justify-end">
                      <AlertDialog>
                        <AlertDialogTrigger asChild>
                          <Button 
                            variant="outline" 
                            size="sm" 
                            className="text-red-500 hover:text-red-700 border-red-200 hover:bg-red-50"
                          >
                            <Trash2 className="h-4 w-4 mr-1" />
                            Delete
                          </Button>
                        </AlertDialogTrigger>
                        <AlertDialogContent>
                          <AlertDialogHeader>
                            <AlertDialogTitle>Delete Journal Entry</AlertDialogTitle>
                            <AlertDialogDescription>
                              Are you sure you want to delete this journal entry? This action cannot be undone.
                            </AlertDialogDescription>
                          </AlertDialogHeader>
                          <AlertDialogFooter>
                            <AlertDialogCancel>Cancel</AlertDialogCancel>
                            <AlertDialogAction 
                              onClick={() => deleteEntry(entry.id)}
                              className="bg-red-500 hover:bg-red-600"
                            >
                              {isDeleting ? (
                                <Loader2 className="h-4 w-4 animate-spin" />
                              ) : (
                                "Delete"
                              )}
                            </AlertDialogAction>
                          </AlertDialogFooter>
                        </AlertDialogContent>
                      </AlertDialog>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          )}
        </div>
      </div>
    </Container>
  );
}