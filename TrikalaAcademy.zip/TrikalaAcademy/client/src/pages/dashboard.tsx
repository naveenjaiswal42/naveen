import { useState } from "react";
import UserProfile from "@/components/dashboard/UserProfile";
import ChakraTracker from "@/components/dashboard/ChakraTracker";
import DailyRituals from "@/components/dashboard/DailyRituals";
import CoursesList from "@/components/dashboard/CoursesList";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useTranslation } from "@/hooks/useTranslation";
import { Button } from "@/components/ui/button";
import { Link } from "wouter";
import ChakrasPage from "./chakras";
import CoursesPage from "./courses";
import RitualsPage from "./rituals";
import GuidancePage from "./guidance";
import ProfilePage from "./profile";
import ChakraTrackerPage from "./chakra-tracker";
import { 
  Home, BookOpen, Sun, LightbulbIcon, User, Flower, Award, 
  Music, Timer, Headphones, CheckSquare, Target, BookOpen as Journal,
  Smile, PieChart, Brain, Sparkles, Image, Users, Map, Medal, Trophy, Star
} from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";

const Dashboard = () => {
  const [activeTab, setActiveTab] = useState("home");
  const { t, language } = useTranslation();
  
  // Group menu items by category for better organization
  const menuCategories = [
    {
      title: "Learning",
      items: [
        { path: "/courses", label: "Courses", icon: <BookOpen className="h-6 w-6" /> },
        { path: "/guidance", label: "Guidance", icon: <LightbulbIcon className="h-6 w-6" /> },
        { path: "/coach", label: "Spiritual Coach", icon: <Brain className="h-6 w-6" /> },
      ]
    },
    {
      title: "Meditation",
      items: [
        { path: "/chakras", label: "Chakras", icon: <Flower className="h-6 w-6" /> },
        { path: "/meditation-timer", label: "Meditation Timer", icon: <Timer className="h-6 w-6" /> },
        { path: "/chakra-music", label: "Meditation Music", icon: <Music className="h-6 w-6" /> },
        { path: "/guided-meditations", label: "Guided Meditations", icon: <Headphones className="h-6 w-6" /> },
      ]
    },
    {
      title: "Daily Practice",
      items: [
        { path: "/rituals", label: "Rituals", icon: <Sun className="h-6 w-6" /> },
        { path: "/daily-ritual", label: "Daily Tracker", icon: <CheckSquare className="h-6 w-6" /> },
        { path: "/affirmations", label: "Daily Affirmation", icon: <Sparkles className="h-6 w-6" /> },
      ]
    },
    {
      title: "Self-Reflection",
      items: [
        { path: "/spiritual-journal", label: "Spiritual Journal", icon: <Journal className="h-6 w-6" /> },
        { path: "/mood-tracker", label: "Mood Tracker", icon: <Smile className="h-6 w-6" /> },
        { path: "/mood-reflection", label: "Mood Reflection", icon: <PieChart className="h-6 w-6" /> },
        { path: "/goals", label: "Goal Tracker", icon: <Target className="h-6 w-6" /> },
      ]
    },
    {
      title: "Community & Achievements",
      items: [
        { path: "/community", label: "Community", icon: <Users className="h-6 w-6" /> },
        { path: "/badges", label: "Badge Wall", icon: <Medal className="h-6 w-6" /> },
        { path: "/affirmations", label: "Affirmation Wallpaper", icon: <Image className="h-6 w-6" /> },
        { path: "/profile", label: "Profile", icon: <User className="h-6 w-6" /> },
      ]
    },
  ];
  
  return (
    <div className="p-4 md:p-6 pb-24 bg-gray-50 dark:bg-gray-900 min-h-screen">
      {/* Show user profile at the top of all tabs */}
      <UserProfile />

      <Tabs defaultValue="home" className="mt-6" value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="grid grid-cols-3 md:grid-cols-6 w-full bg-white dark:bg-gray-800 border border-gray-100 dark:border-gray-700 p-1 rounded-xl shadow-sm">
          <TabsTrigger value="home" className="data-[state=active]:bg-primary data-[state=active]:text-white">
            <Home className="h-4 w-4 mr-2" />
            {t('home')}
          </TabsTrigger>
          <TabsTrigger value="courses" className="data-[state=active]:bg-primary data-[state=active]:text-white">
            <BookOpen className="h-4 w-4 mr-2" />
            {t('courses')}
          </TabsTrigger>
          <TabsTrigger value="chakras" className="data-[state=active]:bg-primary data-[state=active]:text-white">
            <Flower className="h-4 w-4 mr-2" />
            {t('chakras')}
          </TabsTrigger>
          <TabsTrigger value="rituals" className="data-[state=active]:bg-primary data-[state=active]:text-white">
            <Sun className="h-4 w-4 mr-2" />
            {t('rituals')}
          </TabsTrigger>
          <TabsTrigger value="guidance" className="data-[state=active]:bg-primary data-[state=active]:text-white">
            <LightbulbIcon className="h-4 w-4 mr-2" />
            {t('guidance')}
          </TabsTrigger>
          <TabsTrigger value="profile" className="data-[state=active]:bg-primary data-[state=active]:text-white">
            <User className="h-4 w-4 mr-2" />
            {t('profile')}
          </TabsTrigger>
        </TabsList>
        
        <TabsContent value="home" className="pt-6">
          {/* XP Progress Card removed */}

          {/* Categorized Menu Items */}
          {menuCategories.map((category, index) => (
            <div key={index} className="mb-10">
              <div className="bg-white dark:bg-gray-800 rounded-xl shadow-md border border-gray-100 dark:border-gray-700 p-4 mb-4">
                <h2 className="text-lg font-semibold mb-2 text-gray-800 dark:text-white flex items-center">
                  {index === 0 && <BookOpen className="h-5 w-5 text-blue-500 mr-2" />}
                  {index === 1 && <Flower className="h-5 w-5 text-purple-500 mr-2" />}
                  {index === 2 && <Sun className="h-5 w-5 text-amber-500 mr-2" />}
                  {index === 3 && <PieChart className="h-5 w-5 text-indigo-500 mr-2" />}
                  {index === 4 && <Users className="h-5 w-5 text-green-500 mr-2" />}
                  {category.title}
                </h2>
                <p className="text-sm text-gray-600 dark:text-gray-400 mb-1">
                  {index === 0 && "Expand your knowledge and spiritual understanding"}
                  {index === 1 && "Engage in meditation practices to strengthen your chakras"}
                  {index === 2 && "Establish daily routines for spiritual growth"}
                  {index === 3 && "Track your inner feelings and spiritual progress"}
                  {index === 4 && "Connect with others and showcase your achievements"}
                </p>
              </div>
              <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-4">
                {category.items.map((item) => (
                  <Link key={item.path} href={item.path}>
                    <Card className={`group hover:bg-gradient-to-b transition-all duration-300 cursor-pointer h-full border border-gray-200 dark:border-gray-700 shadow-sm hover:shadow-md hover:scale-105
                      ${index === 0 ? 'hover:from-blue-50 hover:to-white dark:hover:from-blue-900/20 dark:hover:to-gray-800' : ''}
                      ${index === 1 ? 'hover:from-purple-50 hover:to-white dark:hover:from-purple-900/20 dark:hover:to-gray-800' : ''}
                      ${index === 2 ? 'hover:from-amber-50 hover:to-white dark:hover:from-amber-900/20 dark:hover:to-gray-800' : ''}
                      ${index === 3 ? 'hover:from-indigo-50 hover:to-white dark:hover:from-indigo-900/20 dark:hover:to-gray-800' : ''}
                      ${index === 4 ? 'hover:from-green-50 hover:to-white dark:hover:from-green-900/20 dark:hover:to-gray-800' : ''}
                    `}>
                      <CardContent className="flex flex-col items-center justify-center p-5 text-center h-full">
                        <div className={`
                          rounded-full p-3.5 mb-3 transition-all duration-300 group-hover:scale-110
                          ${index === 0 ? 'bg-blue-50 dark:bg-blue-900/30 group-hover:bg-blue-100 dark:group-hover:bg-blue-900/50' : ''}
                          ${index === 1 ? 'bg-purple-50 dark:bg-purple-900/30 group-hover:bg-purple-100 dark:group-hover:bg-purple-900/50' : ''}
                          ${index === 2 ? 'bg-amber-50 dark:bg-amber-900/30 group-hover:bg-amber-100 dark:group-hover:bg-amber-900/50' : ''}
                          ${index === 3 ? 'bg-indigo-50 dark:bg-indigo-900/30 group-hover:bg-indigo-100 dark:group-hover:bg-indigo-900/50' : ''}
                          ${index === 4 ? 'bg-green-50 dark:bg-green-900/30 group-hover:bg-green-100 dark:group-hover:bg-green-900/50' : ''}
                        `}>
                          {item.icon}
                        </div>
                        <span className={`font-medium text-sm mt-1 transition-all duration-300 
                          ${index === 0 ? 'group-hover:text-blue-600 dark:group-hover:text-blue-400' : ''}
                          ${index === 1 ? 'group-hover:text-purple-600 dark:group-hover:text-purple-400' : ''}
                          ${index === 2 ? 'group-hover:text-amber-600 dark:group-hover:text-amber-400' : ''}
                          ${index === 3 ? 'group-hover:text-indigo-600 dark:group-hover:text-indigo-400' : ''}
                          ${index === 4 ? 'group-hover:text-green-600 dark:group-hover:text-green-400' : ''}
                        `}>{item.label}</span>
                      </CardContent>
                    </Card>
                  </Link>
                ))}
              </div>
            </div>
          ))}
          
          <div className="bg-white dark:bg-gray-800 rounded-xl shadow-md border border-gray-100 dark:border-gray-700 p-4 mb-8">
            <h3 className="text-lg font-semibold text-gray-800 dark:text-white mb-4 flex items-center">
              <Sun className="h-5 w-5 text-amber-500 mr-2" />
              Daily Rituals
            </h3>
            <DailyRituals />
          </div>
          
          <div className="bg-white dark:bg-gray-800 rounded-xl shadow-md border border-gray-100 dark:border-gray-700 p-4 mb-8">
            <h3 className="text-lg font-semibold text-gray-800 dark:text-white mb-4 flex items-center">
              <BookOpen className="h-5 w-5 text-blue-500 mr-2" />
              Current Courses
            </h3>
            <CoursesList />
          </div>
          
          {/* Certificate Button */}
          <div className="bg-white dark:bg-gray-800 rounded-xl shadow-md border border-gray-100 dark:border-gray-700 p-6 mb-8 flex flex-col items-center justify-center">
            <Award className="h-12 w-12 text-amber-500 mb-3" />
            <h3 className="text-lg font-semibold text-gray-800 dark:text-white mb-2">
              Your Achievements
            </h3>
            <p className="text-sm text-gray-600 dark:text-gray-400 mb-4 text-center max-w-md">
              You've made great progress on your spiritual journey. View and download your personalized certificate.
            </p>
            <Button className="bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-600 hover:to-amber-700 text-white flex items-center gap-2" asChild>
              <Link href="/certificate-view">
                <Trophy className="h-4 w-4" />
                View & Download Certificate
              </Link>
            </Button>
          </div>
        </TabsContent>
        
        <TabsContent value="courses" className="pt-6">
          <div className="bg-white dark:bg-gray-800 rounded-xl shadow-md border border-gray-100 dark:border-gray-700 p-5">
            <h3 className="text-lg font-semibold text-gray-800 dark:text-white mb-4 flex items-center">
              <BookOpen className="h-5 w-5 text-blue-500 mr-2" />
              Spiritual Courses
            </h3>
            <CoursesPage />
          </div>
        </TabsContent>
        
        <TabsContent value="chakras" className="pt-6">
          <div className="bg-white dark:bg-gray-800 rounded-xl shadow-md border border-gray-100 dark:border-gray-700 p-5">
            <h3 className="text-lg font-semibold text-gray-800 dark:text-white mb-4 flex items-center">
              <Flower className="h-5 w-5 text-purple-500 mr-2" />
              Chakra System
            </h3>
            <ChakrasPage />
          </div>
        </TabsContent>
        
        <TabsContent value="rituals" className="pt-6">
          <div className="bg-white dark:bg-gray-800 rounded-xl shadow-md border border-gray-100 dark:border-gray-700 p-5">
            <h3 className="text-lg font-semibold text-gray-800 dark:text-white mb-4 flex items-center">
              <Sun className="h-5 w-5 text-amber-500 mr-2" />
              Daily Spiritual Rituals
            </h3>
            <RitualsPage />
          </div>
        </TabsContent>
        
        <TabsContent value="guidance" className="pt-6">
          <div className="bg-white dark:bg-gray-800 rounded-xl shadow-md border border-gray-100 dark:border-gray-700 p-5">
            <h3 className="text-lg font-semibold text-gray-800 dark:text-white mb-4 flex items-center">
              <LightbulbIcon className="h-5 w-5 text-amber-500 mr-2" />
              Spiritual Guidance
            </h3>
            <GuidancePage />
          </div>
        </TabsContent>
        
        <TabsContent value="profile" className="pt-6">
          <div className="bg-white dark:bg-gray-800 rounded-xl shadow-md border border-gray-100 dark:border-gray-700 p-5">
            <h3 className="text-lg font-semibold text-gray-800 dark:text-white mb-4 flex items-center">
              <User className="h-5 w-5 text-blue-500 mr-2" />
              Your Spiritual Profile
            </h3>
            <ProfilePage />
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default Dashboard;
