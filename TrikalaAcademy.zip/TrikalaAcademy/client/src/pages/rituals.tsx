import { useState, useEffect } from "react";
import { useAuth } from "@/contexts/AuthContext";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";
import { Progress } from "@/components/ui/progress";
import { Ritual, UserRitual } from "@shared/schema";
import { apiRequest } from "@/lib/queryClient";

// Define a type that maps camelCase property names to snake_case database field names
type RitualWithMappedFields = {
  id: number;
  title: string;
  description: string | null;
  duration_minutes: number | null;
  icon: string | null;
  xp_reward: number | null;
  time_of_day: string | null;
  completed: boolean;
};

// Helper function to get today's date in YYYY-MM-DD format
const getTodayDate = () => {
  const today = new Date();
  return today.toISOString().split('T')[0];
};

const Rituals = () => {
  const { user } = useAuth();
  const { toast } = useToast();
  const [rituals, setRituals] = useState<RitualWithMappedFields[]>([]);
  const [loading, setLoading] = useState(true);
  const [completedCount, setCompletedCount] = useState(0);
  
  useEffect(() => {
    const fetchRituals = async () => {
      if (!user) return;
      
      try {
        setLoading(true);
        
        // Get all rituals from API
        const allRituals = await apiRequest<Ritual[]>({
          url: '/api/rituals',
          method: 'GET'
        });
        
        // Get today's completed rituals for user
        const todayStr = getTodayDate();
        const userRituals = await apiRequest<UserRitual[]>({
          url: `/api/users/${user.id}/rituals/date/${todayStr}`,
          method: 'GET'
        }).catch(() => [] as UserRitual[]);
        
        const completedRitualIds = userRituals.map(ur => ur.ritualId);
        
        // Map API response to our frontend model with snake_case field names
        const mappedRituals: RitualWithMappedFields[] = allRituals.map(ritual => ({
          id: ritual.id,
          title: ritual.title,
          description: ritual.description,
          duration_minutes: ritual.durationMinutes,
          icon: ritual.icon,
          xp_reward: ritual.xpReward,
          time_of_day: ritual.timeOfDay,
          completed: completedRitualIds.includes(ritual.id)
        }));
        
        setRituals(mappedRituals);
        setCompletedCount(completedRitualIds.length);
      } catch (error) {
        console.error("Error fetching rituals:", error);
        toast({
          title: "Error",
          description: "Failed to load daily rituals",
          variant: "destructive",
        });
      } finally {
        setLoading(false);
      }
    };
    
    fetchRituals();
  }, [user, toast]);

  const completeRitual = async (ritualId: number) => {
    if (!user) return;
    
    try {
      // Add to user_rituals through API
      await apiRequest({
        url: `/api/users/${user.id}/rituals`,
        method: 'POST',
        body: {
          ritualId: ritualId,
          date: getTodayDate(),
          completed: true
        }
      });
      
      // Update local state
      setRituals(prev => prev.map(ritual => 
        ritual.id === ritualId 
          ? { ...ritual, completed: true } 
          : ritual
      ));
      
      setCompletedCount(prev => prev + 1);
      
      // Add XP for completing ritual
      const completedRitual = rituals.find(r => r.id === ritualId);
      if (completedRitual && completedRitual.xp_reward) {
        // The API automatically adds XP
        toast({
          title: "Ritual Completed",
          description: `You earned ${completedRitual.xp_reward} XP!`,
        });
      }
    } catch (error) {
      console.error("Error completing ritual:", error);
      toast({
        title: "Error",
        description: "Failed to mark ritual as completed",
        variant: "destructive",
      });
    }
  };

  if (loading) {
    return (
      <div className="p-4 pb-24">
        <h1 className="text-2xl font-heading font-bold text-gray-800 dark:text-white mb-6">
          Daily Rituals
        </h1>
        <p className="text-center text-gray-500 dark:text-gray-400 py-8">
          Loading rituals...
        </p>
      </div>
    );
  }

  return (
    <div className="p-4 pb-24">
      <h1 className="text-2xl font-heading font-bold text-gray-800 dark:text-white mb-2">
        Daily Rituals
      </h1>
      <p className="text-gray-600 dark:text-gray-400 mb-6">
        Regular practices to enhance your spiritual journey.
      </p>
      
      {/* Progress bar */}
      <div className="mb-6">
        <div className="flex justify-between items-center mb-2">
          <span className="text-sm font-medium text-gray-700 dark:text-gray-300">
            Today's Progress
          </span>
          <span className="text-sm text-primary dark:text-primary-400">
            {completedCount}/{rituals.length} Completed
          </span>
        </div>
        <Progress 
          value={rituals.length ? (completedCount / rituals.length) * 100 : 0} 
          className="h-2"
        />
      </div>
      
      {rituals.length === 0 ? (
        <Card>
          <CardContent className="pt-6 text-center">
            <p className="text-gray-500 dark:text-gray-400 py-4">
              No rituals available today
            </p>
          </CardContent>
        </Card>
      ) : (
        <div className="space-y-4">
          {rituals.map((ritual) => (
            <Card key={ritual.id} className="overflow-hidden">
              <CardContent className="p-0">
                <div className="flex items-center p-4">
                  <div className={`w-12 h-12 rounded-full ${ritual.completed ? 'bg-green-100 dark:bg-green-900' : 'bg-primary-100 dark:bg-primary-900'} flex items-center justify-center mr-4`}>
                    <i className={`${ritual.icon || 'fas fa-om'} ${ritual.completed ? 'text-green-500 dark:text-green-400' : 'text-primary dark:text-primary-400'} text-lg`}></i>
                  </div>
                  
                  <div className="flex-1">
                    <h3 className="font-semibold text-gray-800 dark:text-white">
                      {ritual.title}
                    </h3>
                    <p className="text-sm text-gray-500 dark:text-gray-400">
                      {ritual.description || `A ${ritual.duration_minutes}-minute practice for spiritual growth.`}
                    </p>
                    <div className="flex items-center mt-1 text-xs text-gray-500 dark:text-gray-400">
                      <span className="mr-3">
                        <i className="far fa-clock mr-1"></i>
                        {ritual.duration_minutes} minutes
                      </span>
                      <span className="mr-3">
                        <i className="far fa-sun mr-1"></i>
                        {ritual.time_of_day}
                      </span>
                      <span>
                        <i className="fas fa-star text-accent mr-1"></i>
                        {ritual.xp_reward} XP
                      </span>
                    </div>
                  </div>
                  
                  <Button 
                    variant={ritual.completed ? "outline" : "default"}
                    className={ritual.completed ? "border-green-500 text-green-500" : ""}
                    disabled={ritual.completed}
                    onClick={() => !ritual.completed && completeRitual(ritual.id)}
                  >
                    {ritual.completed ? (
                      <>
                        <i className="fas fa-check mr-2"></i>
                        Completed
                      </>
                    ) : (
                      'Complete'
                    )}
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
};

export default Rituals;
