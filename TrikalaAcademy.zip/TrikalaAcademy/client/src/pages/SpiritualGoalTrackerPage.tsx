import { useState, useEffect } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { Container } from "@/components/ui/container";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/contexts/AuthContext";
import { 
  Target, 
  Check, 
  X, 
  Edit, 
  Plus, 
  Trash2, 
  RotateCcw,
  CalendarClock,
  Award,
  CircleCheck,
  AlertCircle
} from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";

// Goal interface
interface Goal {
  id: number;
  userId: number;
  text: string;
  completed: boolean;
  category: string;
  targetDate?: string;
  createdAt: string;
  updatedAt?: string;
}

// New goal interface
interface NewGoal {
  text: string;
  category: string;
  targetDate?: string;
}

export default function SpiritualGoalTrackerPage() {
  const [newGoal, setNewGoal] = useState<NewGoal>({
    text: "",
    category: "meditation"
  });
  const [editingGoal, setEditingGoal] = useState<Goal | null>(null);
  const { toast } = useToast();
  const { user } = useAuth();
  const queryClient = useQueryClient();
  const goalCategories = [
    { id: "meditation", label: "Meditation", icon: <Target className="h-4 w-4" /> },
    { id: "chakra", label: "Chakra Work", icon: <CircleCheck className="h-4 w-4" /> },
    { id: "ritual", label: "Daily Rituals", icon: <CalendarClock className="h-4 w-4" /> },
    { id: "study", label: "Spiritual Study", icon: <Award className="h-4 w-4" /> }
  ];
  
  // Fetch user goals
  const { 
    data: goals = [], 
    isLoading,
    isError
  } = useQuery({
    queryKey: [`/api/users/${user?.id}/goals`],
    queryFn: async () => {
      if (!user) return [];
      
      try {
        const response = await fetch(`/api/users/${user.id}/goals`);
        if (!response.ok) {
          throw new Error('Failed to fetch goals');
        }
        const data = await response.json();
        return data as Goal[];
      } catch (error) {
        console.error('Error fetching goals:', error);
        return [];
      }
    },
    enabled: !!user
  });

  // Add goal mutation
  const addGoalMutation = useMutation({
    mutationFn: async (goalData: NewGoal) => {
      if (!user) throw new Error('User not authenticated');
      
      const response = await apiRequest({
        method: "POST",
        url: `/api/users/${user.id}/goals`,
        body: goalData
      });
      
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [`/api/users/${user?.id}/goals`] });
      toast({
        title: "Goal Added",
        description: "Your spiritual goal has been added successfully.",
      });
      setNewGoal({ text: "", category: "meditation" });
    },
    onError: (error) => {
      toast({
        title: "Failed to Add Goal",
        description: "There was an error adding your goal. Please try again.",
        variant: "destructive"
      });
      console.error("Error adding goal:", error);
    }
  });

  // Update goal mutation
  const updateGoalMutation = useMutation({
    mutationFn: async (goal: Goal) => {
      if (!user) throw new Error('User not authenticated');
      
      const response = await apiRequest({
        method: "PATCH",
        url: `/api/users/${user.id}/goals/${goal.id}`,
        body: { 
          text: goal.text,
          completed: goal.completed,
          category: goal.category,
          targetDate: goal.targetDate
        }
      });
      
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [`/api/users/${user?.id}/goals`] });
      toast({
        title: "Goal Updated",
        description: "Your goal has been updated successfully.",
      });
      setEditingGoal(null);
    },
    onError: (error) => {
      toast({
        title: "Failed to Update Goal",
        description: "There was an error updating your goal. Please try again.",
        variant: "destructive"
      });
      console.error("Error updating goal:", error);
    }
  });

  // Delete goal mutation
  const deleteGoalMutation = useMutation({
    mutationFn: async (goalId: number) => {
      if (!user) throw new Error('User not authenticated');
      
      const response = await apiRequest({
        method: "DELETE",
        url: `/api/users/${user.id}/goals/${goalId}`,
      });
      
      return response;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [`/api/users/${user?.id}/goals`] });
      toast({
        title: "Goal Deleted",
        description: "Your goal has been deleted successfully.",
      });
    },
    onError: (error) => {
      toast({
        title: "Failed to Delete Goal",
        description: "There was an error deleting your goal. Please try again.",
        variant: "destructive"
      });
      console.error("Error deleting goal:", error);
    }
  });

  // Toggle goal completion status
  const toggleGoalCompletion = (goal: Goal) => {
    updateGoalMutation.mutate({
      ...goal,
      completed: !goal.completed
    });
    
    // If this is the first time completing the goal, award XP
    if (!goal.completed && user) {
      awardXpForCompletion(user.id);
    }
  };

  // Award XP for completing a goal
  const awardXpForCompletion = async (userId: number) => {
    try {
      const xpAmount = 50; // 50 XP per completed goal
      await apiRequest({
        method: "POST",
        url: `/api/users/${userId}/xp`,
        body: { xpAmount }
      });
      
      toast({
        title: "Goal Completed!",
        description: `Congratulations! You've earned ${xpAmount} XP for completing your spiritual goal.`,
      });
    } catch (error) {
      console.error("Error awarding XP:", error);
    }
  };

  // Handle adding a new goal
  const handleAddGoal = () => {
    if (!newGoal.text.trim()) {
      toast({
        title: "Goal Required",
        description: "Please enter a goal before adding.",
        variant: "destructive"
      });
      return;
    }
    
    addGoalMutation.mutate(newGoal);
  };

  // Start editing a goal
  const startEditing = (goal: Goal) => {
    setEditingGoal(goal);
  };

  // Cancel editing
  const cancelEditing = () => {
    setEditingGoal(null);
  };

  // Save edited goal
  const saveEdit = () => {
    if (editingGoal) {
      if (!editingGoal.text.trim()) {
        toast({
          title: "Goal Required",
          description: "The goal text cannot be empty.",
          variant: "destructive"
        });
        return;
      }
      
      updateGoalMutation.mutate(editingGoal);
    }
  };

  // Get category label
  const getCategoryLabel = (categoryId: string): string => {
    const category = goalCategories.find(cat => cat.id === categoryId);
    return category ? category.label : categoryId;
  };

  // Filter goals by category and completion status
  const getFilteredGoals = (category: string, completed: boolean) => {
    return goals.filter(goal => goal.category === category && goal.completed === completed);
  };

  // Calculate progress percentage
  const calculateProgress = (category: string) => {
    const categoryGoals = goals.filter(goal => goal.category === category);
    if (categoryGoals.length === 0) return 0;
    
    const completedCount = categoryGoals.filter(goal => goal.completed).length;
    return Math.round((completedCount / categoryGoals.length) * 100);
  };

  return (
    <Container className="py-8">
      <div className="mb-8 flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold tracking-tight flex items-center gap-2">
            <Target className="h-8 w-8 text-indigo-600 dark:text-indigo-400" /> 
            Spiritual Goal Tracker
          </h1>
          <p className="text-gray-500 dark:text-gray-400 mt-2">
            Set, track, and achieve your spiritual development goals
          </p>
        </div>
        
        {user && (
          <div className="flex items-center gap-2">
            <div className="flex items-center bg-indigo-50 dark:bg-indigo-950/20 px-3 py-1.5 rounded-full">
              <Award className="h-5 w-5 text-indigo-500 mr-2" />
              <span className="text-indigo-700 dark:text-indigo-300 font-medium">
                {goals.filter(g => g.completed).length} Goals Completed
              </span>
            </div>
          </div>
        )}
      </div>

      {/* Add New Goal */}
      <Card className="mb-8 border-indigo-100 dark:border-indigo-800/30">
        <CardHeader>
          <CardTitle>Add New Spiritual Goal</CardTitle>
          <CardDescription>
            Set measurable goals to track your spiritual growth journey
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <div className="md:col-span-2">
              <Input
                value={newGoal.text}
                onChange={(e) => setNewGoal({...newGoal, text: e.target.value})}
                placeholder="Enter your new spiritual goal..."
                className="w-full"
              />
            </div>
            
            <div>
              <select
                value={newGoal.category}
                onChange={(e) => setNewGoal({...newGoal, category: e.target.value})}
                className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background file:border-0 file:bg-transparent file:text-sm file:font-medium placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50"
              >
                {goalCategories.map(category => (
                  <option key={category.id} value={category.id}>
                    {category.label}
                  </option>
                ))}
              </select>
            </div>
            
            <div>
              <Button 
                onClick={handleAddGoal}
                className="w-full bg-indigo-600 hover:bg-indigo-700"
                disabled={addGoalMutation.isPending}
              >
                {addGoalMutation.isPending ? (
                  <>Adding...</>
                ) : (
                  <>
                    <Plus className="mr-2 h-4 w-4" /> Add Goal
                  </>
                )}
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Goal Categories and Progress */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-8">
        {goalCategories.map(category => {
          const progress = calculateProgress(category.id);
          return (
            <Card key={category.id} className={`border-${category.id === 'meditation' ? 'indigo' : category.id === 'chakra' ? 'purple' : category.id === 'ritual' ? 'amber' : 'emerald'}-100 dark:border-${category.id === 'meditation' ? 'indigo' : category.id === 'chakra' ? 'purple' : category.id === 'ritual' ? 'amber' : 'emerald'}-800/30`}>
              <CardContent className="pt-6">
                <div className="flex justify-between items-center mb-2">
                  <h3 className="font-semibold flex items-center gap-2">
                    {category.icon}
                    {category.label}
                  </h3>
                  <Badge variant="outline" className={`bg-${category.id === 'meditation' ? 'indigo' : category.id === 'chakra' ? 'purple' : category.id === 'ritual' ? 'amber' : 'emerald'}-50 text-${category.id === 'meditation' ? 'indigo' : category.id === 'chakra' ? 'purple' : category.id === 'ritual' ? 'amber' : 'emerald'}-700 dark:bg-${category.id === 'meditation' ? 'indigo' : category.id === 'chakra' ? 'purple' : category.id === 'ritual' ? 'amber' : 'emerald'}-950/20 dark:text-${category.id === 'meditation' ? 'indigo' : category.id === 'chakra' ? 'purple' : category.id === 'ritual' ? 'amber' : 'emerald'}-300`}>
                    {progress}% Complete
                  </Badge>
                </div>
                <Progress 
                  value={progress} 
                  className="h-2" 
                />
                <div className="flex justify-between text-xs mt-2 text-gray-500 dark:text-gray-400">
                  <span>{getFilteredGoals(category.id, true).length} completed</span>
                  <span>{getFilteredGoals(category.id, false).length} in progress</span>
                </div>
              </CardContent>
            </Card>
          );
        })}
      </div>

      {/* Goals List */}
      <Tabs defaultValue="active" className="w-full">
        <TabsList className="mb-6">
          <TabsTrigger value="active">Active Goals</TabsTrigger>
          <TabsTrigger value="completed">Completed Goals</TabsTrigger>
        </TabsList>
        
        <TabsContent value="active">
          {isLoading ? (
            <div className="flex justify-center py-12">
              <div className="animate-spin h-8 w-8 border-4 border-indigo-500 rounded-full border-t-transparent"></div>
            </div>
          ) : isError ? (
            <Card className="border-red-100 dark:border-red-800/30">
              <CardContent className="pt-6 flex items-center justify-center">
                <AlertCircle className="h-5 w-5 text-red-500 mr-2" />
                <p className="text-red-600 dark:text-red-400">Failed to load goals. Please try again later.</p>
              </CardContent>
            </Card>
          ) : goals.filter(goal => !goal.completed).length === 0 ? (
            <Card className="border-indigo-100 dark:border-indigo-800/30">
              <CardContent className="pt-6 text-center">
                <p className="text-gray-500 dark:text-gray-400">You don't have any active goals yet. Add a new goal to get started!</p>
              </CardContent>
            </Card>
          ) : (
            <div className="space-y-4">
              {goals
                .filter(goal => !goal.completed)
                .map(goal => (
                  <Card 
                    key={goal.id} 
                    className={`border-${goal.category === 'meditation' ? 'indigo' : goal.category === 'chakra' ? 'purple' : goal.category === 'ritual' ? 'amber' : 'emerald'}-100 dark:border-${goal.category === 'meditation' ? 'indigo' : goal.category === 'chakra' ? 'purple' : goal.category === 'ritual' ? 'amber' : 'emerald'}-800/30`}
                  >
                    <CardContent className="p-4 flex justify-between items-center">
                      {editingGoal && editingGoal.id === goal.id ? (
                        <div className="flex-grow mr-4">
                          <Input
                            value={editingGoal.text}
                            onChange={(e) => setEditingGoal({...editingGoal, text: e.target.value})}
                            className="w-full"
                          />
                        </div>
                      ) : (
                        <div className="flex-grow mr-4">
                          <div className="flex items-center">
                            <Badge className={`bg-${goal.category === 'meditation' ? 'indigo' : goal.category === 'chakra' ? 'purple' : goal.category === 'ritual' ? 'amber' : 'emerald'}-50 text-${goal.category === 'meditation' ? 'indigo' : goal.category === 'chakra' ? 'purple' : goal.category === 'ritual' ? 'amber' : 'emerald'}-700 dark:bg-${goal.category === 'meditation' ? 'indigo' : goal.category === 'chakra' ? 'purple' : goal.category === 'ritual' ? 'amber' : 'emerald'}-950/20 dark:text-${goal.category === 'meditation' ? 'indigo' : goal.category === 'chakra' ? 'purple' : goal.category === 'ritual' ? 'amber' : 'emerald'}-300 mr-2`}>
                              {getCategoryLabel(goal.category)}
                            </Badge>
                            <h3 className="font-medium text-gray-900 dark:text-gray-100">
                              {goal.text}
                            </h3>
                          </div>
                          <p className="text-sm text-gray-500 dark:text-gray-400 mt-1">
                            Added on {new Date(goal.createdAt).toLocaleDateString()}
                          </p>
                        </div>
                      )}
                      
                      <div className="flex space-x-2">
                        {editingGoal && editingGoal.id === goal.id ? (
                          <>
                            <TooltipProvider>
                              <Tooltip>
                                <TooltipTrigger asChild>
                                  <Button 
                                    variant="outline" 
                                    size="icon"
                                    onClick={saveEdit}
                                    disabled={updateGoalMutation.isPending}
                                  >
                                    <Check className="h-4 w-4 text-green-500" />
                                  </Button>
                                </TooltipTrigger>
                                <TooltipContent>
                                  <p>Save changes</p>
                                </TooltipContent>
                              </Tooltip>
                            </TooltipProvider>
                            
                            <TooltipProvider>
                              <Tooltip>
                                <TooltipTrigger asChild>
                                  <Button 
                                    variant="outline" 
                                    size="icon"
                                    onClick={cancelEditing}
                                  >
                                    <X className="h-4 w-4 text-red-500" />
                                  </Button>
                                </TooltipTrigger>
                                <TooltipContent>
                                  <p>Cancel editing</p>
                                </TooltipContent>
                              </Tooltip>
                            </TooltipProvider>
                          </>
                        ) : (
                          <>
                            <TooltipProvider>
                              <Tooltip>
                                <TooltipTrigger asChild>
                                  <Button 
                                    variant="outline" 
                                    size="icon"
                                    onClick={() => toggleGoalCompletion(goal)}
                                    disabled={updateGoalMutation.isPending}
                                  >
                                    <Check className="h-4 w-4" />
                                  </Button>
                                </TooltipTrigger>
                                <TooltipContent>
                                  <p>Mark as complete</p>
                                </TooltipContent>
                              </Tooltip>
                            </TooltipProvider>
                            
                            <TooltipProvider>
                              <Tooltip>
                                <TooltipTrigger asChild>
                                  <Button 
                                    variant="outline" 
                                    size="icon"
                                    onClick={() => startEditing(goal)}
                                  >
                                    <Edit className="h-4 w-4" />
                                  </Button>
                                </TooltipTrigger>
                                <TooltipContent>
                                  <p>Edit goal</p>
                                </TooltipContent>
                              </Tooltip>
                            </TooltipProvider>
                            
                            <TooltipProvider>
                              <Tooltip>
                                <TooltipTrigger asChild>
                                  <Button 
                                    variant="outline" 
                                    size="icon"
                                    onClick={() => deleteGoalMutation.mutate(goal.id)}
                                    disabled={deleteGoalMutation.isPending}
                                  >
                                    <Trash2 className="h-4 w-4" />
                                  </Button>
                                </TooltipTrigger>
                                <TooltipContent>
                                  <p>Delete goal</p>
                                </TooltipContent>
                              </Tooltip>
                            </TooltipProvider>
                          </>
                        )}
                      </div>
                    </CardContent>
                  </Card>
              ))}
            </div>
          )}
        </TabsContent>
        
        <TabsContent value="completed">
          {isLoading ? (
            <div className="flex justify-center py-12">
              <div className="animate-spin h-8 w-8 border-4 border-indigo-500 rounded-full border-t-transparent"></div>
            </div>
          ) : isError ? (
            <Card className="border-red-100 dark:border-red-800/30">
              <CardContent className="pt-6 flex items-center justify-center">
                <AlertCircle className="h-5 w-5 text-red-500 mr-2" />
                <p className="text-red-600 dark:text-red-400">Failed to load goals. Please try again later.</p>
              </CardContent>
            </Card>
          ) : goals.filter(goal => goal.completed).length === 0 ? (
            <Card className="border-indigo-100 dark:border-indigo-800/30">
              <CardContent className="pt-6 text-center">
                <p className="text-gray-500 dark:text-gray-400">You haven't completed any goals yet. Keep working on your active goals!</p>
              </CardContent>
            </Card>
          ) : (
            <div className="space-y-4">
              {goals
                .filter(goal => goal.completed)
                .map(goal => (
                  <Card 
                    key={goal.id} 
                    className="border-green-100 dark:border-green-800/30 bg-green-50/50 dark:bg-green-950/20"
                  >
                    <CardContent className="p-4 flex justify-between items-center">
                      <div className="flex-grow mr-4">
                        <div className="flex items-center">
                          <Badge className="bg-green-50 text-green-700 dark:bg-green-950/20 dark:text-green-300 mr-2">
                            {getCategoryLabel(goal.category)}
                          </Badge>
                          <h3 className="font-medium text-gray-700 dark:text-gray-300 line-through">
                            {goal.text}
                          </h3>
                        </div>
                        <p className="text-sm text-gray-500 dark:text-gray-400 mt-1">
                          Completed on {goal.updatedAt ? new Date(goal.updatedAt).toLocaleDateString() : 'Unknown date'}
                        </p>
                      </div>
                      
                      <div className="flex space-x-2">
                        <TooltipProvider>
                          <Tooltip>
                            <TooltipTrigger asChild>
                              <Button 
                                variant="outline" 
                                size="icon"
                                onClick={() => toggleGoalCompletion(goal)}
                                disabled={updateGoalMutation.isPending}
                              >
                                <RotateCcw className="h-4 w-4" />
                              </Button>
                            </TooltipTrigger>
                            <TooltipContent>
                              <p>Mark as incomplete</p>
                            </TooltipContent>
                          </Tooltip>
                        </TooltipProvider>
                        
                        <TooltipProvider>
                          <Tooltip>
                            <TooltipTrigger asChild>
                              <Button 
                                variant="outline" 
                                size="icon"
                                onClick={() => deleteGoalMutation.mutate(goal.id)}
                                disabled={deleteGoalMutation.isPending}
                              >
                                <Trash2 className="h-4 w-4" />
                              </Button>
                            </TooltipTrigger>
                            <TooltipContent>
                              <p>Delete goal</p>
                            </TooltipContent>
                          </Tooltip>
                        </TooltipProvider>
                      </div>
                    </CardContent>
                  </Card>
              ))}
            </div>
          )}
        </TabsContent>
      </Tabs>
    </Container>
  );
}