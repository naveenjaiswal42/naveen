import React from 'react'
import ReactDOM from 'react-dom/client'
import App from './App'
import './index.css'
import { QueryClientProvider } from '@tanstack/react-query'
import { queryClient } from './lib/queryClient'
import { ThemeProvider } from "@/components/ui/theme-provider"
import { Toaster } from './components/ui/toaster'
import { LanguageProvider } from './contexts/LanguageContext'
import { AuthProvider } from './contexts/AuthContext'
import { ChakraProvider } from './contexts/ChakraContext'
import { NotificationProvider } from './contexts/NotificationContext'

ReactDOM.createRoot(document.getElementById('root')!).render(
  <QueryClientProvider client={queryClient}>
    <AuthProvider>
      <ChakraProvider>
        <NotificationProvider>
          <LanguageProvider>
            <ThemeProvider defaultTheme="light" storageKey="ui-theme">
              <App />
              <Toaster />
            </ThemeProvider>
          </LanguageProvider>
        </NotificationProvider>
      </ChakraProvider>
    </AuthProvider>
  </QueryClientProvider>
)