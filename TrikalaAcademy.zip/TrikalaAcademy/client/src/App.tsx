import React from "react";
import { Switch, Route } from "wouter";
import Dashboard from "./pages/dashboard";
import MainLayout from "./components/layouts/MainLayout";
import CoursesPage from "./pages/courses";
import MyCourses from "./pages/my-courses";
import ProfilePage from "./pages/profile";
import MeditationTimerPage from "./pages/MeditationTimerPage";
import ChakraTrackerPage from "./pages/chakra-tracker";
import DailyRitualPage from "./pages/DailyRitualTrackerPage";
import MoodTrackerPage from "./pages/MoodTrackerPage";
import SpiritualJournalPage from "./pages/SpiritualJournalPage";
import MoodReflectionSummaryPage from "./pages/MoodReflectionSummaryPage";
import CommunityWallPage from "./pages/CommunityWallPage";
import AffirmationWallpaperPage from "./pages/AffirmationWallpaperPage";
import NotificationSettingsPage from "./pages/NotificationSettingsPage";
import PersonalChallengePage from "./pages/PersonalChallengePage";
import HealingJourneyPage from "./pages/HealingJourneyPage";
import MorePage from "./pages/MorePage";
import AuthPage from "./pages/auth-page";
import DirectEnrollPage from "./pages/direct-enroll";

function App() {
  return (
    <Switch>
      <Route path="/auth" component={AuthPage} />
      
      <Route>
        <MainLayout>
          <Switch>
            <Route path="/" component={Dashboard} />
            <Route path="/dashboard" component={Dashboard} />
            <Route path="/courses" component={CoursesPage} />
            <Route path="/my-courses" component={MyCourses} />
            <Route path="/profile" component={ProfilePage} />
            <Route path="/meditation-timer" component={MeditationTimerPage} />
            <Route path="/chakra-tracker" component={ChakraTrackerPage} />
            <Route path="/daily-ritual" component={DailyRitualPage} />
            <Route path="/mood-tracker" component={MoodTrackerPage} />
            <Route path="/spiritual-journal" component={SpiritualJournalPage} />
            <Route path="/mood-reflection" component={MoodReflectionSummaryPage} />
            <Route path="/community" component={CommunityWallPage} />
            <Route path="/affirmations" component={AffirmationWallpaperPage} />
            <Route path="/notification-settings" component={NotificationSettingsPage} />
            <Route path="/personal-challenge" component={PersonalChallengePage} />
            <Route path="/healing-journey" component={HealingJourneyPage} />
            <Route path="/more" component={MorePage} />
            <Route path="/direct-enroll" component={DirectEnrollPage} />
          </Switch>
        </MainLayout>
      </Route>
    </Switch>
  );
}

export default App;
