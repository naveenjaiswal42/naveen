import { initializeApp } from "firebase/app";
import { getAuth } from "firebase/auth";
import { getFirestore } from "firebase/firestore";

// Firebase configuration
const firebaseConfig = {
  apiKey: import.meta.env.VITE_FIREBASE_API_KEY,
  authDomain: `${import.meta.env.VITE_FIREBASE_PROJECT_ID}.firebaseapp.com`,
  projectId: import.meta.env.VITE_FIREBASE_PROJECT_ID,
  storageBucket: `${import.meta.env.VITE_FIREBASE_PROJECT_ID}.appspot.com`,
  appId: import.meta.env.VITE_FIREBASE_APP_ID,
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);

// Initialize Firebase services
export const auth = getAuth(app);
export const db = getFirestore(app);

// Function to request notification permission using browser API
export const requestNotificationPermission = async (): Promise<boolean> => {
  try {
    // Check if notification permission is supported in browser
    if (!('Notification' in window)) {
      console.log('Notifications not supported in this browser');
      return false;
    }
    
    // Check permission status
    if (Notification.permission !== 'granted') {
      // Request permission
      const permission = await Notification.requestPermission();
      
      if (permission !== 'granted') {
        console.log('Notification permission denied');
        return false;
      }
    }
    
    return true;
  } catch (error) {
    console.error('Error requesting notification permission:', error);
    return false;
  }
};

// Simple function to show browser notification
export const showNotification = (title: string, body: string, icon: string = '/assets/trikala-logo.png') => {
  if (Notification.permission === 'granted') {
    new Notification(title, {
      body,
      icon
    });
    return true;
  }
  return false;
};