import React, { createContext, useContext, useState, useEffect } from 'react';
import { requestNotificationPermission } from '@/firebase';

// Interface for context
interface NotificationContextType {
  isPermissionGranted: boolean;
  requestPermission: () => Promise<boolean>;
  showRitualReminder: (title: string, ritualId?: number, ritualName?: string, time?: string, description?: string) => void;
}

// Create context with default values
const NotificationContext = createContext<NotificationContextType>({
  isPermissionGranted: false,
  requestPermission: async () => false,
  showRitualReminder: () => {},
});

// Custom hook for using notification context
export const useNotifications = () => useContext(NotificationContext);

// Provider component
export const NotificationProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [isPermissionGranted, setIsPermissionGranted] = useState(false);
  
  // Check notification permission on mount
  useEffect(() => {
    const checkPermission = () => {
      if ('Notification' in window) {
        setIsPermissionGranted(Notification.permission === 'granted');
      }
    };
    
    checkPermission();
  }, []);
  
  // Request notification permission
  const requestPermission = async (): Promise<boolean> => {
    const granted = await requestNotificationPermission();
    setIsPermissionGranted(granted);
    return granted;
  };
  
  // Show ritual reminder popup
  const showRitualReminder = (
    title: string,
    ritualId?: number,
    ritualName?: string,
    time?: string,
    description?: string
  ) => {
    // Implementation would go here to show the popup
    console.log("Show ritual reminder:", title, ritualId, ritualName, time);
  };
  
  return (
    <NotificationContext.Provider
      value={{
        isPermissionGranted,
        requestPermission,
        showRitualReminder,
      }}
    >
      {children}
    </NotificationContext.Provider>
  );
};