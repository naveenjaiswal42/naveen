import { createContext, ReactNode, useContext, useEffect, useState } from "react";
import { useAuth } from "./AuthContext";
import { ChakraType, getChakraProgressPercentage } from "@/lib/chakras";
import { apiRequest } from "@/lib/queryClient";

interface ChakraState {
  crown: boolean;
  thirdEye: boolean;
  throat: boolean;
  heart: boolean;
  solar: boolean;
  sacral: boolean;
  root: boolean;
}

interface ChakraContextType {
  chakras: ChakraState;
  activeCount: number;
  progressPercentage: number;
  activateChakra: (chakra: ChakraType) => Promise<void>;
  isLoading: boolean;
}

const defaultChakraState: ChakraState = {
  crown: false,
  thirdEye: false,
  throat: false,
  heart: false,
  solar: false,
  sacral: false,
  root: false,
};

const ChakraContext = createContext<ChakraContextType>({
  chakras: defaultChakraState,
  activeCount: 0,
  progressPercentage: 0,
  activateChakra: async () => {},
  isLoading: true,
});

export const useChakras = () => useContext(ChakraContext);

export const ChakraProvider = ({ children }: { children: ReactNode }) => {
  const { user } = useAuth();
  const [chakras, setChakras] = useState<ChakraState>(defaultChakraState);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const fetchChakraData = async () => {
      if (!user) {
        setChakras(defaultChakraState);
        setIsLoading(false);
        return;
      }

      try {
        setIsLoading(true);
        
        // Use our API to get chakra data
        const chakraData = await apiRequest<ChakraState>({
          url: `/api/users/${user.id}/chakras`,
          method: 'GET'
        }).catch(() => {
          console.log("Using default chakra state");
          return defaultChakraState;
        });
        
        setChakras(chakraData);
      } catch (error) {
        console.error("Error fetching chakra data:", error);
        setChakras(defaultChakraState);
      } finally {
        setIsLoading(false);
      }
    };

    fetchChakraData();
  }, [user]);

  const activateChakra = async (chakra: ChakraType) => {
    if (!user) return;
    
    try {
      const updatedChakras = { ...chakras, [chakra]: true };
      
      // Use our API to update chakra data
      await apiRequest({
        url: `/api/users/${user.id}/chakras`,
        method: 'PATCH',
        body: {
          [chakra]: true
        }
      });
      
      // The API will automatically add XP
      setChakras(updatedChakras);
    } catch (error) {
      console.error("Error activating chakra:", error);
      throw error;
    }
  };

  // Calculate active chakra count
  const activeCount = Object.values(chakras).filter(Boolean).length;
  
  // Calculate progress percentage
  const progressPercentage = getChakraProgressPercentage(chakras);

  return (
    <ChakraContext.Provider 
      value={{ 
        chakras, 
        activeCount, 
        progressPercentage, 
        activateChakra,
        isLoading
      }}
    >
      {children}
    </ChakraContext.Provider>
  );
};
