import { createContext, useContext, useState, ReactNode, useEffect } from "react";
import type { SupportedLanguages } from "../lib/translations";
import { englishTranslations } from "../lib/translations";

interface LanguageContextType {
  language: SupportedLanguages;
  setLanguage: (lang: SupportedLanguages) => void;
  t: (key: string, params?: Record<string, string>) => string;
}

const LanguageContext = createContext<LanguageContextType>({
  language: "en",
  setLanguage: () => {},
  t: () => "",
});

export const useLanguage = () => useContext(LanguageContext);

interface LanguageProviderProps {
  children: ReactNode;
}

export const LanguageProvider = ({ children }: LanguageProviderProps) => {
  // Only English is supported now
  const [language, setLanguage] = useState<SupportedLanguages>('en');

  // Change language function - only English is supported
  const changeLanguage = (newLang: SupportedLanguages) => {
    console.log("Only English language is supported");
    setLanguage('en');
    localStorage.setItem('language', 'en');
  };

  // Translation function
  const t = (key: string, params?: Record<string, string>): string => {
    const translations = englishTranslations;
    // @ts-ignore
    const translation = translations[key] || key;
    
    if (!params) {
      return translation;
    }
    
    // Replace parameters
    let result = translation;
    Object.entries(params).forEach(([paramKey, value]) => {
      result = result.replace(`{${paramKey}}`, value);
    });
    
    return result;
  };

  return (
    <LanguageContext.Provider value={{ language, setLanguage: changeLanguage, t }}>
      {children}
    </LanguageContext.Provider>
  );
};