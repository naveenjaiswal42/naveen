import { createContext, ReactNode, useContext, useEffect, useState } from "react";
import { apiRequest } from "@/lib/queryClient";

// Local storage key for auth data
const LOCAL_STORAGE_KEY = 'trikala_auth_user';

interface User {
  id: number;
  phone: string;
  name?: string;
  profile_image?: string;
  level: number;
  xp: number;
}

interface AuthContextType {
  user: User | null;
  loading: boolean;
  updateUserProfile: (data: Partial<User>) => Promise<void>;
  logout: () => Promise<void>;
}

const AuthContext = createContext<AuthContextType>({
  user: null,
  loading: true,
  updateUserProfile: async () => {},
  logout: async () => {},
});

export const useAuth = () => useContext(AuthContext);

// Create default development user
const DEV_USER: User = {
  id: 1,
  phone: "1234567890",
  name: "Dev User",
  level: 3,
  xp: 750,
  profile_image: undefined,
};

export const AuthProvider = ({ children }: { children: ReactNode }) => {
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);
  
  // Fetch user from the API
  useEffect(() => {
    const fetchUser = async () => {
      try {
        setLoading(true);
        // In a real app, we would fetch the current user
        // For development, we'll use our API to get user with ID 1
        const userData = await apiRequest<User>({
          url: '/api/users/1',
          method: 'GET'
        }).catch(() => {
          console.log("Using default user");
          return DEV_USER;
        });
        
        setUser(userData);
      } catch (error) {
        console.error("Error fetching user:", error);
        // Fallback to default user on error
        setUser(DEV_USER);
      } finally {
        setLoading(false);
      }
    };

    fetchUser();
  }, []);

  const updateUserProfile = async (data: Partial<User>) => {
    if (!user) return;
    
    try {
      // Update via API
      const updatedUser = await apiRequest<User>({
        url: `/api/users/${user.id}`,
        method: 'PATCH',
        body: data
      });
      
      setUser(updatedUser);
    } catch (error) {
      console.error("Error updating profile:", error);
      
      // Optimistic update to keep the UI responsive
      setUser({ ...user, ...data });
    }
  };

  const logout = async () => {
    // In development mode, don't actually log out - just reload the page
    // This ensures we never get stuck on the login screen
    window.location.reload();
  };

  return (
    <AuthContext.Provider value={{ user, loading, updateUserProfile, logout }}>
      {children}
    </AuthContext.Provider>
  );
};
