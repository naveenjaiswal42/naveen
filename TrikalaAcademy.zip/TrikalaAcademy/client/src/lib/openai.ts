import { apiRequest } from "./queryClient";

// Response type for our OpenAI API endpoint
interface OpenAIResponse {
  success: boolean;
  message: string;
}

/**
 * Get spiritual guidance based on the user's query
 * @param query The user's question about spiritual practice
 * @returns The AI-generated response
 */
export async function getSpiritualGuidance(query: string): Promise<string> {
  try {
    const response = await apiRequest({
      url: "/api/openai-test",
      method: "POST",
      body: { query }
    }) as OpenAIResponse;

    if (response.success) {
      return response.message;
    } else {
      throw new Error("Failed to get spiritual guidance");
    }
  } catch (error) {
    console.error("Error getting spiritual guidance:", error);
    return "I'm unable to connect with the universal wisdom at this moment. Please try again later.";
  }
}

/**
 * Get personalized chakra balancing recommendations
 * @param chakraType The chakra to focus on
 * @param userExperience The user's experience level
 * @returns Personalized recommendations
 */
export async function getChakraRecommendations(
  chakraType: string,
  userExperience: "beginner" | "intermediate" | "advanced"
): Promise<{
  affirmations: string[];
  practices: string[];
  dietRecommendations: string[];
}> {
  try {
    const query = `Please provide personalized recommendations for balancing the ${chakraType} chakra for a ${userExperience}. Include specific affirmations, practices, and diet suggestions.`;
    
    const response = await apiRequest({
      url: "/api/openai-test",
      method: "POST",
      body: { query }
    }) as OpenAIResponse;

    if (response.success) {
      // Parse the response into our expected format
      try {
        // Try to extract structured data from the response
        const affirmations = extractSection(response.message, "affirmation", "affirmations");
        const practices = extractSection(response.message, "practice", "exercises");
        const dietRecommendations = extractSection(response.message, "food", "diet", "nutrition");
        
        return {
          affirmations: affirmations.length > 0 ? affirmations : ["I am balanced", "I am whole", "I am connected"],
          practices: practices.length > 0 ? practices : ["Meditation", "Yoga", "Deep breathing"],
          dietRecommendations: dietRecommendations.length > 0 ? dietRecommendations : ["Balanced diet", "Hydration", "Mindful eating"]
        };
      } catch (parseError) {
        console.error("Error parsing chakra recommendations:", parseError);
        return {
          affirmations: ["I am balanced", "I am whole", "I am connected"],
          practices: ["Meditation", "Yoga", "Deep breathing"],
          dietRecommendations: ["Balanced diet", "Hydration", "Mindful eating"]
        };
      }
    } else {
      throw new Error("Failed to get chakra recommendations");
    }
  } catch (error) {
    console.error("Error getting chakra recommendations:", error);
    return {
      affirmations: ["I am patient with technology", "I remain balanced despite challenges", "I am connected to wisdom"],
      practices: ["Basic meditation", "Simple breathing exercise", "Gentle stretching"],
      dietRecommendations: ["Balanced meals", "Staying hydrated", "Eating mindfully"]
    };
  }
}

/**
 * Generate a personalized spiritual growth plan
 * @param userData User information and goals
 * @returns A structured growth plan
 */
export async function generateSpiritualGrowthPlan(userData: {
  name: string;
  currentPractice?: string;
  goal: string;
  timeAvailable: string;
}): Promise<{
  dailyPractices: string[];
  weeklyPractices: string[];
  monthlyMilestones: string[];
  resources: string[];
}> {
  try {
    const query = `Create a personalized spiritual growth plan for ${userData.name} who currently practices "${userData.currentPractice || 'no regular practice'}" and has ${userData.timeAvailable} available for spiritual practice. Their goal is: ${userData.goal}. Include daily practices, weekly practices, monthly milestones, and recommended resources.`;
    
    const response = await apiRequest({
      url: "/api/openai-test",
      method: "POST",
      body: { query }
    }) as OpenAIResponse;

    if (response.success) {
      // Parse the response into our expected format
      try {
        // Try to extract structured data from the response
        const dailyPractices = extractSection(response.message, "daily", "each day");
        const weeklyPractices = extractSection(response.message, "weekly", "each week");
        const monthlyMilestones = extractSection(response.message, "monthly", "milestones");
        const resources = extractSection(response.message, "resource", "book", "app", "community");
        
        return {
          dailyPractices: dailyPractices.length > 0 ? dailyPractices : ["5-minute meditation", "Gratitude journal", "Mindful breathing"],
          weeklyPractices: weeklyPractices.length > 0 ? weeklyPractices : ["Nature walk", "Spiritual reading", "Self-reflection"],
          monthlyMilestones: monthlyMilestones.length > 0 ? monthlyMilestones : ["Complete a book on spirituality", "Try a new meditation technique", "Journal progress"],
          resources: resources.length > 0 ? resources : ["Recommended books", "Guided meditation apps", "Online communities"]
        };
      } catch (parseError) {
        console.error("Error parsing spiritual growth plan:", parseError);
        return {
          dailyPractices: ["5-minute meditation", "Gratitude journal", "Mindful breathing"],
          weeklyPractices: ["Nature walk", "Spiritual reading", "Self-reflection"],
          monthlyMilestones: ["Complete a book on spirituality", "Try a new meditation technique", "Journal progress"],
          resources: ["Recommended books", "Guided meditation apps", "Online communities"]
        };
      }
    } else {
      throw new Error("Failed to generate spiritual growth plan");
    }
  } catch (error) {
    console.error("Error generating spiritual growth plan:", error);
    return {
      dailyPractices: ["Short meditation", "Mindful breathing", "Gratitude practice"],
      weeklyPractices: ["Reflect on progress", "Learn something new", "Connect with nature"],
      monthlyMilestones: ["Establish consistent routine", "Notice inner changes", "Share knowledge"],
      resources: ["Meditation basics", "Spiritual texts", "Community support"]
    };
  }
}

/**
 * Helper function to extract sections from text-based response
 */
function extractSection(text: string, ...keywords: string[]): string[] {
  // Split text into sentences or bullet points
  const lines = text.split(/[.•\n]/).filter(line => line.trim().length > 0);
  
  // Filter lines that contain any of the keywords
  const relevantLines = lines.filter(line => 
    keywords.some(keyword => 
      line.toLowerCase().includes(keyword.toLowerCase())
    )
  );
  
  // Clean up the lines and remove duplicates
  const uniqueLines = Array.from(new Set(
    relevantLines.map(line => 
      line.trim()
        .replace(/^[-*•]/g, '')
        .replace(/^\d+\.\s*/g, '')
        .trim()
    ).filter(line => line.length > 0)
  ));
  
  return uniqueLines;
}