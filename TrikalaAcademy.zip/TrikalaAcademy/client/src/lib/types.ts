// Types for the application

export interface User {
  id: number;
  phone: string;
  name: string | null;
  profileImage: string | null;
  level: number;
  xp: number;
  meditation_streak: number;
  last_meditated_date: string | null;
  daily_ritual_streak: number;
  last_ritual_date: string | null;
  lastMissionCompleted: string | null;
  badges: string[];
  createdAt: string;
}

export interface Ritual {
  id: number;
  title: string;
  description: string;
  durationMinutes: number;
  icon: string;
  xpReward: number;
  timeOfDay: string;
}

export interface UserRitual {
  id: number;
  userId: number;
  ritualId: number;
  completedAt: string;
  date: string;
}

export interface Course {
  id: number;
  title: string;
  description: string;
  imageUrl: string;
  level: number;
  totalLessons: number;
  xpReward: number;
}

export interface UserCourse {
  id: number;
  userId: number;
  courseId: number;
  enrolledAt: string;
  lessonsCompleted: number;
  completionPercentage: number;
}

export interface MeditationTrack {
  id: number;
  title: string;
  chakraType: string;
  audioUrl: string;
  durationSeconds: number;
  frequency: string;
  imageUrl: string;
}

export interface Goal {
  id: number;
  userId: number;
  text: string;
  category: string;
  completed: boolean;
  targetDate: string | null;
  createdAt: string;
  updatedAt: string | null;
}

export interface JournalEntry {
  id: number;
  userId: number;
  title: string;
  content: string;
  mood: string;
  tags: string[];
  category: string;
  createdAt: string;
}

export interface MoodEntry {
  id: number;
  userId: number;
  mood: string;
  reflection: string;
  date: string;
  createdAt: string;
}