// This is a completely mocked Firebase implementation for development
// No actual Firebase imports or initialization is done

// Mock Firebase Auth User type
export interface User {
  uid: string;
  phoneNumber: string | null;
  displayName: string | null;
  email: string | null;
  photoURL: string | null;
  providerId: string;
  emailVerified: boolean;
  isAnonymous: boolean;
  metadata: {
    creationTime: string;
    lastSignInTime: string;
  };
  providerData: any[];
  refreshToken: string;
  tenantId: string | null;
  delete: () => Promise<void>;
  getIdToken: () => Promise<string>;
  getIdTokenResult: () => Promise<any>;
  reload: () => Promise<void>;
  toJSON: () => {};
}

// Mock auth object
export const auth = {
  onAuthStateChanged: (callback: any) => {
    // Immediately call with null to indicate no user
    callback(null);
    
    // Return empty unsubscribe function
    return () => {};
  },
  signOut: async () => {},
  currentUser: null
};

// Mock db object
export const db = {
  collection: () => ({
    doc: () => ({
      get: async () => ({
        exists: false,
        data: () => ({})
      }),
      set: async () => {}
    })
  })
};

// Mock storage object
export const storage = {
  ref: () => ({})
};

// Create a mock user
const createMockUser = (phoneNumber: string): User => {
  return {
    uid: "dev-user-123",
    phoneNumber: phoneNumber,
    displayName: "Dev User",
    email: null,
    photoURL: null,
    providerId: "phone",
    emailVerified: false,
    isAnonymous: false,
    metadata: {
      creationTime: new Date().toISOString(),
      lastSignInTime: new Date().toISOString()
    },
    providerData: [],
    refreshToken: "mock-refresh-token",
    tenantId: null,
    delete: async () => {},
    getIdToken: async () => "mock-id-token",
    getIdTokenResult: async () => ({
      token: "mock-token",
      signInProvider: "phone",
      expirationTime: new Date(Date.now() + 3600000).toISOString(),
      issuedAtTime: new Date().toISOString(),
      authTime: new Date().toISOString(),
      claims: {}
    }),
    reload: async () => {},
    toJSON: () => ({})
  };
};

// No-op functions that don't actually do anything
export const setupRecaptcha = () => {
  console.log("Development mode: Firebase completely disabled");
};

export const sendOtp = async () => {
  console.log("Development mode: Firebase completely disabled");
  return { success: true };
};

export const verifyOtp = async () => {
  console.log("Development mode: Firebase completely disabled");
  return { success: true, user: null };
};

export const logOut = async () => {
  console.log("Development mode: Firebase completely disabled");
  return { success: true };
};

export const getCurrentUser = () => {
  return null;
};

// Type for global window object
declare global {
  interface Window {
    devPhoneNumber: string;
  }
}
