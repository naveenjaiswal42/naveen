import { clsx, type ClassValue } from "clsx"
import { twMerge } from "tailwind-merge"

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs))
}

/**
 * Checks if a specific environment variable is available
 * @param key The environment variable key to check
 * @returns Boolean indicating if the key exists and has a value
 */
export function hasEnvVar(key: string): boolean {
  return !!import.meta.env[key] && import.meta.env[key] !== ""
}
