// Chakra definitions and utility functions

export type ChakraType = 
  | 'crown' 
  | 'thirdEye' 
  | 'throat' 
  | 'heart' 
  | 'solar' 
  | 'sacral' 
  | 'root';

export interface ChakraInfo {
  id: ChakraType;
  name: string;
  color: string;
  icon: string;
  frequency: string;
  affirmation: string;
  description: string;
  element: string;
  order: number;
}

export const chakras: ChakraInfo[] = [
  {
    id: 'crown',
    name: 'Crown',
    color: 'bg-purple-500',
    icon: 'fas fa-circle',
    frequency: '963 Hz',
    affirmation: 'I am connected to the divine',
    description: 'The Crown Chakra represents spiritual connection and higher consciousness.',
    element: 'Thought',
    order: 1
  },
  {
    id: 'thirdEye',
    name: 'Third Eye',
    color: 'bg-indigo-500',
    icon: 'fas fa-eye',
    frequency: '852 Hz',
    affirmation: 'I am intuitive and wise',
    description: 'The Third Eye Chakra is associated with intuition, wisdom, and clarity.',
    element: 'Light',
    order: 2
  },
  {
    id: 'throat',
    name: 'Throat',
    color: 'bg-blue-500',
    icon: 'fas fa-comment',
    frequency: '741 Hz',
    affirmation: 'I speak my truth with clarity',
    description: 'The Throat Chakra governs communication, expression, and truth.',
    element: 'Sound',
    order: 3
  },
  {
    id: 'heart',
    name: 'Heart',
    color: 'bg-green-500',
    icon: 'fas fa-heart',
    frequency: '639 Hz',
    affirmation: 'I am open to giving and receiving love',
    description: 'The Heart Chakra represents love, compassion, and harmony.',
    element: 'Air',
    order: 4
  },
  {
    id: 'solar',
    name: 'Solar Plexus',
    color: 'bg-yellow-500',
    icon: 'fas fa-sun',
    frequency: '528 Hz',
    affirmation: 'I am confident and powerful',
    description: 'The Solar Plexus Chakra is the center of personal power and confidence.',
    element: 'Fire',
    order: 5
  },
  {
    id: 'sacral',
    name: 'Sacral',
    color: 'bg-orange-500',
    icon: 'fas fa-moon',
    frequency: '417 Hz',
    affirmation: 'I embrace creativity and flow',
    description: 'The Sacral Chakra is connected to emotions, creativity, and pleasure.',
    element: 'Water',
    order: 6
  },
  {
    id: 'root',
    name: 'Root',
    color: 'bg-red-500',
    icon: 'fas fa-square-root-alt',
    frequency: '396 Hz',
    affirmation: 'I am safe and grounded',
    description: 'The Root Chakra represents security, stability, and basic needs.',
    element: 'Earth',
    order: 7
  }
];

// Get total count of active chakras
export const getActiveChakrasCount = (userChakras: Record<ChakraType, boolean>): number => {
  return Object.values(userChakras).filter(Boolean).length;
};

// Calculate user's spiritual progress percentage based on chakras
export const getChakraProgressPercentage = (userChakras: Record<ChakraType, boolean>): number => {
  const activeCount = getActiveChakrasCount(userChakras);
  return Math.floor((activeCount / chakras.length) * 100);
};

// Get meditation frequencies for specific chakra
export const getChakraFrequency = (chakraType: ChakraType): string => {
  return chakras.find(chakra => chakra.id === chakraType)?.frequency || '';
};

// Get recommended next chakra to work on
export const getRecommendedChakra = (userChakras: Record<ChakraType, boolean>): ChakraInfo | null => {
  // Find the first inactive chakra (in reverse order - start from root)
  for (const chakra of [...chakras].reverse()) {
    if (!userChakras[chakra.id]) {
      return chakra;
    }
  }
  return null;
};
