// Translation files for the application - English only

export type SupportedLanguages = 'en';

// English translations
export const englishTranslations = {
  // General
  welcome: "Welcome, {name}!",
  spiritualSeeker: "Spiritual Seeker",
  loading: "Loading...",
  pleaseWait: "Please wait",
  
  // Tabs
  home: "Home",
  courses: "Courses",
  chakras: "Chakras",
  rituals: "Rituals",
  guidance: "Guidance",
  profile: "Profile",
  
  // Dashboard
  dailyRituals: "Daily Rituals",
  viewAll: "View All",
  chakraProgress: "Chakra Progress",
  recommendedCourses: "Recommended Courses",
  
  // Profile
  level: "Level",
  experience: "Experience Points (XP)",
  nextLevel: "Next level:",
  moreXpNeeded: "more XP needed",
  meditationStreak: "Meditation Streak",
  consecutiveDays: "consecutive days",
  achievements: "Achievements",
  
  // Chakras
  root: "Root Chakra",
  sacral: "Sacral Chakra",
  solar: "Solar Plexus Chakra",
  heart: "Heart Chakra",
  throat: "Throat Chakra",
  thirdEye: "Third Eye Chakra",
  crown: "Crown Chakra",
  
  // Courses
  allCourses: "All Courses",
  myCourses: "My Courses",
  beginner: "Beginner",
  advanced: "Advanced",
  enroll: "Enroll Now",
  enrolled: "Enrolled",
  lessons: "lessons",
  
  // Language
  changeLanguage: "Change Language"
};

// Get translations - only English is supported
export const getTranslations = (language: SupportedLanguages) => {
  return englishTranslations;
};

// Translation function with parameter substitution
export const translate = (key: keyof typeof englishTranslations, language: SupportedLanguages, params?: Record<string, string>): string => {
  const translations = englishTranslations;
  const translation = translations[key] || key;
  
  if (!params) {
    return translation;
  }
  
  // Replace parameters
  let result = translation;
  Object.entries(params).forEach(([paramKey, value]) => {
    result = result.replace(`{${paramKey}}`, value);
  });
  
  return result;
};