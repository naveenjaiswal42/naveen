import { communityPosts, postComments, postLikes, CommunityPost as DbCommunityPost, PostComment, InsertCommunityPost, InsertPostComment } from "@shared/schema";
import { db } from "./db";
import { eq, desc, and, sql } from "drizzle-orm";
import { SQL } from "drizzle-orm/sql";
import { DatabaseStorage } from "./storage";
import { CommunityPost } from "./storage-community-types";

// Get all community posts with comments
DatabaseStorage.prototype.getCommunityPosts = async function(userId?: number): Promise<CommunityPost[]> {
  const posts = await db.query.communityPosts.findMany({
    orderBy: [desc(communityPosts.createdAt)],
  });

  // Get comments for each post
  const result = await Promise.all(
    posts.map(async (post) => {
      const comments = await db.query.postComments.findMany({
        where: eq(postComments.postId, post.id),
        orderBy: [desc(postComments.createdAt)],
      });

      // Check if the user has liked the post
      let isLiked = false;
      if (userId) {
        const [like] = await db.select()
          .from(postLikes)
          .where(and(
            eq(postLikes.postId, post.id),
            eq(postLikes.userId, userId)
          ));
        isLiked = !!like;
      }

      return {
        ...post,
        comments,
        isLiked
      };
    })
  );

  return result;
};

// Create a new community post
DatabaseStorage.prototype.createCommunityPost = async function(data: InsertCommunityPost): Promise<CommunityPost> {
  const [post] = await db.insert(communityPosts)
    .values(data)
    .returning();
  
  return {
    ...post,
    comments: [],
    isLiked: false
  };
};

// Add a comment to a post
DatabaseStorage.prototype.addComment = async function(data: InsertPostComment): Promise<PostComment> {
  const [comment] = await db.insert(postComments)
    .values(data)
    .returning();
  
  return comment;
};

// Like a post
DatabaseStorage.prototype.likePost = async function(postId: number, userId: number): Promise<void> {
  // Check if the user has already liked the post
  const [existingLike] = await db.select()
    .from(postLikes)
    .where(and(
      eq(postLikes.postId, postId),
      eq(postLikes.userId, userId)
    ));

  if (existingLike) {
    // Unlike if already liked
    await db.delete(postLikes)
      .where(and(
        eq(postLikes.postId, postId),
        eq(postLikes.userId, userId)
      ));
    
    // Decrement the likes count
    await db.update(communityPosts)
      .set({ likes: sql`likes - 1`.mapWith(Number) })
      .where(eq(communityPosts.id, postId));
  } else {
    // Add like
    await db.insert(postLikes)
      .values({
        postId,
        userId
      });
    
    // Increment the likes count
    await db.update(communityPosts)
      .set({ likes: sql`likes + 1`.mapWith(Number) })
      .where(eq(communityPosts.id, postId));
  }
};

// Get post by ID with its comments
DatabaseStorage.prototype.getPostById = async function(postId: number, userId?: number): Promise<CommunityPost | undefined> {
  const [post] = await db.select().from(communityPosts).where(eq(communityPosts.id, postId));
  
  if (!post) return undefined;
  
  const comments = await db.query.postComments.findMany({
    where: eq(postComments.postId, postId),
    orderBy: [desc(postComments.createdAt)],
  });

  // Check if the user has liked the post
  let isLiked = false;
  if (userId) {
    const [like] = await db.select()
      .from(postLikes)
      .where(and(
        eq(postLikes.postId, postId),
        eq(postLikes.userId, userId)
      ));
    isLiked = !!like;
  }

  return {
    ...post,
    comments,
    isLiked
  };
};