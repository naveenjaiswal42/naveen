import OpenAI from "openai";

const openai = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY,
});

/**
 * Generate a spiritual affirmation using OpenAI
 */
export async function generateAffirmation(): Promise<{ affirmation: string }> {
  try {
    console.log("Generating spiritual affirmation...");
    
    const response = await openai.chat.completions.create({
      model: "gpt-4o", // the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
      messages: [
        {
          role: "system",
          content: "You are a spiritual guide with expertise in Vedic traditions, mindfulness, and personal growth. Generate a short, powerful spiritual affirmation that is positive, inspiring, and suitable for daily practice. The affirmation should be concise (maximum 15 words) and focused on spiritual growth, self-awareness, or inner peace.",
        },
        {
          role: "user",
          content: "Generate a spiritual affirmation for my daily practice."
        }
      ],
      max_tokens: 50,
      temperature: 0.7,
    });

    const affirmation = response.choices[0].message.content?.trim() || "I am connected to divine wisdom and inner peace.";
    
    return { affirmation };
  } catch (error: any) {
    console.error("Affirmation generation failed:", error);
    // Return a default affirmation if the API call fails
    return { 
      affirmation: "I am connected to divine wisdom and inner peace."
    };
  }
}

/**
 * Track affirmation download for user rewards
 */
export async function trackAffirmationDownload(userId: number): Promise<{ success: boolean, xpEarned: number }> {
  try {
    // Logic to track the download in the database could be added here
    // For now, we'll just return a success response with XP earned
    
    return {
      success: true,
      xpEarned: 15 // XP reward for downloading an affirmation
    };
  } catch (error) {
    console.error("Error tracking affirmation download:", error);
    return {
      success: false,
      xpEarned: 0
    };
  }
}