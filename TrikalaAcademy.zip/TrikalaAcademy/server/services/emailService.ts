/**
 * Email Service for Trikala Academy
 * Handles email delivery and digest generation for users
 */

import nodemailer from 'nodemailer';
import { format } from 'date-fns';

// Initialize transporter for local development
// In production, would use proper SMTP credentials
const transporter = nodemailer.createTransport({
  host: 'smtp.ethereal.email',
  port: 587,
  auth: {
    user: 'ethereal.user@ethereal.email',
    pass: 'ethereal_pass'
  }
});

// Email template for weekly digest
const generateWeeklyDigestHtml = (user: any, stats: any) => {
  const today = new Date();
  const formattedDate = format(today, 'MMMM d, yyyy');
  
  return `
  <!DOCTYPE html>
  <html>
  <head>
    <meta charset="utf-8">
    <title>Weekly Spiritual Digest - Trikala Academy</title>
    <style>
      body {
        font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        line-height: 1.6;
        color: #333;
        max-width: 600px;
        margin: 0 auto;
        padding: 20px;
      }
      .header {
        background: linear-gradient(135deg, #6366f1 0%, #8b5cf6 100%);
        color: white;
        padding: 20px;
        border-radius: 8px 8px 0 0;
        text-align: center;
      }
      .content {
        background-color: #f9fafb;
        padding: 20px;
        border-radius: 0 0 8px 8px;
        border: 1px solid #e5e7eb;
        border-top: none;
      }
      .footer {
        text-align: center;
        margin-top: 20px;
        font-size: 12px;
        color: #6b7280;
      }
      h1, h2 {
        color: #4f46e5;
      }
      .stats {
        background-color: white;
        border-radius: 8px;
        padding: 15px;
        margin: 20px 0;
        box-shadow: 0 1px 3px rgba(0,0,0,0.1);
      }
      .stat-item {
        display: flex;
        justify-content: space-between;
        margin-bottom: 10px;
        padding-bottom: 10px;
        border-bottom: 1px solid #f3f4f6;
      }
      .stat-item:last-child {
        border-bottom: none;
        margin-bottom: 0;
        padding-bottom: 0;
      }
      .stat-label {
        font-weight: 500;
      }
      .stat-value {
        font-weight: 600;
        color: #4f46e5;
      }
      .cta-button {
        display: inline-block;
        background-color: #4f46e5;
        color: white;
        text-decoration: none;
        padding: 10px 20px;
        border-radius: 4px;
        margin-top: 20px;
        font-weight: 500;
      }
      .quote {
        font-style: italic;
        color: #4b5563;
        padding: 10px 0;
        border-left: 3px solid #8b5cf6;
        padding-left: 15px;
        margin: 20px 0;
      }
    </style>
  </head>
  <body>
    <div class="header">
      <h1>🧘‍♂️ Your Weekly Spiritual Journey</h1>
      <p>${formattedDate}</p>
    </div>
    <div class="content">
      <h2>Hello ${user.name || 'Spiritual Seeker'},</h2>
      <p>Here's a summary of your spiritual progress this week:</p>
      
      <div class="stats">
        <div class="stat-item">
          <span class="stat-label">Total XP Earned:</span>
          <span class="stat-value">${stats.totalXp || 0}</span>
        </div>
        <div class="stat-item">
          <span class="stat-label">Weekly XP Earned:</span>
          <span class="stat-value">+${stats.weeklyXpGain || 0} XP</span>
        </div>
        <div class="stat-item">
          <span class="stat-label">Meditation Streak:</span>
          <span class="stat-value">${stats.meditationStreak || 0} Days</span>
        </div>
        <div class="stat-item">
          <span class="stat-label">Daily Ritual Streak:</span>
          <span class="stat-value">${stats.ritualStreak || 0} Days</span>
        </div>
        <div class="stat-item">
          <span class="stat-label">Active Chakras:</span>
          <span class="stat-value">${stats.activeChakras || 0}/7</span>
        </div>
      </div>
      
      ${stats.achievements && stats.achievements.length > 0 ? `
      <h3>🏆 Recent Achievements</h3>
      <ul>
        ${stats.achievements.map((achievement: any) => `<li>${achievement.title}</li>`).join('')}
      </ul>
      ` : ''}
      
      <div class="quote">
        <p>"The spiritual journey is the unlearning of fear and the acceptance of love." - Marianne Williamson</p>
      </div>
      
      <p>Continue your journey and unlock your inner potential. Remember, consistency is key to spiritual growth.</p>
      
      <a href="https://trikala-academy.replit.app/dashboard" class="cta-button">Continue Your Journey</a>
    </div>
    <div class="footer">
      <p>Trikala Academy - Guiding Your Spiritual Journey</p>
      <p>If you wish to unsubscribe from these emails, <a href="#">click here</a>.</p>
    </div>
  </body>
  </html>
  `;
};

// Send weekly digest email to a user
export const sendWeeklyDigestEmail = async (user: any, stats: any) => {
  try {
    const mailOptions = {
      from: '"Trikala Academy" <noreply@trikala-academy.com>',
      to: user.email,
      subject: '🧘‍♂️ Your Weekly Spiritual Progress - Trikala Academy',
      html: generateWeeklyDigestHtml(user, stats)
    };

    const info = await transporter.sendMail(mailOptions);
    console.log('Message sent: %s', info.messageId);
    return { success: true, messageId: info.messageId };
  } catch (error) {
    console.error('Error sending weekly digest email:', error);
    throw error;
  }
};

// Send a single test email
export const sendTestEmail = async (email: string) => {
  try {
    const testUser = {
      name: 'Test User',
      email
    };
    
    const testStats = {
      totalXp: 1250,
      weeklyXpGain: 320,
      meditationStreak: 7,
      ritualStreak: 5,
      activeChakras: 3,
      achievements: [
        { title: 'Root Chakra Activated' },
        { title: '7-Day Meditation Streak' }
      ]
    };
    
    return await sendWeeklyDigestEmail(testUser, testStats);
  } catch (error) {
    console.error('Error sending test email:', error);
    throw error;
  }
};

// Generate and send weekly digest emails to all active users
export const sendWeeklyDigestToAllUsers = async (users: any[]) => {
  const results = {
    success: 0,
    failed: 0,
    errors: [] as any[]
  };
  
  for (const user of users) {
    try {
      if (!user.email) continue;
      
      // Here we would fetch user's actual stats from database
      const stats = {
        totalXp: user.xp || 0,
        weeklyXpGain: Math.floor(Math.random() * 300),
        meditationStreak: user.meditationStreak || 0,
        ritualStreak: user.dailyRitualStreak || 0,
        activeChakras: user.activeChakras || 0,
        achievements: user.recentAchievements || []
      };
      
      await sendWeeklyDigestEmail(user, stats);
      results.success++;
    } catch (error) {
      console.error(`Failed to send weekly digest to ${user.email}:`, error);
      results.failed++;
      results.errors.push({ email: user.email, error });
    }
  }
  
  return results;
};