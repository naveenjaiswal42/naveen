import { eq, and, sql, desc, gte, lte } from 'drizzle-orm';
import { SQL } from "drizzle-orm/sql";
import { 
  moodEntries,
  type MoodEntry,
  type InsertMoodEntry
} from '@shared/schema';
import { db } from './db';
import { DatabaseStorage } from './storage';

// Extension methods for DatabaseStorage class to handle mood entries
// These methods will be used by adding them to the DatabaseStorage prototype

DatabaseStorage.prototype.getUserMoodEntries = async function(userId: number): Promise<MoodEntry[]> {
  try {
    const entries = await db
      .select()
      .from(moodEntries)
      .where(eq(moodEntries.userId, userId))
      .orderBy(desc(moodEntries.createdAt));
    
    return entries;
  } catch (error) {
    console.error('Error getting mood entries:', error);
    return [];
  }
};

DatabaseStorage.prototype.getUserMoodEntriesByDate = async function(userId: number, date: string): Promise<MoodEntry[]> {
  try {
    const entries = await db
      .select()
      .from(moodEntries)
      .where(and(
        eq(moodEntries.userId, userId),
        eq(moodEntries.date, date)
      ))
      .orderBy(desc(moodEntries.createdAt));
    
    return entries;
  } catch (error) {
    console.error('Error getting mood entries by date:', error);
    return [];
  }
};

DatabaseStorage.prototype.createMoodEntry = async function(entry: InsertMoodEntry): Promise<MoodEntry> {
  try {
    const [newEntry] = await db
      .insert(moodEntries)
      .values(entry)
      .returning();
    
    if (!newEntry) {
      throw new Error("Failed to create mood entry");
    }
    
    // Award XP for tracking mood - emotional awareness is important for spiritual growth
    await this.addUserXP(entry.userId, 20);
    
    return newEntry;
  } catch (error) {
    console.error('Error creating mood entry:', error);
    throw error;
  }
};

DatabaseStorage.prototype.updateMoodEntry = async function(userId: number, entryId: number, data: Partial<MoodEntry>): Promise<MoodEntry | undefined> {
  try {
    const [updatedEntry] = await db
      .update(moodEntries)
      .set(data)
      .where(and(
        eq(moodEntries.id, entryId),
        eq(moodEntries.userId, userId)
      ))
      .returning();
    
    return updatedEntry;
  } catch (error) {
    console.error('Error updating mood entry:', error);
    return undefined;
  }
};

DatabaseStorage.prototype.deleteMoodEntry = async function(userId: number, entryId: number): Promise<boolean> {
  try {
    const result = await db
      .delete(moodEntries)
      .where(and(
        eq(moodEntries.id, entryId),
        eq(moodEntries.userId, userId)
      ));
    
    return result && result.rowCount ? result.rowCount > 0 : false;
  } catch (error) {
    console.error('Error deleting mood entry:', error);
    return false;
  }
};

DatabaseStorage.prototype.getMoodSummary = async function(userId: number, startDate: string, endDate: string): Promise<{mood: string, count: number}[]> {
  try {
    const entries = await db
      .select({
        mood: moodEntries.mood,
        count: sql`count(*)::integer as count`
      })
      .from(moodEntries)
      .where(and(
        eq(moodEntries.userId, userId),
        gte(moodEntries.date, startDate),
        lte(moodEntries.date, endDate)
      ))
      .groupBy(moodEntries.mood);
    
    return entries.map(entry => ({
      mood: entry.mood,
      count: Number(entry.count)
    }));
  } catch (error) {
    console.error('Error getting mood summary:', error);
    return [];
  }
};