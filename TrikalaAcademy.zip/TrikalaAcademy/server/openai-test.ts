import OpenAI from "openai";

const openai = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY,
});

/**
 * Simple function to test OpenAI API connectivity
 */
export async function testOpenAIConnection(): Promise<any> {
  try {
    console.log("Testing OpenAI connection...");
    console.log("Using API key:", process.env.OPENAI_API_KEY ? "****" + process.env.OPENAI_API_KEY.slice(-4) : "Not found");
    
    // Basic test query to check API connectivity
    const response = await openai.chat.completions.create({
      model: "gpt-4o",
      messages: [
        {
          role: "system",
          content: "You are a test assistant. Respond with a simple JSON containing a success message.",
        },
        {
          role: "user",
          content: "Test the API connection."
        }
      ],
      max_tokens: 50,
      response_format: { type: "json_object" },
    });

    return {
      success: true,
      modelUsed: response.model,
      message: response.choices[0].message.content,
      usage: response.usage,
    };
  } catch (error: any) {
    console.error("OpenAI connection test failed:", error);
    return {
      success: false,
      error: error.message,
      statusCode: error.status || error.statusCode,
    };
  }
}

/**
 * Process a custom query to OpenAI
 */
export async function processOpenAIQuery(query: string): Promise<any> {
  try {
    console.log("Processing OpenAI query:", query);
    
    const response = await openai.chat.completions.create({
      model: "gpt-4o",
      messages: [
        {
          role: "system",
          content: "You are a spiritual guide with expertise in Vedic traditions, chakras, meditation, and holistic wellness. Provide insightful, compassionate responses focused on spiritual growth and self-awareness. Keep responses concise (under 250 words).",
        },
        {
          role: "user",
          content: query
        }
      ],
      max_tokens: 500,
    });

    return {
      success: true,
      modelUsed: response.model,
      message: response.choices[0].message.content,
      usage: response.usage,
    };
  } catch (error: any) {
    console.error("OpenAI query processing failed:", error);
    return {
      success: false,
      error: error.message,
      statusCode: error.status || error.statusCode,
    };
  }
}