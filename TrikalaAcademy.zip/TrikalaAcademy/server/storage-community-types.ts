import { InferModel } from "drizzle-orm";
import { pgTable, bigserial, text, boolean, timestamp, integer } from "drizzle-orm/pg-core";

// Community Posts Table
export const communityPosts = pgTable("community_posts", {
  id: bigserial("id", { mode: "number" }).primaryKey(),
  userId: integer("user_id").notNull(),
  content: text("content").notNull(),
  imageUrl: text("image_url"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
  likes: integer("likes").default(0).notNull(),
  isPrivate: boolean("is_private").default(false).notNull(),
});

// Post Comments Table
export const postComments = pgTable("post_comments", {
  id: bigserial("id", { mode: "number" }).primaryKey(),
  postId: integer("post_id").notNull(),
  userId: integer("user_id").notNull(),
  content: text("content").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

// Post Likes Table to track which users liked which posts
export const postLikes = pgTable("post_likes", {
  id: bigserial("id", { mode: "number" }).primaryKey(),
  postId: integer("post_id").notNull(),
  userId: integer("user_id").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// Type Definitions
export type DbCommunityPost = InferModel<typeof communityPosts, 'select'>;
export type InsertCommunityPost = InferModel<typeof communityPosts, 'insert'>;

export type PostComment = InferModel<typeof postComments, 'select'>;
export type InsertPostComment = InferModel<typeof postComments, 'insert'>;

export type PostLike = InferModel<typeof postLikes, 'select'>;
export type InsertPostLike = InferModel<typeof postLikes, 'insert'>;

// Extended Types with Relationships
export interface CommunityPost extends DbCommunityPost {
  comments: PostComment[];
  isLiked?: boolean;
}