import { auth, db } from './firebase';

/**
 * Simple function to test Firebase Admin SDK connectivity
 * With timeout to avoid hanging in Replit environment
 */
export async function testFirebaseConnection() {
  // Create a promise that rejects after a timeout
  const timeout = (ms: number) => new Promise((_, reject) => 
    setTimeout(() => reject(new Error(`Firebase connection test timed out after ${ms}ms`)), ms)
  );
  
  // Main test function
  const runTest = async () => {
    try {
      // Test Firestore connection
      let firestoreConnected = false;
      let firestoreData = null;
      try {
        const testDoc = await db.collection('test').doc('connection-test').get();
        firestoreConnected = true;
        firestoreData = testDoc.exists ? testDoc.data() : null;
      } catch (firestoreError: any) {
        console.error("Firestore connection failed:", firestoreError);
      }
      
      // Test Auth connection
      let authConnected = false;
      let usersCount = 0;
      try {
        const usersResult = await auth.listUsers(1);
        authConnected = true;
        usersCount = usersResult.users.length;
      } catch (authError: any) {
        console.error("Auth connection failed:", authError);
      }
      
      if (firestoreConnected || authConnected) {
        return {
          success: firestoreConnected && authConnected,
          firestoreConnected,
          authConnected,
          firestoreData,
          users: usersCount,
          message: "Firebase connection test completed",
          partialSuccess: firestoreConnected || authConnected
        };
      } else {
        return {
          success: false,
          firestoreConnected: false,
          authConnected: false,
          error: "Both Firestore and Auth connections failed"
        };
      }
    } catch (error: any) {
      console.error('Firebase connection test failed:', error);
      return {
        success: false,
        error: error.message,
        code: error.code,
        firestoreConnected: false,
        authConnected: false
      };
    }
  };
  
  // Race the test against a timeout
  try {
    return await Promise.race([
      runTest(),
      timeout(5000) // 5 second timeout
    ]);
  } catch (error: any) {
    console.error("Firebase test timeout:", error.message);
    return {
      success: false,
      error: error.message,
      firestoreConnected: false,
      authConnected: false,
      timedOut: true
    };
  }
}