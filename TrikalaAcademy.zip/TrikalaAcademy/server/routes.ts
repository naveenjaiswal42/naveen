import type { Express, Request, Response, NextFunction } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { WebSocketServer, WebSocket } from "ws";
import { z } from "zod";
import { db, auth } from "./firebase";
import { testFirebaseConnection } from "./firebase-test";
import { testOpenAIConnection, processOpenAIQuery } from "./openai-test";
import { insertUserSchema, insertChakraSchema, insertRitualSchema, insertUserRitualSchema, insertCourseSchema, insertUserCourseSchema, insertMeditationTrackSchema, insertJournalEntrySchema, insertMoodEntrySchema } from "../shared/schema";
import { CommunityPost } from "./storage-community-types";
import { sendTestEmail, sendWeeklyDigestToAllUsers } from './services/emailService';
import { generateAffirmation, trackAffirmationDownload } from './services/affirmationService';

// Extend Express Request type to include user property
declare global {
  namespace Express {
    interface Request {
      user: {
        uid: string;
        phone?: string;
      };
    }
  }
}

// Define user token validation
const userTokenSchema = z.object({
  uid: z.string(),
  phone: z.string().optional(),
});

// Determine if we're in development mode
const isDevelopment = process.env.NODE_ENV === 'development';

// Middleware to verify authentication token - with development bypass
const verifyToken = async (req: Request, res: Response, next: Function) => {
  // In development mode, auto-assign dev user and skip token verification
  if (isDevelopment) {
    console.log('🔧 Development mode: Bypassing auth check, using dev user');
    req.user = {
      uid: '1', // Use numeric ID that will convert properly to an integer
      phone: '1234567890'
    };
    return next();
  }
  
  // Production authentication flow
  try {
    const authHeader = req.headers.authorization;
    if (!authHeader || !authHeader.startsWith('Bearer ')) {
      return res.status(401).json({ message: 'Unauthorized: No token provided' });
    }

    const token = authHeader.split('Bearer ')[1];
    if (!token) {
      return res.status(401).json({ message: 'Unauthorized: Invalid token format' });
    }

    // Verify the Firebase token
    const decodedToken = await auth.verifyIdToken(token);
    req.user = {
      uid: decodedToken.uid,
      phone: decodedToken.phone_number,
    };
    next();
  } catch (error) {
    console.error('Error verifying token:', error);
    return res.status(401).json({ message: 'Unauthorized: Invalid token' });
  }
};

export async function registerRoutes(app: Express): Promise<Server> {
  const httpServer = createServer(app);
  
  // Create WebSocket server for real-time updates on a specific path
  // to avoid conflicting with Vite's HMR websocket
  const wss = new WebSocketServer({ 
    server: httpServer, 
    path: '/ws' 
  });
  
  wss.on('connection', (ws) => {
    console.log('Client connected');
    
    ws.on('message', (message) => {
      console.log('Received message:', message.toString());
    });
    
    ws.on('close', () => {
      console.log('Client disconnected');
    });
    
    // Send initial connection confirmation
    ws.send(JSON.stringify({ type: 'connected', message: 'Successfully connected to WebSocket server' }));
  });
  
  // Broadcast updates to all connected clients
  const broadcastUpdate = (type: string, data: any) => {
    wss.clients.forEach((client) => {
      if (client.readyState === WebSocket.OPEN) {
        try {
          client.send(JSON.stringify({ type, data }));
        } catch (error) {
          console.error('Error broadcasting update:', error);
        }
      }
    });
  };
  
  // Health check endpoint
  app.get('/api/health', (req, res) => {
    res.status(200).json({ status: 'ok' });
  });
  
  // Firebase connection test endpoint
  app.get('/api/firebase-test', async (req, res) => {
    try {
      console.log('Testing Firebase connection...');
      const result = await testFirebaseConnection();
      console.log('Firebase test result:', result);
      res.json(result);
    } catch (error: any) {
      console.error('Error testing Firebase connection:', error);
      res.status(500).json({ 
        message: 'Firebase connection test failed', 
        error: error.message,
        stack: error.stack
      });
    }
  });
  
  // OpenAI connection test endpoint
  app.get('/api/openai-test', async (req, res) => {
    try {
      console.log('Testing OpenAI connection...');
      const result = await testOpenAIConnection();
      console.log('OpenAI test result:', result);
      res.json(result);
    } catch (error: any) {
      console.error('Error testing OpenAI connection:', error);
      res.status(500).json({ 
        message: 'OpenAI connection test failed', 
        error: error.message,
        stack: error.stack
      });
    }
  });
  
  // Process OpenAI query (no authentication required for testing)
  app.post('/api/openai-test', async (req, res) => {
    try {
      const { query } = req.body;
      
      if (!query || typeof query !== 'string') {
        return res.status(400).json({ 
          success: false, 
          message: 'Query is required and must be a string' 
        });
      }
      
      console.log('Processing OpenAI query:', query);
      const result = await processOpenAIQuery(query);
      res.json(result);
    } catch (error: any) {
      console.error('Error processing OpenAI query:', error);
      res.status(500).json({ 
        success: false,
        message: 'OpenAI query processing failed', 
        error: error.message
      });
    }
  });
  
  // ===== Leaderboard Endpoints =====
  
  // Get weekly leaderboard
  app.get('/api/leaderboard', async (req, res) => {
    try {
      // Get top 10 users by XP
      const users = await storage.getTopUsersByXP(10);
      
      // Format response data
      const leaderboardData = users.map((user, index) => ({
        id: user.id,
        name: user.name || `User ${user.id}`,
        xp: user.xp || 0,
        level: user.level || 1,
        rank: index + 1,
        streak: user.meditation_streak || 0,
        ritualStreak: user.daily_ritual_streak || 0
      }));
      
      res.json(leaderboardData);
    } catch (error) {
      console.error('Error getting leaderboard:', error);
      res.status(500).json({ message: 'Internal server error' });
    }
  });

  // ===== User Endpoints =====
  
  // Get user profile
  app.get('/api/users/:userId', verifyToken, async (req, res) => {
    try {
      const { userId } = req.params;
      
      // Verify user is accessing their own data
      if (req.user.uid !== userId) {
        return res.status(403).json({ message: 'Forbidden: You can only access your own data' });
      }
      
      const user = await storage.getUser(parseInt(userId));
      
      if (!user) {
        return res.status(404).json({ message: 'User not found' });
      }
      
      res.json(user);
    } catch (error) {
      console.error('Error getting user:', error);
      res.status(500).json({ message: 'Internal server error' });
    }
  });
  
  // Update user profile
  app.patch('/api/users/:userId', verifyToken, async (req, res) => {
    try {
      const { userId } = req.params;
      
      // Verify user is updating their own data
      if (req.user.uid !== userId) {
        return res.status(403).json({ message: 'Forbidden: You can only update your own data' });
      }
      
      const updateData = req.body;
      const updatedUser = await storage.updateUser(parseInt(userId), updateData);
      
      res.json(updatedUser);
    } catch (error) {
      console.error('Error updating user:', error);
      res.status(500).json({ message: 'Internal server error' });
    }
  });
  
  // Award XP to user (for certificate download, etc.)
  app.post('/api/users/:userId/xp', verifyToken, async (req, res) => {
    try {
      const { userId } = req.params;
      const { xpAmount } = req.body;
      
      // Validate XP amount
      if (!xpAmount || typeof xpAmount !== 'number' || xpAmount <= 0) {
        return res.status(400).json({ message: 'Invalid XP amount provided' });
      }
      
      // In development, don't enforce same-user policy to make testing easier
      if (!isDevelopment && req.user.uid !== userId) {
        return res.status(403).json({ message: 'Forbidden: You can only modify your own XP' });
      }
      
      const updatedUser = await storage.addUserXP(parseInt(userId), xpAmount);
      
      if (!updatedUser) {
        return res.status(404).json({ message: 'User not found' });
      }
      
      // Broadcast update via WebSocket to notify all clients
      broadcastUpdate('user_xp_updated', { 
        userId: updatedUser.id, 
        xp: updatedUser.xp,
        message: `User received ${xpAmount} XP!`
      });
      
      res.json(updatedUser);
    } catch (error) {
      console.error('Error adding XP to user:', error);
      res.status(500).json({ message: 'Internal server error' });
    }
  });
  
  // Mark ritual as complete
  app.post('/api/users/:userId/rituals/:ritualId/complete', verifyToken, async (req, res) => {
    try {
      const { userId, ritualId } = req.params;
      const { completedDate } = req.body;
      
      // In development, don't enforce same-user policy
      if (!isDevelopment && req.user.uid !== userId) {
        return res.status(403).json({ message: 'Forbidden: You can only complete your own rituals' });
      }
      
      // Create user ritual object for the storage interface
      const userRitual = {
        id: 0, // This will be auto-assigned by the database
        userId: parseInt(userId),
        ritualId: parseInt(ritualId),
        completedAt: new Date(),
        date: completedDate || new Date().toISOString().split('T')[0]
      };
      
      // Complete the ritual and get updated user ritual
      const completedRitual = await storage.completeRitual(userRitual);
      
      if (!completedRitual) {
        return res.status(404).json({ message: 'Ritual or user not found' });
      }
      
      // Award XP for ritual completion (50 XP per ritual)
      const updatedUser = await storage.addUserXP(parseInt(userId), 50);
      
      // Update user streak
      await storage.updateUserStreak(parseInt(userId), completedDate || new Date().toISOString().split('T')[0]);
      
      // Broadcast update via WebSocket to notify all clients
      broadcastUpdate('ritual_completed', { 
        userId: parseInt(userId),
        ritualId: parseInt(ritualId),
        xp: 50,
        message: `Ritual completed! You earned 50 XP!`
      });
      
      res.json({
        ritual: completedRitual,
        user: updatedUser,
        xpAwarded: 50
      });
    } catch (error) {
      console.error('Error completing ritual:', error);
      res.status(500).json({ message: 'Internal server error' });
    }
  });
  
  // ===== Chakra Endpoints =====
  
  // Get user's chakra status
  app.get('/api/users/:userId/chakras', verifyToken, async (req, res) => {
    try {
      const { userId } = req.params;
      
      // Verify user is accessing their own data
      if (req.user.uid !== userId) {
        return res.status(403).json({ message: 'Forbidden: You can only access your own data' });
      }
      
      const chakras = await storage.getUserChakras(parseInt(userId));
      
      if (!chakras) {
        return res.status(404).json({ message: 'Chakras not found' });
      }
      
      res.json(chakras);
    } catch (error) {
      console.error('Error getting chakras:', error);
      res.status(500).json({ message: 'Internal server error' });
    }
  });
  
  // Update user's chakra status
  app.patch('/api/users/:userId/chakras', verifyToken, async (req, res) => {
    try {
      const { userId } = req.params;
      
      // Verify user is updating their own data
      if (req.user.uid !== userId) {
        return res.status(403).json({ message: 'Forbidden: You can only update your own data' });
      }
      
      const updateData = req.body;
      const chakraSchema = insertChakraSchema.partial();
      
      try {
        chakraSchema.parse(updateData);
      } catch (err) {
        return res.status(400).json({ message: 'Invalid chakra data', errors: err });
      }
      
      const updatedChakras = await storage.updateUserChakras(parseInt(userId), updateData);
      
      // Add XP for activating chakra
      await storage.addUserXP(parseInt(userId), 100);
      
      res.json(updatedChakras);
      
      // Broadcast update
      broadcastUpdate('chakraUpdate', { userId, chakras: updatedChakras });
    } catch (error) {
      console.error('Error updating chakras:', error);
      res.status(500).json({ message: 'Internal server error' });
    }
  });
  
  // ===== Daily Mission Endpoints =====
  
  // Complete a daily mission
  app.post('/api/users/:userId/missions/daily', verifyToken, async (req, res) => {
    try {
      const userId = parseInt(req.params.userId);
      const { date, xpAmount } = req.body;
      
      if (!date || !xpAmount) {
        return res.status(400).json({ error: 'Date and xpAmount are required' });
      }
      
      // Verify user is updating their own data (except in development)
      if (!isDevelopment && req.user.uid !== req.params.userId) {
        return res.status(403).json({ message: 'Forbidden: You can only update your own data' });
      }
      
      // Get user data to check last mission completion
      const user = await storage.getUser(userId);
      if (!user) {
        return res.status(404).json({ error: 'User not found' });
      }
      
      // Check if user has already completed a mission today
      if (user.last_meditated_date === date) {
        return res.json({ 
          awarded: false, 
          message: 'Daily mission already completed today', 
          xpAmount: 0 
        });
      }
      
      // Award XP and update last meditated date
      const updatedUser = await storage.updateUser(userId, {
        xp: user.xp + xpAmount,
        last_meditated_date: date
      });
      
      // Notify all connected clients about XP update
      broadcastUpdate('user_xp_updated', { 
        userId: userId, 
        xp: updatedUser.xp,
        message: `User received ${xpAmount} XP from daily mission!`
      });
      
      return res.json({ 
        awarded: true, 
        message: 'Daily mission completed successfully', 
        xpAmount: xpAmount 
      });
    } catch (error) {
      console.error('Error completing daily mission:', error);
      return res.status(500).json({ error: 'Failed to complete daily mission' });
    }
  });

  // Get user streak information
  app.get('/api/users/:userId/streak', verifyToken, async (req, res) => {
    try {
      const userId = parseInt(req.params.userId);
      
      // Verify user is accessing their own data (except in development)
      if (!isDevelopment && req.user.uid !== req.params.userId) {
        return res.status(403).json({ message: 'Forbidden: You can only access your own data' });
      }
      
      // Get user data
      const user = await storage.getUser(userId);
      if (!user) {
        return res.status(404).json({ error: 'User not found' });
      }
      
      // Calculate streak based on last_meditated_date
      const today = new Date().toISOString().split('T')[0];
      const yesterday = new Date(Date.now() - 86400000).toISOString().split('T')[0];
      
      // If user has completed mission today or yesterday, they have at least a 1-day streak
      // For a full streak system, we would ideally track daily completion history in more detail
      const streak = user.meditation_streak || (user.last_meditated_date === today || user.last_meditated_date === yesterday ? 1 : 0);
      
      // Check if user has achieved a weekly streak (7 days)
      const weeklyStreakAchieved = streak > 0 && streak % 7 === 0;
      
      return res.json({ 
        streak: streak,
        weeklyStreakAchieved: weeklyStreakAchieved,
        badges: user.badges || []
      });
    } catch (error) {
      console.error('Error getting user streak:', error);
      return res.status(500).json({ error: 'Failed to get user streak' });
    }
  });
  
  // ===== Ritual Endpoints =====
  
  // Get all rituals
  app.get('/api/rituals', async (req, res) => {
    try {
      const rituals = await storage.getAllRituals();
      res.json(rituals);
    } catch (error) {
      console.error('Error getting rituals:', error);
      res.status(500).json({ message: 'Internal server error' });
    }
  });
  
  // Get user's completed rituals
  app.get('/api/users/:userId/rituals', verifyToken, async (req, res) => {
    try {
      const { userId } = req.params;
      const { date } = req.query;
      
      // Verify user is accessing their own data
      if (req.user.uid !== userId) {
        return res.status(403).json({ message: 'Forbidden: You can only access your own data' });
      }
      
      // If date is provided, get rituals for that date
      if (date && typeof date === 'string') {
        const userRituals = await storage.getUserRitualsByDate(parseInt(userId), date);
        return res.json(userRituals);
      }
      
      // Otherwise, get all user's rituals
      const userRituals = await storage.getUserRituals(parseInt(userId));
      res.json(userRituals);
    } catch (error) {
      console.error('Error getting user rituals:', error);
      res.status(500).json({ message: 'Internal server error' });
    }
  });
  
  // Complete a ritual
  app.post('/api/users/:userId/rituals', verifyToken, async (req, res) => {
    try {
      const { userId } = req.params;
      
      // Verify user is updating their own data
      if (req.user.uid !== userId) {
        return res.status(403).json({ message: 'Forbidden: You can only update your own data' });
      }
      
      const ritualData = req.body;
      
      try {
        insertUserRitualSchema.parse({
          ...ritualData,
          userId: parseInt(userId)
        });
      } catch (err) {
        return res.status(400).json({ message: 'Invalid ritual data', errors: err });
      }
      
      const userRitual = await storage.completeRitual({
        ...ritualData,
        userId: parseInt(userId)
      });
      
      // Get the completed ritual to know how much XP to award
      const ritual = await storage.getRitual(ritualData.ritualId);
      
      if (ritual && ritual.xpReward) {
        await storage.addUserXP(parseInt(userId), ritual.xpReward);
      }
      
      res.json(userRitual);
      
      // Broadcast update
      broadcastUpdate('ritualComplete', { userId, ritualId: ritualData.ritualId });
    } catch (error) {
      console.error('Error completing ritual:', error);
      res.status(500).json({ message: 'Internal server error' });
    }
  });
  
  // ===== Course Endpoints =====
  
  // Get all courses
  app.get('/api/courses', async (req, res) => {
    try {
      const courses = await storage.getAllCourses();
      res.json(courses);
    } catch (error) {
      console.error('Error getting courses:', error);
      res.status(500).json({ message: 'Internal server error' });
    }
  });
  
  // Get a specific course by ID
  app.get('/api/courses/:courseId', async (req, res) => {
    try {
      const { courseId } = req.params;
      const course = await storage.getCourse(parseInt(courseId));
      
      if (!course) {
        return res.status(404).json({ message: 'Course not found' });
      }
      
      res.json(course);
    } catch (error) {
      console.error('Error getting course:', error);
      res.status(500).json({ message: 'Internal server error' });
    }
  });
  
  // Get user's enrolled courses
  app.get('/api/users/:userId/courses', verifyToken, async (req, res) => {
    try {
      const { userId } = req.params;
      
      // Verify user is accessing their own data
      if (req.user.uid !== userId) {
        return res.status(403).json({ message: 'Forbidden: You can only access your own data' });
      }
      
      const userCourses = await storage.getUserCourses(parseInt(userId));
      res.json(userCourses);
    } catch (error) {
      console.error('Error getting user courses:', error);
      res.status(500).json({ message: 'Internal server error' });
    }
  });
  
  // Get a specific user course by course ID
  app.get('/api/users/:userId/courses/:courseId', verifyToken, async (req, res) => {
    try {
      const { userId, courseId } = req.params;
      
      // Verify user is accessing their own data
      if (req.user.uid !== userId) {
        return res.status(403).json({ message: 'Forbidden: You can only access your own data' });
      }
      
      const userCourses = await storage.getUserCourses(parseInt(userId));
      const userCourse = userCourses.find(c => c.courseId === parseInt(courseId));
      
      if (!userCourse) {
        return res.status(404).json({ message: 'User course not found' });
      }
      
      res.json(userCourse);
    } catch (error) {
      console.error('Error getting user course:', error);
      res.status(500).json({ message: 'Internal server error' });
    }
  });
  
  // Enroll in a course
  app.post('/api/users/:userId/courses', verifyToken, async (req, res) => {
    try {
      const { userId } = req.params;
      
      // Verify user is updating their own data
      if (req.user.uid !== userId) {
        return res.status(403).json({ message: 'Forbidden: You can only update your own data' });
      }
      
      const enrollmentData = req.body;
      
      try {
        insertUserCourseSchema.parse({
          ...enrollmentData,
          userId: parseInt(userId)
        });
      } catch (err) {
        return res.status(400).json({ message: 'Invalid enrollment data', errors: err });
      }
      
      const userCourse = await storage.enrollInCourse({
        ...enrollmentData,
        userId: parseInt(userId)
      });
      
      res.json(userCourse);
      
      // Broadcast update
      broadcastUpdate('courseEnrollment', { userId, courseId: enrollmentData.courseId });
    } catch (error) {
      console.error('Error enrolling in course:', error);
      res.status(500).json({ message: 'Internal server error' });
    }
  });
  
  // Direct update of user course
  app.patch('/api/users/:userId/courses/:courseId', verifyToken, async (req, res) => {
    try {
      const { userId, courseId } = req.params;
      
      // Verify user is updating their own data
      if (req.user.uid !== userId) {
        return res.status(403).json({ message: 'Forbidden: You can only update your own data' });
      }
      
      const { lessonsCompleted } = req.body;
      
      if (typeof lessonsCompleted !== 'number' || lessonsCompleted < 0) {
        return res.status(400).json({ message: 'Invalid lessons completed value' });
      }
      
      const updatedCourse = await storage.updateCourseProgress(
        parseInt(userId),
        parseInt(courseId),
        lessonsCompleted
      );
      
      // Get the course to check if lesson completion grants XP
      const course = await storage.getCourse(parseInt(courseId));
      
      if (course && course.xpReward && course.totalLessons) {
        // Calculate XP per lesson
        const xpPerLesson = Math.floor(course.xpReward / course.totalLessons);
        await storage.addUserXP(parseInt(userId), xpPerLesson);
      }
      
      res.json(updatedCourse);
    } catch (error: any) {
      console.error('Error updating course progress:', error);
      res.status(500).json({ message: 'Internal server error', error: error.message });
    }
  });
  
  // Update course progress (legacy endpoint)
  app.patch('/api/users/:userId/courses/:courseId/progress', verifyToken, async (req, res) => {
    try {
      const { userId, courseId } = req.params;
      
      // Verify user is updating their own data
      if (req.user.uid !== userId) {
        return res.status(403).json({ message: 'Forbidden: You can only update your own data' });
      }
      
      const { lessonsCompleted } = req.body;
      
      if (typeof lessonsCompleted !== 'number' || lessonsCompleted < 0) {
        return res.status(400).json({ message: 'Invalid lessons completed value' });
      }
      
      const updatedCourse = await storage.updateCourseProgress(
        parseInt(userId),
        parseInt(courseId),
        lessonsCompleted
      );
      
      // Get the course to check if lesson completion grants XP
      const course = await storage.getCourse(parseInt(courseId));
      
      if (course && course.xpReward && course.totalLessons) {
        // Calculate XP per lesson
        const xpPerLesson = Math.floor(course.xpReward / course.totalLessons);
        await storage.addUserXP(parseInt(userId), xpPerLesson);
      }
      
      res.json(updatedCourse);
    } catch (error: any) {
      console.error('Error updating course progress:', error);
      res.status(500).json({ message: 'Internal server error', error: error.message });
    }
  });
  
  // ===== Meditation Music Endpoints =====
  
  // Get meditation tracks by chakra type
  app.get('/api/meditation-tracks', async (req, res) => {
    try {
      const { chakraType } = req.query;
      
      if (chakraType && typeof chakraType === 'string') {
        const tracks = await storage.getMeditationTracksByChakra(chakraType);
        return res.json(tracks);
      }
      
      const tracks = await storage.getAllMeditationTracks();
      res.json(tracks);
    } catch (error) {
      console.error('Error getting meditation tracks:', error);
      res.status(500).json({ message: 'Internal server error' });
    }
  });
  
  // ===== Meditation Streak Endpoints =====
  
  // Get user's meditation streak
  app.get('/api/users/:userId/streak', verifyToken, async (req, res) => {
    try {
      const { userId } = req.params;
      
      // Verify user is accessing their own data
      if (req.user.uid !== userId) {
        return res.status(403).json({ message: 'Forbidden: You can only access your own data' });
      }
      
      const user = await storage.getUser(parseInt(userId));
      
      if (!user) {
        return res.status(404).json({ message: 'User not found' });
      }
      
      const streak = user.meditation_streak || 0;
      res.json({ streak });
    } catch (error: any) {
      console.error('Error fetching meditation streak:', error);
      res.status(500).json({ message: 'Server error', error: error.message });
    }
  });
  
  // Update meditation streak
  app.post('/api/users/:userId/streak', verifyToken, async (req, res) => {
    try {
      const { userId } = req.params;
      const { date } = req.body;
      
      // Verify user is updating their own data
      if (req.user.uid !== userId) {
        return res.status(403).json({ message: 'Forbidden: You can only update your own data' });
      }
      
      if (!date) {
        return res.status(400).json({ message: 'Date is required' });
      }
      
      const updatedUser = await storage.updateUserStreak(parseInt(userId), date);
      res.json({ streak: updatedUser.meditation_streak || 0 });
    } catch (error: any) {
      console.error('Error updating meditation streak:', error);
      res.status(500).json({ message: 'Server error', error: error.message });
    }
  });
  
  // ===== Daily Ritual Streak Endpoints =====
  
  // Get user's daily ritual streak
  app.get('/api/users/:userId/ritual-streak', verifyToken, async (req, res) => {
    try {
      const { userId } = req.params;
      
      // Verify user is accessing their own data
      if (req.user.uid !== userId) {
        return res.status(403).json({ message: 'Forbidden: You can only access your own data' });
      }
      
      const user = await storage.getUser(parseInt(userId));
      
      if (!user) {
        return res.status(404).json({ message: 'User not found' });
      }
      
      const streak = user.daily_ritual_streak || 0;
      res.json({ streak });
    } catch (error: any) {
      console.error('Error fetching daily ritual streak:', error);
      res.status(500).json({ message: 'Server error', error: error.message });
    }
  });
  
  // Update daily ritual streak
  app.post('/api/users/:userId/ritual-streak', verifyToken, async (req, res) => {
    try {
      const { userId } = req.params;
      const { date } = req.body;
      
      // Verify user is updating their own data
      if (req.user.uid !== userId) {
        return res.status(403).json({ message: 'Forbidden: You can only update your own data' });
      }
      
      if (!date) {
        return res.status(400).json({ message: 'Date is required' });
      }
      
      const updatedUser = await storage.updateUserRitualStreak(parseInt(userId), date);
      res.json({ streak: updatedUser.daily_ritual_streak || 0 });
    } catch (error: any) {
      console.error('Error updating daily ritual streak:', error);
      res.status(500).json({ message: 'Server error', error: error.message });
    }
  });
  
  // ===== Spiritual Goals Endpoints =====
  
  // Get user's goals
  app.get('/api/users/:userId/goals', verifyToken, async (req, res) => {
    try {
      const { userId } = req.params;
      
      // Verify user is accessing their own data (except in development)
      if (!isDevelopment && req.user.uid !== userId) {
        return res.status(403).json({ message: 'Forbidden: You can only access your own data' });
      }
      
      const goals = await storage.getUserGoals(parseInt(userId));
      res.json(goals);
    } catch (error) {
      console.error('Error getting goals:', error);
      res.status(500).json({ message: 'Internal server error' });
    }
  });
  
  // Add a new goal
  app.post('/api/users/:userId/goals', verifyToken, async (req, res) => {
    try {
      const { userId } = req.params;
      const { text, category, targetDate } = req.body;
      
      // Verify user is updating their own data (except in development)
      if (!isDevelopment && req.user.uid !== userId) {
        return res.status(403).json({ message: 'Forbidden: You can only update your own data' });
      }
      
      // Validate input
      if (!text || !category) {
        return res.status(400).json({ message: 'Goal text and category are required' });
      }
      
      const goal = await storage.createGoal({
        userId: parseInt(userId),
        text,
        category,
        targetDate,
        completed: false,
        createdAt: new Date().toISOString()
      });
      
      res.status(201).json(goal);
    } catch (error) {
      console.error('Error creating goal:', error);
      res.status(500).json({ message: 'Internal server error' });
    }
  });
  
  // Update a goal
  app.patch('/api/users/:userId/goals/:goalId', verifyToken, async (req, res) => {
    try {
      const { userId, goalId } = req.params;
      const updateData = req.body;
      
      // Verify user is updating their own data (except in development)
      if (!isDevelopment && req.user.uid !== userId) {
        return res.status(403).json({ message: 'Forbidden: You can only update your own data' });
      }
      
      const goal = await storage.updateGoal(
        parseInt(userId),
        parseInt(goalId),
        {
          ...updateData,
          updatedAt: new Date().toISOString()
        }
      );
      
      if (!goal) {
        return res.status(404).json({ message: 'Goal not found' });
      }
      
      res.json(goal);
    } catch (error) {
      console.error('Error updating goal:', error);
      res.status(500).json({ message: 'Internal server error' });
    }
  });
  
  // Delete a goal
  app.delete('/api/users/:userId/goals/:goalId', verifyToken, async (req, res) => {
    try {
      const { userId, goalId } = req.params;
      
      // Verify user is deleting their own data (except in development)
      if (!isDevelopment && req.user.uid !== userId) {
        return res.status(403).json({ message: 'Forbidden: You can only delete your own data' });
      }
      
      const success = await storage.deleteGoal(parseInt(userId), parseInt(goalId));
      
      if (!success) {
        return res.status(404).json({ message: 'Goal not found' });
      }
      
      res.status(204).end();
    } catch (error) {
      console.error('Error deleting goal:', error);
      res.status(500).json({ message: 'Internal server error' });
    }
  });
  
  // Get user achievements
  app.get('/api/users/:userId/achievements', verifyToken, async (req, res) => {
    try {
      const { userId } = req.params;
      
      // Verify user is accessing their own data (except in development)
      if (!isDevelopment && req.user.uid !== userId) {
        return res.status(403).json({ message: 'Forbidden: You can only access your own data' });
      }
      
      // Generate mock achievements data for demonstration
      const now = new Date();
      const oneDay = 24 * 60 * 60 * 1000;
      
      const achievements = [
        {
          id: "ach1",
          title: "Completed Introduction to Meditation",
          description: "Successfully completed all lessons and practices in the introductory meditation course.",
          date: { seconds: Math.floor((now.getTime() - 15 * oneDay) / 1000), nanoseconds: 0 },
          type: "course"
        },
        {
          id: "ach2",
          title: "7-Day Streak Achievement",
          description: "Maintained a continuous 7-day streak of daily spiritual practices.",
          date: { seconds: Math.floor((now.getTime() - 10 * oneDay) / 1000), nanoseconds: 0 },
          type: "streak"
        },
        {
          id: "ach3",
          title: "Root Chakra Activated",
          description: "Unlocked and balanced your Root Chakra through meditation and mindfulness practices.",
          date: { seconds: Math.floor((now.getTime() - 8 * oneDay) / 1000), nanoseconds: 0 },
          type: "chakra"
        },
        {
          id: "ach4",
          title: "First Certification",
          description: "Received your first official certification in spiritual practices.",
          date: { seconds: Math.floor((now.getTime() - 5 * oneDay) / 1000), nanoseconds: 0 },
          type: "milestone"
        },
        {
          id: "ach5",
          title: "Sacral Chakra Activated",
          description: "Unlocked and balanced your Sacral Chakra through dedicated practice and energy work.",
          date: { seconds: Math.floor((now.getTime() - 2 * oneDay) / 1000), nanoseconds: 0 },
          type: "chakra"
        }
      ];
      
      res.status(200).json(achievements);
    } catch (error) {
      console.error('Error fetching achievements:', error);
      res.status(500).json({ message: 'Internal server error' });
    }
  });
  
  // Get notification preferences
  app.get('/api/users/:userId/notification-preferences', verifyToken, async (req, res) => {
    try {
      const { userId } = req.params;
      
      // Verify user is accessing their own data (except in development)
      if (!isDevelopment && req.user.uid !== userId) {
        return res.status(403).json({ message: 'Forbidden: You can only access your own data' });
      }
      
      // Default notification preferences
      const defaultPrefs = {
        enabled: true,
        morningTime: '08:00',
        eveningTime: '20:00',
        types: {
          rituals: true,
          meditation: true,
          courses: true,
          achievements: true
        }
      };
      
      res.status(200).json(defaultPrefs);
    } catch (error) {
      console.error('Error fetching notification preferences:', error);
      res.status(500).json({ message: 'Internal server error' });
    }
  });
  
  // Update notification preferences
  app.post('/api/users/:userId/notification-preferences', verifyToken, async (req, res) => {
    try {
      const { userId } = req.params;
      const preferences = req.body;
      
      // Verify user is updating their own data (except in development)
      if (!isDevelopment && req.user.uid !== userId) {
        return res.status(403).json({ message: 'Forbidden: You can only update your own data' });
      }
      
      // Validate preferences
      if (!preferences || typeof preferences !== 'object') {
        return res.status(400).json({ message: 'Invalid notification preferences' });
      }
      
      // Here we would normally save to database, but for now we'll just acknowledge
      console.log(`Saving notification preferences for user ${userId}:`, preferences);
      
      res.status(200).json({ 
        message: 'Notification preferences updated successfully',
        preferences
      });
    } catch (error) {
      console.error('Error updating notification preferences:', error);
      res.status(500).json({ message: 'Internal server error' });
    }
  });
  
  // Get user badges
  app.get('/api/users/:userId/badges', verifyToken, async (req, res) => {
    try {
      const { userId } = req.params;
      
      // Verify user is accessing their own data (except in development)
      if (!isDevelopment && req.user.uid !== userId) {
        return res.status(403).json({ message: 'Forbidden: You can only access your own data' });
      }
      
      // Generate sample badges data
      const now = new Date();
      const oneDay = 24 * 60 * 60 * 1000;
      
      const badges = [
        {
          id: "badge1",
          title: "7-Day Meditation Warrior",
          description: "Completed 7 consecutive days of meditation practice",
          category: "streak",
          dateEarned: new Date(now.getTime() - 15 * oneDay).toISOString(),
          iconType: "streak"
        },
        {
          id: "badge2",
          title: "Root Chakra Master",
          description: "Fully activated and balanced your Root Chakra",
          category: "chakra",
          dateEarned: new Date(now.getTime() - 10 * oneDay).toISOString(),
          iconType: "chakra"
        },
        {
          id: "badge3",
          title: "Spiritual Seeker",
          description: "Reached Level 2 in your spiritual journey",
          category: "level",
          dateEarned: new Date(now.getTime() - 5 * oneDay).toISOString(),
          iconType: "level"
        },
        {
          id: "badge4",
          title: "Daily Ritual Master",
          description: "Completed 5 consecutive days of daily rituals",
          category: "ritual",
          dateEarned: new Date(now.getTime() - 3 * oneDay).toISOString(),
          iconType: "ritual"
        },
        {
          id: "badge5",
          title: "Sacral Chakra Master",
          description: "Fully activated and balanced your Sacral Chakra",
          category: "chakra",
          dateEarned: new Date(now.getTime() - 2 * oneDay).toISOString(),
          iconType: "chakra"
        }
      ];
      
      res.status(200).json(badges);
    } catch (error) {
      console.error('Error fetching badges:', error);
      res.status(500).json({ message: 'Internal server error' });
    }
  });
  
  // ===== Journal Entry Endpoints =====
  
  // Get all journal entries for a user
  app.get('/api/users/:userId/journal-entries', verifyToken, async (req, res) => {
    try {
      const { userId } = req.params;
      
      // Verify user is accessing their own data
      if (req.user.uid !== userId) {
        return res.status(403).json({ message: 'Forbidden: You can only access your own journal entries' });
      }
      
      const entries = await storage.getUserJournalEntries(parseInt(userId));
      res.json(entries);
    } catch (error) {
      console.error('Error getting journal entries:', error);
      res.status(500).json({ message: 'Internal server error' });
    }
  });
  
  // Get journal entries by category for a user
  app.get('/api/users/:userId/journal-entries/category/:category', verifyToken, async (req, res) => {
    try {
      const { userId, category } = req.params;
      
      // Verify user is accessing their own data
      if (req.user.uid !== userId) {
        return res.status(403).json({ message: 'Forbidden: You can only access your own journal entries' });
      }
      
      const entries = await storage.getUserJournalEntriesByCategory(parseInt(userId), category);
      res.json(entries);
    } catch (error) {
      console.error('Error getting journal entries by category:', error);
      res.status(500).json({ message: 'Internal server error' });
    }
  });
  
  // Create a new journal entry
  app.post('/api/users/:userId/journal-entries', verifyToken, async (req, res) => {
    try {
      const { userId } = req.params;
      
      // Verify user is creating their own entry
      if (req.user.uid !== userId) {
        return res.status(403).json({ message: 'Forbidden: You can only create your own journal entries' });
      }
      
      // Validate the request body
      const entryData = insertJournalEntrySchema.parse({
        ...req.body,
        userId: parseInt(userId)
      });
      
      const entry = await storage.createJournalEntry(entryData);
      
      // Broadcast an update via WebSocket
      broadcastUpdate('journal_entry_created', {
        userId: parseInt(userId),
        entryId: entry.id,
        message: 'New journal entry created'
      });
      
      res.status(201).json(entry);
    } catch (error) {
      console.error('Error creating journal entry:', error);
      res.status(500).json({ message: 'Internal server error' });
    }
  });
  
  // Update a journal entry
  app.patch('/api/users/:userId/journal-entries/:entryId', verifyToken, async (req, res) => {
    try {
      const { userId, entryId } = req.params;
      
      // Verify user is updating their own entry
      if (req.user.uid !== userId) {
        return res.status(403).json({ message: 'Forbidden: You can only update your own journal entries' });
      }
      
      const updatedEntry = await storage.updateJournalEntry(
        parseInt(userId),
        parseInt(entryId),
        req.body
      );
      
      if (!updatedEntry) {
        return res.status(404).json({ message: 'Journal entry not found or does not belong to user' });
      }
      
      res.json(updatedEntry);
    } catch (error) {
      console.error('Error updating journal entry:', error);
      res.status(500).json({ message: 'Internal server error' });
    }
  });
  
  // Delete a journal entry
  app.delete('/api/users/:userId/journal-entries/:entryId', verifyToken, async (req, res) => {
    try {
      const { userId, entryId } = req.params;
      
      // Verify user is deleting their own entry
      if (req.user.uid !== userId) {
        return res.status(403).json({ message: 'Forbidden: You can only delete your own journal entries' });
      }
      
      const deleted = await storage.deleteJournalEntry(
        parseInt(userId),
        parseInt(entryId)
      );
      
      if (!deleted) {
        return res.status(404).json({ message: 'Journal entry not found or does not belong to user' });
      }
      
      res.json({ success: true, message: 'Journal entry deleted successfully' });
    } catch (error) {
      console.error('Error deleting journal entry:', error);
      res.status(500).json({ message: 'Internal server error' });
    }
  });
  
  // ===== Mood Tracker Endpoints =====
  
  // Get all mood entries for a user
  app.get('/api/users/:userId/mood-entries', verifyToken, async (req, res) => {
    try {
      const { userId } = req.params;
      
      // Verify user is accessing their own data
      if (req.user.uid !== userId) {
        return res.status(403).json({ message: 'Forbidden: You can only access your own mood entries' });
      }
      
      const entries = await storage.getUserMoodEntries(parseInt(userId));
      res.json(entries);
    } catch (error) {
      console.error('Error getting mood entries:', error);
      res.status(500).json({ message: 'Internal server error' });
    }
  });
  
  // Get mood entries by date for a user
  app.get('/api/users/:userId/mood-entries/date/:date', verifyToken, async (req, res) => {
    try {
      const { userId, date } = req.params;
      
      // Verify user is accessing their own data
      if (req.user.uid !== userId) {
        return res.status(403).json({ message: 'Forbidden: You can only access your own mood entries' });
      }
      
      const entries = await storage.getUserMoodEntriesByDate(parseInt(userId), date);
      res.json(entries);
    } catch (error) {
      console.error('Error getting mood entries by date:', error);
      res.status(500).json({ message: 'Internal server error' });
    }
  });
  
  // Get mood summary for a date range
  app.get('/api/users/:userId/mood-summary', verifyToken, async (req, res) => {
    try {
      const { userId } = req.params;
      const { startDate, endDate } = req.query;
      
      // Verify user is accessing their own data
      if (req.user.uid !== userId) {
        return res.status(403).json({ message: 'Forbidden: You can only access your own mood data' });
      }
      
      if (!startDate || !endDate || typeof startDate !== 'string' || typeof endDate !== 'string') {
        return res.status(400).json({ message: 'Start date and end date are required' });
      }
      
      const summary = await storage.getMoodSummary(parseInt(userId), startDate, endDate);
      res.json(summary);
    } catch (error) {
      console.error('Error getting mood summary:', error);
      res.status(500).json({ message: 'Internal server error' });
    }
  });
  
  // Create a new mood entry
  app.post('/api/users/:userId/mood-entries', verifyToken, async (req, res) => {
    try {
      const { userId } = req.params;
      
      // Verify user is creating their own entry
      if (req.user.uid !== userId) {
        return res.status(403).json({ message: 'Forbidden: You can only create your own mood entries' });
      }
      
      // Validate request body
      const moodEntryData = insertMoodEntrySchema.parse({
        ...req.body,
        userId: parseInt(userId)
      });
      
      const newEntry = await storage.createMoodEntry(moodEntryData);
      
      // Broadcast update via WebSocket
      broadcastUpdate('mood_entry_created', {
        userId: parseInt(userId),
        entryId: newEntry.id,
        mood: newEntry.mood,
        message: 'New mood entry created'
      });
      
      res.status(201).json(newEntry);
    } catch (error) {
      console.error('Error creating mood entry:', error);
      res.status(500).json({ message: 'Internal server error' });
    }
  });
  
  // Update a mood entry
  app.patch('/api/users/:userId/mood-entries/:entryId', verifyToken, async (req, res) => {
    try {
      const { userId, entryId } = req.params;
      
      // Verify user is updating their own entry
      if (req.user.uid !== userId) {
        return res.status(403).json({ message: 'Forbidden: You can only update your own mood entries' });
      }
      
      const updatedEntry = await storage.updateMoodEntry(
        parseInt(userId),
        parseInt(entryId),
        req.body
      );
      
      if (!updatedEntry) {
        return res.status(404).json({ message: 'Mood entry not found or does not belong to user' });
      }
      
      res.json(updatedEntry);
    } catch (error) {
      console.error('Error updating mood entry:', error);
      res.status(500).json({ message: 'Internal server error' });
    }
  });
  
  // Delete a mood entry
  app.delete('/api/users/:userId/mood-entries/:entryId', verifyToken, async (req, res) => {
    try {
      const { userId, entryId } = req.params;
      
      // Verify user is deleting their own entry
      if (req.user.uid !== userId) {
        return res.status(403).json({ message: 'Forbidden: You can only delete your own mood entries' });
      }
      
      const deleted = await storage.deleteMoodEntry(
        parseInt(userId),
        parseInt(entryId)
      );
      
      if (!deleted) {
        return res.status(404).json({ message: 'Mood entry not found or does not belong to user' });
      }
      
      res.json({ success: true, message: 'Mood entry deleted successfully' });
    } catch (error) {
      console.error('Error deleting mood entry:', error);
      res.status(500).json({ message: 'Internal server error' });
    }
  });
  
  // ===== Community Wall Endpoints =====
  
  // Get all community posts
  app.get('/api/community', verifyToken, async (req, res) => {
    try {
      const userId = parseInt(req.user.uid);
      const posts = await storage.getCommunityPosts(userId);
      res.json(posts);
    } catch (error) {
      console.error('Error getting community posts:', error);
      res.status(500).json({ message: 'Internal server error' });
    }
  });
  
  // Get a single post with its comments
  app.get('/api/community/:postId', verifyToken, async (req, res) => {
    try {
      const userId = parseInt(req.user.uid);
      const postId = parseInt(req.params.postId);
      
      if (isNaN(postId)) {
        return res.status(400).json({ message: 'Invalid post ID' });
      }
      
      const post = await storage.getPostById(postId, userId);
      
      if (!post) {
        return res.status(404).json({ message: 'Post not found' });
      }
      
      res.json(post);
    } catch (error) {
      console.error('Error getting post:', error);
      res.status(500).json({ message: 'Internal server error' });
    }
  });
  
  // Create a new post
  app.post('/api/community', verifyToken, async (req, res) => {
    try {
      const userId = parseInt(req.user.uid);
      const { text } = req.body;
      
      if (!text) {
        return res.status(400).json({ message: 'Post text is required' });
      }
      
      // Get user information for the author field
      const user = await storage.getUser(userId);
      
      const newPost = {
        text,
        userId,
        author: user?.name || `User ${userId}`,
        likes: 0
      };
      
      const post = await storage.createCommunityPost(newPost);
      
      // Award XP for creating a post
      await storage.addUserXP(userId, 25);
      
      // Broadcast update via WebSocket to notify all clients
      broadcastUpdate('post_created', { 
        post,
        message: `New post by ${post.author}`
      });
      
      res.status(201).json(post);
    } catch (error) {
      console.error('Error creating post:', error);
      res.status(500).json({ message: 'Internal server error' });
    }
  });
  
  // Add a comment to a post
  app.post('/api/community/:postId/comment', verifyToken, async (req, res) => {
    try {
      const userId = parseInt(req.user.uid);
      const postId = parseInt(req.params.postId);
      const { text } = req.body;
      
      if (isNaN(postId)) {
        return res.status(400).json({ message: 'Invalid post ID' });
      }
      
      if (!text) {
        return res.status(400).json({ message: 'Comment text is required' });
      }
      
      // Check if post exists
      const post = await storage.getPostById(postId);
      
      if (!post) {
        return res.status(404).json({ message: 'Post not found' });
      }
      
      // Get user information for the author field
      const user = await storage.getUser(userId);
      
      const newComment = {
        text,
        userId,
        postId,
        author: user?.name || `User ${userId}`
      };
      
      const comment = await storage.addComment(newComment);
      
      // Award XP for commenting
      await storage.addUserXP(userId, 10);
      
      // Broadcast update via WebSocket to notify all clients
      broadcastUpdate('comment_added', { 
        postId,
        comment,
        message: `New comment by ${comment.author}`
      });
      
      res.status(201).json(comment);
    } catch (error) {
      console.error('Error adding comment:', error);
      res.status(500).json({ message: 'Internal server error' });
    }
  });
  
  // Like or unlike a post
  app.post('/api/community/:postId/like', verifyToken, async (req, res) => {
    try {
      const userId = parseInt(req.user.uid);
      const postId = parseInt(req.params.postId);
      
      if (isNaN(postId)) {
        return res.status(400).json({ message: 'Invalid post ID' });
      }
      
      // Like/unlike the post
      await storage.likePost(postId, userId);
      
      // Get the updated post
      const updatedPost = await storage.getPostById(postId, userId);
      
      if (!updatedPost) {
        return res.status(404).json({ message: 'Post not found' });
      }
      
      // Broadcast update via WebSocket to notify all clients
      broadcastUpdate('post_liked', { 
        postId,
        likes: updatedPost.likes,
        message: `Post liked/unliked by user ${userId}`
      });
      
      res.json(updatedPost);
    } catch (error) {
      console.error('Error liking post:', error);
      res.status(500).json({ message: 'Internal server error' });
    }
  });
  
  // Email digest endpoints
  
  // Send a test email digest
  app.post('/api/admin/send-test-email', async (req, res) => {
    try {
      const { email } = req.body;
      
      if (!email) {
        return res.status(400).json({ message: 'Email is required' });
      }
      
      const result = await sendTestEmail(email);
      
      res.status(200).json({ 
        message: 'Test email sent successfully',
        result
      });
    } catch (error) {
      console.error('Error sending test email:', error);
      res.status(500).json({ message: 'Failed to send test email', error: (error as Error).message });
    }
  });
  
  // Trigger sending weekly digests to all users
  app.post('/api/admin/send-weekly-digest', async (req, res) => {
    try {
      // In a real app, we would get users from the database
      // For demo, we'll use dummy data
      const users = [
        { id: 1, name: 'User One', email: 'user1@example.com', xp: 750, meditationStreak: 12, dailyRitualStreak: 8 },
        { id: 2, name: 'User Two', email: 'user2@example.com', xp: 1250, meditationStreak: 7, dailyRitualStreak: 4 },
        { id: 3, name: 'User Three', email: 'user3@example.com', xp: 980, meditationStreak: 3, dailyRitualStreak: 2 }
      ];
      
      const results = await sendWeeklyDigestToAllUsers(users);
      
      res.status(200).json({
        message: 'Weekly digest emails processed',
        results
      });
    } catch (error) {
      console.error('Error sending weekly digest emails:', error);
      res.status(500).json({ message: 'Failed to send weekly digest emails', error: (error as Error).message });
    }
  });
  
  // ===== Affirmation Wallpaper Endpoints =====
  
  // Generate a spiritual affirmation
  app.post('/api/generate-affirmation', verifyToken, async (req, res) => {
    try {
      console.log('Generating spiritual affirmation...');
      const result = await generateAffirmation();
      res.json(result);
    } catch (error) {
      console.error('Error generating affirmation:', error);
      res.status(500).json({ 
        message: 'Failed to generate affirmation', 
        error: (error as Error).message 
      });
    }
  });
  
  // Track affirmation wallpaper download
  app.post('/api/track-affirmation-download', verifyToken, async (req, res) => {
    try {
      const { userId, affirmation } = req.body;
      
      if (!userId) {
        return res.status(400).json({ message: 'User ID is required' });
      }
      
      // Track the download
      const result = await trackAffirmationDownload(userId);
      
      // Award XP for downloading affirmation wallpaper (15 XP)
      if (result.success) {
        const updatedUser = await storage.addUserXP(userId, 15);
        
        // Broadcast update via WebSocket to notify all clients
        broadcastUpdate('affirmation_downloaded', { 
          userId: userId, 
          xp: 15,
          message: `Affirmation wallpaper downloaded! You earned 15 XP!`
        });
        
        return res.json({
          success: true,
          xpAwarded: 15,
          user: updatedUser
        });
      }
      
      res.json({ success: true });
    } catch (error) {
      console.error('Error tracking affirmation download:', error);
      res.status(500).json({ 
        message: 'Failed to track affirmation download', 
        error: (error as Error).message 
      });
    }
  });
  
  return httpServer;
}
