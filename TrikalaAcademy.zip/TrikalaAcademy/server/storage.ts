import { eq, and, sql, desc, gte, lte } from 'drizzle-orm';
import { 
  users, 
  chakras, 
  rituals, 
  userRituals, 
  courses, 
  userCourses, 
  meditationTracks,
  goals,
  journalEntries,
  moodEntries,
  communityPosts,
  postComments,
  postLikes,
  type User,
  type InsertUser,
  type Chakra,
  type InsertChakra,
  type Ritual,
  type InsertRitual,
  type UserRitual,
  type InsertUserRitual,
  type Course,
  type InsertCourse,
  type UserCourse,
  type InsertUserCourse,
  type MeditationTrack,
  type InsertMeditationTrack,
  type Goal,
  type InsertGoal,
  type JournalEntry,
  type InsertJournalEntry,
  type MoodEntry,
  type InsertMoodEntry,
  type CommunityPost as DbCommunityPost,
  type InsertCommunityPost,
  type PostComment,
  type InsertPostComment,
  type PostLike,
  type InsertPostLike
} from '@shared/schema';
import { db } from './db';
import { pool } from "./db";
import session from "express-session";
import { Store } from "express-session";
import createMemoryStore from "memorystore";
import connectPg from "connect-pg-simple";

const MemoryStore = createMemoryStore(session);
const PostgresStore = connectPg(session);

// Storage interface with all CRUD methods needed for the application
export interface IStorage {
  // Session store
  sessionStore: Store;
  
  // User methods
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUser(id: number, data: Partial<User>): Promise<User>;
  addUserXP(id: number, xpAmount: number): Promise<User>;
  updateUserStreak(id: number, date: string): Promise<User>;
  updateUserRitualStreak(id: number, date: string): Promise<User>;
  addBadgeToUser(id: number, badge: string): Promise<User>;
  getTopUsersByXP(limit: number): Promise<User[]>;
  
  // Chakra methods
  getUserChakras(userId: number): Promise<Record<string, boolean>>;
  updateUserChakras(userId: number, chakraData: Partial<Record<string, boolean>>): Promise<Record<string, boolean>>;
  
  // Ritual methods
  getAllRituals(): Promise<Ritual[]>;
  getRitual(id: number): Promise<Ritual | undefined>;
  getUserRituals(userId: number): Promise<UserRitual[]>;
  getUserRitualsByDate(userId: number, date: string): Promise<UserRitual[]>;
  completeRitual(userRitual: UserRitual): Promise<UserRitual>;
  
  // Course methods
  getAllCourses(): Promise<Course[]>;
  getCourse(id: number): Promise<Course | undefined>;
  getUserCourses(userId: number): Promise<UserCourse[]>;
  enrollInCourse(userCourse: UserCourse): Promise<UserCourse>;
  updateCourseProgress(userId: number, courseId: number, lessonsCompleted: number): Promise<UserCourse>;
  
  // Meditation tracks methods
  getAllMeditationTracks(): Promise<MeditationTrack[]>;
  getMeditationTracksByChakra(chakraType: string): Promise<MeditationTrack[]>;
  
  // Goal methods
  getUserGoals(userId: number): Promise<Goal[]>;
  createGoal(goal: InsertGoal): Promise<Goal>;
  updateGoal(userId: number, goalId: number, data: Partial<Goal>): Promise<Goal | undefined>;
  deleteGoal(userId: number, goalId: number): Promise<boolean>;
  
  // Journal methods
  getUserJournalEntries(userId: number): Promise<JournalEntry[]>;
  getUserJournalEntriesByCategory(userId: number, category: string): Promise<JournalEntry[]>;
  createJournalEntry(entry: InsertJournalEntry): Promise<JournalEntry>;
  updateJournalEntry(userId: number, entryId: number, data: Partial<JournalEntry>): Promise<JournalEntry | undefined>;
  deleteJournalEntry(userId: number, entryId: number): Promise<boolean>;
  
  // Mood Tracker methods
  getUserMoodEntries(userId: number): Promise<MoodEntry[]>;
  getUserMoodEntriesByDate(userId: number, date: string): Promise<MoodEntry[]>;
  createMoodEntry(entry: InsertMoodEntry): Promise<MoodEntry>;
  updateMoodEntry(userId: number, entryId: number, data: Partial<MoodEntry>): Promise<MoodEntry | undefined>;
  deleteMoodEntry(userId: number, entryId: number): Promise<boolean>;
  getMoodSummary(userId: number, startDate: string, endDate: string): Promise<{mood: string, count: number}[]>;
  
  // Community Wall methods
  getCommunityPosts(userId?: number): Promise<CommunityPost[]>;
  createCommunityPost(data: InsertCommunityPost): Promise<CommunityPost>;
  addComment(data: InsertPostComment): Promise<PostComment>;
  likePost(postId: number, userId: number): Promise<void>;
  getPostById(postId: number, userId?: number): Promise<CommunityPost | undefined>;
}

// Import community post types from schema
import { 
  CommunityPost, PostComment, PostLike, 
  InsertCommunityPost, InsertPostComment, InsertPostLike 
} from '@shared/schema';

// Database storage implementation
export class DatabaseStorage implements IStorage {
  sessionStore: Store;
  
  // Method stubs for mood tracker (will be filled by prototype extensions)
  async getUserMoodEntries(userId: number): Promise<MoodEntry[]> { throw new Error('Not implemented'); }
  async getUserMoodEntriesByDate(userId: number, date: string): Promise<MoodEntry[]> { throw new Error('Not implemented'); }
  async createMoodEntry(entry: InsertMoodEntry): Promise<MoodEntry> { throw new Error('Not implemented'); }
  async updateMoodEntry(userId: number, entryId: number, data: Partial<MoodEntry>): Promise<MoodEntry | undefined> { throw new Error('Not implemented'); }
  async deleteMoodEntry(userId: number, entryId: number): Promise<boolean> { throw new Error('Not implemented'); }
  async getMoodSummary(userId: number, startDate: string, endDate: string): Promise<{mood: string, count: number}[]> { throw new Error('Not implemented'); }
  
  // Method stubs for community wall (will be filled by prototype extensions)
  async getCommunityPosts(userId?: number): Promise<CommunityPost[]> { throw new Error('Not implemented'); }
  async createCommunityPost(data: InsertCommunityPost): Promise<CommunityPost> { throw new Error('Not implemented'); }
  async addComment(data: InsertPostComment): Promise<PostComment> { throw new Error('Not implemented'); }
  async likePost(postId: number, userId: number): Promise<void> { throw new Error('Not implemented'); }
  async getPostById(postId: number, userId?: number): Promise<CommunityPost | undefined> { throw new Error('Not implemented'); }
  
  constructor() {
    this.sessionStore = new PostgresStore({
      pool,
      createTableIfMissing: true
    });
  }
  // User methods
  async getUser(id: number): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user || undefined;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.phone, username));
    return user || undefined;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values({
        ...insertUser,
        level: 1,
        xp: 0,
        createdAt: new Date()
      })
      .returning();
    
    // Initialize chakra data for new user
    await db.insert(chakras).values({
      userId: user.id,
      root: false,
      sacral: false,
      solar: false,
      heart: false,
      throat: false,
      thirdEye: false,
      crown: false
    });
    
    return user;
  }

  async updateUser(id: number, data: Partial<User>): Promise<User> {
    const [updatedUser] = await db
      .update(users)
      .set(data)
      .where(eq(users.id, id))
      .returning();
    
    if (!updatedUser) {
      throw new Error(`User with id ${id} not found`);
    }
    
    return updatedUser;
  }

  async addUserXP(id: number, xpAmount: number): Promise<User> {
    const user = await this.getUser(id);
    if (!user) {
      throw new Error(`User with id ${id} not found`);
    }
    
    // Update XP
    const updatedXP = (user.xp || 0) + xpAmount;
    
    // Calculate level - simple formula: level = 1 + floor(XP / 1000)
    const updatedLevel = 1 + Math.floor(updatedXP / 1000);
    
    return this.updateUser(id, { 
      xp: updatedXP, 
      level: updatedLevel > (user.level || 1) ? updatedLevel : user.level
    });
  }

  async updateUserStreak(id: number, date: string): Promise<User> {
    const user = await this.getUser(id);
    if (!user) {
      throw new Error(`User with id ${id} not found`);
    }
    
    const lastMeditatedDate = user.last_meditated_date || '';
    const currentStreak = user.meditation_streak || 0;
    
    // Check if this is a new meditation (not on the same day)
    if (lastMeditatedDate !== date) {
      // Check if streak is broken (more than 1 day gap)
      const lastDate = lastMeditatedDate ? new Date(lastMeditatedDate) : new Date(0);
      const currentDate = new Date(date);
      const dayDifference = Math.floor((currentDate.getTime() - lastDate.getTime()) / (1000 * 60 * 60 * 24));
      
      let updatedStreak = currentStreak;
      
      // If it's the next day, increase streak
      if (dayDifference === 1) {
        updatedStreak = currentStreak + 1;
        
        // Award bonus XP for continuing streak
        // Higher streak = higher XP bonus
        const streakBonus = Math.min(50, 10 + (updatedStreak * 2));
        await this.addUserXP(id, streakBonus);
        
        // Weekly streak achievement - 7 days
        if (updatedStreak > 0 && updatedStreak % 7 === 0) {
          // Award weekly streak bonus
          const weeklyStreakBonus = 500;
          await this.addUserXP(id, weeklyStreakBonus);
          
          // Add weekly streak badge
          await this.addBadgeToUser(id, "7-Day Meditation Warrior");
        }
        
        // Monthly streak achievement - 30 days
        if (updatedStreak >= 30 && updatedStreak % 30 === 0) {
          // Award monthly streak bonus
          const monthlyStreakBonus = 2000;
          await this.addUserXP(id, monthlyStreakBonus);
          
          // Add monthly streak badge
          await this.addBadgeToUser(id, "Spiritual Titan");
        }
      } 
      // If it's been more than 1 day, reset streak to 1
      else if (dayDifference > 1) {
        updatedStreak = 1;
      }
      
      return this.updateUser(id, {
        meditation_streak: updatedStreak,
        last_meditated_date: date
      });
    }
    
    // Already meditated today, just return current user
    return user;
  }
  
  async addBadgeToUser(id: number, badge: string): Promise<User> {
    const user = await this.getUser(id);
    if (!user) {
      throw new Error(`User with id ${id} not found`);
    }
    
    // Get current badges
    const currentBadges = user.badges || [];
    
    // Check if user already has this badge
    if (currentBadges.includes(badge)) {
      return user;
    }
    
    // Add new badge
    const updatedBadges = [...currentBadges, badge];
    
    // Update user badges
    return this.updateUser(id, {
      badges: updatedBadges
    });
  }
  
  async updateUserRitualStreak(id: number, date: string): Promise<User> {
    const user = await this.getUser(id);
    if (!user) {
      throw new Error(`User with id ${id} not found`);
    }
    
    const lastRitualDate = user.last_ritual_date || '';
    const currentStreak = user.daily_ritual_streak || 0;
    
    // Check if this is a new ritual completion (not on the same day)
    if (lastRitualDate !== date) {
      // Check if streak is broken (more than 1 day gap)
      const lastDate = lastRitualDate ? new Date(lastRitualDate) : new Date(0);
      const currentDate = new Date(date);
      const dayDifference = Math.floor((currentDate.getTime() - lastDate.getTime()) / (1000 * 60 * 60 * 24));
      
      let updatedStreak = currentStreak;
      
      // If it's the next day, increase streak
      if (dayDifference === 1) {
        updatedStreak = currentStreak + 1;
        
        // Award bonus XP for continuing streak
        // Higher streak = higher XP bonus
        const streakBonus = Math.min(50, 10 + (updatedStreak * 2));
        await this.addUserXP(id, streakBonus);
        
        // Weekly streak achievement - 5 days
        if (updatedStreak > 0 && updatedStreak % 5 === 0) {
          // Award ritual streak bonus
          const ritualStreakBonus = 300;
          await this.addUserXP(id, ritualStreakBonus);
          
          // Add ritual streak badge
          await this.addBadgeToUser(id, "Daily Ritual Master");
        }
        
        // Monthly streak achievement - 30 days
        if (updatedStreak >= 30 && updatedStreak % 30 === 0) {
          // Award monthly streak bonus
          const monthlyStreakBonus = 1500;
          await this.addUserXP(id, monthlyStreakBonus);
          
          // Add monthly streak badge
          await this.addBadgeToUser(id, "Spiritual Discipline Master");
        }
      } 
      // If it's been more than 1 day, reset streak to 1
      else if (dayDifference > 1) {
        updatedStreak = 1;
      }
      
      return this.updateUser(id, {
        daily_ritual_streak: updatedStreak,
        last_ritual_date: date
      });
    }
    
    // Already completed rituals today, just return current user
    return user;
  }
  
  async getTopUsersByXP(limit: number): Promise<User[]> {
    // Fetch users ordered by XP in descending order
    const topUsers = await db
      .select()
      .from(users)
      .orderBy(sql`${users.xp} DESC`)
      .limit(limit);
    
    return topUsers;
  }

  // Chakra methods
  async getUserChakras(userId: number): Promise<Record<string, boolean>> {
    const [userChakra] = await db
      .select()
      .from(chakras)
      .where(eq(chakras.userId, userId));
    
    if (!userChakra) {
      // Initialize chakra data if not exist
      const defaultChakras = {
        userId,
        root: false,
        sacral: false,
        solar: false,
        heart: false,
        throat: false,
        thirdEye: false,
        crown: false
      };
      
      await db.insert(chakras).values(defaultChakras);
      
      return {
        root: false,
        sacral: false,
        solar: false,
        heart: false,
        throat: false,
        thirdEye: false,
        crown: false
      };
    }
    
    // Convert to record object
    return {
      root: userChakra.root || false,
      sacral: userChakra.sacral || false,
      solar: userChakra.solar || false,
      heart: userChakra.heart || false,
      throat: userChakra.throat || false,
      thirdEye: userChakra.thirdEye || false,
      crown: userChakra.crown || false
    };
  }

  async updateUserChakras(userId: number, chakraData: Partial<Record<string, boolean>>): Promise<Record<string, boolean>> {
    // Check if user chakras exist
    const [userChakra] = await db
      .select()
      .from(chakras)
      .where(eq(chakras.userId, userId));
    
    if (!userChakra) {
      // Create new chakra record with provided data
      const newChakras = {
        userId,
        root: chakraData.root || false,
        sacral: chakraData.sacral || false,
        solar: chakraData.solar || false,
        heart: chakraData.heart || false,
        throat: chakraData.throat || false,
        thirdEye: chakraData.thirdEye || false,
        crown: chakraData.crown || false
      };
      
      await db.insert(chakras).values(newChakras);
      
      return {
        root: newChakras.root,
        sacral: newChakras.sacral,
        solar: newChakras.solar,
        heart: newChakras.heart,
        throat: newChakras.throat,
        thirdEye: newChakras.thirdEye,
        crown: newChakras.crown
      };
    }
    
    // Filter out undefined values
    const filteredChakraData: Record<string, boolean> = {};
    Object.entries(chakraData).forEach(([key, value]) => {
      if (value !== undefined) {
        filteredChakraData[key] = value;
      }
    });
    
    // Update existing chakra record
    const [updatedChakra] = await db
      .update(chakras)
      .set(filteredChakraData)
      .where(eq(chakras.userId, userId))
      .returning();
    
    // Convert to record object
    return {
      root: updatedChakra.root || false,
      sacral: updatedChakra.sacral || false,
      solar: updatedChakra.solar || false,
      heart: updatedChakra.heart || false,
      throat: updatedChakra.throat || false,
      thirdEye: updatedChakra.thirdEye || false,
      crown: updatedChakra.crown || false
    };
  }

  // Ritual methods
  async getAllRituals(): Promise<Ritual[]> {
    return db.select().from(rituals);
  }

  async getRitual(id: number): Promise<Ritual | undefined> {
    const [ritual] = await db.select().from(rituals).where(eq(rituals.id, id));
    return ritual || undefined;
  }

  async getUserRituals(userId: number): Promise<UserRitual[]> {
    return db.select().from(userRituals).where(eq(userRituals.userId, userId));
  }

  async getUserRitualsByDate(userId: number, date: string): Promise<UserRitual[]> {
    return db
      .select()
      .from(userRituals)
      .where(
        and(
          eq(userRituals.userId, userId),
          eq(userRituals.date, date)
        )
      );
  }

  async completeRitual(userRitual: UserRitual): Promise<UserRitual> {
    // Check if already completed
    const existingRituals = await db
      .select()
      .from(userRituals)
      .where(
        and(
          eq(userRituals.userId, userRitual.userId),
          eq(userRituals.ritualId, userRitual.ritualId),
          eq(userRituals.date, userRitual.date)
        )
      );
    
    if (existingRituals.length > 0) {
      // Already completed - return existing
      return existingRituals[0];
    }
    
    // Create new with completedAt timestamp
    const [insertedRitual] = await db
      .insert(userRituals)
      .values({
        ...userRitual,
        completedAt: new Date()
      })
      .returning();
    
    // Add XP for completing the ritual
    const ritual = await this.getRitual(userRitual.ritualId);
    if (ritual && ritual.xpReward) {
      await this.addUserXP(userRitual.userId, ritual.xpReward);
    }
    
    return insertedRitual;
  }

  // Course methods
  async getAllCourses(): Promise<Course[]> {
    return db.select().from(courses);
  }

  async getCourse(id: number): Promise<Course | undefined> {
    const [course] = await db.select().from(courses).where(eq(courses.id, id));
    return course || undefined;
  }

  async getUserCourses(userId: number): Promise<UserCourse[]> {
    return db.select().from(userCourses).where(eq(userCourses.userId, userId));
  }

  async enrollInCourse(userCourse: UserCourse): Promise<UserCourse> {
    // Check if already enrolled
    const existingEnrollments = await db
      .select()
      .from(userCourses)
      .where(
        and(
          eq(userCourses.userId, userCourse.userId),
          eq(userCourses.courseId, userCourse.courseId)
        )
      );
    
    if (existingEnrollments.length > 0) {
      return existingEnrollments[0];
    }
    
    // Create new enrollment
    const [enrollment] = await db
      .insert(userCourses)
      .values({
        userId: userCourse.userId,
        courseId: userCourse.courseId,
        lessonsCompleted: 0,
        completionPercentage: 0
      })
      .returning();
    
    return enrollment;
  }

  async updateCourseProgress(userId: number, courseId: number, lessonsCompleted: number): Promise<UserCourse> {
    // Get the course to calculate percentage
    const course = await this.getCourse(courseId);
    if (!course) {
      throw new Error(`Course with id ${courseId} not found`);
    }
    
    // Calculate completion percentage
    const totalLessons = course.totalLessons || 1; // Avoid division by zero
    const completionPercentage = Math.min(100, Math.round((lessonsCompleted / totalLessons) * 100));
    
    // Check current progress to determine if XP should be awarded
    const [userCourse] = await db
      .select()
      .from(userCourses)
      .where(
        and(
          eq(userCourses.userId, userId),
          eq(userCourses.courseId, courseId)
        )
      );
    
    if (!userCourse) {
      throw new Error(`User ${userId} is not enrolled in course ${courseId}`);
    }
    
    // Update progress
    const [updatedUserCourse] = await db
      .update(userCourses)
      .set({
        lessonsCompleted,
        completionPercentage,
        updatedAt: new Date()
      })
      .where(
        and(
          eq(userCourses.userId, userId),
          eq(userCourses.courseId, courseId)
        )
      )
      .returning();
    
    // If course is newly completed, add XP reward
    if (course.xpReward && completionPercentage === 100 && userCourse.completionPercentage !== 100) {
      await this.addUserXP(userId, course.xpReward);
    }
    
    return updatedUserCourse;
  }

  // Meditation tracks methods
  async getAllMeditationTracks(): Promise<MeditationTrack[]> {
    return db.select().from(meditationTracks);
  }

  async getMeditationTracksByChakra(chakraType: string): Promise<MeditationTrack[]> {
    return db
      .select()
      .from(meditationTracks)
      .where(eq(meditationTracks.chakraType, chakraType));
  }
  
  // Goal methods
  async getUserGoals(userId: number): Promise<Goal[]> {
    return db
      .select()
      .from(goals)
      .where(eq(goals.userId, userId))
      .orderBy(sql`${goals.createdAt} DESC`);
  }
  
  async createGoal(goal: InsertGoal): Promise<Goal> {
    const [newGoal] = await db
      .insert(goals)
      .values(goal)
      .returning();
    
    return newGoal;
  }
  
  async updateGoal(userId: number, goalId: number, data: Partial<Goal>): Promise<Goal | undefined> {
    // Make sure the goal belongs to the user
    const [existingGoal] = await db
      .select()
      .from(goals)
      .where(and(
        eq(goals.id, goalId),
        eq(goals.userId, userId)
      ));
    
    if (!existingGoal) {
      return undefined;
    }
    
    const [updatedGoal] = await db
      .update(goals)
      .set(data)
      .where(and(
        eq(goals.id, goalId),
        eq(goals.userId, userId)
      ))
      .returning();
    
    return updatedGoal;
  }
  
  async deleteGoal(userId: number, goalId: number): Promise<boolean> {
    // Make sure the goal belongs to the user
    const [existingGoal] = await db
      .select()
      .from(goals)
      .where(and(
        eq(goals.id, goalId),
        eq(goals.userId, userId)
      ));
    
    if (!existingGoal) {
      return false;
    }
    
    await db
      .delete(goals)
      .where(and(
        eq(goals.id, goalId),
        eq(goals.userId, userId)
      ));
    
    return true;
  }
  
  // Journal Entry methods
  async getUserJournalEntries(userId: number): Promise<JournalEntry[]> {
    return db
      .select()
      .from(journalEntries)
      .where(eq(journalEntries.userId, userId))
      .orderBy(sql`${journalEntries.createdAt} DESC`);
  }
  
  async getUserJournalEntriesByCategory(userId: number, category: string): Promise<JournalEntry[]> {
    return db
      .select()
      .from(journalEntries)
      .where(
        and(
          eq(journalEntries.userId, userId),
          eq(journalEntries.category, category)
        )
      )
      .orderBy(sql`${journalEntries.createdAt} DESC`);
  }
  
  async createJournalEntry(entry: InsertJournalEntry): Promise<JournalEntry> {
    const [journalEntry] = await db
      .insert(journalEntries)
      .values({
        ...entry,
        createdAt: new Date()
      })
      .returning();
    
    // Award XP for creating a journal entry - spiritual reflection is rewarded
    await this.addUserXP(entry.userId, 25);
    
    return journalEntry;
  }
  
  async updateJournalEntry(userId: number, entryId: number, data: Partial<JournalEntry>): Promise<JournalEntry | undefined> {
    // Make sure the entry belongs to the user
    const [existingEntry] = await db
      .select()
      .from(journalEntries)
      .where(
        and(
          eq(journalEntries.id, entryId),
          eq(journalEntries.userId, userId)
        )
      );
    
    if (!existingEntry) {
      return undefined;
    }
    
    const [updatedEntry] = await db
      .update(journalEntries)
      .set(data)
      .where(
        and(
          eq(journalEntries.id, entryId),
          eq(journalEntries.userId, userId)
        )
      )
      .returning();
    
    return updatedEntry;
  }
  
  async deleteJournalEntry(userId: number, entryId: number): Promise<boolean> {
    // Make sure the entry belongs to the user
    const [existingEntry] = await db
      .select()
      .from(journalEntries)
      .where(
        and(
          eq(journalEntries.id, entryId),
          eq(journalEntries.userId, userId)
        )
      );
    
    if (!existingEntry) {
      return false;
    }
    
    await db
      .delete(journalEntries)
      .where(
        and(
          eq(journalEntries.id, entryId),
          eq(journalEntries.userId, userId)
        )
      );
    
    return true;
  }

  // Initialization
  async initializeDefaultData(): Promise<void> {
    // Check if we need to initialize
    const ritualsCount = await db.select({ count: sql`count(*)` }).from(rituals);
    if (Number(ritualsCount[0].count) > 0) {
      console.log('Database already contains data, skipping initialization');
      return;
    }
    
    console.log('Initializing database with default data');
    
    // Sample rituals
    await db.insert(rituals).values([
      { title: "Morning Meditation", description: "Start your day with mindfulness", durationMinutes: 15, icon: "sunrise", xpReward: 50, timeOfDay: "morning" },
      { title: "Gratitude Journal", description: "Write down three things you're grateful for", durationMinutes: 10, icon: "book-open", xpReward: 30, timeOfDay: "evening" },
      { title: "Evening Yoga", description: "Wind down with gentle stretches", durationMinutes: 20, icon: "moon", xpReward: 70, timeOfDay: "evening" },
      { title: "Affirmations", description: "Positive affirmations for self-growth", durationMinutes: 5, icon: "sun", xpReward: 25, timeOfDay: "morning" },
      { title: "Pranayama Breathing", description: "Controlled breathing exercises", durationMinutes: 10, icon: "wind", xpReward: 40, timeOfDay: "any" }
    ]);
    
    // Sample courses
    await db.insert(courses).values([
      { title: "Introduction to Meditation", level: 1, description: "Learn the basics of meditation practice", imageUrl: "/images/meditation.jpg", totalLessons: 7, xpReward: 500 },
      { title: "Chakra Healing", level: 2, description: "Deep dive into chakra balancing techniques", imageUrl: "/images/chakra.jpg", totalLessons: 10, xpReward: 800 },
      { title: "Vedic Philosophy", level: 3, description: "Explore ancient wisdom and spiritual teachings", imageUrl: "/images/vedic.jpg", totalLessons: 12, xpReward: 1000 },
      { title: "Yoga for Beginners", level: 1, description: "Gentle introduction to yoga poses and philosophy", imageUrl: "/images/yoga.jpg", totalLessons: 8, xpReward: 600 }
    ]);
    
    // Sample meditation tracks
    await db.insert(meditationTracks).values([
      { title: "Root Chakra Healing", chakraType: "root", audioUrl: "/audio/root.mp3", durationSeconds: 600, frequency: "396 Hz", imageUrl: "/images/root-chakra.jpg" },
      { title: "Sacral Chakra Balance", chakraType: "sacral", audioUrl: "/audio/sacral.mp3", durationSeconds: 720, frequency: "417 Hz", imageUrl: "/images/sacral-chakra.jpg" },
      { title: "Solar Plexus Activation", chakraType: "solar", audioUrl: "/audio/solar.mp3", durationSeconds: 540, frequency: "528 Hz", imageUrl: "/images/solar-chakra.jpg" },
      { title: "Heart Chakra Opening", chakraType: "heart", audioUrl: "/audio/heart.mp3", durationSeconds: 900, frequency: "639 Hz", imageUrl: "/images/heart-chakra.jpg" },
      { title: "Throat Chakra Expression", chakraType: "throat", audioUrl: "/audio/throat.mp3", durationSeconds: 660, frequency: "741 Hz", imageUrl: "/images/throat-chakra.jpg" },
      { title: "Third Eye Awakening", chakraType: "thirdEye", audioUrl: "/audio/third-eye.mp3", durationSeconds: 840, frequency: "852 Hz", imageUrl: "/images/third-eye-chakra.jpg" },
      { title: "Crown Chakra Connection", chakraType: "crown", audioUrl: "/audio/crown.mp3", durationSeconds: 720, frequency: "963 Hz", imageUrl: "/images/crown-chakra.jpg" }
    ]);
    
    console.log('Database initialization complete');
  }
}

// In-memory storage implementation for development/fallback
export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private chakras: Map<number, Record<string, boolean>>;
  private rituals: Map<number, Ritual>;
  private userRituals: Map<string, UserRitual>; // Composite key: userId-ritualId-date
  private courses: Map<number, Course>;
  private userCourses: Map<string, UserCourse>; // Composite key: userId-courseId
  private meditationTracks: Map<number, MeditationTrack>;
  private journalEntries: Map<number, JournalEntry> = new Map<number, JournalEntry>();
  private moodEntries: Map<number, MoodEntry> = new Map<number, MoodEntry>();
  private communityPosts: Map<number, CommunityPost> = new Map<number, CommunityPost>();
  private postComments: Map<number, PostComment> = new Map<number, PostComment>();
  private postLikes: Map<string, PostLike> = new Map<string, PostLike>(); // Composite key: userId-postId
  
  sessionStore: session.Store;
  currentId: number;

  constructor() {
    this.sessionStore = new MemoryStore({
      checkPeriod: 86400000 // 24 hours
    });
    this.users = new Map();
    this.chakras = new Map();
    this.rituals = new Map();
    this.userRituals = new Map();
    this.courses = new Map();
    this.userCourses = new Map();
    this.meditationTracks = new Map();
    this.goals = new Map();
    this.journalEntries = new Map();
    this.moodEntries = new Map();
    
    // Initialize sample courses
    this.initSampleCourses();
    this.communityPosts = new Map();
    this.postComments = new Map();
    this.postLikes = new Map();
    this.currentId = 1;
    
    // Initialize with some sample data
    this.initializeSampleData();
  }
  
  async addBadgeToUser(id: number, badge: string): Promise<User> {
    const user = await this.getUser(id);
    if (!user) {
      throw new Error(`User with id ${id} not found`);
    }
    
    // Convert badges to array if it doesn't exist
    const currentBadges = user.badges || [];
    
    // Don't add duplicate badges
    if (currentBadges.includes(badge)) {
      return user;
    }
    
    const updatedBadges = [...currentBadges, badge];
    return this.updateUser(id, { badges: updatedBadges });
  }

  // User methods
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.phone === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.currentId++;
    const user: User = { 
      ...insertUser, 
      id,
      level: 1,
      xp: 0,
      createdAt: new Date(),
      name: null,
      profileImage: null,
      meditation_streak: 0,
      last_meditated_date: null,
      daily_ritual_streak: 0,
      last_ritual_date: null,
      lastMissionCompleted: null,
      badges: []
    };
    this.users.set(id, user);
    
    // Initialize empty chakra state for new users
    this.chakras.set(id, {
      crown: false,
      thirdEye: false,
      throat: false,
      heart: false,
      solar: false,
      sacral: false,
      root: false
    });
    
    return user;
  }
  
  async updateUser(id: number, data: Partial<User>): Promise<User> {
    const user = await this.getUser(id);
    if (!user) {
      throw new Error(`User with id ${id} not found`);
    }
    
    const updatedUser = { ...user, ...data };
    this.users.set(id, updatedUser);
    return updatedUser;
  }
  
  async addUserXP(id: number, xpAmount: number): Promise<User> {
    const user = await this.getUser(id);
    if (!user) {
      throw new Error(`User with id ${id} not found`);
    }
    
    // Calculate new XP and level
    const newXP = (user.xp || 0) + xpAmount;
    const newLevel = Math.floor(newXP / 1000) + 1; // Simple level calculation
    
    const updatedUser = { ...user, xp: newXP, level: newLevel };
    this.users.set(id, updatedUser);
    return updatedUser;
  }
  
  async updateUserStreak(id: number, date: string): Promise<User> {
    const user = await this.getUser(id);
    if (!user) {
      throw new Error(`User with id ${id} not found`);
    }
    
    // Get current streak or initialize to 0
    let currentStreak = user.meditation_streak || 0;
    const lastDate = user.last_meditated_date;
    
    // Check if this is a consecutive day
    if (lastDate) {
      const lastMeditatedDate = new Date(lastDate);
      const currentDate = new Date(date);
      
      // Calculate difference in days
      const timeDiff = currentDate.getTime() - lastMeditatedDate.getTime();
      const dayDiff = Math.floor(timeDiff / (1000 * 3600 * 24));
      
      if (dayDiff === 1) {
        // Consecutive day, increment streak
        currentStreak += 1;
      } else if (dayDiff === 0) {
        // Same day, no change to streak
      } else {
        // Streak broken, reset to 1
        currentStreak = 1;
      }
    } else {
      // First meditation ever, set streak to 1
      currentStreak = 1;
    }
    
    const updatedUser = { 
      ...user, 
      meditation_streak: currentStreak, 
      last_meditated_date: date 
    };
    
    this.users.set(id, updatedUser);
    return updatedUser;
  }
  
  async updateUserRitualStreak(id: number, date: string): Promise<User> {
    const user = await this.getUser(id);
    if (!user) {
      throw new Error(`User with id ${id} not found`);
    }
    
    // Get current ritual streak or initialize to 0
    let currentStreak = user.daily_ritual_streak || 0;
    const lastDate = user.last_ritual_date;
    
    // Check if this is a consecutive day
    if (lastDate) {
      const lastRitualDate = new Date(lastDate);
      const currentDate = new Date(date);
      
      // Calculate difference in days
      const timeDiff = currentDate.getTime() - lastRitualDate.getTime();
      const dayDiff = Math.floor(timeDiff / (1000 * 3600 * 24));
      
      if (dayDiff === 1) {
        // Consecutive day, increment streak
        currentStreak += 1;
        
        // Weekly ritual streak achievement - 5 days
        if (currentStreak > 0 && currentStreak % 5 === 0) {
          // Add ritual streak badge
          await this.addBadgeToUser(id, "Daily Ritual Master");
        }
        
        // Monthly ritual streak achievement - 30 days
        if (currentStreak >= 30 && currentStreak % 30 === 0) {
          // Add monthly streak badge
          await this.addBadgeToUser(id, "Spiritual Discipline Master");
        }
      } else if (dayDiff === 0) {
        // Same day, no change to streak
      } else {
        // Streak broken, reset to 1
        currentStreak = 1;
      }
    } else {
      // First ritual completion ever, set streak to 1
      currentStreak = 1;
    }
    
    const updatedUser = { 
      ...user, 
      daily_ritual_streak: currentStreak, 
      last_ritual_date: date 
    };
    
    this.users.set(id, updatedUser);
    return updatedUser;
  }
  
  // Chakra methods
  async getUserChakras(userId: number): Promise<Record<string, boolean>> {
    const chakras = this.chakras.get(userId);
    if (!chakras) {
      // Return default chakra state if not found
      return {
        crown: false,
        thirdEye: false,
        throat: false,
        heart: false,
        solar: false,
        sacral: false,
        root: false
      };
    }
    return chakras;
  }
  
  async updateUserChakras(userId: number, chakraData: Partial<Record<string, boolean>>): Promise<Record<string, boolean>> {
    const chakras = await this.getUserChakras(userId);
    
    // Filter out undefined values and create a clean object with only boolean values
    const filteredChakraData: Record<string, boolean> = {};
    Object.entries(chakraData).forEach(([key, value]) => {
      if (value !== undefined) {
        filteredChakraData[key] = value;
      }
    });
    
    const updatedChakras = { ...chakras, ...filteredChakraData };
    this.chakras.set(userId, updatedChakras);
    return updatedChakras;
  }
  
  // Ritual methods
  async getAllRituals(): Promise<Ritual[]> {
    return Array.from(this.rituals.values());
  }
  
  async getRitual(id: number): Promise<Ritual | undefined> {
    return this.rituals.get(id);
  }
  
  async getUserRituals(userId: number): Promise<UserRitual[]> {
    return Array.from(this.userRituals.values()).filter(
      ritual => ritual.userId === userId
    );
  }
  
  async getUserRitualsByDate(userId: number, date: string): Promise<UserRitual[]> {
    return Array.from(this.userRituals.values()).filter(
      ritual => ritual.userId === userId && ritual.date === date
    );
  }
  
  async completeRitual(userRitual: UserRitual): Promise<UserRitual> {
    const key = `${userRitual.userId}-${userRitual.ritualId}-${userRitual.date}`;
    const completedRitual = {
      ...userRitual,
      completedAt: new Date()
    };
    this.userRituals.set(key, completedRitual);
    return completedRitual;
  }
  
  // Course methods
  async getAllCourses(): Promise<Course[]> {
    return Array.from(this.courses.values());
  }
  
  async getCourse(id: number): Promise<Course | undefined> {
    return this.courses.get(id);
  }
  
  private initSampleCourses(): void {
    // Sample spiritual courses
    const sampleCourses: Course[] = [
      {
        id: 1,
        title: "Chakra Healing Fundamentals",
        description: "Learn to understand and balance the seven chakras to enhance your spiritual wellbeing and energy flow.",
        level: 1,
        totalLessons: 7,
        xpReward: 200,
        imageUrl: "/chakra-healing.jpg",
        createdAt: new Date(),
        updatedAt: new Date()
      },
      {
        id: 2,
        title: "Tarot Reading for Beginners",
        description: "Discover the ancient art of tarot with this comprehensive guide to reading and interpreting the cards.",
        level: 1,
        totalLessons: 8,
        xpReward: 250,
        imageUrl: "/tarot-reading.jpg",
        createdAt: new Date(),
        updatedAt: new Date()
      },
      {
        id: 3,
        title: "Advanced Meditation Techniques",
        description: "Take your meditation practice to the next level with these advanced techniques for deeper states of consciousness.",
        level: 3,
        totalLessons: 6,
        xpReward: 350,
        imageUrl: "/meditation-guide.jpg",
        createdAt: new Date(),
        updatedAt: new Date()
      },
      {
        id: 4,
        title: "Vedic Astrology Foundations",
        description: "Explore the ancient wisdom of Vedic astrology and learn how the stars and planets influence your spiritual journey.",
        level: 2,
        totalLessons: 9,
        xpReward: 300,
        imageUrl: "/vedic-wisdom.jpg",
        createdAt: new Date(),
        updatedAt: new Date()
      }
    ];
    
    // Add courses to storage
    sampleCourses.forEach(course => {
      this.courses.set(course.id, course);
    });
  }
  
  async getUserCourses(userId: number): Promise<UserCourse[]> {
    return Array.from(this.userCourses.values()).filter(
      course => course.userId === userId
    );
  }
  
  async enrollInCourse(userCourse: UserCourse): Promise<UserCourse> {
    const key = `${userCourse.userId}-${userCourse.courseId}`;
    const course = { 
      ...userCourse, 
      lessonsCompleted: 0, 
      completionPercentage: 0 
    };
    this.userCourses.set(key, course);
    return course;
  }
  
  async updateCourseProgress(userId: number, courseId: number, lessonsCompleted: number): Promise<UserCourse> {
    const key = `${userId}-${courseId}`;
    const userCourse = this.userCourses.get(key);
    
    if (!userCourse) {
      throw new Error(`User ${userId} is not enrolled in course ${courseId}`);
    }
    
    const course = await this.getCourse(courseId);
    if (!course) {
      throw new Error(`Course ${courseId} not found`);
    }
    
    const completionPercentage = Math.round((lessonsCompleted / (course.totalLessons || 1)) * 100);
    const updatedCourse = { 
      ...userCourse, 
      lessonsCompleted, 
      completionPercentage 
    };
    
    this.userCourses.set(key, updatedCourse);
    return updatedCourse;
  }
  
  // Meditation tracks methods
  async getAllMeditationTracks(): Promise<MeditationTrack[]> {
    return Array.from(this.meditationTracks.values());
  }
  
  async getMeditationTracksByChakra(chakraType: string): Promise<MeditationTrack[]> {
    return Array.from(this.meditationTracks.values()).filter(
      track => track.chakraType === chakraType
    );
  }
  
  // Goal methods
  private goals: Map<number, Goal> = new Map();
  private goalCounter: number = 1;
  
  async getUserGoals(userId: number): Promise<Goal[]> {
    // Filter goals by userId
    return Array.from(this.goals.values())
      .filter(goal => goal.userId === userId)
      .sort((a, b) => {
        // Sort by created date in descending order (newest first)
        return new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime();
      });
  }
  
  async createGoal(goalData: InsertGoal): Promise<Goal> {
    const id = this.goalCounter++;
    
    const newGoal: Goal = {
      id,
      userId: goalData.userId,
      text: goalData.text,
      category: goalData.category,
      completed: goalData.completed || false,
      targetDate: goalData.targetDate || null,
      createdAt: goalData.createdAt,
      updatedAt: null
    };
    
    this.goals.set(id, newGoal);
    return newGoal;
  }
  
  async updateGoal(userId: number, goalId: number, data: Partial<Goal>): Promise<Goal | undefined> {
    const goal = this.goals.get(goalId);
    
    // Check if goal exists and belongs to the user
    if (!goal || goal.userId !== userId) {
      return undefined;
    }
    
    // Update the goal
    const updatedGoal: Goal = {
      ...goal,
      ...data,
      updatedAt: new Date().toISOString()
    };
    
    this.goals.set(goalId, updatedGoal);
    return updatedGoal;
  }
  
  async deleteGoal(userId: number, goalId: number): Promise<boolean> {
    const goal = this.goals.get(goalId);
    
    // Check if goal exists and belongs to the user
    if (!goal || goal.userId !== userId) {
      return false;
    }
    
    // Delete the goal
    return this.goals.delete(goalId);
  }
  
  // Leaderboard methods
  async getTopUsersByXP(limit: number): Promise<User[]> {
    // Convert users map to array
    const userArray = Array.from(this.users.values());
    
    // Sort by XP in descending order
    userArray.sort((a, b) => {
      const aXP = a.xp || 0;
      const bXP = b.xp || 0;
      return bXP - aXP; // Descending order
    });
    
    // Return top N users
    return userArray.slice(0, limit);
  }
  
  // Journal Entry methods
  private journalEntryCounter: number = 1;
  
  async getUserJournalEntries(userId: number): Promise<JournalEntry[]> {
    return Array.from(this.journalEntries.values())
      .filter(entry => entry.userId === userId)
      .sort((a, b) => {
        const dateA = a.createdAt instanceof Date ? a.createdAt.getTime() : new Date(a.createdAt).getTime();
        const dateB = b.createdAt instanceof Date ? b.createdAt.getTime() : new Date(b.createdAt).getTime();
        return dateB - dateA;
      });
  }
  
  async getUserJournalEntriesByCategory(userId: number, category: string): Promise<JournalEntry[]> {
    return Array.from(this.journalEntries.values())
      .filter(entry => entry.userId === userId && entry.category === category)
      .sort((a, b) => {
        const dateA = a.createdAt instanceof Date ? a.createdAt.getTime() : new Date(a.createdAt).getTime();
        const dateB = b.createdAt instanceof Date ? b.createdAt.getTime() : new Date(b.createdAt).getTime();
        return dateB - dateA;
      });
  }
  
  async createJournalEntry(entry: InsertJournalEntry): Promise<JournalEntry> {
    const id = this.journalEntryCounter++;
    
    const newEntry: JournalEntry = {
      id,
      userId: entry.userId,
      content: entry.content,
      category: entry.category,
      mood: entry.mood || null,
      createdAt: new Date()
    };
    
    this.journalEntries.set(id, newEntry);
    
    // Award XP for creating a journal entry - spiritual reflection is rewarded
    await this.addUserXP(entry.userId, 25);
    
    return newEntry;
  }
  
  async updateJournalEntry(userId: number, entryId: number, data: Partial<JournalEntry>): Promise<JournalEntry | undefined> {
    const entry = this.journalEntries.get(entryId);
    
    // Check if entry exists and belongs to the user
    if (!entry || entry.userId !== userId) {
      return undefined;
    }
    
    // Update the entry
    const updatedEntry: JournalEntry = {
      ...entry,
      ...data
    };
    
    this.journalEntries.set(entryId, updatedEntry);
    return updatedEntry;
  }
  
  async deleteJournalEntry(userId: number, entryId: number): Promise<boolean> {
    const entry = this.journalEntries.get(entryId);
    
    // Check if entry exists and belongs to the user
    if (!entry || entry.userId !== userId) {
      return false;
    }
    
    // Delete the entry
    return this.journalEntries.delete(entryId);
  }
  
  // Mood Tracker methods
  private moodEntryCounter: number = 1;
  
  async getUserMoodEntries(userId: number): Promise<MoodEntry[]> {
    return Array.from(this.moodEntries.values())
      .filter(entry => entry.userId === userId)
      .sort((a, b) => {
        const dateA = a.createdAt instanceof Date ? a.createdAt.getTime() : new Date(a.createdAt).getTime();
        const dateB = b.createdAt instanceof Date ? b.createdAt.getTime() : new Date(b.createdAt).getTime();
        return dateB - dateA;
      });
  }

  async getUserMoodEntriesByDate(userId: number, date: string): Promise<MoodEntry[]> {
    return Array.from(this.moodEntries.values())
      .filter(entry => entry.userId === userId && entry.date === date)
      .sort((a, b) => {
        const dateA = a.createdAt instanceof Date ? a.createdAt.getTime() : new Date(a.createdAt).getTime();
        const dateB = b.createdAt instanceof Date ? b.createdAt.getTime() : new Date(b.createdAt).getTime();
        return dateB - dateA;
      });
  }

  async createMoodEntry(entry: InsertMoodEntry): Promise<MoodEntry> {
    const id = this.moodEntryCounter++;
    
    const newEntry: MoodEntry = {
      id,
      userId: entry.userId,
      mood: entry.mood,
      reflection: entry.reflection || '',
      date: entry.date,
      createdAt: new Date()
    };
    
    this.moodEntries.set(id, newEntry);
    
    // Award XP for tracking mood - emotional awareness is important for spiritual growth
    await this.addUserXP(entry.userId, 20);
    
    return newEntry;
  }

  async updateMoodEntry(userId: number, entryId: number, data: Partial<MoodEntry>): Promise<MoodEntry | undefined> {
    const entry = this.moodEntries.get(entryId);
    
    // Check if entry exists and belongs to the user
    if (!entry || entry.userId !== userId) {
      return undefined;
    }
    
    // Update the entry
    const updatedEntry: MoodEntry = {
      ...entry,
      ...data
    };
    
    this.moodEntries.set(entryId, updatedEntry);
    return updatedEntry;
  }

  async deleteMoodEntry(userId: number, entryId: number): Promise<boolean> {
    const entry = this.moodEntries.get(entryId);
    
    // Check if entry exists and belongs to the user
    if (!entry || entry.userId !== userId) {
      return false;
    }
    
    // Delete the entry
    return this.moodEntries.delete(entryId);
  }

  async getMoodSummary(userId: number, startDate: string, endDate: string): Promise<{mood: string, count: number}[]> {
    // Filter entries by user and date range
    const filteredEntries = Array.from(this.moodEntries.values())
      .filter(entry => {
        if (entry.userId !== userId) return false;
        
        const entryDate = entry.date;
        return entryDate >= startDate && entryDate <= endDate;
      });
    
    // Count occurrences of each mood
    const moodCounts = new Map<string, number>();
    
    filteredEntries.forEach(entry => {
      const mood = entry.mood;
      const currentCount = moodCounts.get(mood) || 0;
      moodCounts.set(mood, currentCount + 1);
    });
    
    // Convert map to array of objects
    return Array.from(moodCounts.entries()).map(([mood, count]) => ({
      mood,
      count
    }));
  }
  
  // Community Wall Methods
  private communityPostCounter: number = 1;
  private postCommentCounter: number = 1;
  
  async getCommunityPosts(userId?: number): Promise<CommunityPost[]> {
    const posts = Array.from(this.communityPosts.values()).sort((a, b) => {
      // Sort by created date in descending order (newest first)
      const dateA = a.createdAt instanceof Date ? a.createdAt.getTime() : new Date(a.createdAt || new Date()).getTime();
      const dateB = b.createdAt instanceof Date ? b.createdAt.getTime() : new Date(b.createdAt || new Date()).getTime();
      return dateB - dateA;
    });

    // For each post, get its comments and check if the user has liked it
    return posts.map(post => {
      const comments = Array.from(this.postComments.values())
        .filter(comment => comment.postId === post.id)
        .sort((a, b) => {
          const dateA = a.createdAt instanceof Date ? a.createdAt.getTime() : new Date(a.createdAt || new Date()).getTime();
          const dateB = b.createdAt instanceof Date ? b.createdAt.getTime() : new Date(b.createdAt || new Date()).getTime();
          return dateB - dateA;
        });

      // Check if the user has liked this post
      let isLiked = false;
      if (userId) {
        isLiked = !!this.postLikes.get(`${userId}-${post.id}`);
      }

      return {
        ...post,
        comments,
        isLiked
      };
    });
  }

  async createCommunityPost(data: InsertCommunityPost): Promise<CommunityPost> {
    const id = this.communityPostCounter++;

    const newPost: CommunityPost = {
      id,
      userId: data.userId,
      text: data.text,
      author: data.author,
      likes: 0,
      createdAt: new Date()
    };

    this.communityPosts.set(id, newPost);

    return {
      ...newPost,
      comments: [],
      isLiked: false
    };
  }

  async addComment(data: InsertPostComment): Promise<PostComment> {
    const id = this.postCommentCounter++;

    const newComment: PostComment = {
      id,
      postId: data.postId,
      userId: data.userId, 
      text: data.text,
      author: data.author,
      createdAt: new Date()
    };

    this.postComments.set(id, newComment);
    return newComment;
  }

  async likePost(postId: number, userId: number): Promise<void> {
    const likeKey = `${userId}-${postId}`;
    const post = this.communityPosts.get(postId);

    if (!post) {
      throw new Error(`Post with id ${postId} not found`);
    }

    const existingLike = this.postLikes.get(likeKey);

    if (existingLike) {
      // Unlike the post
      this.postLikes.delete(likeKey);
      
      // Decrease likes count
      const updatedPost = {
        ...post,
        likes: Math.max(0, (post.likes || 0) - 1)
      };
      this.communityPosts.set(postId, updatedPost);
    } else {
      // Like the post
      const newLike: PostLike = {
        id: this.postLikes.size + 1,
        postId,
        userId,
        createdAt: new Date()
      };
      
      this.postLikes.set(likeKey, newLike);
      
      // Increase likes count
      const updatedPost = {
        ...post,
        likes: (post.likes || 0) + 1
      };
      this.communityPosts.set(postId, updatedPost);
    }
  }

  async getPostById(postId: number, userId?: number): Promise<CommunityPost | undefined> {
    const post = this.communityPosts.get(postId);
    
    if (!post) {
      return undefined;
    }
    
    const comments = Array.from(this.postComments.values())
      .filter(comment => comment.postId === postId)
      .sort((a, b) => {
        const dateA = a.createdAt instanceof Date ? a.createdAt.getTime() : new Date(a.createdAt || new Date()).getTime();
        const dateB = b.createdAt instanceof Date ? b.createdAt.getTime() : new Date(b.createdAt || new Date()).getTime();
        return dateB - dateA;
      });
    
    // Check if the user has liked this post
    let isLiked = false;
    if (userId) {
      isLiked = !!this.postLikes.get(`${userId}-${post.id}`);
    }
    
    return {
      ...post,
      comments,
      isLiked
    };
  }
  
  // Helper method to initialize sample data
  private initializeSampleData() {
    // Sample rituals
    const sampleRituals: Ritual[] = [
      { id: 1, title: "Morning Meditation", description: "Start your day with mindfulness", durationMinutes: 15, icon: "sunrise", xpReward: 50, timeOfDay: "morning" },
      { id: 2, title: "Gratitude Journal", description: "Write down three things you're grateful for", durationMinutes: 10, icon: "book-open", xpReward: 30, timeOfDay: "evening" },
      { id: 3, title: "Evening Yoga", description: "Wind down with gentle stretches", durationMinutes: 20, icon: "moon", xpReward: 70, timeOfDay: "evening" },
      { id: 4, title: "Affirmations", description: "Positive affirmations for self-growth", durationMinutes: 5, icon: "sun", xpReward: 25, timeOfDay: "morning" },
      { id: 5, title: "Pranayama Breathing", description: "Controlled breathing exercises", durationMinutes: 10, icon: "wind", xpReward: 40, timeOfDay: "any" }
    ];
    
    // Add sample rituals
    sampleRituals.forEach(ritual => {
      this.rituals.set(ritual.id, ritual);
    });
    
    // Sample courses
    const sampleCourses: Course[] = [
      { id: 1, title: "Introduction to Meditation", level: 1, description: "Learn the basics of meditation practice", imageUrl: "/images/meditation.jpg", totalLessons: 7, xpReward: 500 },
      { id: 2, title: "Chakra Healing", level: 2, description: "Deep dive into chakra balancing techniques", imageUrl: "/images/chakra.jpg", totalLessons: 10, xpReward: 800 },
      { id: 3, title: "Vedic Philosophy", level: 3, description: "Explore ancient wisdom and spiritual teachings", imageUrl: "/images/vedic.jpg", totalLessons: 12, xpReward: 1000 },
      { id: 4, title: "Yoga for Beginners", level: 1, description: "Gentle introduction to yoga poses and philosophy", imageUrl: "/images/yoga.jpg", totalLessons: 8, xpReward: 600 }
    ];
    
    // Add sample courses
    sampleCourses.forEach(course => {
      this.courses.set(course.id, course);
    });
    
    // Sample meditation tracks
    const sampleTracks: MeditationTrack[] = [
      { id: 1, title: "Root Chakra Healing", chakraType: "root", audioUrl: "/audio/root.mp3", durationSeconds: 600, frequency: "396 Hz", imageUrl: "/images/root-chakra.jpg" },
      { id: 2, title: "Sacral Chakra Balance", chakraType: "sacral", audioUrl: "/audio/sacral.mp3", durationSeconds: 720, frequency: "417 Hz", imageUrl: "/images/sacral-chakra.jpg" },
      { id: 3, title: "Solar Plexus Activation", chakraType: "solar", audioUrl: "/audio/solar.mp3", durationSeconds: 540, frequency: "528 Hz", imageUrl: "/images/solar-chakra.jpg" },
      { id: 4, title: "Heart Chakra Opening", chakraType: "heart", audioUrl: "/audio/heart.mp3", durationSeconds: 900, frequency: "639 Hz", imageUrl: "/images/heart-chakra.jpg" },
      { id: 5, title: "Throat Chakra Expression", chakraType: "throat", audioUrl: "/audio/throat.mp3", durationSeconds: 660, frequency: "741 Hz", imageUrl: "/images/throat-chakra.jpg" },
      { id: 6, title: "Third Eye Awakening", chakraType: "thirdEye", audioUrl: "/audio/third-eye.mp3", durationSeconds: 840, frequency: "852 Hz", imageUrl: "/images/third-eye-chakra.jpg" },
      { id: 7, title: "Crown Chakra Connection", chakraType: "crown", audioUrl: "/audio/crown.mp3", durationSeconds: 720, frequency: "963 Hz", imageUrl: "/images/crown-chakra.jpg" }
    ];
    
    // Add sample meditation tracks
    sampleTracks.forEach(track => {
      this.meditationTracks.set(track.id, track);
    });
  }
}

// Export the database storage implementation
export const storage = new DatabaseStorage();
