import admin from 'firebase-admin';

// Initialize Firebase Admin
// We need a service account for full admin functionality
// For development purposes, we can initialize with only project ID
const app = admin.initializeApp({
  projectId: process.env.VITE_FIREBASE_PROJECT_ID || 'trikala-academy',
});

// Export Firebase admin services
export const auth = admin.auth(app);
export const db = admin.firestore(app);
export const storage = admin.storage(app);