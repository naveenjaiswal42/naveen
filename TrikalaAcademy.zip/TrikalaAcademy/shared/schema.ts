import { pgTable, text, serial, integer, boolean, timestamp, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// User schema
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  phone: text("phone").notNull().unique(),
  name: text("name"),
  profileImage: text("profile_image"),
  level: integer("level").default(1),
  xp: integer("xp").default(0),
  meditation_streak: integer("meditation_streak").default(0),
  last_meditated_date: text("last_meditated_date"),
  daily_ritual_streak: integer("daily_ritual_streak").default(0),
  last_ritual_date: text("last_ritual_date"),
  lastMissionCompleted: text("last_mission_completed"), // YYYY-MM-DD format for daily mission tracking
  badges: text("badges").array(), // Array of badges earned by the user
  createdAt: timestamp("created_at").defaultNow(),
});

export const insertUserSchema = createInsertSchema(users).pick({
  phone: true,
  name: true,
  profileImage: true,
});

// Chakra schema
export const chakras = pgTable("chakras", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  crown: boolean("crown").default(false),
  thirdEye: boolean("third_eye").default(false),
  throat: boolean("throat").default(false),
  heart: boolean("heart").default(false),
  solar: boolean("solar").default(false),
  sacral: boolean("sacral").default(false),
  root: boolean("root").default(false),
  lastUpdated: timestamp("last_updated").defaultNow(),
});

export const insertChakraSchema = createInsertSchema(chakras).pick({
  userId: true,
  crown: true,
  thirdEye: true,
  throat: true,
  heart: true,
  solar: true,
  sacral: true,
  root: true,
});

// Ritual schema
export const rituals = pgTable("rituals", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  description: text("description"),
  durationMinutes: integer("duration_minutes"),
  icon: text("icon"),
  xpReward: integer("xp_reward"),
  timeOfDay: text("time_of_day"),
});

export const insertRitualSchema = createInsertSchema(rituals).pick({
  title: true,
  description: true,
  durationMinutes: true,
  icon: true,
  xpReward: true,
  timeOfDay: true,
});

// User Ritual Completion
export const userRituals = pgTable("user_rituals", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  ritualId: integer("ritual_id").notNull(),
  completedAt: timestamp("completed_at").defaultNow(),
  date: text("date").notNull(), // Format: YYYY-MM-DD
});

export const insertUserRitualSchema = createInsertSchema(userRituals).pick({
  userId: true,
  ritualId: true,
  date: true,
});

// Course schema
export const courses = pgTable("courses", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  description: text("description"),
  imageUrl: text("image_url"),
  level: integer("level").default(1),
  totalLessons: integer("total_lessons"),
  xpReward: integer("xp_reward"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at"),
});

export const insertCourseSchema = createInsertSchema(courses).pick({
  title: true,
  description: true,
  imageUrl: true,
  level: true,
  totalLessons: true,
  xpReward: true,
  createdAt: true,
  updatedAt: true,
});

// User Course Enrollment
export const userCourses = pgTable("user_courses", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  courseId: integer("course_id").notNull(),
  lessonsCompleted: integer("lessons_completed").default(0),
  completionPercentage: integer("completion_percentage").default(0),
  enrolledAt: timestamp("enrolled_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const insertUserCourseSchema = createInsertSchema(userCourses).pick({
  userId: true,
  courseId: true,
});

// Meditation Music
export const meditationTracks = pgTable("meditation_tracks", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  chakraType: text("chakra_type"), // root, sacral, solar, etc.
  audioUrl: text("audio_url").notNull(),
  durationSeconds: integer("duration_seconds"),
  imageUrl: text("image_url"),
  frequency: text("frequency"), // Hz or specific frequency information
});

export const insertMeditationTrackSchema = createInsertSchema(meditationTracks).pick({
  title: true,
  chakraType: true,
  audioUrl: true,
  durationSeconds: true,
  imageUrl: true,
  frequency: true,
});

// Goals schema
export const goals = pgTable("goals", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id),
  text: text("text").notNull(),
  completed: boolean("completed").default(false),
  category: text("category").notNull(),
  targetDate: text("target_date"),
  createdAt: text("created_at").notNull(),
  updatedAt: text("updated_at"),
});

export const insertGoalSchema = createInsertSchema(goals).pick({
  userId: true,
  text: true,
  completed: true,
  category: true,
  targetDate: true,
  createdAt: true,
});

// Types
export type User = typeof users.$inferSelect;
export type InsertUser = z.infer<typeof insertUserSchema>;

export type Chakra = typeof chakras.$inferSelect;
export type InsertChakra = z.infer<typeof insertChakraSchema>;

export type Ritual = typeof rituals.$inferSelect;
export type InsertRitual = z.infer<typeof insertRitualSchema>;

export type UserRitual = typeof userRituals.$inferSelect;
export type InsertUserRitual = z.infer<typeof insertUserRitualSchema>;

export type Course = typeof courses.$inferSelect;
export type InsertCourse = z.infer<typeof insertCourseSchema>;

export type UserCourse = typeof userCourses.$inferSelect;
export type InsertUserCourse = z.infer<typeof insertUserCourseSchema>;

export type MeditationTrack = typeof meditationTracks.$inferSelect;
export type InsertMeditationTrack = z.infer<typeof insertMeditationTrackSchema>;

export type Goal = typeof goals.$inferSelect;
export type InsertGoal = z.infer<typeof insertGoalSchema>;

// Journal entries schema
export const journalEntries = pgTable("journal_entries", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id),
  content: text("content").notNull(),
  category: text("category").notNull(), // e.g., "gratitude", "insight", "reflection", "dream"
  mood: text("mood"), // Optional mood tracking
  createdAt: timestamp("created_at").defaultNow(),
});

export const insertJournalEntrySchema = createInsertSchema(journalEntries).pick({
  userId: true,
  content: true,
  category: true,
  mood: true,
});

export type JournalEntry = typeof journalEntries.$inferSelect;
export type InsertJournalEntry = z.infer<typeof insertJournalEntrySchema>;

// Mood Tracker schema
export const moodEntries = pgTable("mood_entries", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id),
  mood: text("mood").notNull(),
  reflection: text("reflection"),
  date: text("date").notNull(), // Format: YYYY-MM-DD
  createdAt: timestamp("created_at").defaultNow(),
});

export const insertMoodEntrySchema = createInsertSchema(moodEntries).pick({
  userId: true,
  mood: true,
  reflection: true,
  date: true,
});

export type MoodEntry = typeof moodEntries.$inferSelect;
export type InsertMoodEntry = z.infer<typeof insertMoodEntrySchema>;

// Community Posts schema
export const communityPosts = pgTable("community_posts", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id),
  text: text("text").notNull(),
  author: text("author").notNull(),
  likes: integer("likes").default(0),
  createdAt: timestamp("created_at").defaultNow(),
});

export const insertCommunityPostSchema = createInsertSchema(communityPosts).pick({
  userId: true,
  text: true,
  author: true,
});

// Comments schema
export const postComments = pgTable("post_comments", {
  id: serial("id").primaryKey(),
  postId: integer("post_id").notNull().references(() => communityPosts.id),
  userId: integer("user_id").notNull().references(() => users.id),
  text: text("text").notNull(),
  author: text("author").notNull(),
  createdAt: timestamp("created_at").defaultNow(),
});

export const insertPostCommentSchema = createInsertSchema(postComments).pick({
  postId: true,
  userId: true,
  text: true,
  author: true,
});

// Post Likes schema
export const postLikes = pgTable("post_likes", {
  id: serial("id").primaryKey(),
  postId: integer("post_id").notNull().references(() => communityPosts.id),
  userId: integer("user_id").notNull().references(() => users.id),
  createdAt: timestamp("created_at").defaultNow(),
});

export const insertPostLikeSchema = createInsertSchema(postLikes).pick({
  postId: true,
  userId: true,
});

export type CommunityPost = typeof communityPosts.$inferSelect;
export type InsertCommunityPost = z.infer<typeof insertCommunityPostSchema>;

export type PostComment = typeof postComments.$inferSelect;
export type InsertPostComment = z.infer<typeof insertPostCommentSchema>;

export type PostLike = typeof postLikes.$inferSelect;
export type InsertPostLike = z.infer<typeof insertPostLikeSchema>;
