// Firebase Cloud Messaging Service Worker for Trikala Academy

// Import and configure the Firebase SDK
importScripts('https://www.gstatic.com/firebasejs/9.0.0/firebase-app-compat.js');
importScripts('https://www.gstatic.com/firebasejs/9.0.0/firebase-messaging-compat.js');

// Firebase configuration - must be in service worker context
firebase.initializeApp({
  apiKey: 'VITE_FIREBASE_API_KEY',
  authDomain: 'VITE_FIREBASE_PROJECT_ID.firebaseapp.com',
  projectId: 'VITE_FIREBASE_PROJECT_ID',
  storageBucket: 'VITE_FIREBASE_PROJECT_ID.appspot.com',
  messagingSenderId: 'VITE_FIREBASE_MESSAGING_SENDER_ID',
  appId: 'VITE_FIREBASE_APP_ID',
});

// Get an instance of Firebase Messaging
const messaging = firebase.messaging();

// Background message handler
messaging.onBackgroundMessage((payload) => {
  console.log('[firebase-messaging-sw.js] Received background message:', payload);
  
  // Customize notification data
  const notificationTitle = payload.notification.title || 'Trikala Academy Notification';
  const notificationOptions = {
    body: payload.notification.body || 'New notification from Trikala Academy',
    icon: '/assets/trikala-logo.png',
    badge: '/assets/notification-badge.png',
    vibrate: [200, 100, 200],
    tag: 'trikala-notification',
    // Custom data that can be used when notification is clicked
    data: payload.data,
  };

  // Show the notification
  return self.registration.showNotification(notificationTitle, notificationOptions);
});

// Handle notification click (open the app)
self.addEventListener('notificationclick', (event) => {
  console.log('[firebase-messaging-sw.js] Notification clicked:', event);
  
  event.notification.close();
  
  // Get the notification data
  const data = event.notification.data;
  
  // Handle click based on the notification data
  // This will open the app and navigate to a specific page if needed
  let url = '/';
  
  if (data && data.url) {
    url = data.url;
  }
  
  // Open or focus the client
  event.waitUntil(
    clients.matchAll({ type: 'window', includeUncontrolled: true })
      .then((clientList) => {
        // If a window is already open, focus it
        for (const client of clientList) {
          if (client.url.includes(self.location.origin) && 'focus' in client) {
            client.postMessage({ type: 'NOTIFICATION_CLICKED', url });
            return client.focus();
          }
        }
        
        // Otherwise open a new window
        if (clients.openWindow) {
          return clients.openWindow(url);
        }
      })
  );
});